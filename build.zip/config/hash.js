import { defineConfig, drivers } from '@adonisjs/core/hash';
const hashConfig = defineConfig({
    default: 'bcrypt',
    list: {
        bcrypt: drivers.bcrypt({
            rounds: 10,
            saltSize: 16,
            version: 97,
        }),
    },
});
export default hashConfig;
//# sourceMappingURL=hash.js.map