export class BaseJob {
}
//# sourceMappingURL=job.js.map