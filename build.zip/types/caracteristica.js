export {};
//# sourceMappingURL=caracteristica.js.map