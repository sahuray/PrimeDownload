export {};
//# sourceMappingURL=produto.js.map