export {};
//# sourceMappingURL=comanda.js.map