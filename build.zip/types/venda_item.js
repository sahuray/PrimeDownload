export {};
//# sourceMappingURL=venda_item.js.map