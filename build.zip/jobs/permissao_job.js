import { BaseJob } from '#types/job';
import HealthCheckJob from './health_check_job.js';
import PermissaoService from '#services/synchrony/permissao';
import PermissaoUsuarioService from '#services/synchrony/permissao_usuario';
export default class PermissionJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const permissaoService = new PermissaoService();
        const permissaoUsuarioService = new PermissaoUsuarioService();
        await permissaoService.syncPermission();
        await permissaoUsuarioService.syncPermissionUser();
    }
}
//# sourceMappingURL=permissao_job.js.map