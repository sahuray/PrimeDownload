import { BaseJob } from '#types/job';
import SetorService from '#services/synchrony/setor';
import HealthCheckJob from './health_check_job.js';
export default class SetorJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const setorService = new SetorService();
        await setorService.syncSetor();
    }
}
//# sourceMappingURL=setor_job.js.map