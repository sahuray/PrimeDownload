import { BaseJob } from '#types/job';
import UploadService from '#services/synchrony/upload';
import HealthCheckJob from './health_check_job.js';
export default class UploadJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const uploadService = new UploadService();
        await uploadService.syncUpload();
    }
}
//# sourceMappingURL=upload_job.js.map