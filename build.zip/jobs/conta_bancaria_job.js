import { BaseJob } from '#types/job';
import BandeiraService from '#services/synchrony/bandeira';
import BancoService from '#services/synchrony/banco';
import ContaBancariaService from '#services/synchrony/conta_bancaria';
import HealthCheckJob from './health_check_job.js';
export default class ContaBancariaJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const bandeiraService = new BandeiraService();
        const bancoService = new BancoService();
        const contaBancariaService = new ContaBancariaService();
        await bandeiraService.syncFlags();
        await bancoService.syncBanks();
        await contaBancariaService.syncBankAccount();
    }
}
//# sourceMappingURL=conta_bancaria_job.js.map