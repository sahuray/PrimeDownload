import { BaseJob } from '#types/job';
import TaxaDeEntregaService from '#services/synchrony/taxa_de_entrega';
import HealthCheckJob from './health_check_job.js';
export default class DeliveryFeeJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const taxaDeEntregaService = new TaxaDeEntregaService();
        await taxaDeEntregaService.syncDeliveryFee();
    }
}
//# sourceMappingURL=taxa_de_entrega_job.js.map