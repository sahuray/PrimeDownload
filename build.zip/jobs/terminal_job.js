import { BaseJob } from '#types/job';
import TerminalService from '#services/synchrony/terminal';
import HealthCheckJob from './health_check_job.js';
export default class TerminalJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const terminalService = new TerminalService();
        await terminalService.syncTerminals();
    }
}
//# sourceMappingURL=terminal_job.js.map