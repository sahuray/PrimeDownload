import { BaseJob } from '#types/job';
import HealthCheckJob from './health_check_job.js';
import PermissaoUsuarioService from '#services/synchrony/permissao_usuario';
export default class PermissionUserJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const permissaoUsuarioService = new PermissaoUsuarioService();
        await permissaoUsuarioService.syncPermissionUser();
    }
}
//# sourceMappingURL=permissao_usuario_job.js.map