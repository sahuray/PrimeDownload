import { BaseJob } from '#types/job';
import HealthCheckJob from './health_check_job.js';
import FuncionarioUsuarioService from '#services/synchrony/funcionario_usuario';
export default class FuncionarioUsuarioJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const funcionarioUsuarioService = new FuncionarioUsuarioService();
        await funcionarioUsuarioService.getUsers();
    }
}
//# sourceMappingURL=funcionario_usuario_job.js.map