import { BaseJob } from '#types/job';
import ProdutoService from '#services/synchrony/produto';
import ProdutoCompativelService from '#services/synchrony/produto_compativel';
import ProdutoInformacaoNutricionalService from '#services/synchrony/produto_informacao_nutricional';
import UnidadeService from '#services/synchrony/unidade';
import MarcaService from '#services/synchrony/marca';
import ProdutoEmpresaService from '#services/synchrony/produto_empresa';
import ProdutoEstoqueService from '#services/synchrony/produto_estoque';
import ProdutoLoteExpiracaoService from '#services/synchrony/produto_lote_expiracao';
import ProdutoPrecoService from '#services/synchrony/produto_preco';
import ProdutoNumeroSerieService from '#services/synchrony/produto_numero_de_serie';
import ProdutoCompostoService from '#services/synchrony/produto_composto';
import ProdutoCaracteristicaService from '#services/synchrony/produto_caracteristica';
import HealthCheckJob from './health_check_job.js';
export default class ProdutoJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const unidadeService = new UnidadeService();
        const marcaService = new MarcaService();
        const produtoInformacaoNutricionalService = new ProdutoInformacaoNutricionalService();
        const produtoService = new ProdutoService();
        const produtoCompativelService = new ProdutoCompativelService();
        const produtoEmpresaService = new ProdutoEmpresaService();
        const produtoEstoqueService = new ProdutoEstoqueService();
        const produtoLoteExpiracaoService = new ProdutoLoteExpiracaoService();
        const produtoPrecoService = new ProdutoPrecoService();
        const produtoNumeroSerieService = new ProdutoNumeroSerieService();
        const produtoCompostoService = new ProdutoCompostoService();
        const produtoCaracteristicaService = new ProdutoCaracteristicaService();
        await unidadeService.syncUnit();
        await marcaService.syncBrand();
        await produtoInformacaoNutricionalService.syncInformationNutritional();
        await produtoService.syncProduct();
        await produtoCompativelService.syncProdutoCompativel();
        await produtoEmpresaService.syncProdutoEmpresa();
        await produtoEstoqueService.syncProdutoEstoque();
        await produtoLoteExpiracaoService.syncProdutoLoteExpiracao();
        await produtoPrecoService.syncProductPrice();
        await produtoNumeroSerieService.syncProdutoNumeroSerie();
        await produtoCompostoService.syncProdutoComposto();
        await produtoCaracteristicaService.syncProductCharacteristic();
    }
}
//# sourceMappingURL=produto_job.js.map