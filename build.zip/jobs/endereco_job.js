import { BaseJob } from '#types/job';
import EnderecoService from '#services/synchrony/endereco';
import HealthCheckJob from './health_check_job.js';
export default class AddressJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const addressService = new EnderecoService();
        await addressService.syncAddresses();
    }
}
//# sourceMappingURL=endereco_job.js.map