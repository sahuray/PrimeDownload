import { BaseJob } from '#types/job';
import HealthCheckJob from './health_check_job.js';
import OperationMovementTypeService from '#services/synchrony/operacao_movimento_tipo';
export default class OperationMovementTypeJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const operationMovementTypeService = new OperationMovementTypeService();
        await operationMovementTypeService.syncOperationMovementType();
    }
}
//# sourceMappingURL=operacao_movimento_tipo.js.map