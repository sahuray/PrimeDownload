import { BaseJob } from '#types/job';
import ComandaService from '#services/synchrony/comanda';
import HealthCheckJob from './health_check_job.js';
export default class ComandaJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const comandaService = new ComandaService();
        await comandaService.syncComanda();
    }
}
//# sourceMappingURL=comanda_job.js.map