import { BaseJob } from '#types/job';
import ImagemService from '#services/synchrony/imagem';
import HealthCheckJob from './health_check_job.js';
export default class ImagemJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const imagemService = new ImagemService();
        await imagemService.syncImagem();
    }
}
//# sourceMappingURL=imagem_job.js.map