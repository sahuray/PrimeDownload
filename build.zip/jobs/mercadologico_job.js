import { BaseJob } from '#types/job';
import ProdCategoriaSetorService from '#services/synchrony/produto_categoria_setor';
import ProdCategoriaGrupoService from '#services/synchrony/produto_categoria_grupo';
import ProdCategoriaSubGrupoService from '#services/synchrony/produto_categoria_sub_grupo';
import ProdCategoriaLinhaService from '#services/synchrony/produto_categoria_linha';
import HealthCheckJob from './health_check_job.js';
export default class MercadoLogicoJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const prodCategoriaSetorService = new ProdCategoriaSetorService();
        const prodCategoriaGrupoService = new ProdCategoriaGrupoService();
        const prodCategoriaSubGrupoService = new ProdCategoriaSubGrupoService();
        const prodCategoriaLinhaService = new ProdCategoriaLinhaService();
        await prodCategoriaSetorService.syncProdCategorySector();
        await prodCategoriaGrupoService.syncProdCategoryGroup();
        await prodCategoriaSubGrupoService.syncProdCategorySubGroup();
        await prodCategoriaLinhaService.syncProdCategoryLine();
    }
}
//# sourceMappingURL=mercadologico_job.js.map