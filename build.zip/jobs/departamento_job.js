import { BaseJob } from '#types/job';
import DepartamentService from '#services/synchrony/departamento';
import HealthCheckJob from './health_check_job.js';
export default class DepartamentJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const departamentService = new DepartamentService();
        await departamentService.syncDepartament();
    }
}
//# sourceMappingURL=departamento_job.js.map