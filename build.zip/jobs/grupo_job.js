import { BaseJob } from '#types/job';
import GrupoService from '#services/synchrony/group';
import HealthCheckJob from './health_check_job.js';
export default class GrupoJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const grupoService = new GrupoService();
        await grupoService.syncGroups();
    }
}
//# sourceMappingURL=grupo_job.js.map