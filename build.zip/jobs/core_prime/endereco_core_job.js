import { BaseJob } from '#types/job';
import AddressCoreService from '#services/synchrony_core/endereco';
import HealthCheckJob from '#jobs/health_check_job';
export default class AddressCoreJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const addressCoreService = new AddressCoreService();
        await addressCoreService.syncCore();
    }
}
//# sourceMappingURL=endereco_core_job.js.map