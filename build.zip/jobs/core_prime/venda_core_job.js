import { BaseJob } from '#types/job';
import SaleCoreService from '#services/synchrony_core/venda';
import SaleClientCoreService from '#services/synchrony_core/venda_cliente';
import SaleItemCoreService from '#services/synchrony_core/venda_item';
import SaleSubItemCoreService from '#services/synchrony_core/venda_sub_item';
import SaleNfceCoreService from '#services/synchrony_core/venda_nfce';
import SalePaymentMethodCoreService from '#services/synchrony_core/venda_forma_de_pagamento';
import SaleTermPaymentCoreService from '#services/synchrony_core/venda_pagamento_a_prazo';
import SaleItemCharacteristicCoreService from '#services/synchrony_core/venda_item_caracteristica';
import SaleControlInventoryCoreService from '#services/synchrony_core/venda_controle_estoque';
import HealthCheckJob from '#jobs/health_check_job';
export default class SaleCoreJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const saleCoreService = new SaleCoreService();
        const saleClientCoreService = new SaleClientCoreService();
        const saleItemCoreService = new SaleItemCoreService();
        const saleSubItemCoreService = new SaleSubItemCoreService();
        const saleNfceCoreService = new SaleNfceCoreService();
        const salePaymentMethodCoreService = new SalePaymentMethodCoreService();
        const saleTermPaymentCoreService = new SaleTermPaymentCoreService();
        const saleItemCharacteristicCoreService = new SaleItemCharacteristicCoreService();
        const saleControlInventoryCoreService = new SaleControlInventoryCoreService();
        await saleCoreService.syncCore();
        await saleClientCoreService.syncCore();
        await saleNfceCoreService.syncCore();
        await salePaymentMethodCoreService.syncCore();
        await saleTermPaymentCoreService.syncCore();
        await saleItemCoreService.syncCore();
        await saleSubItemCoreService.syncCore();
        await saleItemCharacteristicCoreService.syncCore();
        await saleControlInventoryCoreService.syncCore();
    }
}
//# sourceMappingURL=venda_core_job.js.map