import { BaseJob } from '#types/job';
import HealthCheckJob from '#jobs/health_check_job';
import MovementOpearationCoreService from '#services/synchrony_core/operacao_movimento';
import MovementOpearationItemCoreService from '#services/synchrony_core/operacao_movimento_item';
export default class MovementOperationCoreJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const movementOpearationCoreService = new MovementOpearationCoreService();
        const movementOpearationItemCoreService = new MovementOpearationItemCoreService();
        await movementOpearationCoreService.syncCore();
        await movementOpearationItemCoreService.syncCore();
    }
}
//# sourceMappingURL=movimento_operacao_job.js.map