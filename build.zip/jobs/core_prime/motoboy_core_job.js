import { BaseJob } from '#types/job';
import HealthCheckJob from '#jobs/health_check_job';
import MotoboyCoreService from '#services/synchrony_core/motoboy';
export default class MovementCashDeskCoreJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const motoboyCoreService = new MotoboyCoreService();
        await motoboyCoreService.syncCore();
    }
}
//# sourceMappingURL=motoboy_core_job.js.map