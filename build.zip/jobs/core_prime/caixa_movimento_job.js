import { BaseJob } from '#types/job';
import HealthCheckJob from '#jobs/health_check_job';
import MovementCashDeskCoreService from '#services/synchrony_core/caixa_movimento';
import CloseCashDeskCoreService from '#services/synchrony_core/caixa_fechamento';
export default class MovementCashDeskCoreJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const movementCashDeskCoreService = new MovementCashDeskCoreService();
        const closeCashDeskCoreService = new CloseCashDeskCoreService();
        await movementCashDeskCoreService.syncCore();
        await closeCashDeskCoreService.syncCore();
    }
}
//# sourceMappingURL=caixa_movimento_job.js.map