import { BaseJob } from '#types/job';
import ContactCoreService from '#services/synchrony_core/contato';
import HealthCheckJob from '#jobs/health_check_job';
export default class ContactCoreJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const contactCoreService = new ContactCoreService();
        await contactCoreService.syncCore();
    }
}
//# sourceMappingURL=contato_core_job.js.map