import { BaseJob } from '#types/job';
import EmpresaCoreService from '#services/synchrony_core/empresa';
import HealthCheckJob from '#jobs/health_check_job';
export default class EmpresaCoreJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const empresaCoreService = new EmpresaCoreService();
        await empresaCoreService.syncCore();
    }
}
//# sourceMappingURL=empresa_core_job.js.map