import { BaseJob } from '#types/job';
import EmpresaComandaConfigService from '#services/synchrony/empresa_comanda_config';
import EmpresaPdvConfigService from '#services/synchrony/empresa_pdv_config';
import EmpresaPrathosConfigService from '#services/synchrony/empresa_prathos_config';
import EmpresaDeliveryConfigService from '#services/synchrony/empresa_delivery_config';
import HealthCheckJob from './health_check_job.js';
export default class CompanySettingJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const empresaComandaConfigService = new EmpresaComandaConfigService();
        const empresaPdvConfigService = new EmpresaPdvConfigService();
        const empresaPrathosConfigService = new EmpresaPrathosConfigService();
        const empresaDeliveryConfigService = new EmpresaDeliveryConfigService();
        await empresaComandaConfigService.syncCompanyCommandSetting();
        await empresaPdvConfigService.syncCompanyPdvSetting();
        await empresaPrathosConfigService.syncCompanyPrathosSetting();
        await empresaDeliveryConfigService.syncCompanyDeliverySetting();
    }
}
//# sourceMappingURL=empresa_configs_job.js.map