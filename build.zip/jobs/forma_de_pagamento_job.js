import { BaseJob } from '#types/job';
import FormaDePagamentoService from '#services/synchrony/forma_de_pagamento';
import FormaDePagamentoCondicaoService from '#services/synchrony/forma_de_pagamento_condicao';
import FormaDePagamentoTipoService from '#services/synchrony/forma_de_pagamento_tipo';
import HealthCheckJob from './health_check_job.js';
export default class FormaDePagamentoJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const formaDePagamentoTipoService = new FormaDePagamentoTipoService();
        const formaDePagamentoCondicaoService = new FormaDePagamentoCondicaoService();
        const formaDePagamentoService = new FormaDePagamentoService();
        await formaDePagamentoTipoService.syncPaymentsMethodType();
        await formaDePagamentoCondicaoService.syncPaymentsMethodCondition();
        await formaDePagamentoService.syncPaymentsMethod();
    }
}
//# sourceMappingURL=forma_de_pagamento_job.js.map