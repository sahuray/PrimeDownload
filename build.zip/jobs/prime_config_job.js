import { BaseJob } from '#types/job';
import PrimeConfigService from '#services/synchrony/prime_config';
import HealthCheckJob from './health_check_job.js';
export default class PrimeConfigJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const primeConfigService = new PrimeConfigService();
        await primeConfigService.syncPrimeConfig();
    }
}
//# sourceMappingURL=prime_config_job.js.map