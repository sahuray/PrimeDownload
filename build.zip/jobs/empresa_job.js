import { BaseJob } from '#types/job';
import EmpresaService from '#services/synchrony/empresa';
import HealthCheckJob from './health_check_job.js';
export default class EmpresaJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const empresaService = new EmpresaService();
        await empresaService.syncCompanies();
    }
}
//# sourceMappingURL=empresa_job.js.map