import { BaseJob } from '#types/job';
import CaixaMovimentoService from '#services/synchrony/caixa_movimento';
import HealthCheckJob from './health_check_job.js';
export default class CaixaMovimentoJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const caixaMovimentoService = new CaixaMovimentoService();
        await caixaMovimentoService.syncCaixaMovimento();
    }
}
//# sourceMappingURL=caixa_movimento_job.js.map