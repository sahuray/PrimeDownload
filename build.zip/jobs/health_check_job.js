import { BaseJob } from '#types/job';
import HealthCheckService from '#services/health_check_service';
export default class HealthCheckJob extends BaseJob {
    async run() {
        const healthCheckService = new HealthCheckService();
        const isOnline = await healthCheckService.verifyConnection();
        return isOnline;
    }
}
//# sourceMappingURL=health_check_job.js.map