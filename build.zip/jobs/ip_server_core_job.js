import { BaseJob } from '#types/job';
import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
import { networkInterfaces } from 'node:os';
import IpServerCoreService from '#services/synchrony_core/ip_server_core';
export default class IpServerCoreJob extends BaseJob {
    getLocalIpAddress() {
        const nets = networkInterfaces();
        const ethernetInterface = nets['Ethernet'];
        if (ethernetInterface) {
            for (const net of ethernetInterface) {
                if (net.family === 'IPv4' && !net.internal) {
                    return net.address;
                }
            }
        }
        const wifiInterface = nets['Wi-Fi'];
        if (wifiInterface) {
            for (const net of wifiInterface) {
                if (net.family === 'IPv4' && !net.internal) {
                    return net.address;
                }
            }
        }
        return '';
    }
    async run() {
        try {
            const ipServerCoreService = new IpServerCoreService();
            const ipAddress = this.getLocalIpAddress();
            if (ipAddress) {
                console.log('--------------------------------');
                console.log('Servidor conectado no IP:', ipAddress);
                console.log('--------------------------------');
                await EmpresaPdvConfig.query().whereNull('deleted_at').update({ ip_server_core: ipAddress });
                await ipServerCoreService.syncCore();
            }
            else {
                console.log('Nenhum IP válido encontrado, continuando execução normalmente...');
            }
        }
        catch (error) {
            console.log('Erro ao atualizar IP do servidor, continuando execução normalmente...');
            console.error(error);
        }
    }
}
//# sourceMappingURL=ip_server_core_job.js.map