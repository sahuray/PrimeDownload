import { BaseJob } from '#types/job';
import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
import { networkInterfaces } from 'node:os';
export default class IpServerCoreJob extends BaseJob {
    getLocalIpAddress() {
        const nets = networkInterfaces();
        console.log('\n=== TODAS AS INTERFACES E IPs ===');
        Object.entries(nets).forEach(([interfaceName, interfaces]) => {
            console.log(`\nInterface: ${interfaceName}`);
            interfaces?.forEach((net) => {
                console.log({
                    address: net.address,
                    internal: net.internal,
                    netmask: net.netmask,
                    interface: interfaceName,
                });
            });
        });
        console.log('================================\n');
        const ethernetInterface = nets['Ethernet'];
        if (ethernetInterface) {
            for (const net of ethernetInterface) {
                if (net.family === 'IPv4' && !net.internal) {
                    console.log('Usando IP da Ethernet:', net.address);
                    return net.address;
                }
            }
        }
        const wifiInterface = nets['Wi-Fi'];
        if (wifiInterface) {
            for (const net of wifiInterface) {
                if (net.family === 'IPv4' && !net.internal) {
                    console.log('Usando IP do Wi-Fi:', net.address);
                    return net.address;
                }
            }
        }
        console.log('Nenhum IP válido encontrado em Ethernet ou Wi-Fi');
        return '';
    }
    async run() {
        try {
            const ipAddress = this.getLocalIpAddress();
            console.log('--------------------------------');
            console.log('IP do servidor:', ipAddress);
            console.log('--------------------------------');
            if (ipAddress) {
                await EmpresaPdvConfig.query().whereNull('deleted_at').update({ ip_server_core: ipAddress });
            }
            else {
                console.log('Nenhum IP válido encontrado, continuando execução normalmente...');
            }
        }
        catch (error) {
            console.log('Erro ao atualizar IP do servidor, continuando execução normalmente...');
            console.error(error);
        }
    }
}
//# sourceMappingURL=ip_server_core_job.js.map