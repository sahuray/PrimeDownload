import { BaseJob } from '#types/job';
import MunicipioService from '#services/synchrony/municipio';
import HealthCheckJob from './health_check_job.js';
export default class MunicipioJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const municipioService = new MunicipioService();
        await municipioService.syncMunicipality();
    }
}
//# sourceMappingURL=municipio_job.js.map