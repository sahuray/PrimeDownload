import { BaseJob } from '#types/job';
import HealthCheckJob from './health_check_job.js';
import VendaFormaDePagamentoService from '#services/synchrony/venda_forma_de_pagamento';
import VendaPagamentoAPrazoService from '#services/synchrony/venda_pagamento_a_prazo';
import VendaItemService from '#services/synchrony/venda_item';
import VendaSubItemService from '#services/synchrony/venda_sub_item';
import VendaNfceService from '#services/synchrony/venda_nfce';
import VendaService from '#services/synchrony/venda';
export default class VendaJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const vendaFormaDePagamentoService = new VendaFormaDePagamentoService();
        const vendaPagamentoAPrazoService = new VendaPagamentoAPrazoService();
        const vendaItemService = new VendaItemService();
        const vendaSubItemService = new VendaSubItemService();
        const vendaNfceService = new VendaNfceService();
        const vendaService = new VendaService();
        await vendaService.syncSales();
        await vendaNfceService.syncSaleNfce();
        await vendaItemService.syncSaleItems();
        await vendaSubItemService.syncSaleSubItems();
        await vendaFormaDePagamentoService.syncSaleMethodPayments();
        await vendaPagamentoAPrazoService.syncSaleTermPayments();
    }
}
//# sourceMappingURL=venda_job.js.map