import { BaseJob } from '#types/job';
import MesaService from '#services/synchrony/mesa';
import HealthCheckJob from './health_check_job.js';
export default class MesaJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const mesaService = new MesaService();
        await mesaService.syncMesa();
    }
}
//# sourceMappingURL=mesa_job.js.map