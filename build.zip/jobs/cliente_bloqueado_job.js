import { BaseJob } from '#types/job';
import HealthCheckJob from './health_check_job.js';
import ClienteBloqueadoService from '#services/synchrony/cliente_bloqueado';
export default class ClienteBloqueadoJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const clienteBloqueadoService = new ClienteBloqueadoService();
        await clienteBloqueadoService.syncClienteBloqueado();
    }
}
//# sourceMappingURL=cliente_bloqueado_job.js.map