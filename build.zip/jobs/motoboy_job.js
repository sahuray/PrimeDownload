import { BaseJob } from '#types/job';
import MotoboyService from '#services/synchrony/motoboy';
import HealthCheckJob from './health_check_job.js';
export default class MotoboyJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const motoboyService = new MotoboyService();
        await motoboyService.syncMotoboy();
    }
}
//# sourceMappingURL=motoboy_job.js.map