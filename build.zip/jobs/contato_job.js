import { BaseJob } from '#types/job';
import ContatoService from '#services/synchrony/contato';
import HealthCheckJob from './health_check_job.js';
export default class ContactJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const contatoService = new ContatoService();
        await contatoService.syncContact();
    }
}
//# sourceMappingURL=contato_job.js.map