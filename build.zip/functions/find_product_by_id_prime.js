import PrimeProduct from '#models/prime_produto';
async function findProductByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findProduct = await PrimeProduct.findBy('id_prime', idPrime);
    return findProduct ? findProduct.id : null;
}
export default findProductByIdPrime;
//# sourceMappingURL=find_product_by_id_prime.js.map