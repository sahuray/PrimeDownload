import Permissao from '#models/prime_permissao';
async function findPermissionByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findPermission = await Permissao.findBy('id_prime', idPrime);
    return findPermission ? findPermission.id : null;
}
export default findPermissionByIdPrime;
//# sourceMappingURL=find_permission_by_id_prime.js.map