import CaixaMovimento from '#models/caixa_movimento';
async function findMovementCashDeskByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findMovementCashDesk = await CaixaMovimento.findBy('id_prime', idPrime);
    return findMovementCashDesk ? findMovementCashDesk.idcaixamovimento : null;
}
export default findMovementCashDeskByIdPrime;
//# sourceMappingURL=find_movement_cash_desk_by_id_prime.js.map