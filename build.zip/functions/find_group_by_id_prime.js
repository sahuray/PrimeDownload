import Grupo from '#models/grupo';
async function findGroupByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const finGroup = await Grupo.findBy('id_prime', idPrime);
    return finGroup ? finGroup.id : null;
}
export default findGroupByIdPrime;
//# sourceMappingURL=find_group_by_id_prime.js.map