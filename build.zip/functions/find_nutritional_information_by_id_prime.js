import NutritionalInformation from '#models/prime_produto_informacao_nutricional';
async function findNutritionalInformationByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findNutritionalInformation = await NutritionalInformation.findBy('id_prime', idPrime);
    return findNutritionalInformation ? findNutritionalInformation.id : null;
}
export default findNutritionalInformationByIdPrime;
//# sourceMappingURL=find_nutritional_information_by_id_prime.js.map