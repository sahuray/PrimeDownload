import PrimeProdutoCategoriaLinha from '#models/prime_produto_categoria_linha';
async function findCategoryLineByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findCategoryLine = await PrimeProdutoCategoriaLinha.findBy('id_prime', idPrime);
    return findCategoryLine ? findCategoryLine.id : null;
}
export default findCategoryLineByIdPrime;
//# sourceMappingURL=find_category_line_by_id_prime.js.map