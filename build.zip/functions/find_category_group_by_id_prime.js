import PrimeProdutoCategoriaGrupo from '#models/prime_produto_categoria_grupo';
async function findCategoryGroupByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findCategoryGroup = await PrimeProdutoCategoriaGrupo.findBy('id_prime', idPrime);
    return findCategoryGroup ? findCategoryGroup.id : null;
}
export default findCategoryGroupByIdPrime;
//# sourceMappingURL=find_category_group_by_id_prime.js.map