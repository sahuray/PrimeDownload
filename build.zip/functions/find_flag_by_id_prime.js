import Bandeira from '#models/bandeira';
async function findFlagByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findFlag = await Bandeira.findBy('id_prime', idPrime);
    return findFlag ? findFlag.id : null;
}
export default findFlagByIdPrime;
//# sourceMappingURL=find_flag_by_id_prime.js.map