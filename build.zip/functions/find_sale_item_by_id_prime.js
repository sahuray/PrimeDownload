import VendaItem from '#models/venda_item';
async function findSaleItemByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const finSaleItem = await VendaItem.findBy('id_prime', idPrime);
    return finSaleItem ? finSaleItem.id : null;
}
export default findSaleItemByIdPrime;
//# sourceMappingURL=find_sale_item_by_id_prime.js.map