import Unidade from '#models/prime_produto_unidade';
async function findUnitByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findUnit = await Unidade.findBy('id_prime', idPrime);
    return findUnit ? findUnit.id : null;
}
export default findUnitByIdPrime;
//# sourceMappingURL=find_unit_by_id_prime.js.map