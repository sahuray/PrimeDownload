import Departamento from '#models/departamento';
async function findDepartamentByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findDepartament = await Departamento.findBy('id_prime', idPrime);
    return findDepartament ? findDepartament.id : null;
}
export default findDepartamentByIdPrime;
//# sourceMappingURL=find_departament_by_id_prime.js.map