import Empresa from '#models/empresa';
async function findCompanyByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findCompany = await Empresa.findBy('id_prime_empresa', idPrime);
    return findCompany ? findCompany.id : null;
}
export default findCompanyByIdPrime;
//# sourceMappingURL=find_company_by_id_prime.js.map