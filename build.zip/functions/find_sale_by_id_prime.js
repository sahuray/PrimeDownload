import Venda from '#models/venda';
async function findSaleByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const finSale = await Venda.findBy('id_prime', idPrime);
    return finSale ? finSale.id : null;
}
export default findSaleByIdPrime;
//# sourceMappingURL=find_sale_by_id_prime.js.map