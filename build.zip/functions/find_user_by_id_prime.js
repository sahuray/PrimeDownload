import FuncionarioUsuario from '#models/funcionario_usuario';
async function findUserByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findUser = await FuncionarioUsuario.findBy('id_prime', idPrime);
    return findUser ? findUser.idfuncionariousuario : null;
}
export default findUserByIdPrime;
//# sourceMappingURL=find_user_by_id_prime.js.map