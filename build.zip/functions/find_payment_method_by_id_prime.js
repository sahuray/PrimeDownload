import FormaDePagamento from '#models/forma_de_pagamento';
async function findPaymentMethodByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findPaymentMethod = await FormaDePagamento.findBy('id_prime', idPrime);
    return findPaymentMethod ? findPaymentMethod.id : null;
}
export default findPaymentMethodByIdPrime;
//# sourceMappingURL=find_payment_method_by_id_prime.js.map