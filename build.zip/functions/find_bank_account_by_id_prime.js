import ContaBancaria from '#models/conta_bancaria';
async function findBankAccountByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findBankAccount = await ContaBancaria.findBy('id_prime', idPrime);
    return findBankAccount ? findBankAccount.id : null;
}
export default findBankAccountByIdPrime;
//# sourceMappingURL=find_bank_account_by_id_prime.js.map