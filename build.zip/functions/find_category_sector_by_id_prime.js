import PrimeProdutoCategoriaSetor from '#models/prime_produto_categoria_setor';
async function findCategorySectorByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findCategorySector = await PrimeProdutoCategoriaSetor.findBy('id_prime', idPrime);
    return findCategorySector ? findCategorySector.id : null;
}
export default findCategorySectorByIdPrime;
//# sourceMappingURL=find_category_sector_by_id_prime.js.map