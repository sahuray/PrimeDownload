import Setor from '#models/setor';
async function findSetorByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findSetor = await Setor.findBy('id_prime', idPrime);
    return findSetor ? findSetor.id : null;
}
export default findSetorByIdPrime;
//# sourceMappingURL=find_setor_by_id_prime.js.map