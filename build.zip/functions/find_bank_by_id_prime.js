import Banco from '#models/banco';
async function findBankByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findBank = await Banco.findBy('id_prime', idPrime);
    return findBank ? findBank.id : null;
}
export default findBankByIdPrime;
//# sourceMappingURL=find_bank_by_id_prime.js.map