import Terminal from '#models/terminal';
async function findTerminalByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findTerminal = await Terminal.findBy('id_prime', idPrime);
    return findTerminal ? findTerminal.idterminal : null;
}
export default findTerminalByIdPrime;
//# sourceMappingURL=find_terminal_by_id_prime.js.map