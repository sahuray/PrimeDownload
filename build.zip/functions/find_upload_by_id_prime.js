import PrimeUpload from '#models/prime_upload';
async function findUploadByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findUpload = await PrimeUpload.findBy('id_prime', idPrime);
    return findUpload ? findUpload.id : null;
}
export default findUploadByIdPrime;
//# sourceMappingURL=find_upload_by_id_prime.js.map