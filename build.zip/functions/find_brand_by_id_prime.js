import Marca from '#models/prime_marca';
async function findBrandByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findBrand = await Marca.findBy('id_prime', idPrime);
    return findBrand ? findBrand.id : null;
}
export default findBrandByIdPrime;
//# sourceMappingURL=find_brand_by_id_prime.js.map