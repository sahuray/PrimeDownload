import VendaFormaDePagamento from '#models/venda_forma_de_pagamento';
async function findSaleMethodPaymentByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const finSale = await VendaFormaDePagamento.findBy('id_prime', idPrime);
    return finSale ? finSale.id : null;
}
export default findSaleMethodPaymentByIdPrime;
//# sourceMappingURL=find_sale_payment_method_by_id_prime.js.map