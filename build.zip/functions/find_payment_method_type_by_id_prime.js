import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
async function findPaymentMethodTypeByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findPaymentMethodType = await FormaDePagamentoTipo.findBy('id_prime', idPrime);
    return findPaymentMethodType ? findPaymentMethodType.id : null;
}
export default findPaymentMethodTypeByIdPrime;
//# sourceMappingURL=find_payment_method_type_by_id_prime.js.map