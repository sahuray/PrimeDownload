import Produto from '#models/prime_produto';
async function findProductByIdCore(idCore) {
    if (!idCore)
        return null;
    const finProduct = await Produto.findBy('id', idCore);
    return finProduct ? finProduct.id_prime : null;
}
export default findProductByIdCore;
//# sourceMappingURL=find_product_by_id_core.js.map