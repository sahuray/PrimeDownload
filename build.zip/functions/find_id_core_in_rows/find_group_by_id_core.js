import Grupo from '#models/grupo';
async function findGroupByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const finGroup = await Grupo.findBy('id', idCore);
    return finGroup ? finGroup.id_prime : null;
}
export default findGroupByIdCore;
//# sourceMappingURL=find_group_by_id_core.js.map