import VendaFormaDePagamento from '#models/venda_forma_de_pagamento';
async function findSalePaymentMethodByIdCore(idCore) {
    if (!idCore)
        return null;
    const findPaymentMethod = await VendaFormaDePagamento.findBy('id', idCore);
    return findPaymentMethod ? findPaymentMethod.idPrime : null;
}
export default findSalePaymentMethodByIdCore;
//# sourceMappingURL=find_sale_payment_method_by_id_core.js.map