import Funcionario from '#models/funcionario';
async function findSellerByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const findVendedor = await Funcionario.findBy('idfuncionario', idCore);
    return findVendedor ? findVendedor.idPrime : null;
}
export default findSellerByIdCore;
//# sourceMappingURL=find_seller_by_id_core.js.map