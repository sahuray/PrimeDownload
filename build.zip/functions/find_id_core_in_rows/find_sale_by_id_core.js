import Venda from '#models/venda';
async function findSaleByIdCore(idCore) {
    if (!idCore)
        return null;
    const finSale = await Venda.findBy('id', idCore);
    return finSale ? finSale.idPrime : null;
}
export default findSaleByIdCore;
//# sourceMappingURL=find_sale_by_id_core.js.map