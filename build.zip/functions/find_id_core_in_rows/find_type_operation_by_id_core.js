import OperacaoMovimentoTipo from '#models/operacao_movimento_tipo';
async function findTypeOperationByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const findTypeOperation = await OperacaoMovimentoTipo.findBy('id', idCore);
    return findTypeOperation ? findTypeOperation.id_prime : null;
}
export default findTypeOperationByIdCore;
//# sourceMappingURL=find_type_operation_by_id_core.js.map