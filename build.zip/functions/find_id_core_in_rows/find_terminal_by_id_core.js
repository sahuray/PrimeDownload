import Terminal from '#models/terminal';
async function findTerminalByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const findTerminal = await Terminal.findBy('idterminal', idCore);
    return findTerminal ? findTerminal.id_prime : null;
}
export default findTerminalByIdCore;
//# sourceMappingURL=find_terminal_by_id_core.js.map