import OperacaoMovimento from '#models/operacao_movimento';
async function findMovementOperationByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const findMovementOperation = await OperacaoMovimento.findBy('id', idCore);
    return findMovementOperation ? findMovementOperation.id_prime : null;
}
export default findMovementOperationByIdCore;
//# sourceMappingURL=find_movement_operation_by_id_core.js.map