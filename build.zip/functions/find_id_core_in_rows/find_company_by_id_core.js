import Empresa from '#models/empresa';
async function findCompanyByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const finGroup = await Empresa.findBy('id', idCore);
    return finGroup ? finGroup.id_prime_empresa : null;
}
export default findCompanyByIdCore;
//# sourceMappingURL=find_company_by_id_core.js.map