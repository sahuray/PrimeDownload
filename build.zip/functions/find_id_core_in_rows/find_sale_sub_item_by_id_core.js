import VendaSubItem from '#models/venda_sub_item';
async function findSaleSubItemByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const finGroup = await VendaSubItem.findBy('id', idCore);
    return finGroup ? finGroup.idPrime : null;
}
export default findSaleSubItemByIdCore;
//# sourceMappingURL=find_sale_sub_item_by_id_core.js.map