import ProdutoCaracteristica from '#models/prime_produto_caracteristica';
async function findProductCharacteristicByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const finGroup = await ProdutoCaracteristica.findBy('id', idCore);
    return finGroup ? finGroup.id_prime : null;
}
export default findProductCharacteristicByIdCore;
//# sourceMappingURL=find_product_characteristic_by_id_core.js.map