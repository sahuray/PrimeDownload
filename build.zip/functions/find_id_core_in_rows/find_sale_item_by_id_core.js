import VendaItem from '#models/venda_item';
async function findSaleItemByIdCore(idCore) {
    if (!idCore)
        return null;
    const finSaleItem = await VendaItem.findBy('id', idCore);
    return finSaleItem ? finSaleItem.idPrime : null;
}
export default findSaleItemByIdCore;
//# sourceMappingURL=find_sale_item_by_id_core.js.map