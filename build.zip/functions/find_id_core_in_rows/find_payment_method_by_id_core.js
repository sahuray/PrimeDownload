import FormaDePagamento from '#models/forma_de_pagamento';
async function findPaymentMethodByIdCore(idCore) {
    if (!idCore)
        return null;
    const findPaymentMethod = await FormaDePagamento.findBy('id', idCore);
    return findPaymentMethod ? findPaymentMethod.id_prime : null;
}
export default findPaymentMethodByIdCore;
//# sourceMappingURL=find_payment_method_by_id_core.js.map