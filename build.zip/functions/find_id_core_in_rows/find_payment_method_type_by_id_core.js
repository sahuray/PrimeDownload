import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
async function findPaymentMethodTypeByIdCore(idCore) {
    if (!idCore)
        return null;
    const findPaymentMethodType = await FormaDePagamentoTipo.findBy('id', idCore);
    return findPaymentMethodType ? findPaymentMethodType.id_prime : null;
}
export default findPaymentMethodTypeByIdCore;
//# sourceMappingURL=find_payment_method_type_by_id_core.js.map