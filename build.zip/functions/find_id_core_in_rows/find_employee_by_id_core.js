import Funcionario from '#models/funcionario';
async function findEmployeeByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const finEmployee = await Funcionario.findBy('idfuncionario', idCore);
    return finEmployee ? finEmployee.idPrime : null;
}
export default findEmployeeByIdCore;
//# sourceMappingURL=find_employee_by_id_core.js.map