import CaixaMovimento from '#models/caixa_movimento';
async function findMovemntCashDeskByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const finMovemntCashDesk = await CaixaMovimento.findBy('idcaixamovimento', idCore);
    return finMovemntCashDesk ? finMovemntCashDesk.id_prime : null;
}
export default findMovemntCashDeskByIdCore;
//# sourceMappingURL=find_movement_cash_desk_by_id_core.js.map