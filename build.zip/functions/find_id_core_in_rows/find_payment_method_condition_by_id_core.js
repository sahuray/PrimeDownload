import FormaDePagamentoCondicao from '#models/forma_de_pagamento_condicao';
async function findPaymentMethodConditionByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const findPaymentMethodCondition = await FormaDePagamentoCondicao.findBy('id', idCore);
    return findPaymentMethodCondition ? findPaymentMethodCondition.id_prime : null;
}
export default findPaymentMethodConditionByIdCore;
//# sourceMappingURL=find_payment_method_condition_by_id_core.js.map