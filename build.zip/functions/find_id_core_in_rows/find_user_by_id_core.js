import Usuario from '#models/funcionario_usuario';
async function findUserByIdCore(idCore) {
    if (!idCore || idCore === 0)
        return null;
    const finUser = await Usuario.findBy('idfuncionariousuario', idCore);
    return finUser ? finUser.id_prime : null;
}
export default findUserByIdCore;
//# sourceMappingURL=find_user_by_id_core.js.map