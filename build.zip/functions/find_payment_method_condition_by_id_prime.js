import FormaDePagamentoCondicao from '#models/forma_de_pagamento_condicao';
async function findPaymentMethodConditionByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findPaymentMethodCondition = await FormaDePagamentoCondicao.findBy('id_prime', idPrime);
    return findPaymentMethodCondition ? findPaymentMethodCondition.id : null;
}
export default findPaymentMethodConditionByIdPrime;
//# sourceMappingURL=find_payment_method_condition_by_id_prime.js.map