import VendaSubItem from '#models/venda_sub_item';
async function findSaleSubItemByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const finSaleItem = await VendaSubItem.findBy('id_prime', idPrime);
    return finSaleItem ? finSaleItem.id : null;
}
export default findSaleSubItemByIdPrime;
//# sourceMappingURL=find_sale_sub_item_by_id_prime.js.map