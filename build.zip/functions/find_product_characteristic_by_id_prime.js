import ProductCharacteristic from '#models/prime_produto_caracteristica';
async function findProductCharacteristicByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findProduct = await ProductCharacteristic.findBy('id_prime', idPrime);
    return findProduct ? findProduct.id : null;
}
export default findProductCharacteristicByIdPrime;
//# sourceMappingURL=find_product_characteristic_by_id_prime.js.map