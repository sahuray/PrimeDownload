import Funcionario from '#models/funcionario';
import FuncionarioUsuario from '#models/funcionario_usuario';
async function findEmployeeByIdUser(idUser) {
    if (!idUser)
        return null;
    let idPrimeEmployee = null;
    const findUser = await FuncionarioUsuario.findBy('idfuncionariousuario', idUser);
    if (findUser) {
        const findEmployee = await Funcionario.findBy('idfuncionario', findUser.idFuncionario);
        idPrimeEmployee = findEmployee ? findEmployee.idPrime : null;
    }
    return idPrimeEmployee;
}
export default findEmployeeByIdUser;
//# sourceMappingURL=find_employee_by_id_funcionario_usuario.js.map