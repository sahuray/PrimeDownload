import PrimeProdutoCategoriaSubgrupo from '#models/prime_produto_categoria_subgrupo';
async function findCategorySubGroupByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findCategorySubGroup = await PrimeProdutoCategoriaSubgrupo.findBy('id_prime', idPrime);
    return findCategorySubGroup ? findCategorySubGroup.id : null;
}
export default findCategorySubGroupByIdPrime;
//# sourceMappingURL=find_category_sub_group_by_id_prime.js.map