import Funcionario from '#models/funcionario';
async function findEmployeeByIdPrime(idPrime) {
    if (!idPrime)
        return null;
    const findEmployee = await Funcionario.findBy('id_prime', idPrime);
    return findEmployee ? findEmployee.idfuncionario : null;
}
export default findEmployeeByIdPrime;
//# sourceMappingURL=find_employee_by_id_prime.js.map