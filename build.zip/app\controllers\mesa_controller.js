import Setor from '#models/setor';
import Mesa from '#models/prime_mesa';
import Funcionario from '#models/funcionario';
import Venda from '#models/venda';
import VendaItem from '#models/venda_item';
import MesaConfig from '#models/prime_mesa_config';
import { DateTime } from 'luxon';
export default class MesaController {
    async findMesa(ctx) {
        const numeroMesa = ctx.params.numeroMesa;
        const mesa = await Mesa.query().where('numero_mesa', numeroMesa).whereNull('deleted_at').first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        const vendaItem = await VendaItem.query()
            .where('id_mesa', mesa.id)
            .preload('garcon')
            .whereHas('venda', (query) => {
            query.where('status', 'PROVISORIO_MESA');
        })
            .preload('venda', (query) => {
            query.preload('UsuarioCriacao');
        })
            .preload('produto')
            .preload('mesa', (query) => {
            query.where('status', 'OCUPADO');
        })
            .whereNull('deleted_at')
            .select('*');
        if (vendaItem.length === 0) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        return ctx.response.json({ status: 200, message: 'MESA ENCONTRADA', vendaItem });
    }
    async findFuncionario(ctx) {
        const id = ctx.params.id;
        if (!id) {
            return ctx.response.badRequest({ message: 'ID DO GARÇOM É OBRIGATÓRIO' });
        }
        const funcionario = await Funcionario.query()
            .where('idfuncionario', Number(id))
            .where('statusfuncionario', true)
            .whereNull('deleted_at')
            .first();
        return ctx.response.json(funcionario);
    }
    async index(ctx) {
        const setor = await Setor.query()
            .where('status', true)
            .whereNull('deleted_at')
            .preload('mesas')
            .select('*')
            .orderBy('nome_setor', 'asc');
        const mesaData = await Mesa.query()
            .where('active', true)
            .whereNull('deleted_at')
            .select('*')
            .orderBy('numero_mesa', 'asc');
        let mesa = {
            setores: setor,
            mesaData,
        };
        return ctx.response.json(mesa);
    }
    async openMesa(ctx) {
        const { numeroMesa, idGarcom, quantidadePessoas, identificacaoMesa, observacao, produtosMesa } = ctx.request.body();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const mesa = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .where('status', 'LIVRE')
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        if (mesa.status === 'OCUPADO') {
            return ctx.response.badRequest({ message: 'MESA JÁ ESTÁ OCUPADA' });
        }
        mesa.status = 'OCUPADO';
        mesa.id_garcon = idGarcom;
        mesa.quantidade_pessoas = quantidadePessoas;
        mesa.identificacao_mesa = identificacaoMesa;
        mesa.observacao = observacao;
        mesa.hora_abertura = DateTime.now();
        mesa.hora_ultimo_atendimento = DateTime.now();
        await mesa.save();
        const newSale = await Venda.create({
            idEmpresa: sessionData.empresaId,
            idUsuarioCriacao: Number(mesa.id_garcon),
            idGrupo: 1,
            finalizado: false,
            idTerminal: terminal.idterminal || terminal.idTerminal,
            status: 'PROVISORIO_MESA',
            origem: 'MESA',
        });
        for (const item of produtosMesa) {
            const totalValue = item.valor_total;
            const saledQuantity = item.quantidade;
            const itemExistente = await VendaItem.query()
                .where('idProduto', item.id_produto)
                .where('idVenda', newSale.id)
                .first();
            if (itemExistente) {
                itemExistente.saledQuantity += saledQuantity;
                itemExistente.totalValue += totalValue;
                itemExistente.id_venda_anterior = itemExistente.idVenda;
                itemExistente.idVenda = newSale.id;
                await itemExistente.save();
            }
            else {
                await VendaItem.create({
                    idProduto: item.id_produto,
                    saledQuantity: saledQuantity,
                    totalValue: totalValue,
                    listar_na_comanda: false,
                    id_venda_anterior: newSale.id,
                    idVenda: newSale.id,
                    id_mesa: mesa.id,
                    id_garcon: Number(mesa.id_garcon),
                });
            }
        }
        return ctx.response.json({ status: 200, message: 'MESA ABERTA COM SUCESSO!', mesa });
    }
    async updateMesaItems(ctx) {
        const { numeroMesa, idGarcom, quantidadePessoas, identificacaoMesa, observacao, produtosMesa } = ctx.request.body();
        const mesa = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .whereNot('status', 'LIVRE')
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        const vendaItems = await VendaItem.query()
            .where('id_mesa', mesa.id)
            .whereHas('venda', (query) => {
            query.where('status', 'PROVISORIO_MESA');
        })
            .whereNull('deleted_at')
            .select('*');
        if (vendaItems.length === 0) {
            return ctx.response.json({ status: 404, message: 'VENDAS NÃO ENCONTRADAS' });
        }
        for (const item of produtosMesa) {
            const totalValue = item.valor_total;
            const saledQuantity = item.quantidade;
            const itemExistente = await VendaItem.query()
                .where('idProduto', item.id_produto)
                .where('idVenda', vendaItems.find((v) => v.idProduto === item.id_produto)?.idVenda || 0)
                .first();
            if (itemExistente) {
                itemExistente.saledQuantity += saledQuantity;
                itemExistente.totalValue += totalValue;
                itemExistente.id_venda_anterior = itemExistente.idVenda;
                itemExistente.idVenda =
                    vendaItems.find((v) => v.idProduto === item.id_produto)?.idVenda || 0;
                await itemExistente.save();
            }
            else {
                await VendaItem.create({
                    idProduto: item.id_produto,
                    saledQuantity: saledQuantity,
                    totalValue: totalValue,
                    listar_na_comanda: false,
                    id_venda_anterior: vendaItems[0].idVenda,
                    idVenda: vendaItems[0].idVenda,
                    id_mesa: mesa.id,
                    id_garcon: idGarcom,
                });
            }
        }
        mesa.status = 'OCUPADO';
        mesa.id_garcon = idGarcom;
        mesa.quantidade_pessoas = quantidadePessoas;
        mesa.identificacao_mesa = identificacaoMesa;
        mesa.observacao = observacao;
        mesa.hora_ultimo_atendimento = DateTime.now();
        await mesa.save();
        return ctx.response.json({
            status: 200,
            message: 'ITENS DA MESA ATUALIZADOS COM SUCESSO!',
            mesa,
        });
    }
    async filterMesaBySetor(ctx) {
        const idSetor = ctx.params.idSetor;
        const setor = await Setor.query()
            .where('status', true)
            .whereNull('deleted_at')
            .preload('mesas')
            .select('*')
            .orderBy('nome_setor', 'asc');
        const mesaData = await Mesa.query()
            .where('id_setor', idSetor)
            .whereNull('deleted_at')
            .select('*')
            .orderBy('numero_mesa', 'asc');
        let mesa = {
            setores: setor,
            mesaData,
        };
        return ctx.response.json(mesa);
    }
    async indexStatusMesa(ctx) {
        const status = ['LIVRE', 'OCUPADO', 'FECHANDO', 'OCIOSO'];
        const config = await MesaConfig.query().whereNull('deleted_at').first();
        const tempoLimiteOcioso = 1000 * 60 * (config?.idle_time || 1);
        const mesas = await Mesa.query().whereIn('status', status).whereNull('deleted_at').select('*');
        let idsToUpdate = [];
        const mesaData = await mesas.reduce((acc, mesa) => {
            if (mesa.hora_ultimo_atendimento) {
                const horaAtendimentoStr = String(mesa.hora_ultimo_atendimento);
                const dateObject = new Date(horaAtendimentoStr);
                const ultimoAtendimento = DateTime.fromJSDate(dateObject, { zone: 'utc' });
                if (ultimoAtendimento.isValid) {
                    const tempoDesdeUltimoAtendimento = DateTime.now().diff(ultimoAtendimento).toMillis();
                    acc.totalTime = (acc.totalTime || 0) + tempoDesdeUltimoAtendimento;
                    acc.count = (acc.count || 0) + 1;
                    if (mesa.status !== 'FECHANDO' && tempoDesdeUltimoAtendimento > tempoLimiteOcioso) {
                        idsToUpdate.push(mesa.id);
                        acc['OCIOSO'] = (acc['OCIOSO'] || 0) + 1;
                    }
                    else {
                        acc[mesa.status] = (acc[mesa.status] || 0) + 1;
                    }
                }
            }
            else {
                acc[mesa.status] = (acc[mesa.status] || 0) + 1;
            }
            return acc;
        }, { LIVRE: 0, FECHANDO: 0, OCUPADO: 0, OCIOSO: 0, totalTime: 0, count: 0 });
        mesaData['T.M.A'] =
            mesaData.count > 0 ? Math.round(mesaData.totalTime / mesaData.count / (1000 * 60)) : 0;
        delete mesaData.totalTime;
        delete mesaData.count;
        if (idsToUpdate.length > 0) {
            await Mesa.query().whereIn('id', idsToUpdate).update({ status: 'OCIOSO' });
        }
        return ctx.response.json(mesaData);
    }
    async setIdleTime(ctx) {
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const { idleTime } = ctx.request.body();
        await MesaConfig.query().update({ deletedAt: DateTime.now() });
        const config = await MesaConfig.create({
            id_usuario: sessionData.idfuncionariousuario,
            idle_time: idleTime,
        });
        return ctx.response.json({
            status: 200,
            message: 'TEMPO DE OCIOSIDADE SETADO COM SUCESSO!',
            config,
        });
    }
}
//# sourceMappingURL=mesa_controller.js.map