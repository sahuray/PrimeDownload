import axios from 'axios';
import Mesa from '#models/prime_mesa';
import Grupo from '#models/grupo';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findSetorByIdPrime from '../../../functions/find_setor_by_id_prime.js';
export default class MesaService {
    async syncMesa() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_mesa')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/mesa', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const mesas = response.data.mesas;
            console.log(`${mesas.length} MESAS ENCONTRADAS PARA SINCRONIZAR`);
            if (mesas && mesas.length > 0) {
                console.log('SINCRONIZANDO MESAS');
                const mesasToSync = [];
                let idGroup = await Grupo.query().where('id', 1).select(['id']).first();
                if (idGroup && idGroup.id) {
                    for (const mesa of mesas) {
                        const mesaExists = await Mesa.findBy('id_prime', mesa.id);
                        let idCompany = await findCompanyByIdPrime(mesa.id_empresa);
                        let idSetor = await findSetorByIdPrime(mesa.id_setor);
                        if (idCompany) {
                            const upsertMesa = {
                                id_prime: mesa.id,
                                id_empresa: idCompany,
                                id_setor: idSetor || 0,
                                id_garcon: mesa.id_garcon || null,
                                id_agrupamento: mesa.id_agrupamento || null,
                                numero_mesa: mesa.numero_mesa,
                                numero_cadeiras: mesa.numero_cadeiras,
                                observacao: mesa.observacao,
                                status: mesa.status,
                                favorite: mesa.favorite,
                                identificacao_mesa: mesa.identificacao_mesa,
                                quantidade_pessoas: mesa.quantidade_pessoas,
                                active: mesa.active,
                                deletedAt: mesa.deleted_at,
                            };
                            if (mesaExists) {
                                await mesaExists.merge(upsertMesa).save();
                                mesasToSync.push(mesa.id);
                            }
                            else {
                                await Mesa.create(upsertMesa);
                                mesasToSync.push(mesa.id);
                            }
                        }
                    }
                    if (mesasToSync && mesasToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'prime_mesa' }, { updated_at: DateTime.now() });
                    }
                }
                console.log(`${mesasToSync.length} MESA(S) SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) MESA(S)', error);
        }
    }
}
//# sourceMappingURL=mesa.js.map