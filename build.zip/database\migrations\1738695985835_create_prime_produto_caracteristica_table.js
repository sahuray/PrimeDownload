import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_caracteristica';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_produto').unsigned().references('id').inTable('prime_produto');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.text('codigo');
            table.text('descricao');
            table.text('categoria');
            table.boolean('fixo').defaultTo(false);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1738695985835_create_prime_produto_caracteristica_table.js.map