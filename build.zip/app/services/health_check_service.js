import axios from 'axios';
import { apiURL } from './index.js';
export default class HealthCheckService {
    async verifyConnection() {
        try {
            const response = await axios.get(apiURL + '/v1/core/health_check', { timeout: 5000 });
            console.log('✅ API ESTÁ ONLINE:', response.status);
            return true;
        }
        catch (error) {
            console.error('❌ API INACESSÍVEL:', error.message);
            return false;
        }
    }
}
//# sourceMappingURL=health_check_service.js.map