const apiURL = (process.env.API_EMPRESA_URL || '').replace(/\/$/, '');
export { apiURL };
//# sourceMappingURL=index.js.map