import axios from 'axios';
import EmpresaDeliveryConfig from '#models/prime_empresa_delivery_config';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
export default class EmpresaDeliveryConfigService {
    async syncCompanyDeliverySetting() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_empresa_delivery_config')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/company_delivery_setting', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const settings = response.data.settings;
            console.log(`${settings.length} CONFIGURAÇÃO DELIVERY ENCONTRADAS PARA SINCRONIZAR`);
            if (settings && settings.length > 0) {
                const settingToSync = [];
                for (const setting of settings) {
                    const settingExists = await EmpresaDeliveryConfig.findBy('id_prime', setting.id);
                    let idCompany = await findCompanyByIdPrime(setting.empresa_id);
                    let idProduct = await findProductByIdPrime(setting.id_produto_vinculado);
                    if (idCompany) {
                        const upsertSettings = {
                            id_prime: setting.id,
                            id_empresa: idCompany,
                            id_produto_vinculado: idProduct,
                            utiliza_delivery: setting.utiliza_delivery,
                            trazer_ultima_observacao_pedido: setting.trazer_ultima_observacao_pedido,
                            confirmar_impressao_caminho_entrega: setting.confirmar_impressao_caminho_entrega,
                            alterar_valor_produto: setting.alterar_valor_produto,
                            trazer_endereco_delivery_cupom_venda: setting.trazer_endereco_delivery_cupom_venda,
                            confirmacao_geral_delivery_pedidos_aplicativo: setting.confirmacao_geral_delivery_pedidos_aplicativo,
                            utiliza_ifood: setting.utiliza_ifood,
                            utiliza_pedido_whatsapp: setting.utiliza_pedido_whatsapp,
                            utiliza_pedido_anota_ai: setting.utiliza_pedido_anota_ai,
                            impressao_por_departamento: setting.impressao_por_departamento,
                            epadoca: setting.epadoca,
                            ifood: setting.ifood,
                            app_delivery: setting.app_delivery,
                            multi_pedidos: setting.multi_pedidos,
                            anota_ai: setting.anota_ai,
                            divisao_de_pizza_maior_valor: setting.divisao_de_pizza_maior_valor,
                            tempo_medio: setting.tempo_medio,
                            taxa_ao_produto: setting.taxa_ao_produto,
                            valor_utilizado_na_venda: setting.valor_utilizado_na_venda,
                            label_produto_vinculado: setting.label_produto_vinculado,
                            deleted_at: setting.deleted_at,
                        };
                        if (settingExists) {
                            await settingExists.merge(upsertSettings).save();
                            settingToSync.push(setting.id);
                        }
                        else {
                            await EmpresaDeliveryConfig.create(upsertSettings);
                            settingToSync.push(setting.id);
                        }
                    }
                }
                if (settingToSync && settingToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_empresa_delivery_config' }, { updated_at: DateTime.now() });
                }
                console.log(`${settingToSync.length} CONFIGURAÇÃO DELIVERY SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS CONFIGURAÇÃO DELIVERY', error);
        }
    }
}
//# sourceMappingURL=empresa_delivery_config.js.map