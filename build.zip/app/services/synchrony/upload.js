import axios from 'axios';
import Upload from '#models/prime_upload';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findCategorySectorByIdPrime from '../../../functions/find_category_sector_by_id_prime.js';
export default class UploadService {
    async syncUpload() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'UPLOAD')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/upload', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const uploads = response.data.uploads;
            console.log(`${uploads.length} UPLOADS ENCONTRADOS PARA SINCRONIZAR`);
            if (uploads && uploads.length > 0) {
                const uploadsToSync = [];
                for (const upload of uploads) {
                    const uploadExists = await Upload.findBy('id_prime', upload.id);
                    if (upload.type === 'products') {
                        let idProduct = await findProductByIdPrime(upload.id_fk);
                        if (idProduct) {
                            const upsertUpload = {
                                id_prime: upload.id,
                                id_funcionario_usuario: upload.id_funcionario_usuario,
                                url: upload.url,
                                type: upload.type,
                                id_fk: idProduct,
                                description: upload.description,
                                name: upload.name,
                                expiration_date: upload.expiration_date,
                            };
                            if (uploadExists) {
                                await uploadExists.merge(upsertUpload).save();
                                uploadsToSync.push(upload.id);
                            }
                            else {
                                await Upload.create(upsertUpload);
                                uploadsToSync.push(upload.id);
                            }
                        }
                    }
                    if (upload.type === 'image_sector') {
                        let idSector = await findCategorySectorByIdPrime(upload.id_fk);
                        if (idSector) {
                            const upsertUpload = {
                                id_prime: upload.id,
                                id_funcionario_usuario: upload.id_funcionario_usuario,
                                url: upload.url,
                                type: upload.type,
                                id_fk: idSector,
                                description: upload.description,
                                name: upload.name,
                                expiration_date: upload.expiration_date,
                            };
                            if (uploadExists) {
                                await uploadExists.merge(upsertUpload).save();
                                uploadsToSync.push(upload.id);
                            }
                            else {
                                await Upload.create(upsertUpload);
                                uploadsToSync.push(upload.id);
                            }
                        }
                    }
                }
                if (uploadsToSync && uploadsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'UPLOAD' }, { updated_at: DateTime.now() });
                }
                console.log(`${uploadsToSync.length} UPLOAD(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) UPLOAD(S)', error);
        }
    }
}
//# sourceMappingURL=upload.js.map