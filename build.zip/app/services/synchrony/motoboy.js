import axios from 'axios';
import Motoboy from '#models/motoboy';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import Grupo from '#models/grupo';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
export default class MotoboyService {
    async syncMotoboy() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'MOTOBOY')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/motoboy', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const motoboys = response.data.motoboys;
            console.log(`${motoboys.length} MOTOBOYS ENCONTRADOS PARA SINCRONIZAR`);
            if (motoboys && motoboys.length > 0) {
                const motoboysToSync = [];
                let idGroup = await Grupo.query().where('id', 1).select(['id']).first();
                if (idGroup && idGroup.id) {
                    for (const motoboy of motoboys) {
                        const motoboyExists = await Motoboy.findBy('id_prime', motoboy.id);
                        let idCompany = await findCompanyByIdPrime(motoboy.company_id);
                        if (idCompany) {
                            const upsertMotoboy = {
                                id_prime: motoboy.id,
                                id_grupo: idGroup.id,
                                id_empresa: idCompany,
                                nome: motoboy.nome,
                                codigo: motoboy.codigo,
                                rg: motoboy.rg,
                                cnh: motoboy.cnh,
                                telefone: motoboy.telefone,
                                email: motoboy.email,
                                endereco: motoboy.endereco,
                                numero: motoboy.numero,
                                complemento: motoboy.complemento,
                                bairro: motoboy.bairro,
                                cidade: motoboy.cidade,
                                uf: motoboy.uf,
                                cep: motoboy.cep,
                                placa: motoboy.placa,
                                ano: motoboy.ano,
                                modelo: motoboy.modelo,
                                logradouro: motoboy.logradouro,
                                deletedAt: motoboy.deleted_at,
                            };
                            if (motoboyExists) {
                                await motoboyExists.merge(upsertMotoboy).save();
                                motoboysToSync.push(motoboy.id);
                            }
                            else {
                                await Motoboy.create(upsertMotoboy);
                                motoboysToSync.push(motoboy.id);
                            }
                        }
                    }
                    if (motoboysToSync && motoboysToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'MOTOBOY' }, { updated_at: DateTime.now() });
                    }
                }
                console.log(`${motoboysToSync.length} MOTOBOY(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) MOTOBOY(S)', error);
        }
    }
}
//# sourceMappingURL=motoboy.js.map