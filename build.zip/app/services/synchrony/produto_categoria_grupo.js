import axios from 'axios';
import PrimeProdutoCategoriaGrupo from '#models/prime_produto_categoria_grupo';
import findCategorySectorByIdPrime from '../../../functions/find_category_sector_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdCategoriaGrupoService {
    async syncProdCategoryGroup() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_produto_categoria_grupo')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_category_group', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const marketingGroups = response.data.marketingGroups;
            console.log(`${marketingGroups.length} CATEGORIA (GRUPO) ENCNTRADOS PARA SINCRONIZAR`);
            if (marketingGroups && marketingGroups.length > 0) {
                const marketingGroupsToSync = [];
                for (const marketingGroup of marketingGroups) {
                    const marketingGroupExists = await PrimeProdutoCategoriaGrupo.findBy('id_prime', marketingGroup.id);
                    let idProdCategorySector = await findCategorySectorByIdPrime(marketingGroup.product_category_section_id);
                    if (idProdCategorySector) {
                        const upsertmarketingGroup = {
                            id_prime: marketingGroup.id,
                            name: marketingGroup.name,
                            id_produto_categoria_setor: idProdCategorySector,
                            deleted_at: marketingGroup.deleted_at,
                            sync_prime: false,
                        };
                        if (marketingGroupExists) {
                            await marketingGroupExists.merge(upsertmarketingGroup).save();
                            marketingGroupsToSync.push(marketingGroup.id);
                        }
                        else {
                            await PrimeProdutoCategoriaGrupo.create(upsertmarketingGroup);
                            marketingGroupsToSync.push(marketingGroup.id);
                        }
                    }
                }
                if (marketingGroupsToSync && marketingGroupsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_produto_categoria_grupo' }, { updated_at: DateTime.now() });
                }
                console.log(`${marketingGroupsToSync.length} CATEGORIA (GRUPO) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) CATEGORIA (GRUPO)', error);
        }
    }
}
//# sourceMappingURL=produto_categoria_grupo.js.map