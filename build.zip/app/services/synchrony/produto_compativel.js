import axios from 'axios';
import ProdutoCompativel from '#models/prime_produto_compativel';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoCompativelService {
    async syncProdutoCompativel() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PRODUTO COMPATIVEL')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_compatible', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productCompatibles = response.data.productCompatibles;
            console.log(`${productCompatibles.length} PRODUTO COMPATIVEL ENCONTRADOS PARA SINCRONIZAR`);
            if (productCompatibles && productCompatibles.length > 0) {
                const productCompatiblesToSync = [];
                for (const productCompatible of productCompatibles) {
                    const productCompatibleExists = await ProdutoCompativel.findBy('id_prime', productCompatible.id);
                    let idProduct = await findProductByIdPrime(productCompatible.product_id);
                    let idProductCompatible = await findProductByIdPrime(productCompatible.compatible_product_id);
                    if (idProduct && idProductCompatible) {
                        const upsertproductCompatible = {
                            id_prime: productCompatible.id,
                            id_produto: idProduct,
                            id_produto_compativel: idProductCompatible,
                            deleted_at: productCompatible.deleted_at,
                        };
                        if (productCompatibleExists) {
                            await productCompatibleExists.merge(upsertproductCompatible).save();
                            productCompatiblesToSync.push(productCompatible.id);
                        }
                        else {
                            await ProdutoCompativel.create(upsertproductCompatible);
                            productCompatiblesToSync.push(productCompatible.id);
                        }
                    }
                }
                if (productCompatiblesToSync && productCompatiblesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'PRODUTO COMPATIVEL' }, { updated_at: DateTime.now() });
                }
                console.log(`${productCompatiblesToSync.length} PRODUTO COMPATIVEL SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO COMPATIVEL', error);
        }
    }
}
//# sourceMappingURL=produto_compativel.js.map