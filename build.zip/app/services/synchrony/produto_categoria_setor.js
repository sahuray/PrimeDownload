import axios from 'axios';
import PrimeProdutoCategoriaSetor from '#models/prime_produto_categoria_setor';
import Grupo from '#models/grupo';
import findUploadByIdPrime from '../../../functions/find_upload_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdCategoriaSetorService {
    async syncProdCategorySector() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PRODUTO CATEGORIA SETOR')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_category_sector', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const marketingSectors = response.data.marketingSectors;
            console.log(`${marketingSectors.length} CATEGORIA (SETOR) ENCNTRADOS PARA SINCRONIZAR`);
            if (marketingSectors && marketingSectors.length > 0) {
                const marketingSectorsToSync = [];
                for (const marketingSector of marketingSectors) {
                    const marketingSectorExists = await PrimeProdutoCategoriaSetor.findBy('id_prime', marketingSector.id);
                    let idGroup = await Grupo.query().where('id', 1).first();
                    let idUpload = await findUploadByIdPrime(marketingSector.id_upload);
                    if (idGroup) {
                        const upsertmarketingSector = {
                            id_prime: marketingSector.id,
                            name: marketingSector.name,
                            id_grupo: idGroup.id,
                            id_upload: idUpload,
                            deleted_at: marketingSector.deleted_at,
                            sync_prime: false,
                        };
                        if (marketingSectorExists) {
                            await marketingSectorExists.merge(upsertmarketingSector).save();
                            marketingSectorsToSync.push(marketingSector.id);
                        }
                        else {
                            await PrimeProdutoCategoriaSetor.create(upsertmarketingSector);
                            marketingSectorsToSync.push(marketingSector.id);
                        }
                    }
                }
                if (marketingSectorsToSync && marketingSectorsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'PRODUTO CATEGORIA SETOR' }, { updated_at: DateTime.now() });
                }
                console.log(`${marketingSectorsToSync.length} CATEGORIA (SETOR) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) CATEGORIA (SETOR)', error);
        }
    }
}
//# sourceMappingURL=produto_categoria_setor.js.map