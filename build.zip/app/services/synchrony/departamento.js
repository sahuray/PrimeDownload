import axios from 'axios';
import { apiURL } from '../index.js';
import Sincronia from '#models/sincronia';
import Departamento from '#models/departamento';
import { DateTime } from 'luxon';
export default class DepartamentoService {
    async syncDepartament() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'DEPARTAMENTO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/departament', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const departaments = response.data.departaments;
            console.log(`${departaments.length} DEPARTAMENTO(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (departaments && departaments.length > 0) {
                const departamentsToSync = [];
                for (const departament of departaments) {
                    const departamentExists = await Departamento.findBy('id_prime', departament.id);
                    const upsertDepartament = {
                        id_prime: departament.id,
                        nome: departament.nome,
                        deletedAt: departament.deleted_at,
                    };
                    if (departamentExists) {
                        await departamentExists.merge(upsertDepartament).save();
                        departamentsToSync.push(departament.id);
                    }
                    else {
                        await Departamento.create(upsertDepartament);
                        departamentsToSync.push(departament.id);
                    }
                }
                if (departamentsToSync && departamentsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'DEPARTAMENTO' }, { updated_at: DateTime.now() });
                }
                console.log(`${departamentsToSync.length} DEPARTAMENTO(S) SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=departamento.js.map