import axios from 'axios';
import Grupo from '#models/grupo';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class GrupoService {
    async syncGroups() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'GRUPO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/group', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const groups = response.data.group;
            console.log(`${groups.length} GRUPO ENCNTRADO PARA SINCRONIZAR`);
            if (groups && groups.length > 0) {
                const groupsToSync = [];
                for (const group of groups) {
                    const groupExists = await Grupo.findBy('id_prime', group.id);
                    const upsertGroup = {
                        id_prime: group.id,
                        foto: group.foto,
                        nome: group.nome,
                        deletedAt: group.deleted_at,
                        slug: group.slug,
                        utilizaContabilizathos: group.utiliza_contabilizathos,
                        vizualizar_empresas: group.vizualizar_empresas,
                    };
                    if (groupExists) {
                        await groupExists.merge(upsertGroup).save();
                        groupsToSync.push(group.id);
                    }
                    else {
                        await Grupo.create(upsertGroup);
                        groupsToSync.push(group.id);
                    }
                }
                if (groupsToSync && groupsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'GRUPO' }, { updated_at: DateTime.now() });
                }
                console.log(`${groupsToSync.length} GRUPO SINCRONIZADO`);
            }
        }
        catch (error) {
            console.error('ERRO AO BUSCAR GRUPO', error);
        }
    }
}
//# sourceMappingURL=group.js.map