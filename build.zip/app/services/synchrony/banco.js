import axios from 'axios';
import Banco from '#models/banco';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class BancoService {
    async syncBanks() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'BANCO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/bank', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const banks = response.data.banks;
            console.log(`${banks.length} BANCO(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (banks && banks.length > 0) {
                const banksToSync = [];
                for (const bank of banks) {
                    const bankExists = await Banco.findBy('id_prime', bank.id);
                    const upsertBank = {
                        id_prime: bank.id,
                        codigo: bank.codigo,
                        nome: bank.nome,
                        homologado: bank.homologado,
                        deleted_at: bank.deleted_at,
                    };
                    if (bankExists) {
                        await bankExists.merge(upsertBank).save();
                        banksToSync.push(bank.id);
                    }
                    else {
                        await Banco.create(upsertBank);
                        banksToSync.push(bank.id);
                    }
                }
                if (banksToSync && banksToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'BANCO' }, { updated_at: DateTime.now() });
                }
                console.log(`${banksToSync.length} BANCO(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR OS BANCOS', error);
        }
    }
}
//# sourceMappingURL=banco.js.map