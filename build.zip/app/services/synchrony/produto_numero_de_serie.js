import axios from 'axios';
import ProdutoNumeroSerie from '#models/prime_produto_numero_de_serie';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoNumeroSerieService {
    async syncProdutoNumeroSerie() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_produto_numero_de_serie')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_serial_number', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productSerialNumbers = response.data.productSerialNumbers;
            console.log(`${productSerialNumbers.length} PRODUTO NUMERO SERIE ENCONTRADOS PARA SINCRONIZAR`);
            if (productSerialNumbers && productSerialNumbers.length > 0) {
                const productSerialNumbersToSync = [];
                for (const productSerialNumber of productSerialNumbers) {
                    const prodSerialNumberExists = await ProdutoNumeroSerie.findBy('id_prime', productSerialNumber.id);
                    let idCompany = await findCompanyByIdPrime(productSerialNumber.company_id);
                    let idProduct = await findProductByIdPrime(productSerialNumber.product_id);
                    if (idProduct && idCompany) {
                        const upsertproductSerialNumber = {
                            id_prime: productSerialNumber.id,
                            id_empresa: idCompany,
                            id_produto: idProduct,
                            doc_destination: productSerialNumber.doc_destination,
                            doc_origin: productSerialNumber.doc_origin,
                            expired_at: productSerialNumber.expired_at,
                            deleted_at: productSerialNumber.deleted_at,
                            stock_quantity: productSerialNumber.stock_quantity,
                            serial_number: productSerialNumber.serial_number,
                        };
                        if (prodSerialNumberExists) {
                            await prodSerialNumberExists.merge(upsertproductSerialNumber).save();
                            productSerialNumbersToSync.push(productSerialNumber.id);
                        }
                        else {
                            await ProdutoNumeroSerie.create(upsertproductSerialNumber);
                            productSerialNumbersToSync.push(productSerialNumber.id);
                        }
                    }
                }
                if (productSerialNumbersToSync && productSerialNumbersToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_produto_numero_de_serie' }, { updated_at: DateTime.now() });
                }
                console.log(`${productSerialNumbersToSync.length} PRODUTO PRODUTO NUMERO DE SERIE(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO NUMERO DE SERIE PRECO(S)', error);
        }
    }
}
//# sourceMappingURL=produto_numero_de_serie.js.map