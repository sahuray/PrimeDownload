import axios from 'axios';
import CaixaMovimento from '#models/caixa_movimento';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import findTerminalByIdPrime from '../../../functions/find_terminal_by_id_prime.js';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import { apiURL } from '../index.js';
export default class CaixaMovimentoService {
    async syncCaixaMovimento() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'CAIXA_MOVIMENTO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/movement_cash_desk', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const movementCashDesks = response.data.movementCashDesks;
            console.log(`${movementCashDesks.length} CAIXA MOVIMENTO ENCONTRADOS PARA SINCRONIZAR`);
            if (movementCashDesks && movementCashDesks.length > 0) {
                const movementCashDesksToSync = [];
                for (const movementCashDesk of movementCashDesks) {
                    const movementCashDeskExists = await CaixaMovimento.findBy('id_prime', movementCashDesk.id);
                    let idUserOpenBy = await findUserByIdPrime(movementCashDesk.idfuncionariousuarioabertura);
                    let idUserCloseBy = await findUserByIdPrime(movementCashDesk.idfuncionariousuariofechamento);
                    let idTerminal = await findTerminalByIdPrime(movementCashDesk.idterminal);
                    const upsertCaixaMovimento = {
                        id_prime: movementCashDesk.id,
                        idfuncionariousuariofechamento: idUserCloseBy,
                        idfuncionariousuarioabertura: idUserOpenBy,
                        idterminal: idTerminal,
                        dataabertura: movementCashDesk.dataabertura,
                        horaabertura: movementCashDesk.horaabertura,
                        datafechamento: movementCashDesk.datafechamento,
                        horafechamento: movementCashDesk.horafechamento,
                        totalvenda: movementCashDesk.totalvenda,
                        totalsaida: movementCashDesk.totalsaida,
                        totalestorno: movementCashDesk.totalestorno,
                        totaldinheirocaixa: movementCashDesk.totaldinheirocaixa,
                        suprimentoatual: movementCashDesk.suprimentoatual,
                        saldoanterior: movementCashDesk.saldoanterior,
                        saldofinal: movementCashDesk.saldofinal,
                        status: movementCashDesk.status,
                        justificativa: movementCashDesk.justificativa,
                        datasync: movementCashDesk.datasync,
                    };
                    if (movementCashDeskExists) {
                        await movementCashDeskExists.merge(upsertCaixaMovimento).save();
                        movementCashDesksToSync.push(movementCashDesk.id);
                    }
                    else {
                        await CaixaMovimento.create(upsertCaixaMovimento);
                        movementCashDesksToSync.push(movementCashDesk.id);
                    }
                }
                if (movementCashDesksToSync && movementCashDesksToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'CAIXA_MOVIMENTO' }, { updated_at: DateTime.now() });
                }
                console.log(`${movementCashDesksToSync.length} CAIXA MOVIMENTO SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR OS CAIXA MOVIMENTO', error);
        }
    }
}
//# sourceMappingURL=caixa_movimento.js.map