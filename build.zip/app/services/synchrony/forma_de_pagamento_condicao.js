import axios from 'axios';
import FormaDePagamentoCondicao from '#models/forma_de_pagamento_condicao';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class FormaDePagamentoCondicaoService {
    async syncPaymentsMethodCondition() {
        let updatedAtSynchrony = null;
        const synchrony = await Sincronia.query()
            .where('nome_tabela', 'prime_forma_de_pagamento_condicao')
            .select('updated_at')
            .first();
        if (synchrony) {
            updatedAtSynchrony = synchrony.updated_at;
        }
        try {
            const response = await axios.get(apiURL + '/v1/core/payment_method_condition', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const paymentsMethodCondition = response.data.paymentsMethodCondition;
            console.log(`${paymentsMethodCondition.length} FORMA DE PAGAMENTO CONDIÇÃO ENCONTRADOS PARA SINCRONIZAR`);
            if (paymentsMethodCondition && paymentsMethodCondition.length > 0) {
                const paymentsMethodConditionToSync = [];
                for (const paymentMethodCondition of paymentsMethodCondition) {
                    const paymentMethodConditionExists = await FormaDePagamentoCondicao.findBy('id_prime', paymentMethodCondition.id);
                    let idUserCreatedBy = await findUserByIdPrime(paymentMethodCondition.created_by);
                    let idUserUpdatedBy = await findUserByIdPrime(paymentMethodCondition.updated_by);
                    const upsertPaymentMethodCondition = {
                        id_prime: paymentMethodCondition.id,
                        nome: paymentMethodCondition.nome,
                        code: paymentMethodCondition.code,
                        deletedAt: paymentMethodCondition.deleted_at,
                        createdBy: idUserCreatedBy,
                        updatedBy: idUserUpdatedBy,
                    };
                    if (paymentMethodConditionExists) {
                        await paymentMethodConditionExists.merge(upsertPaymentMethodCondition).save();
                        paymentsMethodConditionToSync.push(paymentMethodCondition.id);
                    }
                    else {
                        await FormaDePagamentoCondicao.create(upsertPaymentMethodCondition);
                        paymentsMethodConditionToSync.push(paymentMethodCondition.id);
                    }
                }
                if (paymentsMethodConditionToSync && paymentsMethodConditionToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_forma_de_pagamento_condicao' }, { updated_at: DateTime.now() });
                }
                console.log(`${paymentsMethodConditionToSync.length} FORMA DE PAGAMENTO CONDIÇÃO SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS FORMA DE PAGAMENTO CONDIÇÃO', error);
        }
    }
}
//# sourceMappingURL=forma_de_pagamento_condicao.js.map