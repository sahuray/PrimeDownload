import axios from 'axios';
import Unidade from '#models/prime_produto_unidade';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class UnidadeService {
    async syncUnit() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PRODUTO UNIDADE')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_unit', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const units = response.data.units;
            console.log(`${units.length} UNIDADE(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (units && units.length > 0) {
                const unitsToSync = [];
                for (const unit of units) {
                    const unitExists = await Unidade.findBy('id_prime', unit.id);
                    const upsertUnit = {
                        id_prime: unit.id,
                        nome: unit.nome,
                        sigla: unit.sigla,
                        deletedAt: unit.deleted_at,
                    };
                    if (unitExists) {
                        await unitExists.merge(upsertUnit).save();
                        unitsToSync.push(unit.id);
                    }
                    else {
                        await Unidade.create(upsertUnit);
                        unitsToSync.push(unit.id);
                    }
                }
                if (unitsToSync && unitsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'PRODUTO UNIDADE' }, { updated_at: DateTime.now() });
                }
                console.log(`${unitsToSync.length} UNIDADE(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) UNIDADE(S)', error);
        }
    }
}
//# sourceMappingURL=unidade.js.map