import axios from 'axios';
import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
export default class EmpresaPdvConfigService {
    async syncCompanyPdvSetting() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_empresa_pdv_config')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/company_pdv_setting', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const settings = response.data.settings;
            console.log(`${settings.length} CONFIGURAÇÃO PDV ENCONTRADAS PARA SINCRONIZAR`);
            if (settings && settings.length > 0) {
                const settingToSync = [];
                for (const setting of settings) {
                    const settingExists = await EmpresaPdvConfig.findBy('id_prime', setting.id);
                    let idCompany = await findCompanyByIdPrime(setting.empresa_id);
                    let IdProductTax = await findProductByIdPrime(setting.id_servico_taxa);
                    let IdProductCouvert = await findProductByIdPrime(setting.id_servico_couvert);
                    if (idCompany) {
                        const upsertSettings = {
                            id_prime: setting.id,
                            id_empresa: idCompany,
                            tipo_de_prazo: setting.tipo_de_prazo,
                            limite_qtd_itens_venda: setting.limite_qtd_itens_venda,
                            qtd_vias_cupom_prazo: setting.qtd_vias_cupom_prazo,
                            qtd_vias_cupom_vista: setting.qtd_vias_cupom_vista,
                            limite_vendas_a_prazo: setting.limite_vendas_a_prazo,
                            desconto_maximo_na_venda: setting.desconto_maximo_na_venda,
                            dia_do_prazo: setting.dia_do_prazo,
                            nao_pedir_valor_caixa: setting.nao_pedir_valor_caixa,
                            gerar_comissao: setting.gerar_comissao,
                            imprimir_codigo_produto: setting.imprimir_codigo_produto,
                            utiliza_numero_serie: setting.utiliza_numero_serie,
                            solicitar_confirmacao_exclusao_estoque: setting.solicitar_confirmacao_exclusao_estoque,
                            imprimir_observacao_produto: setting.imprimir_observacao_produto,
                            desconto_maximo_venda: setting.desconto_maximo_venda,
                            exigir_senha_sangria: setting.exigir_senha_sangria,
                            imprimir_comprovante_operacao: setting.imprimir_comprovante_operacao,
                            fechar_venda_com_enter: setting.fechar_venda_com_enter,
                            imprimir_obs_peso: setting.imprimir_obs_peso,
                            imprimir_endereco_cliente_detalhado: setting.imprimir_endereco_cliente_detalhado,
                            nao_permitir_orcamento_estoque_zerado: setting.nao_permitir_orcamento_estoque_zerado,
                            permitir_escolher_preco_venda: setting.permitir_escolher_preco_venda,
                            imprimir_comprovante_venda_prazo: setting.imprimir_comprovante_venda_prazo,
                            confirmar_impressao_comprovante_venda_prazo: setting.confirmar_impressao_comprovante_venda_prazo,
                            msg_rodape_impresso_gerado_sistema: setting.msg_rodape_impresso_gerado_sistema,
                            bloquear_vendas_a_prazo_por_limite: setting.bloquear_vendas_a_prazo_por_limite,
                            bloquear_vendas_a_prazo_por_atraso_do_cliente: setting.bloquear_vendas_a_prazo_por_atraso_do_cliente,
                            lancar_mesa_fechamento: setting.lancar_mesa_fechamento,
                            divisao_maior_valor: setting.divisao_maior_valor,
                            arredondamento_padrao_valor: setting.arredondamento_padrao_valor,
                            utiliza_taxa: setting.utiliza_taxa,
                            utiliza_couvert: setting.utiliza_couvert,
                            id_servico_taxa: IdProductTax,
                            nome_produto_taxa: setting.nome_produto_taxa,
                            codigo_produto_taxa: setting.codigo_produto_taxa,
                            id_servico_couvert: IdProductCouvert,
                            nome_produto_couvert: setting.nome_produto_couvert,
                            codigo_produto_couvert: setting.codigo_produto_couvert,
                            valor_taxa: setting.valor_taxa,
                            valor_couvert: setting.valor_couvert,
                            deletedAt: setting.deletedAt,
                        };
                        if (settingExists) {
                            await settingExists.merge(upsertSettings).save();
                            settingToSync.push(setting.id);
                        }
                        else {
                            await EmpresaPdvConfig.create(upsertSettings);
                            settingToSync.push(setting.id);
                        }
                    }
                }
                if (settingToSync && settingToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_empresa_pdv_config' }, { updated_at: DateTime.now() });
                }
                console.log(`${settingToSync.length} CONFIGURAÇÃO PDV SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS CONFIGURAÇÃO PDV', error);
        }
    }
}
//# sourceMappingURL=empresa_pdv_config.js.map