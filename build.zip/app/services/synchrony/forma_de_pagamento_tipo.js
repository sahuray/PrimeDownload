import axios from 'axios';
import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class FormaDePagamentoTipoService {
    async syncPaymentsMethodType() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'FORMA DE PAGAMENTO TIPO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/payment_method_type', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const paymentsMethodType = response.data.paymentsMethodType;
            console.log(`${paymentsMethodType.length} FORMA DE PAGAMENTO TIPO ENCONTRADOS PARA SINCRONIZAR`);
            if (paymentsMethodType && paymentsMethodType.length > 0) {
                const paymentsMethodTypeToSync = [];
                for (const paymentMethodType of paymentsMethodType) {
                    const paymentMethodTypeExists = await FormaDePagamentoTipo.findBy('id_prime', paymentMethodType.id);
                    const upsertPaymentMethodType = {
                        id_prime: paymentMethodType.id,
                        nome: paymentMethodType.nome,
                        cmp: paymentMethodType.cmp,
                        deletedAt: paymentMethodType.deleted_at,
                    };
                    if (paymentMethodTypeExists) {
                        await paymentMethodTypeExists.merge(upsertPaymentMethodType).save();
                        paymentsMethodTypeToSync.push(paymentMethodType.id);
                    }
                    else {
                        await FormaDePagamentoTipo.create(upsertPaymentMethodType);
                        paymentsMethodTypeToSync.push(paymentMethodType.id);
                    }
                }
                if (paymentsMethodTypeToSync && paymentsMethodTypeToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'FORMA DE PAGAMENTO TIPO' }, { updated_at: DateTime.now() });
                }
                console.log(`${paymentsMethodTypeToSync.length} FORMA DE PAGAMENTO TIPO SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS FORMA DE PAGAMENTO TIPO', error);
        }
    }
}
//# sourceMappingURL=forma_de_pagamento_tipo.js.map