import axios from 'axios';
import ProdutoComposto from '#models/prime_produto_composto';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoCompostoService {
    async syncProdutoComposto() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PRODUTO COMPOSTO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_composite', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productComposites = response.data.productComposites;
            console.log(`${productComposites.length} PRODUTO COMPOSTO ENCONTRADOS PARA SINCRONIZAR`);
            if (productComposites && productComposites.length > 0) {
                const productCompositesToSync = [];
                for (const productComposite of productComposites) {
                    const productCompositeExists = await ProdutoComposto.findBy('id_prime', productComposite.id);
                    let idCompany = await findCompanyByIdPrime(productComposite.company_id);
                    let idProduct = await findProductByIdPrime(productComposite.product_id);
                    let idDetail = await findProductByIdPrime(productComposite.id_detail);
                    if (idProduct && idCompany && idDetail) {
                        const upsertproductComposite = {
                            id_prime: productComposite.id,
                            id_detalhe: idDetail,
                            id_empresa: idCompany,
                            id_produto: idProduct,
                            quantity: productComposite.quantity,
                            composicao: productComposite.composicao,
                            custo_unitario: productComposite.custo_unitario,
                            custo_total: productComposite.custo_total,
                            estoque: productComposite.estoque,
                            restante: productComposite.restante,
                            perda_real: productComposite.perda_real,
                            perda_porcentagem: productComposite.perda_porcentagem,
                            custo_perda: productComposite.custo_perda,
                            custo_real_com_perdas: productComposite.custo_real_com_perdas,
                            codigo: productComposite.codigo,
                            deleted_at: productComposite.deleted_at,
                        };
                        if (productCompositeExists) {
                            await productCompositeExists.merge(upsertproductComposite).save();
                            productCompositesToSync.push(productComposite.id);
                        }
                        else {
                            await ProdutoComposto.create(upsertproductComposite);
                            productCompositesToSync.push(productComposite.id);
                        }
                    }
                }
                if (productCompositesToSync && productCompositesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'PRODUTO COMPOSTO' }, { updated_at: DateTime.now() });
                }
                console.log(`${productCompositesToSync.length} PRODUTO COMPOSTO SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO COMPOSTO', error);
        }
    }
}
//# sourceMappingURL=produto_composto.js.map