import axios from 'axios';
import Bandeira from '#models/bandeira';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class BandeiraService {
    async syncFlags() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'BANDEIRA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/flag', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const flags = response.data.flags;
            console.log(`${flags.length} BANDEIRA(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (flags && flags.length > 0) {
                const flagsToSync = [];
                for (const flag of flags) {
                    const flagExists = await Bandeira.findBy('id_prime', flag.id);
                    const upsertFlag = {
                        id_prime: flag.id,
                        nome: flag.nome,
                        deletedAt: flag.deleted_at,
                    };
                    if (flagExists) {
                        await flagExists.merge(upsertFlag).save();
                        flagsToSync.push(flag.id);
                    }
                    else {
                        await Bandeira.create(upsertFlag);
                        flagsToSync.push(flag.id);
                    }
                }
                if (flagsToSync && flagsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'BANDEIRA' }, { updated_at: DateTime.now() });
                }
                console.log(`${flagsToSync.length} BANDEIRA(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) BANDEIRA(S)', error);
        }
    }
}
//# sourceMappingURL=bandeira.js.map