import axios from 'axios';
import Sincronia from '#models/sincronia';
import PermissaoUsuario from '#models/prime_permissao_usuario';
import Grupo from '#models/grupo';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import findPermissionByIdPrime from '../../../functions/find_permission_by_id_prime.js';
export default class PermissaoUsuarioService {
    async syncPermissionUser() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PERMISSAO USUARIO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = null;
            }
            const response = await axios.get(apiURL + '/v1/core/permission/user', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const permissionUsers = response.data.permissionUsers;
            console.log(`${permissionUsers.length} PERMISSAO(ÇÕES) DO USUÁRIO(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (permissionUsers && permissionUsers.length > 0) {
                const permissionUsersToSync = [];
                await PermissaoUsuario.query().delete();
                let idGroup = await Grupo.query().where('id', 1).first();
                if (idGroup) {
                    for (const permissionUser of permissionUsers) {
                        const permissionExists = await PermissaoUsuario.findBy('id_prime', permissionUser.id);
                        const idCompany = await findCompanyByIdPrime(permissionUser.empresa_id);
                        const idUser = await findUserByIdPrime(permissionUser.user_id);
                        const idPermission = await findPermissionByIdPrime(permissionUser.permission_id);
                        if (idUser && idPermission) {
                            const upsertPermissionUser = {
                                id_prime: permissionUser.id,
                                id_permissao: idPermission,
                                id_usuario: idUser,
                                id_empresa: idCompany,
                                id_grupo: idGroup.id,
                                deletedAt: permissionUser.deleted_at,
                            };
                            if (permissionExists) {
                                await permissionExists.merge(upsertPermissionUser).save();
                                permissionUsersToSync.push(permissionUser.id);
                            }
                            else {
                                await PermissaoUsuario.create(upsertPermissionUser);
                                permissionUsersToSync.push(permissionUser.id);
                            }
                        }
                    }
                    if (permissionUsersToSync && permissionUsersToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'PERMISSAO USUARIO' }, { updated_at: DateTime.now() });
                    }
                    console.log(`${permissionUsersToSync.length} PERMISSAO(ÇÕES) USUARIO(S) SINCRONIZADOS`);
                }
            }
        }
        catch (error) {
            console.log('ERRO AS BUSCAR A(S) PERMISSAO(ÇÕES) USUARIO(S)', error);
        }
    }
}
//# sourceMappingURL=permissao_usuario.js.map