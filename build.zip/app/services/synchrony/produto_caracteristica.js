import axios from 'axios';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import ProdutoCaracteristica from '#models/prime_produto_caracteristica';
import Sincronia from '#models/sincronia';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
export default class ProdutoCaracteristicaService {
    async syncProductCharacteristic() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PRODUTO CARACTERISTICA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_characteristic', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productCharacteristics = response.data.productCharacteristics;
            console.log(`${productCharacteristics.length} PRODUTO CARACTERISTICA ENCONTRADOS PARA SINCRONIZAR`);
            if (productCharacteristics && productCharacteristics.length > 0) {
                const productCharacteristicsToSync = [];
                for (const productCharacteristic of productCharacteristics) {
                    const productCharacteristicExists = await ProdutoCaracteristica.findBy('id_prime', productCharacteristic.id);
                    let idCompany = await findCompanyByIdPrime(productCharacteristic.empresa_id);
                    let idProduct = await findProductByIdPrime(productCharacteristic.product_id);
                    if (idCompany && idProduct) {
                        const upsertProductCharacteristic = {
                            id_prime: productCharacteristic.id,
                            id_empresa: idCompany,
                            id_produto: idProduct,
                            categoria: productCharacteristic.categoria,
                            codigo: productCharacteristic.codigo,
                            descricao: productCharacteristic.descricao,
                            fixo: productCharacteristic.fixo,
                            deletedAt: productCharacteristic.deleted_at,
                        };
                        if (productCharacteristicExists) {
                            await productCharacteristicExists.merge(upsertProductCharacteristic).save();
                            productCharacteristicsToSync.push(productCharacteristic.id);
                        }
                        else {
                            await ProdutoCaracteristica.create(upsertProductCharacteristic);
                            productCharacteristicsToSync.push(productCharacteristic.id);
                        }
                    }
                }
                if (productCharacteristicsToSync && productCharacteristicsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'PRODUTO CARACTERISTICA' }, { updated_at: DateTime.now() });
                }
                console.log(`${productCharacteristicsToSync.length} PRODUTO CARACTERISTICA(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO CARACTERISTICA(S)', error);
        }
    }
}
//# sourceMappingURL=produto_caracteristica.js.map