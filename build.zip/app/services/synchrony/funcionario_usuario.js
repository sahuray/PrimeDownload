import axios from 'axios';
import FuncionarioUsuario from '#models/funcionario_usuario';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import { apiURL } from '../index.js';
import findEmployeeByIdPrime from '../../../functions/find_employee_by_id_prime.js';
export default class FuncionarioUsuarioService {
    async getUsers() {
        try {
            let updatedAt = null;
            const sincronia = await Sincronia.query().where('nome_tabela', 'USUARIO').first();
            if (sincronia) {
                updatedAt = sincronia.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/user', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAt,
                },
            });
            const users = response.data.users;
            const empresaId = await findCompanyByIdPrime(response.data.empresaId);
            console.log(`${users.length} USUÁRIO(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (users && users.length > 0) {
                const usersToSync = [];
                for (const user of users) {
                    const userExists = await FuncionarioUsuario.findBy('id_prime', user.id);
                    let idEmployee = await findEmployeeByIdPrime(user.funcionario_id);
                    const data = {
                        id_prime: user.id,
                        usuario: user.username,
                        senha: user.password,
                        ultimaalteracao: new Date(),
                        idFuncionario: idEmployee,
                        ...(empresaId ? { empresaId } : {}),
                    };
                    if (userExists) {
                        await userExists.merge(data).save();
                        usersToSync.push(user.username);
                    }
                    else {
                        await FuncionarioUsuario.create(data);
                        usersToSync.push(user.username);
                    }
                }
                if (usersToSync && usersToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'USUARIO' }, { updated_at: DateTime.now() });
                }
                console.log(`${usersToSync.length} USUÁRIOS SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('Erro ao buscar usuários:', error);
        }
    }
}
//# sourceMappingURL=funcionario_usuario.js.map