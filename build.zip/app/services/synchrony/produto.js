import axios from 'axios';
import Produto from '#models/prime_produto';
import Grupo from '#models/grupo';
import findCategorySectorByIdPrime from '../../../functions/find_category_sector_by_id_prime.js';
import findCategorySubGroupByIdPrime from '../../../functions/find_category_sub_group_by_id_prime.js';
import findCategoryGroupByIdPrime from '../../../functions/find_category_group_by_id_prime.js';
import findCategoryLineByIdPrime from '../../../functions/find_category_line_by_id_prime.js';
import findBrandByIdPrime from '../../../functions/find_brand_by_id_prime.js';
import findUnitByIdPrime from '../../../functions/find_unit_by_id_prime.js';
import findNutricionalInformationByIdPrime from '../../../functions/find_nutritional_information_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoService {
    async syncProduct() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_produto')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const products = response.data.products;
            console.log(`${products.length} PRODUTO(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (products && products.length > 0) {
                const productsToSync = [];
                let idGroup = await Grupo.query().where('id', 1).first();
                if (idGroup) {
                    for (const product of products) {
                        const productExists = await Produto.findBy('id_prime', product.id);
                        let idProdCategorySector = await findCategorySectorByIdPrime(product.product_category_section_id);
                        let idProdCategoryGroup = await findCategoryGroupByIdPrime(product.product_category_group_id);
                        let idProdCategorySubGroup = await findCategorySubGroupByIdPrime(product.product_category_subgroup_id);
                        let idProdCategoryLine = await findCategoryLineByIdPrime(product.product_category_line_id);
                        let idBrand = await findBrandByIdPrime(product.brand_id);
                        let idUnitCommercial = await findUnitByIdPrime(product.commercial_unit_id);
                        let idUnitTaxable = await findUnitByIdPrime(product.tributary_unit_id);
                        let idProdNutricionalInformation = await findNutricionalInformationByIdPrime(product.product_nutritional_information_id);
                        const upsertProduct = {
                            id_prime: product.id,
                            id_grupo: idGroup.id,
                            id_unidade_comercial: idUnitCommercial,
                            id_unidade_tributavel: idUnitTaxable,
                            id_marca: idBrand,
                            id_produto_informacao_nutricional: idProdNutricionalInformation,
                            id_produto_categoria_setor: idProdCategorySector,
                            id_produto_categoria_grupo: idProdCategoryGroup,
                            id_produto_categoria_subgrupo: idProdCategorySubGroup,
                            id_produto_categoria_linha: idProdCategoryLine,
                            sync_prime: false,
                            deleted_at: product.deleted_at,
                            codigo_barra_1: product.codigo_barra_1,
                            codigo_barra_2: product.codigo_barra_2,
                            code: product.code,
                            packing_weight: product.packing_weight,
                            packing_depth: product.packing_depth,
                            packing_heigth: product.packing_heigth,
                            packing_width: product.packing_width,
                            reference: product.reference,
                            name: product.name,
                            short_name: product.short_name,
                            use_gride: product.use_gride,
                            characteristics: product.characteristics,
                        };
                        if (productExists) {
                            await productExists.merge(upsertProduct).save();
                            productsToSync.push(product.id);
                        }
                        else {
                            await Produto.create(upsertProduct);
                            productsToSync.push(product.id);
                        }
                    }
                }
                if (productsToSync && productsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_produto' }, { updated_at: DateTime.now() });
                }
                console.log(`${productsToSync.length} PRODUTO(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) PRODUTO(S)', error);
        }
    }
}
//# sourceMappingURL=produto.js.map