import axios from 'axios';
import ProdutoEstoque from '#models/prime_produto_estoque';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoEstoqueService {
    async syncProdutoEstoque() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'ESTOQUE')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_inventory', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productInventories = response.data.productInventories;
            console.log(`${productInventories.length} PRODUTO ESTOQUE ENCONTRADOS PARA SINCRONIZAR`);
            if (productInventories && productInventories.length > 0) {
                const productInventoriesToSync = [];
                for (const productInventory of productInventories) {
                    const productInventoryExists = await ProdutoEstoque.findBy('id_prime', productInventory.id);
                    let idCompany = await findCompanyByIdPrime(productInventory.company_id);
                    let idProduct = await findProductByIdPrime(productInventory.product_id);
                    if (idProduct && idCompany) {
                        const upsertproductInventory = {
                            id_prime: productInventory.id,
                            id_empresa: idCompany,
                            id_produto: idProduct,
                            description: productInventory.description,
                            ecommerce: productInventory.ecommerce,
                            main_inventory: productInventory.main_inventory,
                            quantity: productInventory.quantity,
                        };
                        if (productInventoryExists) {
                            await productInventoryExists.merge(upsertproductInventory).save();
                            productInventoriesToSync.push(productInventory.id);
                        }
                        else {
                            await ProdutoEstoque.create(upsertproductInventory);
                            productInventoriesToSync.push(productInventory.id);
                        }
                    }
                }
                if (productInventoriesToSync && productInventoriesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'ESTOQUE' }, { updated_at: DateTime.now() });
                }
                console.log(`${productInventoriesToSync.length} PRODUTO ESTOQUE SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO ESTOQUE', error);
        }
    }
}
//# sourceMappingURL=produto_estoque.js.map