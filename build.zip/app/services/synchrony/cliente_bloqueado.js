import axios from 'axios';
import { apiURL } from '../index.js';
import ClienteBloqueado from '#models/prime_cliente_bloqueado';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
export default class ClienteBloqueadoService {
    async syncClienteBloqueado() {
        try {
            await ClienteBloqueado.query().delete();
            const response = await axios.get(apiURL + '/v1/core/blocked_customers', {
                params: {
                    key: process.env.API_CORE_KEY,
                },
            });
            const blockedCustomersFiltred = response.data.blockedCustomersFiltred;
            console.log(`${blockedCustomersFiltred.length} CLIENTE BLOQUEADO ENCONTRADOS PARA SINCRONIZAR`);
            if (blockedCustomersFiltred && blockedCustomersFiltred.length > 0) {
                const blockedCustomersToSync = [];
                for (const blockedCustomer of blockedCustomersFiltred) {
                    const blockedCustomerExists = await ClienteBloqueado.findBy('id_prime', blockedCustomer);
                    let idCompany = await findCompanyByIdPrime(String(blockedCustomer));
                    if (idCompany) {
                        const upsertBlockedCustomer = {
                            id_prime: blockedCustomer,
                            id_empresa: idCompany,
                        };
                        if (blockedCustomerExists) {
                            await blockedCustomerExists.merge(upsertBlockedCustomer).save();
                            blockedCustomersToSync.push(blockedCustomer);
                        }
                        else {
                            await ClienteBloqueado.create(upsertBlockedCustomer);
                            blockedCustomersToSync.push(blockedCustomer);
                        }
                    }
                }
                if (blockedCustomersToSync && blockedCustomersToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'CLIENTE BLOQUEADOS' }, { updated_at: DateTime.now() });
                }
                console.log(`${blockedCustomersToSync.length} CLIENTE BLOQUEADO SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.error('ERRO AS BUSCAR AS CLIENTE BLOQUEADOS', err);
        }
    }
}
//# sourceMappingURL=cliente_bloqueado.js.map