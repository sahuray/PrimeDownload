import PrimeProdutoCategoriaLinha from '#models/prime_produto_categoria_linha';
import axios from 'axios';
import findCategorySubGroupByIdPrime from '../../../functions/find_category_sub_group_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdCategoriaLinhaService {
    async syncProdCategoryLine() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PRODUTO CATEGORIA LINHA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_category_line', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const marketingLines = response.data.marketingLines;
            console.log(`${marketingLines.length} CATEGORIA (LINHA) ENCNTRADOS PARA SINCRONIZAR`);
            if (marketingLines && marketingLines.length > 0) {
                const marketingLineToSync = [];
                for (const marketingLine of marketingLines) {
                    const marketingLineExists = await PrimeProdutoCategoriaLinha.findBy('id_prime', marketingLine.id);
                    let idProdCategorySubGroup = await findCategorySubGroupByIdPrime(marketingLine.product_category_subgroup_id);
                    if (idProdCategorySubGroup) {
                        const upsertmarketingLine = {
                            id_prime: marketingLine.id,
                            name: marketingLine.name,
                            id_produto_categoria_subgrupo: idProdCategorySubGroup,
                            deleted_at: marketingLine.deleted_at,
                            sync_prime: false,
                        };
                        if (marketingLineExists) {
                            await marketingLineExists.merge(upsertmarketingLine).save();
                            marketingLineToSync.push(marketingLine.id);
                        }
                        else {
                            await PrimeProdutoCategoriaLinha.create(upsertmarketingLine);
                            marketingLineToSync.push(marketingLine.id);
                        }
                    }
                }
                if (marketingLineToSync && marketingLineToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'PRODUTO CATEGORIA LINHA' }, { updated_at: DateTime.now() });
                }
                console.log(`${marketingLineToSync.length} CATEGORIA (LINHA) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) CATEGORIA (LINHA)', error);
        }
    }
}
//# sourceMappingURL=produto_categoria_linha.js.map