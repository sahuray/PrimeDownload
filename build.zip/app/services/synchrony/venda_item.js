import Sincronia from '#models/sincronia';
import VendaItem from '#models/venda_item';
import axios from 'axios';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class VendaItemService {
    async syncSaleItems() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'VENDA ITEM')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/sale_product', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const saleProducts = response.data.saleProducts;
            console.log(`${saleProducts.length} VENDA ITENS ENCONTRADOS PARA SINCRONIZAR`);
            if (saleProducts && saleProducts.length > 0) {
                const saleProductsToSync = [];
                for (const saleProduct of saleProducts) {
                    const saleProductExists = await VendaItem.findBy('id_prime', saleProduct.id);
                    let idProduct = await findProductByIdPrime(saleProduct.product_id);
                    let idSale = await findSaleByIdPrime(saleProduct.sale_id);
                    if (idProduct && idSale) {
                        const upsertSaleProduct = {
                            idPrime: saleProduct.id,
                            idProduto: idProduct,
                            idVenda: idSale,
                            status: saleProduct.status,
                            productDescription: saleProduct.productDescription,
                            comissaoPorcentagem: saleProduct.comissaoPorcentagem,
                            saledQuantity: saleProduct.saledQuantity,
                            unitaryValue: saleProduct.unitaryValue,
                            totalValue: saleProduct.totalValue,
                            totalDescountValue: saleProduct.totalDescountValue,
                            codigo: saleProduct.codigo,
                            ncm: saleProduct.ncm,
                            cfop: saleProduct.cfop,
                            csosn: saleProduct.csosn,
                            aliquotIcms: saleProduct.aliquotIcms,
                            listar_na_comanda: saleProduct.listar_na_comanda,
                            id_venda_anterior: saleProduct.id_venda_anterior,
                            id_comanda: saleProduct.id_comanda,
                            deletedAt: saleProduct.deletedAt,
                        };
                        if (saleProductExists) {
                            await saleProductExists.merge(upsertSaleProduct).save();
                            saleProductsToSync.push(saleProduct.id);
                        }
                        else {
                            await VendaItem.create(upsertSaleProduct);
                            saleProductsToSync.push(saleProduct.id);
                        }
                    }
                }
                if (saleProductsToSync && saleProductsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'VENDA ITEM' }, { updated_at: DateTime.now() });
                }
                console.log(`${saleProductsToSync.length} VENDA ITENS SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.error('ERRO AS BUSCAR A VENDA ITENS', err);
        }
    }
}
//# sourceMappingURL=venda_item.js.map