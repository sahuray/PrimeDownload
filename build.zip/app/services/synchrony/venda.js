import axios from 'axios';
import Venda from '#models/venda';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import Grupo from '#models/grupo';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import findMovementCashDeskByIdPrime from '../../../functions/find_movement_cash_desk_by_id_prime.js';
import findTerminalByIdPrime from '../../../functions/find_terminal_by_id_prime.js';
import findEmployeeByIdPrime from '../../../functions/find_employee_by_id_prime.js';
import { apiURL } from '../index.js';
export default class VendaService {
    async syncSales() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'VENDA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/sale', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const sales = response.data.sales;
            console.log(`${sales.length} VENDA(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (sales && sales.length > 0) {
                const salesToSync = [];
                let idGroup = await Grupo.query().where('id', 1).first();
                if (idGroup) {
                    for (const sale of sales) {
                        const saleExists = await Venda.findBy('id_prime', sale.id);
                        let idUserCreatedBy = await findUserByIdPrime(sale.user_created_id);
                        let idUserDeletedBy = await findUserByIdPrime(sale.user_deleted_id);
                        let idCompany = await findCompanyByIdPrime(sale.cliente_id);
                        let idMovementCashDesk = await findMovementCashDeskByIdPrime(sale.caixa_movimento_id);
                        let idTerminal = await findTerminalByIdPrime(sale.terminal_id);
                        let idSeller = await findEmployeeByIdPrime(sale.vendedor_id);
                        let idClient = await findCompanyByIdPrime(sale.cliente_id);
                        if (idTerminal) {
                            const upsertSale = {
                                idPrime: sale.id,
                                idGrupo: idGroup.id,
                                idCliente: idClient,
                                idCaixaMovimento: idMovementCashDesk,
                                idUsuarioInativar: idUserDeletedBy,
                                idUsuarioCriacao: idUserCreatedBy,
                                idTerminal: idTerminal,
                                idVendedor: idSeller,
                                idEmpresa: idCompany,
                                comissaoPorcentagem: sale.comissaoPorcentagem,
                                totalValue: sale.totalValue,
                                totalDescountValue: sale.totalDescountValue,
                                cpf: sale.cpf,
                                motivoCancelamento: sale.motivoCancelamento,
                                codigo: sale.codigo,
                                observacao: sale.observacao,
                                finalizado: sale.finalizado,
                                deletedAt: sale.deletedAt,
                                code: sale.code,
                                satXml: sale.satXml,
                                satXmlPath: sale.satXmlPath,
                                satNumeroSerie: sale.satNumeroSerie,
                                coo: sale.coo,
                                satXmlCancelamento: sale.satXmlCancelamento,
                                satXmlPathCancelamento: sale.satXmlPathCancelamento,
                                cooCancelamento: sale.cooCancelamento,
                            };
                            if (saleExists) {
                                await saleExists.merge(upsertSale).save();
                                salesToSync.push(sale.id);
                            }
                            else {
                                await Venda.create(upsertSale);
                                salesToSync.push(sale.id);
                            }
                        }
                    }
                    if (salesToSync && salesToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'VENDA' }, { updated_at: DateTime.now() });
                    }
                }
                console.log(`${salesToSync.length} Venda(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR OS VendaS', error);
        }
    }
}
//# sourceMappingURL=venda.js.map