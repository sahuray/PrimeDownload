import Sincronia from '#models/sincronia';
import VendaPagamentoAPrazo from '#models/venda_pagamento_a_prazo';
import { DateTime } from 'luxon';
import axios from 'axios';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findSaleMethodPaymentByIdPrime from '../../../functions/find_sale_payment_method_by_id_prime.js';
import findPaymentMethodConditionByIdPrime from '../../../functions/find_payment_method_condition_by_id_prime.js';
import { apiURL } from '../index.js';
export default class VendaPagamentoAPrazoService {
    async syncSaleTermPayments() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'VENDA PAGAMENTO A PRAZO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/sale_term_payment', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const saleTermPayments = response.data.saleTermPayments;
            console.log(`${saleTermPayments.length} VENDA PAGAMENTO A PRAZO ENCONTRADOS PARA SINCRONIZAR`);
            if (saleTermPayments && saleTermPayments.length > 0) {
                const saleTermPaymentsToSync = [];
                for (const saleTermPayment of saleTermPayments) {
                    const saleTermPaymentExists = await VendaPagamentoAPrazo.findBy('id_prime', saleTermPayment.id);
                    let idSaleMethodPayment = await findSaleMethodPaymentByIdPrime(saleTermPayment.method_id);
                    let idSaleMethodPaymentCondition = await findPaymentMethodConditionByIdPrime(saleTermPayment.condition_payment_id);
                    let idSale = await findSaleByIdPrime(saleTermPayment.sale_id);
                    if (idSale && idSaleMethodPayment) {
                        const upsertsaleTermPayment = {
                            idPrime: saleTermPayment.id,
                            idVenda: idSale,
                            idVendaFormaDePagamento: idSaleMethodPayment,
                            idFormaDePagamentoCondicao: idSaleMethodPaymentCondition,
                            installmentValue: saleTermPayment.installmentValue,
                            installmentDate: saleTermPayment.installmentDate,
                            deletedAt: saleTermPayment.deletedAt,
                        };
                        if (saleTermPaymentExists) {
                            await saleTermPaymentExists.merge(upsertsaleTermPayment).save();
                            saleTermPaymentsToSync.push(saleTermPayment.id);
                        }
                        else {
                            await VendaPagamentoAPrazo.create(upsertsaleTermPayment);
                            saleTermPaymentsToSync.push(saleTermPayment.id);
                        }
                    }
                }
                if (saleTermPaymentsToSync && saleTermPaymentsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'VENDA PAGAMENTO A PRAZO' }, { updated_at: DateTime.now() });
                }
                console.log(`${saleTermPaymentsToSync.length} VENDA PAGAMENTO A PRAZO SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.error('ERRO AS BUSCAR A VENDA PAGAMENTO A PRAZO', err);
        }
    }
}
//# sourceMappingURL=venda_pagamento_a_prazo.js.map