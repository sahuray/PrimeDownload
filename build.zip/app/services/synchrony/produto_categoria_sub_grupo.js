import axios from 'axios';
import PrimeProdutoCategoriaSubGrupo from '#models/prime_produto_categoria_subgrupo';
import findCategoryGroupByIdPrime from '../../../functions/find_category_group_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdCategoriaSubGrupoService {
    async syncProdCategorySubGroup() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_produto_categoria_subgrupo')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_category_sub_group', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const marketingSubGroups = response.data.marketingSubGroups;
            console.log(`${marketingSubGroups.length} CATEGORIA (SUB-GRUPO) ENCNTRADOS PARA SINCRONIZAR`);
            if (marketingSubGroups && marketingSubGroups.length > 0) {
                const marketingSubGroupToSync = [];
                for (const marketingSubGroup of marketingSubGroups) {
                    const marketingSubGroupExists = await PrimeProdutoCategoriaSubGrupo.findBy('id_prime', marketingSubGroup.id);
                    let idProdCategoryGroup = await findCategoryGroupByIdPrime(marketingSubGroup.product_category_group_id);
                    if (idProdCategoryGroup) {
                        const upsertmarketingSubGroup = {
                            id_prime: marketingSubGroup.id,
                            name: marketingSubGroup.name,
                            id_produto_categoria_grupo: idProdCategoryGroup,
                            deleted_at: marketingSubGroup.deleted_at,
                            sync_prime: false,
                        };
                        if (marketingSubGroupExists) {
                            await marketingSubGroupExists.merge(upsertmarketingSubGroup).save();
                            marketingSubGroupToSync.push(marketingSubGroup.id);
                        }
                        else {
                            await PrimeProdutoCategoriaSubGrupo.create(upsertmarketingSubGroup);
                            marketingSubGroupToSync.push(marketingSubGroup.id);
                        }
                    }
                }
                if (marketingSubGroupToSync && marketingSubGroupToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_produto_categoria_subgrupo' }, { updated_at: DateTime.now() });
                }
                console.log(`${marketingSubGroupToSync.length} CATEGORIA (SUB-GRUPO) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) CATEGORIA (GRUPO)', error);
        }
    }
}
//# sourceMappingURL=produto_categoria_sub_grupo.js.map