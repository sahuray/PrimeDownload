import axios from 'axios';
import Terminal from '#models/terminal';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import { apiURL } from '../index.js';
export default class TerminalService {
    async syncTerminals() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'TERMINAL')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/terminal', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const terminals = response.data.terminals;
            console.log(`${terminals.length} TERMINAL(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (terminals && terminals.length > 0) {
                const terminalsToSync = [];
                for (const terminal of terminals) {
                    const terminalExists = await Terminal.findBy('id_prime', terminal.id);
                    let idCompany = await findCompanyByIdPrime(terminal.empresa_id);
                    if (idCompany) {
                        const upsertTerminal = {
                            id_prime: terminal.id,
                            id_empresa: idCompany,
                            idVisitor: terminal.visitor_id,
                            numero: terminal.numero,
                            nome: terminal.nome,
                            caixa_destino: terminal.caixa_destino,
                            liberarEditarValor: terminal.liberar_editar_valor,
                            solicitarQuantidade: terminal.solicitar_quantidade,
                            deleted: terminal.deleted,
                            nfce: terminal.nfce,
                            tipoImpressaoSatNfce: terminal.tipo_impressao_sat_nfce,
                            desativarConsultaProduto: terminal.desativar_consulta_produto,
                            exigirSenhaVendedor: terminal.exigir_senha_vendedor,
                            solicitarCodigoVendedor: terminal.solicitar_codigo_vendedor,
                            tiposDeImpressaoEscolhaImpressora: terminal.tipos_de_impressao_escolha_impressora,
                            pedirObsFechamentoOrcamento: terminal.pedir_obs_fechamento_orcamento,
                            selecionarImpressoraOrcamento: terminal.selecionar_impressora_orcamento,
                            imprimirItensCupom2Linhas: terminal.imprimir_itens_cupom_2_linhas,
                            solicitarConfirmacaoDoValorDoItem: terminal.solicitar_confirmacao_do_valor_do_item,
                            terminalPrincipal: terminal.terminal_principal,
                        };
                        if (terminalExists) {
                            await terminalExists.merge(upsertTerminal).save();
                            terminalsToSync.push(terminal.id);
                        }
                        else {
                            await Terminal.create(upsertTerminal);
                            terminalsToSync.push(terminal.id);
                        }
                    }
                }
                if (terminalsToSync && terminalsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'TERMINAL' }, { updated_at: DateTime.now() });
                }
                console.log(`${terminalsToSync.length} TERMINAL(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR OS terminals', error);
        }
    }
}
//# sourceMappingURL=terminal.js.map