import Sincronia from '#models/sincronia';
import VendaSubItem from '#models/venda_sub_item';
import { DateTime } from 'luxon';
import axios from 'axios';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findSaleItemByIdPrime from '../../../functions/find_sale_item_by_id_prime.js';
import { apiURL } from '../index.js';
export default class VendaSubItemService {
    async syncSaleSubItems() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_venda_sub_item')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/sale_sub_product', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const saleSubProducts = response.data.saleSubProducts;
            console.log(`${saleSubProducts.length} VENDA SUB PRODUTO ENCONTRADOS PARA SINCRONIZAR`);
            if (saleSubProducts && saleSubProducts.length > 0) {
                const saleSubProductsToSync = [];
                for (const saleSubProduct of saleSubProducts) {
                    const saleSubProductExists = await VendaSubItem.findBy('id_prime', saleSubProduct.id);
                    let idSale = await findSaleByIdPrime(saleSubProduct.id_sale);
                    let idProduct = await findProductByIdPrime(saleSubProduct.id_product);
                    let idSalePorduct = await findSaleItemByIdPrime(saleSubProduct.id_sale_product);
                    if (idSale && idProduct && idSalePorduct) {
                        const upsertsaleSubProduct = {
                            idPrime: saleSubProduct.id,
                            idVenda: idSale,
                            idVendaItem: idSalePorduct,
                            idProduto: idProduct,
                            status: saleSubProduct.status,
                            descricao: saleSubProduct.descricao,
                            quantidade: saleSubProduct.quantidade,
                            valorUnitario: saleSubProduct.valorUnitario,
                            valorTotal: saleSubProduct.valorTotal,
                            valorDesconto: saleSubProduct.valorDesconto,
                        };
                        if (saleSubProductExists) {
                            await saleSubProductExists.merge(upsertsaleSubProduct).save();
                            saleSubProductsToSync.push(saleSubProduct.id);
                        }
                        else {
                            await VendaSubItem.create(upsertsaleSubProduct);
                            saleSubProductsToSync.push(saleSubProduct.id);
                        }
                    }
                }
                if (saleSubProductsToSync && saleSubProductsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_venda_sub_item' }, { updated_at: DateTime.now() });
                }
                console.log(`${saleSubProductsToSync.length} VENDA SUB PRODUTO SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.error('ERRO AS BUSCAR A VENDA SUB PRODUTO', err);
        }
    }
}
//# sourceMappingURL=venda_sub_item.js.map