import axios from 'axios';
import Endereco from '#models/endereco';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import TaxaDeEntrega from '#models/taxa_de_entrega';
export default class EnderecoService {
    async syncAddresses() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'ENDERECO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/address', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const addresses = response.data.addresses;
            console.log(`${addresses.length} ENDERECO(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (addresses && addresses.length > 0) {
                const addressToSync = [];
                for (const address of addresses) {
                    const addressExists = await Endereco.findBy('id_prime', address.id);
                    if (address.tipo_relacionamento === 'empresa') {
                        let idCompany = await findCompanyByIdPrime(address.id_fk);
                        let idTaxaDeEntrega = await TaxaDeEntrega.findBy('id_prime', address.id_taxa_de_entrega);
                        if (idCompany) {
                            const upsertaddress = {
                                id_prime: address.id,
                                id_fk: idCompany,
                                tipo_relacionamento: address.tipo_relacionamento,
                                tipo: address.tipo,
                                cep: address.cep,
                                uf: address.uf,
                                cidade: address.cidade,
                                bairro: address.bairro,
                                logradouro: address.logradouro,
                                numero: address.numero,
                                complemento: address.complemento,
                                codigo_cidade: address.codigo_cidade,
                                codigo_uf: address.codigo_uf,
                                referencia: address.referencia,
                                sync_prime: true,
                                idTaxaDeEntrega: idTaxaDeEntrega?.id || null,
                            };
                            if (addressExists) {
                                await addressExists.merge(upsertaddress).save();
                                addressToSync.push(address.id);
                            }
                            else {
                                await Endereco.create(upsertaddress);
                                addressToSync.push(address.id);
                            }
                        }
                    }
                }
                if (addressToSync && addressToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'ENDERECO' }, { updated_at: DateTime.now() });
                }
                console.log(`${addressToSync.length} ENDERECO(S) SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS ENDERECO(S)', error);
        }
    }
}
//# sourceMappingURL=endereco.js.map