import axios from 'axios';
import Imagem from '#models/prime_imagem';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import findTerminalByIdPrime from '../../../functions/find_terminal_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ImagemService {
    async syncImagem() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'IMAGEM')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/image', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const imagens = response.data.imagens;
            console.log(`${imagens.length} IMAGEM ENCONTRADOS PARA SINCRONIZAR`);
            if (imagens && imagens.length > 0) {
                const imagensToSync = [];
                await Imagem.query().delete();
                for (const imagem of imagens) {
                    const imagemExists = await Imagem.findBy('id_prime', imagem.id);
                    let idCompany = await findCompanyByIdPrime(imagem.id_empresa);
                    let idTerminal = await findTerminalByIdPrime(imagem.id_terminal);
                    let idUser = await findUserByIdPrime(imagem.id_usuario);
                    if (idCompany) {
                        const upsertImagem = {
                            idPrime: imagem.id,
                            idEmpresa: idCompany,
                            idTerminal: idTerminal,
                            idUsuario: idUser,
                            nomeDoArquivo: imagem.nome_do_arquivo,
                            caminhoDoArquivo: imagem.caminho_do_arquivo,
                            tipo: imagem.tipo,
                            ordemDeExecucao: imagem.ordem_de_execucao,
                            tamanhoDoArquivo: imagem.tamanho_do_arquivo,
                            extensaoDoArquivo: imagem.extensao_do_arquivo,
                            descricao: imagem.descricao,
                            base64: imagem.base64,
                            duracaoExibicaoMinutos: imagem.duracao_exibicao_minutos,
                            duracaoExibicaoSegundos: imagem.duracao_exibicao_segundos,
                            dimensoes: imagem.dimensoes,
                            status: imagem.status,
                            fixo: imagem.fixo,
                            createdAt: imagem.created_at,
                            updatedAt: imagem.updated_at,
                        };
                        if (imagemExists) {
                            await imagemExists.merge(upsertImagem).save();
                            imagensToSync.push(imagem.id);
                        }
                        else {
                            await Imagem.create(upsertImagem);
                            imagensToSync.push(imagem.id);
                        }
                    }
                }
                if (imagensToSync && imagensToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'IMAGEM' }, { updated_at: DateTime.now() });
                }
                console.log(`${imagensToSync.length} IMAGEM SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) IMAGEM', error);
        }
    }
}
//# sourceMappingURL=imagem.js.map