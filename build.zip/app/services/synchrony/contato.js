import axios from 'axios';
import Contato from '#models/contato';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
export default class ContatoService {
    async syncContact() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_contato')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/contact', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const contacts = response.data.contacts;
            console.log(`${contacts.length} CONTATO(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (contacts && contacts.length > 0) {
                const contactsToSync = [];
                for (const contact of contacts) {
                    const contactExists = await Contato.findBy('id_prime', contact.id);
                    if (contact.tipo_relacionamento === 'empresa') {
                        let idCompany = await findCompanyByIdPrime(contact.id_fk);
                        if (idCompany) {
                            const upsertContact = {
                                id_prime: contact.id,
                                id_fk: idCompany,
                                tipo_relacionamento: contact.tipo_relacionamento,
                                tipo_contato: contact.tipo_contato,
                                email: contact.email,
                                nome: contact.nome,
                                telefone: contact.telefone,
                                observacao: contact.observacao,
                                deletedAt: contact.deletedAt,
                            };
                            if (contactExists) {
                                await contactExists.merge(upsertContact).save();
                                contactsToSync.push(contact.id);
                            }
                            else {
                                await Contato.create(upsertContact);
                                contactsToSync.push(contact.id);
                            }
                        }
                    }
                }
                if (contactsToSync && contactsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_contato' }, { updated_at: DateTime.now() });
                }
                console.log(`${contactsToSync.length} CONTATOS(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR OS CONTATOS(S)', error);
        }
    }
}
//# sourceMappingURL=contato.js.map