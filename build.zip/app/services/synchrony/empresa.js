import axios from 'axios';
import Empresa from '#models/empresa';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import Grupo from '#models/grupo';
import { apiURL } from '../index.js';
export default class EmpresaService {
    async syncCompanies() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'EMPRESA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/company', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const companies = response.data.companies;
            console.log(`${companies.length} EMPRESA(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (companies && companies.length > 0) {
                const companiesToSync = [];
                let idGroup = await Grupo.query().where('id', 1).first();
                if (idGroup) {
                    for (const company of companies) {
                        let idEmployeeResponsibleRegister = await findUserByIdPrime(company.user_id_responsavel_cadastro);
                        let idEmployeeResponsibleAlter = await findUserByIdPrime(company.user_id_responsavel_ultima_alteracao);
                        const companyExists = await Empresa.findBy('id_prime_empresa', company.id);
                        const upsertCompany = {
                            id_prime_empresa: company.id,
                            id_focus: company.id_focus,
                            focus_token_producao: company.focus_token_producao,
                            focus_token_homologacao: company.focus_token_homologacao,
                            url_logo: company.url_logo,
                            regime_tributario: company.regime_tributario,
                            regime_especial_tributacao: company.regime_especial_tributacao,
                            grupo_id: idGroup.id,
                            funcionarioUsuarioIdResponsavelCadastro: idEmployeeResponsibleRegister,
                            funcionarioUsuarioIdResponsavelUltimaAlteracao: idEmployeeResponsibleAlter,
                            situacao_cadastral: company.situacao_cadastral,
                            tipo: company.tipo,
                            origem: company.origem,
                            descricao_servico: company.descricao_servico,
                            ativo: company.ativo,
                            nome_fantasia: company.nome_fantasia,
                            razao_social: company.razao_social,
                            apelido: company.apelido,
                            emissao_nfse_nothos_prime_completo: company.emissao_nfse_nothos_prime_completo || false,
                            emissao_nfce_nothos_prime_completo: company.emissao_nfce_nothos_prime_completo || false,
                            emissao_nfe_nothos_prime_completo: company.emissao_nfe_nothos_prime_completo || false,
                            cnpj_aguardando: company.cnpj_aguardando,
                            ie_isento: company.ie_isento,
                            ie_aguardando: company.ie_aguardando,
                            im_isento: company.im_isento,
                            im_aguardando: company.im_aguardando,
                            prazo_bloqueado: company.prazo_bloqueado,
                            cnpj_cpf: company.cnpj_cpf,
                            ie_rg: company.ie_rg,
                            im: company.im,
                            suframa: company.suframa,
                            sexo: company.sexo,
                            email: company.email,
                            telefone: company.telefone,
                            representante_nome: company.representante_nome,
                            representante_tipo: company.representante_tipo,
                            representante_cpf: company.representante_cpf,
                            representante_rg: company.representante_rg,
                            representante_celular: company.representante_celular,
                            representante_email: company.representante_email,
                            representante_data_nascimento: company.representante_data_nascimento,
                            cartao_preferencial_utiliza: company.cartao_preferencial_utiliza,
                            cartao_preferencial_numero: company.cartao_preferencial_numero,
                            cartao_preferencial_saldo: company.cartao_preferencial_saldo
                                ? Number(company.cartao_preferencial_saldo)
                                : 0,
                            prazo_tipo: company.prazo_tipo,
                            prazo_dias: Math.round(company.prazo_dias || 0),
                            prazo_limite: Math.round(company.prazo_limite || 0),
                            quantidade_dia_orcamento: Math.round(company.quantidade_dia_orcamento || 0),
                            codigo: company.codigo,
                            cliente_athos: company.cliente_athos,
                            quantity_decimal_places: company.quantity_decimal_places,
                            price_decimal_places: company.price_decimal_places,
                            rounding_type: company.rounding_type,
                            user_repos_id: company.user_repos_id,
                            permitir_item_duplicado: company.permitir_item_duplicado,
                            permitir_ajustar_quantidade: company.permitir_ajustar_quantidade,
                            associar_cliente_orcamento: company.associar_cliente_orcamento,
                            pedir_observacao_venda: company.pedir_observacao_venda,
                            pedir_observacao_orcamento: company.pedir_observacao_orcamento,
                            estoque_zerado_orcamento: company.estoque_zerado_orcamento,
                            associar_transportadora: company.associar_transportadora,
                            exibir_observacao_cliente: company.exibir_observacao_cliente,
                            utilizar_data_entrega: company.utilizar_data_entrega,
                            periodo_orcamento: company.periodo_orcamento,
                            controle_estoque_reservado: company.controle_estoque_reservado,
                            vencimento_orcamento: company.vencimento_orcamento,
                            data_vencimento_orcamento: company.data_vencimento_orcamento,
                            desconto_maximo: company.desconto_maximo,
                            associar_cliente_venda_inicio: company.associar_cliente_venda_inicio,
                            associar_cliente_venda_final: company.associar_cliente_venda_final,
                            aceitar_cpf_invalido: company.aceitar_cpf_invalido,
                            pedir_codigo_vendedor: company.pedir_codigo_vendedor,
                            limite_items_venda: company.limite_items_venda,
                            ponto_sangria: company.ponto_sangria ? Number(company.ponto_sangria) : 0,
                            focar_preco_unitario: company.focar_preco_unitario,
                            permitir_escolha_preco_venda: company.permitir_escolha_preco_venda,
                            informar_diferenca_entre_valores: company.informar_diferenca_entre_valores,
                            utiliza_balanca_retaguarda: company.utiliza_balanca_retaguarda,
                            quantidade_digitos: company.quantidade_digitos,
                            tipo_codigo_barras: company.tipo_codigo_barras,
                            observacao_venda: company.observacao_venda,
                            observacao_orcamento: company.observacao_orcamento,
                            site: company.site,
                            carga_portal: company.carga_portal,
                            permission_show_vehicular_plate: company.permission_show_vehicular_plate,
                            deletedAt: company.deleted_at,
                            data_constituicao: company.data_constituicao,
                            aniversario: company.aniversario,
                            sync_prime: true,
                        };
                        if (companyExists) {
                            await companyExists.merge(upsertCompany).save();
                            companiesToSync.push(company.id);
                        }
                        else {
                            await Empresa.create(upsertCompany);
                            companiesToSync.push(company.id);
                        }
                    }
                    if (companiesToSync && companiesToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'EMPRESA' }, { updated_at: DateTime.now() });
                    }
                }
                console.log(`${companiesToSync.length} EMPRESA(S) SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS EMPRESA(S)', error);
        }
    }
}
//# sourceMappingURL=empresa.js.map