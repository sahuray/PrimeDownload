import Sincronia from '#models/sincronia';
import VendaFormaDePagamento from '#models/venda_forma_de_pagamento';
import { DateTime } from 'luxon';
import axios from 'axios';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findPaymentMethodByIdPrime from '../../../functions/find_payment_method_by_id_prime.js';
import { apiURL } from '../index.js';
export default class VendaFormaDePagamentoService {
    async syncSaleMethodPayments() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_venda_forma_de_pagamento')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/sale_method_payment', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const saleMethodPayments = response.data.saleMethodPayments;
            console.log(`${saleMethodPayments.length} VENDA FORMA DE PAGAMENTO ENCONTRADOS PARA SINCRONIZAR`);
            if (saleMethodPayments && saleMethodPayments.length > 0) {
                const saleMethodPaymentsToSync = [];
                for (const saleMethodPayment of saleMethodPayments) {
                    const saleMethodPaymentExists = await VendaFormaDePagamento.findBy('id_prime', saleMethodPayment.id);
                    let idMethodPayment = await findPaymentMethodByIdPrime(saleMethodPayment.method_payment_id);
                    let idSale = await findSaleByIdPrime(saleMethodPayment.sale_id);
                    if (idMethodPayment && idSale) {
                        const upsertsaleMethodPayment = {
                            idPrime: saleMethodPayment.id,
                            idVenda: idSale,
                            idFormaDePagamento: idMethodPayment,
                            installmentValue: saleMethodPayment.installmentValue,
                            deletedAt: saleMethodPayment.deletedAt,
                        };
                        if (saleMethodPaymentExists) {
                            await saleMethodPaymentExists.merge(upsertsaleMethodPayment).save();
                            saleMethodPaymentsToSync.push(saleMethodPayment.id);
                        }
                        else {
                            await VendaFormaDePagamento.create(upsertsaleMethodPayment);
                            saleMethodPaymentsToSync.push(saleMethodPayment.id);
                        }
                    }
                }
                if (saleMethodPaymentsToSync && saleMethodPaymentsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_venda_forma_de_pagamento' }, { updated_at: DateTime.now() });
                }
                console.log(`${saleMethodPaymentsToSync.length} VENDA FORMA DE PAGAMENTO SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.error('ERRO AS BUSCAR A VENDA FORMA DE PAGAMENTO', err);
        }
    }
}
//# sourceMappingURL=venda_forma_de_pagamento.js.map