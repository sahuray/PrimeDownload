import axios from 'axios';
import ProdutoPreco from '#models/prime_produto_preco';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoPrecoService {
    async syncProductPrice() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_produto_preco')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_price', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productPrices = response.data.productPrices;
            console.log(`${productPrices.length} PRODUTO PRECO(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (productPrices && productPrices.length > 0) {
                const productPricesToSync = [];
                for (const productPrice of productPrices) {
                    const productExists = await ProdutoPreco.findBy('id_prime', productPrice.id);
                    let idCompany = await findCompanyByIdPrime(productPrice.company_id);
                    let idProduct = await findProductByIdPrime(productPrice.product_id);
                    if (idProduct && idCompany) {
                        const upsertProductPrice = {
                            id_prime: productPrice.id,
                            id_empresa: idCompany,
                            id_produto: idProduct,
                            sync_prime: productPrice.sync_prime,
                            description: productPrice.description,
                            main_price: productPrice.main_price,
                            ecommerce: productPrice.ecommerce,
                            value: productPrice.value,
                            margin: productPrice.margin,
                            discount_max: productPrice.discount_max,
                            commission_value: productPrice.commission_value,
                            commission_percentage: productPrice.commission_percentage,
                            is_promotion: productPrice.is_promotion,
                            promotion_ended_at: productPrice.promotion_ended_at,
                            promotion_started_at: productPrice.promotion_started_at,
                            deleted_at: productPrice.deleted_at,
                        };
                        if (productExists) {
                            await productExists.merge(upsertProductPrice).save();
                            productPricesToSync.push(productPrice.id);
                        }
                        else {
                            await ProdutoPreco.create(upsertProductPrice);
                            productPricesToSync.push(productPrice.id);
                        }
                    }
                }
                if (productPricesToSync && productPricesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_produto_preco' }, { updated_at: DateTime.now() });
                }
                console.log(`${productPricesToSync.length} PRODUTO PRECO(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO PRECO(S)', error);
        }
    }
}
//# sourceMappingURL=produto_preco.js.map