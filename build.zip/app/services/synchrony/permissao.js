import axios from 'axios';
import Sincronia from '#models/sincronia';
import Permissao from '#models/prime_permissao';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class PermissaoService {
    async syncPermission() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_permissao')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/permission', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const permissions = response.data.permissions;
            console.log(`${permissions.length} PERMISSAO(ÇÕES) ENCONTRADAS PARA SINCRONIZAR`);
            if (permissions && permissions.length > 0) {
                const permissionsToSync = [];
                for (const permission of permissions) {
                    const permissionExists = await Permissao.findBy('id_prime', permission.id);
                    const upsertPermission = {
                        id_prime: permission.id,
                        slug: permission.slug,
                        pagina: permission.pagina,
                        icon: permission.icon,
                        index: permission.index,
                        name: permission.name,
                        description: permission.description,
                        por_grupo: permission.por_grupo,
                        internalAccess: permission.internal_access,
                        agrupamentoCor: permission.agrupamento_cor,
                        deletedAt: permission.deleted_at,
                    };
                    if (permissionExists) {
                        await permissionExists.merge(upsertPermission).save();
                        permissionsToSync.push(permission.id);
                    }
                    else {
                        await Permissao.create(upsertPermission);
                        permissionsToSync.push(permission.id);
                    }
                }
                if (permissionsToSync && permissionsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_permissao' }, { updated_at: DateTime.now() });
                }
                console.log(`${permissionsToSync.length} PERMISSAO(ÇÕES) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.log('ERRO AS BUSCAR A(S) PERMISSAO(ÇÕES)', error);
        }
    }
}
//# sourceMappingURL=permissao.js.map