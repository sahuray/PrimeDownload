import axios from 'axios';
import Marca from '#models/prime_marca';
import Grupo from '#models/grupo';
import Sincronia from '#models/sincronia';
import console from 'node:console';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class MarcaService {
    async syncBrand() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'MARCA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/brand', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const brands = response.data.brands;
            console.log(`${brands.length} MARCA(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (brands && brands.length > 0) {
                const brandsToSync = [];
                let idGroup = await Grupo.query().where('id', 1).first();
                if (idGroup) {
                    for (const brand of brands) {
                        const brandExists = await Marca.findBy('id_prime', brand.id);
                        const upsertBrand = {
                            id_prime: brand.id,
                            id_grupo: idGroup.id,
                            nome: brand.nome,
                            deleted_at: brand.deleted_at,
                            sync_prime: false,
                        };
                        if (brandExists) {
                            await brandExists.merge(upsertBrand).save();
                            brandsToSync.push(brand.id);
                        }
                        else {
                            await Marca.create(upsertBrand);
                            brandsToSync.push(brand.id);
                        }
                    }
                }
                if (brandsToSync && brandsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'MARCA' }, { updated_at: DateTime.now() });
                }
                console.log(`${brandsToSync.length} MARCA(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) MARCA(S)', error);
        }
    }
}
//# sourceMappingURL=marca.js.map