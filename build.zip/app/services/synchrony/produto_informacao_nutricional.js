import axios from 'axios';
import ProdutoInformacaoNutricional from '#models/prime_produto_informacao_nutricional';
import Grupo from '#models/grupo';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoInformacaoNutricionalService {
    async syncInformationNutritional() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'PRODUTO INFORMACAO NUTRICIONAL')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_nutricional_information', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const prodNutritionalInformations = response.data.productNutritionalInformations;
            console.log(`${prodNutritionalInformations.length} INFORMAÇÃO NUTRICIONAL(S) ENCNTRADOS PARA SINCRONIZAR`);
            if (prodNutritionalInformations && prodNutritionalInformations.length > 0) {
                const prodNutritionalInformationsToSync = [];
                let idGroup = await Grupo.query().where('id', 1).first();
                if (idGroup) {
                    for (const prodNutritionalInformation of prodNutritionalInformations) {
                        const productExists = await ProdutoInformacaoNutricional.findBy('id_prime', prodNutritionalInformation.id);
                        const upsertProdNutritionalInformation = {
                            id_prime: prodNutritionalInformation.id,
                            deleted_at: prodNutritionalInformation.deleted_at,
                            sync_prime: prodNutritionalInformation.sync_prime,
                            id_grupo: idGroup.id,
                            description: prodNutritionalInformation.description,
                            dietary_fiber_grams: prodNutritionalInformation.dietary_fiber_grams,
                            dietary_fiber_vd: prodNutritionalInformation.dietary_fiber_vd,
                            portion: prodNutritionalInformation.portion,
                            proteins_grams: prodNutritionalInformation.proteins_grams,
                            proteins_vd: prodNutritionalInformation.proteins_vd,
                            liquid_weight: prodNutritionalInformation.liquid_weight,
                            origin: prodNutritionalInformation.origin,
                            calories_grams: prodNutritionalInformation.calories_grams,
                            calories_vd: prodNutritionalInformation.calories_vd,
                            carbohydrates_grams: prodNutritionalInformation.carbohydrates_grams,
                            carbohydrates_vd: prodNutritionalInformation.carbohydrates_vd,
                            fats_grams: prodNutritionalInformation.fats_grams,
                            fats_saturated_grams: prodNutritionalInformation.fats_saturated_grams,
                            fats_saturated_vd: prodNutritionalInformation.fats_saturated_vd,
                            fats_totals: prodNutritionalInformation.fats_totals,
                            fats_totals_vd: prodNutritionalInformation.fats_totals_vd,
                            fats_trans_grams: prodNutritionalInformation.fats_trans_grams,
                            fats_trans_vd: prodNutritionalInformation.fats_trans_vd,
                            fats_vd: prodNutritionalInformation.fats_vd,
                            sodium_miligrams: prodNutritionalInformation.sodium_miligrams,
                            complementary_attributes: prodNutritionalInformation.complementary_attributes,
                            ingredients: prodNutritionalInformation.ingredients,
                        };
                        if (productExists) {
                            await productExists.merge(upsertProdNutritionalInformation).save();
                            prodNutritionalInformationsToSync.push(prodNutritionalInformation.id);
                        }
                        else {
                            await ProdutoInformacaoNutricional.create(upsertProdNutritionalInformation);
                            prodNutritionalInformationsToSync.push(prodNutritionalInformation.id);
                        }
                    }
                }
                if (prodNutritionalInformationsToSync && prodNutritionalInformationsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'PRODUTO INFORMACAO NUTRICIONAL' }, { updated_at: DateTime.now() });
                }
                console.log(`${prodNutritionalInformationsToSync.length} INFORMAÇÃO NUTRICIONAL(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) INFORMAÇÃO NUTRICIONAL(S)', error);
        }
    }
}
//# sourceMappingURL=produto_informacao_nutricional.js.map