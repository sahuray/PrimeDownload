import axios from 'axios';
import { apiURL } from '../index.js';
import Municipio from '#models/prime_municipio';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
export default class MunicipioService {
    async syncMunicipality() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'MUNICIPIO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/municipality', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const municipalities = response.data.municipalities;
            console.log(`${municipalities.length} MUNICIPIO(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (municipalities && municipalities.length > 0) {
                const municipalitiesToSync = [];
                for (const municipality of municipalities) {
                    const municipalityExists = await Municipio.findBy('id_prime', municipality.id);
                    const upsertMunicipality = {
                        id_prime: municipality.id,
                        cidade: municipality.cidade,
                        uf: municipality.uf,
                        ibge: municipality.ibge,
                    };
                    if (municipalityExists) {
                        await municipalityExists.merge(upsertMunicipality).save();
                        municipalitiesToSync.push(municipality.id);
                    }
                    else {
                        await Municipio.create(upsertMunicipality);
                        municipalitiesToSync.push(municipality.id);
                    }
                }
                if (municipalitiesToSync && municipalitiesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'MUNICIPIO' }, { updated_at: DateTime.now() });
                }
                console.log(`${municipalitiesToSync.length} MUNICIPIO(S) SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=municipio.js.map