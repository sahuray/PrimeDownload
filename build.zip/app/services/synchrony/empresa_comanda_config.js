import axios from 'axios';
import EmpresaComandaConfig from '#models/prime_empresa_comanda_config';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
export default class EmpresaComandaConfigsService {
    async syncCompanyCommandSetting() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'CONFIG EMPRESA COMANDA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/company_command_setting', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const settings = response.data.settings;
            console.log(`${settings.length} CONFIGURAÇÃO COMANDA ENCONTRADAS PARA SINCRONIZAR`);
            if (settings && settings.length > 0) {
                const settingToSync = [];
                for (const setting of settings) {
                    const settingExists = await EmpresaComandaConfig.findBy('id_prime', setting.id);
                    let idCompany = await findCompanyByIdPrime(setting.empresa_id);
                    if (idCompany) {
                        const upsertSettings = {
                            id_prime: setting.id,
                            id_empresa: idCompany,
                            utiliza_comanda: setting.utiliza_comanda,
                            pedir_mesa_lancamento_comanda: setting.pedir_mesa_lancamento_comanda,
                            imprimir_item_composicao: setting.imprimir_item_composicao,
                            utiliza_observacao_comanda: setting.utiliza_observacao_comanda,
                            utiliza_couvert: setting.utiliza_couvert,
                            utiliza_taxa_de_servico: setting.utiliza_taxa_de_servico,
                            ativar_busca_comandas_campo_lancamento_produtos_pdv: setting.ativar_busca_comandas_campo_lancamento_produtos_pdv,
                            codigo_taxa_servico: setting.codigo_taxa_servico,
                            digito_controle_comanda: setting.digito_controle_comanda,
                            percentual_taxa_servico: setting.percentual_taxa_servico,
                            quantidade_caracteres_comanda: setting.quantidade_caracteres_comanda,
                            deletedAt: setting.deletedAt,
                        };
                        if (settingExists) {
                            await settingExists.merge(upsertSettings).save();
                            settingToSync.push(setting.id);
                        }
                        else {
                            await EmpresaComandaConfig.create(upsertSettings);
                            settingToSync.push(setting.id);
                        }
                    }
                }
                if (settingToSync && settingToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'CONFIG EMPRESA COMANDA' }, { updated_at: DateTime.now() });
                }
                console.log(`${settingToSync.length} CONFIGURAÇÃO COMANDA SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS CONFIGURAÇÃO COMANDA', error);
        }
    }
}
//# sourceMappingURL=empresa_comanda_config.js.map