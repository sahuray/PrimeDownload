import axios from 'axios';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import PrimeConfig from '#models/prime_config';
export default class PrimeConfigService {
    async syncPrimeConfig() {
        try {
            const primeConfig = await PrimeConfig.query().select('id', 'id_empresa_prime').first();
            console.log('------------------------------------------------------');
            console.log('SINCRONIZANDO CONFIGURAÇÕES DO PRIME', primeConfig);
            console.log('------------------------------------------------------');
            if (primeConfig && primeConfig.id_empresa_prime !== null) {
                return;
            }
            const response = await axios.get(apiURL + '/v1/core/prime_config', {
                params: {
                    key: process.env.API_CORE_KEY,
                },
            });
            console.log('RESPONSE  ----->', response.data);
            const idCompany = response.data.idCompany;
            if (idCompany) {
                let idCompanyCore = await findCompanyByIdPrime(idCompany);
                if (idCompanyCore) {
                    console.log('ID DA EMPRESA DO CORE', idCompanyCore);
                    primeConfig.id_empresa_prime = idCompanyCore;
                    await primeConfig.save();
                }
            }
        }
        catch (error) {
            console.error('ERRO AO SINCRONIZAR CONFIGURAÇÕES DO PRIME', error);
        }
    }
}
//# sourceMappingURL=prime_config.js.map