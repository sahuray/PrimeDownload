import axios from 'axios';
import ProdutoEmpresa from '#models/prime_produto_empresa';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findDepartamentByIdPrime from '../../../functions/find_departament_by_id_prime.js';
export default class ProdutoEmpresaService {
    async syncProdutoEmpresa() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_produto_empresa')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_company', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productCompanies = response.data.productCompanies;
            console.log(`${productCompanies.length} PRODUTO EMPRESA ENCONTRADOS PARA SINCRONIZAR`);
            if (productCompanies && productCompanies.length > 0) {
                const productCompaniesToSync = [];
                for (const productCompany of productCompanies) {
                    const productCompanyExists = await ProdutoEmpresa.findBy('id_prime', productCompany.id);
                    let idCompany = await findCompanyByIdPrime(productCompany.company_id);
                    let idProduct = await findProductByIdPrime(productCompany.product_id);
                    let idDepartament = await findDepartamentByIdPrime(productCompany.departament_id);
                    if (idProduct && idCompany) {
                        const upsertproductCompany = {
                            id_prime: productCompany.id,
                            id_empresa: idCompany,
                            id_produto: idProduct,
                            id_departamento: idDepartament,
                            sell: productCompany.sell,
                            active: productCompany.active,
                            control_inventory: productCompany.control_inventory,
                            control_number_serie: productCompany.control_number_serie,
                            permit_fractionate: productCompany.permit_fractionate,
                            use_characteristic: productCompany.use_characteristic,
                            weight_balance: productCompany.weight_balance,
                            by_kg: productCompany.by_kg,
                            control_lot_expiration: productCompany.control_lot_expiration,
                            control_serial_number: productCompany.control_serial_number,
                            custom_name: productCompany.custom_name,
                            custom_short_name: productCompany.custom_short_name,
                            descrition: productCompany.descrition,
                            price_cost_box_cost: productCompany.price_cost_box_cost,
                            price_cost_box_quantity: productCompany.price_cost_box_quantity,
                            price_cost_unit_cost: productCompany.price_cost_unit_cost,
                            tax_expenses: productCompany.tax_expenses,
                            ipi_expenses: productCompany.ipi_expenses,
                            shipping_expenses: productCompany.shipping_expenses,
                            other_expenses: productCompany.other_expenses,
                            value_st_extenses: productCompany.value_st_extenses,
                            real_cost_real_cost_box: productCompany.real_cost_real_cost_box,
                            real_cost_real_cost_unitary: productCompany.real_cost_real_cost_unitary,
                            real_cost_margin_loss: productCompany.real_cost_margin_loss,
                            nfe_aliquot_ipi: productCompany.nfe_aliquot_ipi,
                            nfe_ipi_framing: productCompany.nfe_ipi_framing,
                            nfe_aliquot_icms: productCompany.nfe_aliquot_icms,
                            nfe_origin: productCompany.nfe_origin,
                            nfe_csosn: productCompany.nfe_csosn,
                            nfe_taxation: productCompany.nfe_taxation,
                            nfe_ipi_cst: productCompany.nfe_ipi_cst,
                            nfe_ipi_control_seal: productCompany.nfe_ipi_control_seal,
                            nfe_reduction: productCompany.nfe_reduction,
                            nfe_tributacao_icms: productCompany.nfe_tributacao_icms,
                            beneficio_fiscal: productCompany.beneficio_fiscal,
                            desoneracao_motivo: productCompany.desoneracao_motivo,
                            desoneracao_porcentagem: productCompany.desoneracao_porcentagem,
                            nfe_use_cfop: productCompany.nfe_use_cfop,
                            uf_origem_combustivel: productCompany.uf_origem_combustivel,
                            indicador_importacao_combustivel: productCompany.indicador_importacao_combustivel,
                            originario_para_uf_porcentagem_combustivel: productCompany.originario_para_uf_porcentagem_combustivel,
                            indice_mistura_combustivel: productCompany.indice_mistura_combustivel,
                            nfe_use_reduction: productCompany.nfe_use_reduction,
                            nfe_cfop_state: productCompany.nfe_cfop_state,
                            nfe_cfop_interstate: productCompany.nfe_cfop_interstate,
                            nfe_cfop_fuel_code_anp: productCompany.nfe_cfop_fuel_code_anp,
                            nfe_pis_cst: productCompany.nfe_pis_cst,
                            nfe_pis_aliquot: productCompany.nfe_pis_aliquot,
                            nfe_cofins_cst: productCompany.nfe_cofins_cst,
                            nfe_cofins_aliquot: productCompany.nfe_cofins_aliquot,
                            ex: productCompany.ex,
                            tipo: productCompany.tipo,
                            nfe_cst: productCompany.nfe_cst,
                            nfe_pis_base_calculo: productCompany.nfe_pis_base_calculo,
                            nfe_pis_bc_quantidade: productCompany.nfe_pis_bc_quantidade,
                            nfe_pis_aliquot_porc: productCompany.nfe_pis_aliquot_porc,
                            nfe_pis_valor: productCompany.nfe_pis_valor,
                            nfe_cofins_base_calculo: productCompany.nfe_cofins_base_calculo,
                            nfe_cofins_bc_quantidade: productCompany.nfe_cofins_bc_quantidade,
                            nfe_cofins_aliquot_porc: productCompany.nfe_cofins_aliquot_porc,
                            nfe_cofins_valor: productCompany.nfe_cofins_valor,
                            nfe_base_ipi: productCompany.nfe_base_ipi,
                            nfe_enquadramento_ipi: productCompany.nfe_enquadramento_ipi,
                            nfe_valor_devolvido_ipi: productCompany.nfe_valor_devolvido_ipi,
                            nfe_porc_devolvido_ipi: productCompany.nfe_porc_devolvido_ipi,
                            nfe_valor_ipi: productCompany.nfe_valor_ipi,
                            nfe_aliquota_issqn: productCompany.nfe_aliquota_issqn,
                            nfe_base_icms: productCompany.nfe_base_icms,
                            nfe_valor_operacao_icms: productCompany.nfe_valor_operacao_icms,
                            nfe_diferimento_porc_icms: productCompany.nfe_diferimento_porc_icms,
                            nfe_diferimento_icms: productCompany.nfe_diferimento_icms,
                            nfe_valor_icms: productCompany.nfe_valor_icms,
                            nfe_issqn_aliquota: productCompany.nfe_issqn_aliquota,
                            nfe_issqn_indicador_incentivo: productCompany.nfe_issqn_indicador_incentivo,
                            nfe_issqn_indicador_exigibilidade: productCompany.nfe_issqn_indicador_exigibilidade,
                            nfe_issqn_item_lista_servico: productCompany.nfe_issqn_item_lista_servico,
                            sat_nfce_cfop: productCompany.sat_nfce_cfop,
                            sat_nfce_cfop_exchange: productCompany.sat_nfce_cfop_exchange,
                            sat_nfce_aliquot_icms: productCompany.sat_nfce_aliquot_icms,
                            sat_nfce_origin: productCompany.sat_nfce_origin,
                            sat_nfce_csosn: productCompany.sat_nfce_csosn,
                            sat_nfce_taxation: productCompany.sat_nfce_taxation,
                            sat_nfce_pis_cst: productCompany.sat_nfce_pis_cst,
                            sat_nfce_pis_aliquot: productCompany.sat_nfce_pis_aliquot,
                            sat_nfce_cofins_cst: productCompany.sat_nfce_cofins_cst,
                            sat_nfce_cofins_aliquot: productCompany.sat_nfce_cofins_aliquot,
                            nfse_code_service: productCompany.nfse_code_service,
                            nfse_code_activity: productCompany.nfse_code_activity,
                            nfse_aliquot: productCompany.nfse_aliquot,
                            sped_item_type: productCompany.sped_item_type,
                            sped_accounting_account: productCompany.sped_accounting_account,
                            sped_income_tax_amount: productCompany.sped_income_tax_amount,
                            sped_genre_item: productCompany.sped_genre_item,
                            product_composite: productCompany.product_composite,
                            ncm: productCompany.ncm,
                            cest: productCompany.cest,
                            deleted_at: productCompany.deleted_at,
                        };
                        if (productCompanyExists) {
                            await productCompanyExists.merge(upsertproductCompany).save();
                            productCompaniesToSync.push(productCompany.id);
                        }
                        else {
                            await ProdutoEmpresa.create(upsertproductCompany);
                            productCompaniesToSync.push(productCompany.id);
                        }
                    }
                }
                if (productCompaniesToSync && productCompaniesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_produto_empresa' }, { updated_at: DateTime.now() });
                }
                console.log(`${productCompaniesToSync.length} PRODUTO EMPRESA SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO EMPRESA', error);
        }
    }
}
//# sourceMappingURL=produto_empresa.js.map