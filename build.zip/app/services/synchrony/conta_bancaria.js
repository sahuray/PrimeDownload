import axios from 'axios';
import ContaBancaria from '#models/conta_bancaria';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findBankByIdPrime from '../../../functions/find_bank_by_id_prime.js';
import Grupo from '#models/grupo';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ContaBancariaService {
    async syncBankAccount() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_conta_bancaria')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/account_bank', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const accountsBank = response.data.accountsBank;
            console.log(`${accountsBank.length} CONTA BANCARIA(S) ENCONTRADOS PARA SINCRONIZAR`);
            let idGroup = await Grupo.query().where('id', 1).first();
            if (accountsBank && accountsBank.length > 0) {
                const accountBanksToSync = [];
                for (const accountBank of accountsBank) {
                    const accountbankExists = await ContaBancaria.findBy('id_prime', accountBank.id);
                    let idUserUpdatedBy = await findUserByIdPrime(accountBank.updated_by);
                    let idBank = await findBankByIdPrime(accountBank.banco_id);
                    let idCompany = await findCompanyByIdPrime(accountBank.empresa_id);
                    if (idCompany && idBank && idGroup) {
                        const upsertAccountBank = {
                            id_prime: accountBank.id,
                            id_banco: idBank,
                            id_empresa: idCompany,
                            id_grupo: idGroup.id,
                            deletedAt: accountBank.deletedAt,
                            updatedBy: idUserUpdatedBy,
                            agencia: accountBank.agencia,
                            conta_corrente: accountBank.conta_corrente,
                            tipo_pessoa: accountBank.tipo_pessoa,
                            titular_conta: accountBank.titular_conta,
                            socio_titular_conta: accountBank.socio_titular_conta,
                            gerente_conta: accountBank.gerente_conta,
                            telefone_gerente: accountBank.telefone_gerente,
                            email_gerente: accountBank.email_gerente,
                            operadora: accountBank.operadora,
                            status: accountBank.status,
                            boleto_registrado_status: accountBank.boleto_registrado_status,
                            utiliza_desconto_pontualidade: accountBank.utiliza_desconto_pontualidade,
                            padrao_para_todas_as_vendas: accountBank.padrao_para_todas_as_vendas,
                            boleto_carteira_registrado: accountBank.boleto_carteira_registrado,
                            especie_padrao: accountBank.especie_padrao,
                            boleto_carteira_registrado_codigo: accountBank.boleto_carteira_registrado_codigo,
                            boleto_nosso_numero_automatico: accountBank.boleto_nosso_numero_automatico,
                            boleto_nosso_numero: accountBank.boleto_nosso_numero,
                            boleto_dias_devolucao: accountBank.boleto_dias_devolucao,
                            boleto_carteira_variacao: accountBank.boleto_carteira_variacao,
                            boleto_instrucao: accountBank.boleto_instrucao,
                            boleto_instrucao_remessa_1: accountBank.boleto_instrucao_remessa1,
                            boleto_instrucao_remessa_2: accountBank.boleto_instrucao_remessa2,
                            boleto_instrucao_remessa_3: accountBank.boleto_instrucao_remessa3,
                            boleto_dias_carencia: accountBank.boleto_dias_carencia,
                            boleto_dias_negativacao: accountBank.boleto_dias_negativacao,
                            boleto_tipo_cobranca: accountBank.boleto_tipo_cobranca,
                            boleto_layout: accountBank.boleto_layout,
                            boleto_especie_padrao: accountBank.boleto_especie_padrao,
                            boleto_aceite_padrao: accountBank.boleto_aceite_padrao,
                            boleto_codigo_cedente: accountBank.boleto_codigo_cedente,
                            boleto_porcentagem_mora: accountBank.boleto_porcentagem_mora,
                            boleto_porcentagem_multa: accountBank.boleto_porcentagem_multa,
                            dias_carencia: accountBank.dias_carencia,
                            boleto_convenio: accountBank.boleto_convenio,
                            boleto_tipo_numero_documento: accountBank.boleto_tipo_numero_documento,
                            boleto_layoutremessa: accountBank.boleto_layoutremessa,
                            boleto_codigo_transmissao: accountBank.boleto_codigo_transmissao,
                            boleto_tipo_nome_pagador: accountBank.boleto_tipo_nome_pagador,
                            boleto_tipo_cliente_arquivo_remessa: accountBank.boleto_tipo_cliente_arquivo_remessa,
                            agencia_digito: accountBank.agencia_digito,
                            conta_digito: accountBank.conta_digito,
                            permite_boleto: accountBank.permite_boleto,
                            instruction_six: accountBank.instruction_six,
                            instruction_seven: accountBank.instruction_seven,
                            instruction_eight: accountBank.instruction_eight,
                            local_pagamento: accountBank.local_pagamento,
                        };
                        if (accountbankExists) {
                            await accountbankExists.merge(upsertAccountBank).save();
                            accountBanksToSync.push(accountBank.id);
                        }
                        else {
                            await ContaBancaria.create(upsertAccountBank);
                            accountBanksToSync.push(accountBank.id);
                        }
                    }
                }
                if (accountBanksToSync && accountBanksToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_conta_bancaria' }, { updated_at: DateTime.now() });
                }
                console.log(`${accountBanksToSync.length} CONTA BANCARIA(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS CONTA(S) BANCARIA(S)', error);
        }
    }
}
//# sourceMappingURL=conta_bancaria.js.map