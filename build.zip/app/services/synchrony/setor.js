import axios from 'axios';
import Setor from '#models/setor';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import Grupo from '#models/grupo';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
export default class SetorService {
    async syncSetor() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'SETOR')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/setor', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const setors = response.data.setores;
            console.log(`${setors.length} SETORS ENCONTRADOS PARA SINCRONIZAR`);
            if (setors && setors.length > 0) {
                const setorsToSync = [];
                let idGroup = await Grupo.query().where('id', 1).select(['id']).first();
                if (idGroup && idGroup.id) {
                    for (const setor of setors) {
                        const setorExists = await Setor.findBy('id_prime', setor.id);
                        let idCompany = await findCompanyByIdPrime(setor.id_empresa);
                        if (idCompany) {
                            const upsertSetor = {
                                id_prime: setor.id,
                                id_empresa: idCompany,
                                nome_setor: setor.nome_setor,
                                observacao_setor: setor.observacao_setor,
                                status: setor.status,
                                favorite: setor.favorite,
                                deletedAt: setor.deleted_at,
                            };
                            if (setorExists) {
                                await setorExists.merge(upsertSetor).save();
                                setorsToSync.push(setor.id);
                            }
                            else {
                                await Setor.create(upsertSetor);
                                setorsToSync.push(setor.id);
                            }
                        }
                    }
                    if (setorsToSync && setorsToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'SETOR' }, { updated_at: DateTime.now() });
                    }
                }
                console.log(`${setorsToSync.length} SETOR(S) SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) SETOR(S)', error);
        }
    }
}
//# sourceMappingURL=setor.js.map