import axios from 'axios';
import EmpresaPrathosConfig from '#models/prime_empresa_prathos_config';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
export default class EmpresaPrathosConfigsService {
    async syncCompanyPrathosSetting() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'CONFIG EMPRESA PRATHOS')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/company_prathos_setting', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const settings = response.data.settings;
            console.log(`${settings.length} CONFIGURAÇÃO PRATHOS ENCONTRADAS PARA SINCRONIZAR`);
            if (settings && settings.length > 0) {
                const settingToSync = [];
                for (const setting of settings) {
                    const settingExists = await EmpresaPrathosConfig.findBy('id_prime', setting.id);
                    let idCompany = await findCompanyByIdPrime(setting.empresa_id);
                    if (idCompany) {
                        const upsertSettings = {
                            id_prime: setting.id,
                            id_empresa: idCompany,
                            utiliza_couvert: setting.utiliza_couvert,
                            utiliza_prathos: setting.utiliza_prathos,
                            utiliza_replique: setting.utiliza_replique,
                            utiliza_taxa_de_servico: setting.utiliza_taxa_de_servico,
                            deleted_at: setting.deleted_at,
                        };
                        if (settingExists) {
                            await settingExists.merge(upsertSettings).save();
                            settingToSync.push(setting.id);
                        }
                        else {
                            await EmpresaPrathosConfig.create(upsertSettings);
                            settingToSync.push(setting.id);
                        }
                    }
                }
                if (settingToSync && settingToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'CONFIG EMPRESA PRATHOS' }, { updated_at: DateTime.now() });
                }
                console.log(`${settingToSync.length} CONFIGURAÇÃO PRATHOS SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS CONFIGURAÇÃO PRATHOS', error);
        }
    }
}
//# sourceMappingURL=empresa_prathos_config.js.map