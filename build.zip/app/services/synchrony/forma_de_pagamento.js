import axios from 'axios';
import FormaDePagamento from '#models/forma_de_pagamento';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findFlagByIdPrime from '../../../functions/find_flag_by_id_prime.js';
import findBankAccountByIdPrime from '../../../functions/find_bank_account_by_id_prime.js';
import findPaymentMethodConditionByIdPrime from '../../../functions/find_payment_method_condition_by_id_prime.js';
import findPaymentMethodTypeByIdPrime from '../../../functions/find_payment_method_type_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class FormaDePagamentoService {
    async syncPaymentsMethod() {
        let updatedAtSynchrony = null;
        const synchrony = await Sincronia.query()
            .where('nome_tabela', 'FORMA DE PAGAMENTO')
            .select('updated_at')
            .first();
        if (synchrony) {
            updatedAtSynchrony = synchrony.updated_at;
        }
        try {
            const response = await axios.get(apiURL + '/v1/core/payment_method', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const paymentsMethod = response.data.paymentsMethod;
            console.log(`${paymentsMethod.length} FORMA DE PAGAMENTO ENCONTRADOS PARA SINCRONIZAR`);
            if (paymentsMethod && paymentsMethod.length > 0) {
                const paymentsMethodToSync = [];
                for (const paymentMethod of paymentsMethod) {
                    const paymentMethodExists = await FormaDePagamento.findBy('id_prime', paymentMethod.id);
                    let idCompany = await findCompanyByIdPrime(paymentMethod.company_id);
                    let idFlag = await findFlagByIdPrime(paymentMethod.bandeira_id);
                    let idBankAccount = await findBankAccountByIdPrime(paymentMethod.conta_bancaria_id);
                    let idPaymentMethodCondition = await findPaymentMethodConditionByIdPrime(paymentMethod.condicao_id);
                    let idPaymentMethodType = await findPaymentMethodTypeByIdPrime(paymentMethod.tipo_id);
                    if (idCompany && idPaymentMethodType && idPaymentMethodCondition) {
                        const upsertPaymentMethod = {
                            id_prime: paymentMethod.id,
                            id_empresa: idCompany,
                            id_bandeira: idFlag,
                            id_conta_bancaria: idBankAccount,
                            id_forma_de_pagamento_condicao: idPaymentMethodCondition,
                            id_forma_de_pagamento_tipo: idPaymentMethodType,
                            quantidade: paymentMethod.quantidade,
                            prazo: paymentMethod.prazo,
                            tarifa: paymentMethod.tarifa,
                            description: paymentMethod.description,
                            code: paymentMethod.code,
                            inativo: paymentMethod.inativo,
                            deleted_at: paymentMethod.deleted_at,
                            sync_prime: false,
                        };
                        if (paymentMethodExists) {
                            await paymentMethodExists.merge(upsertPaymentMethod).save();
                            paymentsMethodToSync.push(paymentMethod.id);
                        }
                        else {
                            await FormaDePagamento.create(upsertPaymentMethod);
                            paymentsMethodToSync.push(paymentMethod.id);
                        }
                    }
                    if (paymentsMethodToSync && paymentsMethodToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'FORMA DE PAGAMENTO' }, { updated_at: DateTime.now() });
                    }
                }
                console.log(`${paymentsMethodToSync.length} FORMA DE PAGAMENTO SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR AS FORMA DE PAGAMENTO', error);
        }
    }
}
//# sourceMappingURL=forma_de_pagamento.js.map