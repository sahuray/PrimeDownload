import Sincronia from '#models/sincronia';
import VendaNfce from '#models/venda_nfce';
import axios from 'axios';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class VendaNfceService {
    async syncSaleNfce() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_venda_nfce')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/sale_nfce', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const salesNfce = response.data.salesNfce;
            console.log(`${salesNfce.length} VENDA NFCE ENCONTRADOS PARA SINCRONIZAR`);
            if (salesNfce && salesNfce.length > 0) {
                const salesNfceToSync = [];
                for (const saleNfce of salesNfce) {
                    const saleNfceExists = await VendaNfce.findBy('id_prime', saleNfce.id);
                    let idSale = await findSaleByIdPrime(saleNfce.id_sale);
                    if (idSale) {
                        const upsertSaleNfce = {
                            idPrime: saleNfce.id,
                            idVenda: idSale,
                            status: saleNfce.status,
                            message: saleNfce.message,
                            data: saleNfce.data,
                        };
                        if (saleNfceExists) {
                            await saleNfceExists.merge(upsertSaleNfce).save();
                            salesNfceToSync.push(saleNfce.id);
                        }
                        else {
                            await VendaNfce.create(upsertSaleNfce);
                            salesNfceToSync.push(saleNfce.id);
                        }
                    }
                }
                if (salesNfceToSync && salesNfceToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_venda_nfce' }, { updated_at: DateTime.now() });
                }
                console.log(`${salesNfceToSync.length} VENDA NFCE ITENS SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.error('ERRO AS BUSCAR A VENDA NFCE', err);
        }
    }
}
//# sourceMappingURL=venda_nfce.js.map