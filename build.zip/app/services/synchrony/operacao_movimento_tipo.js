import axios from 'axios';
import { apiURL } from '../index.js';
import { DateTime } from 'luxon';
import OperacaoMovimentoTipo from '#models/operacao_movimento_tipo';
import Sincronia from '#models/sincronia';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
export default class OperacaoMovimentoTipoService {
    async syncOperationMovementType() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'OPERACAO MOVIMENTO TIPO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/operation_movement_type', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const operationMovementTypes = response.data.operationMovementTypes;
            console.log(`${operationMovementTypes.length} OPERACAO MOVIMENTO TIPO(S) ENCONTRADOS PARA SINCRONIZAR`);
            if (operationMovementTypes && operationMovementTypes.length > 0) {
                const operationMovementTypesToSync = [];
                for (const operationMovementType of operationMovementTypes) {
                    const operationMovementTypeExists = await OperacaoMovimentoTipo.findBy('id_prime', operationMovementType.id);
                    const idCompany = await findCompanyByIdPrime(operationMovementType.id_empresa);
                    if (idCompany) {
                        const upsertOperationMovementType = {
                            id_prime: operationMovementType.id,
                            id_empresa: idCompany,
                            descricao: operationMovementType.descricao,
                            tipo: operationMovementType.tipo,
                            deletedAt: operationMovementType.deleted_at,
                        };
                        if (operationMovementTypeExists) {
                            await operationMovementTypeExists.merge(upsertOperationMovementType).save();
                            operationMovementTypesToSync.push(operationMovementType.id);
                        }
                        else {
                            await OperacaoMovimentoTipo.create(upsertOperationMovementType);
                            operationMovementTypesToSync.push(operationMovementType.id);
                        }
                    }
                }
                if (operationMovementTypesToSync && operationMovementTypesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'OPERACAO MOVIMENTO TIPO' }, { updated_at: DateTime.now() });
                }
                console.log(`${operationMovementTypesToSync.length} OPERACAO MOVIMENTO TIPO(S) SINCRONIZADOS`);
            }
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=operacao_movimento_tipo.js.map