import axios from 'axios';
import ProdutoLoteExpiracao from '#models/prime_produto_lote_expiracao';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
export default class ProdutoLoteExpiracaoService {
    async syncProdutoLoteExpiracao() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_produto_lote_expiracao')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/product_lot_expiration', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const productLotExpirations = response.data.productLotExpirations;
            console.log(`${productLotExpirations.length} PRODUTO LOTE EXPIRACAO ENCONTRADOS PARA SINCRONIZAR`);
            if (productLotExpirations && productLotExpirations.length > 0) {
                const productLotExpirationsToSync = [];
                for (const productLotExpiration of productLotExpirations) {
                    const productLotExpirationExists = await ProdutoLoteExpiracao.findBy('id_prime', productLotExpiration.id);
                    let idCompany = await findCompanyByIdPrime(productLotExpiration.company_id);
                    let idProduct = await findProductByIdPrime(productLotExpiration.product_id);
                    if (idProduct && idCompany) {
                        const upsertproductLotExpiration = {
                            id_prime: productLotExpiration.id,
                            id_empresa: idCompany,
                            id_produto: idProduct,
                            deleted_at: productLotExpiration.deleted_at,
                            elaboration_date: productLotExpiration.elaboration_date,
                            expiration_date: productLotExpiration.expiration_date,
                            lot: productLotExpiration.lot,
                        };
                        if (productLotExpirationExists) {
                            await productLotExpirationExists.merge(upsertproductLotExpiration).save();
                            productLotExpirationsToSync.push(productLotExpiration.id);
                        }
                        else {
                            await ProdutoLoteExpiracao.create(upsertproductLotExpiration);
                            productLotExpirationsToSync.push(productLotExpiration.id);
                        }
                    }
                }
                if (productLotExpirationsToSync && productLotExpirationsToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'prime_produto_lote_expiracao' }, { updated_at: DateTime.now() });
                }
                console.log(`${productLotExpirationsToSync.length} PRODUTO LOTE EXPIRACAO SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR O(S) PRODUTO LOTE EXPIRACAO', error);
        }
    }
}
//# sourceMappingURL=produto_lote_expiracao.js.map