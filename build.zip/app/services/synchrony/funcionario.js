import axios from 'axios';
import Funcionario from '#models/funcionario';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import { apiURL } from '../index.js';
export default class FuncionarioService {
    async syncEmployees() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'FUNCIONARIO')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/employee', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const employees = response.data.employees;
            console.log(`${employees.length} FUNCIONARIO(S) ENCONTRADO PARA SINCRONIZAR`);
            if (employees && employees.length > 0) {
                const employeesToSync = [];
                for (const employee of employees) {
                    const employeeExists = await Funcionario.findBy('id_prime', employee.id);
                    let idCompany = await findCompanyByIdPrime(employee.empresa_id);
                    if (idCompany) {
                        const upsertEmployee = {
                            idPrime: employee.id,
                            idEmpresa: idCompany,
                            nome: employee.nome,
                            cpf: employee.cpf,
                            email: employee.email,
                            sexo: employee.sexo,
                            telefone: employee.telefone,
                            salario: employee.salario,
                            code_seller: employee.code_seller,
                            funcionario_venda_permission: employee.funcionario_venda_permission,
                            statusfuncionario: employee.status,
                            dataadmissao: employee.data_admissao,
                            datademissao: employee.data_demissao,
                            deleted_at: employee.deleted_at,
                        };
                        if (employeeExists) {
                            await employeeExists.merge(upsertEmployee).save();
                            employeesToSync.push(employee.id);
                        }
                        else {
                            await Funcionario.create(upsertEmployee);
                            employeesToSync.push(employee.id);
                        }
                    }
                }
                if (employeesToSync && employeesToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'FUNCIONARIO' }, { updated_at: DateTime.now() });
                }
                console.log(`${employeesToSync.length} FUNCIONARIO(S) SINCRONIZADO`);
            }
        }
        catch (error) {
            console.error('ERRO AO BUSCAR FUNCIONARIO(S)', error);
        }
    }
}
//# sourceMappingURL=funcionario.js.map