import axios from 'axios';
import Comanda from '#models/comanda';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
export default class ComandaService {
    async syncComanda() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'COMANDA')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/comanda', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const comandas = response.data.comandas;
            console.log(`${comandas.length} COMANDA(S) ENCONTRADAS PARA SINCRONIZAR`);
            if (comandas && comandas.length > 0) {
                const comandasToSync = [];
                for (const comanda of comandas) {
                    const comandaExists = await Comanda.findBy('id_prime', comanda.id);
                    let idCompany = await findCompanyByIdPrime(comanda.id_empresa);
                    if (idCompany) {
                        const upsertComanda = {
                            id_prime: comanda.id,
                            id_empresa: idCompany,
                            comanda: comanda.comanda,
                            chip: comanda.chip,
                            status: comanda.status,
                            deleted_at: comanda.deleted_at,
                        };
                        if (comandaExists) {
                            await comandaExists.merge(upsertComanda).save();
                            comandasToSync.push(comanda.id);
                        }
                        else {
                            await Comanda.create(upsertComanda);
                            comandasToSync.push(comanda.id);
                        }
                    }
                }
                if (comandasToSync && comandasToSync.length > 0) {
                    await Sincronia.updateOrCreate({ nome_tabela: 'COMANDA' }, { updated_at: DateTime.now() });
                }
                console.log(`${comandasToSync.length} COMANDA(S) SINCRONIZADAS`);
            }
        }
        catch (error) {
            console.error('ERRO AO BUSCAR AS COMANDAS', error);
        }
    }
}
//# sourceMappingURL=comanda.js.map