import axios from 'axios';
import TaxaDeEntrega from '#models/taxa_de_entrega';
import Sincronia from '#models/sincronia';
import { DateTime } from 'luxon';
import { apiURL } from '../index.js';
import Grupo from '#models/grupo';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
export default class TaxaDeEntregaService {
    async syncDeliveryFee() {
        try {
            let updatedAtSynchrony = null;
            const synchrony = await Sincronia.query()
                .where('nome_tabela', 'prime_taxa_de_entrega')
                .select('updated_at')
                .first();
            if (synchrony) {
                updatedAtSynchrony = synchrony.updated_at;
            }
            const response = await axios.get(apiURL + '/v1/core/delivery_fee', {
                params: {
                    key: process.env.API_CORE_KEY,
                    updated_at: updatedAtSynchrony,
                },
            });
            const deliveryRates = response.data.deliveryRates;
            console.log(`${deliveryRates.length} TAXA(S) DE ENTREGA ENCONTRADOS PARA SINCRONIZAR`);
            if (deliveryRates && deliveryRates.length > 0) {
                const deliveryRatesToSync = [];
                let idGroup = await Grupo.query().where('id', 1).select(['id']).first();
                if (idGroup) {
                    for (const deliveryFee of deliveryRates) {
                        const deliveryFeeExists = await TaxaDeEntrega.findBy('id_prime', deliveryFee.id);
                        let idCompany = await findCompanyByIdPrime(deliveryFee.empresa_id);
                        let idCreatedByUser = await findUserByIdPrime(deliveryFee.user_created_id);
                        let idUpdatedByUser = await findUserByIdPrime(deliveryFee.user_updated_id);
                        if (idCompany && idGroup && idGroup.id) {
                            const upsertDeliveryFee = {
                                id_prime: deliveryFee.id,
                                valor: deliveryFee.valor,
                                descricao: deliveryFee.descricao,
                                tempo_previsao: deliveryFee.tempo_previsao,
                                grupo_id: idGroup.id,
                                user_created_id: idCreatedByUser,
                                user_updated_id: idUpdatedByUser,
                                user_created_name: deliveryFee.user_created_name,
                                user_updated_name: deliveryFee.user_updated_name,
                                codigo: deliveryFee.codigo,
                                empresa_id: deliveryFee.empresa_id,
                                deleted_at: deliveryFee.deleted_at,
                            };
                            if (deliveryFeeExists) {
                                await deliveryFeeExists.merge(upsertDeliveryFee).save();
                                deliveryRatesToSync.push(deliveryFee.id);
                            }
                            else {
                                await TaxaDeEntrega.create(upsertDeliveryFee);
                                deliveryRatesToSync.push(deliveryFee.id);
                            }
                        }
                    }
                    if (deliveryRatesToSync && deliveryRatesToSync.length > 0) {
                        await Sincronia.updateOrCreate({ nome_tabela: 'prime_taxa_de_entrega' }, { updated_at: DateTime.now() });
                    }
                }
                console.log(`${deliveryRatesToSync.length} TAXA(S) DE ENTREGA SINCRONIZADOS`);
            }
        }
        catch (error) {
            console.error('ERRO AS BUSCAR A(S) TAXA(S) DE ENTREGA', error);
        }
    }
}
//# sourceMappingURL=taxa_de_entrega.js.map