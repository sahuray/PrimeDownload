import VendaSubItem from '#models/venda_sub_item';
import axios from 'axios';
import { apiURL } from '../index.js';
import findSaleByIdCore from '../../../functions/find_id_core_in_rows/find_sale_by_id_core.js';
import findProductByIdCore from '../../../functions/find_id_core_in_rows/find_product_by_id_core.js';
import findSaleItemByIdCore from '../../../functions/find_id_core_in_rows/find_sale_item_by_id_core.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findSaleItemByIdPrime from '../../../functions/find_sale_item_by_id_prime.js';
let fieldsToShow = [
    'id',
    'idPrime',
    'idVendaItem',
    'idProduto',
    'idVenda',
    'status',
    'descricao',
    'comissaoPorcentagem',
    'quantidade',
    'valorUnitario',
    'valorTotal',
    'valorDesconto',
    'codigo',
    'ncm',
    'cfop',
    'csosn',
    'aliquotaIcms',
    'observacao',
    'deletedAt',
];
export default class SaleSubItemCoreService {
    async syncCore() {
        try {
            let saleSubItemsNotSyncPrime = [];
            const saleSubItemsNotSync = await VendaSubItem.query()
                .whereNotNull('id_venda')
                .whereNotNull('id_produto')
                .whereNotNull('id_venda_item')
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${saleSubItemsNotSync.length} VENDA SUB ITEM(S) ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleSubItemsNotSync && saleSubItemsNotSync.length) {
                for (const saleSubItem of saleSubItemsNotSync) {
                    const idSalePrime = await findSaleByIdCore(saleSubItem.idVenda);
                    const idProductPrime = await findProductByIdCore(saleSubItem.idProduto);
                    const idSaleItem = await findSaleItemByIdCore(saleSubItem.idVendaItem);
                    if (idSaleItem && idProductPrime && idSalePrime) {
                        saleSubItemsNotSyncPrime.push({
                            id_core: saleSubItem.id,
                            id_prime: saleSubItem.idPrime,
                            id_produto_prime: idProductPrime,
                            id_venda_prime: idSalePrime,
                            id_venda_item_prime: idSaleItem,
                            status: saleSubItem.status,
                            descricao: saleSubItem.descricao,
                            comissao_porcentagem: saleSubItem.comissaoPorcentagem,
                            quantidade: saleSubItem.quantidade,
                            valor_unitario: saleSubItem.valorUnitario,
                            valor_total: saleSubItem.valorTotal,
                            valor_desconto: saleSubItem.valorDesconto,
                            codigo: saleSubItem.codigo,
                            ncm: saleSubItem.ncm,
                            cfop: saleSubItem.cfop,
                            csosn: saleSubItem.csosn,
                            aliquota_icms: saleSubItem.aliquotaIcms,
                            observacao: saleSubItem.observacao,
                            deleted_at: saleSubItem.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_sub_item', { data: saleSubItemsNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleItems = returnSync.dataSaleSubItemsAlreadySynchronized;
                    if (saleItems && saleItems.length > 0) {
                        for (const saleItem of saleItems) {
                            const idCore = saleItem.id_core;
                            const idProductCore = await findProductByIdPrime(saleItem.id_produto_prime);
                            const idSaleCore = await findSaleByIdPrime(saleItem.id_venda_prime);
                            const idSaleItemCore = await findSaleItemByIdPrime(saleItem.id_venda_item_prime);
                            if (idCore && idSaleCore && idProductCore && idSaleItemCore) {
                                await VendaSubItem.query().where('id', idCore).update({
                                    sync_prime: true,
                                    idPrime: saleItem.id_prime,
                                    idProduto: idProductCore,
                                    idVenda: idSaleCore,
                                    idVendaItem: idSaleItemCore,
                                    status: saleItem.status,
                                    descricao: saleItem.descricao,
                                    comissaoPorcentagem: saleItem.comissao_porcentagem,
                                    quantidade: saleItem.quantidade,
                                    valorUnitario: saleItem.valor_unitario,
                                    valorTotal: saleItem.valor_total,
                                    valorDesconto: saleItem.valor_desconto,
                                    codigo: saleItem.codigo,
                                    ncm: saleItem.ncm,
                                    cfop: saleItem.cfop,
                                    csosn: saleItem.csosn,
                                    aliquotaIcms: saleItem.aliquota_icms,
                                    observacao: saleItem.observacao,
                                    deletedAt: saleItem.deleted_at,
                                });
                            }
                        }
                        console.log(`${saleItems.length} VENDA SUB ITEM(S) | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA SUB ITEM(S) | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_sub_item.js.map