import VendaItemCaracteristica from '#models/venda_item_caracteristica';
import axios from 'axios';
import { apiURL } from '../index.js';
import findSaleSubItemByIdCore from '../../../functions/find_id_core_in_rows/find_sale_sub_item_by_id_core.js';
import findSaleItemByIdCore from '../../../functions/find_id_core_in_rows/find_sale_item_by_id_core.js';
import findProductCharacteristicByIdCore from '../../../functions/find_id_core_in_rows/find_product_characteristic_by_id_core.js';
import findSaleItemByIdPrime from '../../../functions/find_sale_item_by_id_prime.js';
import findSaleSubItemByIdPrime from '../../../functions/find_sale_sub_item_by_id_prime.js';
import findProductCharacteristicByIdPrime from '../../../functions/find_product_characteristic_by_id_prime.js';
let fieldsToShow = [
    'id',
    'id_prime',
    'id_venda_item',
    'id_venda_sub_item',
    'id_produto_caracteristica',
    'codigo',
    'descricao',
    'categoria',
    'fixo',
    'deleted_at',
];
export default class SaleItemCharacteristicCoreService {
    async syncCore() {
        try {
            let saleItemCharacteristicNotSyncPrime = [];
            const saleItemCharacteristicsNotSync = await VendaItemCaracteristica.query()
                .whereNotNull('id_venda_item')
                .whereNotNull('id_produto_caracteristica')
                .whereNotNull('id_venda_sub_item')
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${saleItemCharacteristicsNotSync.length} VENDA ITEM CARACTERISTICA ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleItemCharacteristicsNotSync && saleItemCharacteristicsNotSync.length) {
                for (const saleItemCharacteristicNotSync of saleItemCharacteristicsNotSync) {
                    let idSaleItemPrime = null;
                    let idSaleSubItemPrime = null;
                    if (saleItemCharacteristicNotSync.id_venda_item) {
                        idSaleItemPrime = await findSaleItemByIdCore(saleItemCharacteristicNotSync.id_venda_item);
                    }
                    if (saleItemCharacteristicNotSync.id_venda_sub_item) {
                        idSaleSubItemPrime = await findSaleSubItemByIdCore(saleItemCharacteristicNotSync.id_venda_sub_item);
                    }
                    const idProductCharacteristicPrime = await findProductCharacteristicByIdCore(saleItemCharacteristicNotSync.id_produto_caracteristica);
                    if (idProductCharacteristicPrime) {
                        saleItemCharacteristicNotSyncPrime.push({
                            id_core: saleItemCharacteristicNotSync.id,
                            id_prime: saleItemCharacteristicNotSync.id_prime,
                            id_venda_item_prime: idSaleItemPrime,
                            id_venda_sub_item_prime: idSaleSubItemPrime,
                            id_produto_caracteristica_prime: idProductCharacteristicPrime,
                            codigo: saleItemCharacteristicNotSync.codigo,
                            descricao: saleItemCharacteristicNotSync.descricao,
                            categoria: saleItemCharacteristicNotSync.categoria,
                            fixo: saleItemCharacteristicNotSync.fixo,
                            deleted_at: saleItemCharacteristicNotSync.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_item_characteristic', { data: saleItemCharacteristicNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleItemCharacteristicsAlreadySynchronized = returnSync.dataSaleItemCharacteristicsAlreadySynchronized;
                    if (saleItemCharacteristicsAlreadySynchronized &&
                        saleItemCharacteristicsAlreadySynchronized.length > 0) {
                        for (const saleItemCharacteristic of saleItemCharacteristicsAlreadySynchronized) {
                            const idCore = saleItemCharacteristic.id_core;
                            const idSaleItemCore = await findSaleItemByIdPrime(saleItemCharacteristic.id_venda_item_prime);
                            const idSaleSubItemCore = await findSaleSubItemByIdPrime(saleItemCharacteristic.id_venda_sub_item_prime);
                            const idProductCharacteristicCore = await findProductCharacteristicByIdPrime(saleItemCharacteristic.id_produto_caracteristica_prime);
                            if (idCore) {
                                await VendaItemCaracteristica.query().where('id', idCore).update({
                                    sync_prime: true,
                                    id_prime: saleItemCharacteristic.id_prime,
                                    id_venda_item: idSaleItemCore,
                                    id_venda_sub_item: idSaleSubItemCore,
                                    id_produto_caracteristica: idProductCharacteristicCore,
                                    codigo: saleItemCharacteristic.codigo,
                                    descricao: saleItemCharacteristic.descricao,
                                    categoria: saleItemCharacteristic.categoria,
                                    fixo: saleItemCharacteristic.fixo,
                                    deletedAt: saleItemCharacteristic.deletedAt,
                                });
                            }
                        }
                        console.log(`${saleItemCharacteristicsAlreadySynchronized.length} VENDA ITEM CARACTERISTICA | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA ITEM CARACTERISTICA | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_item_caracteristica.js.map