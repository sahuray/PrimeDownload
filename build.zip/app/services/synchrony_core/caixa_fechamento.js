import axios from 'axios';
import { apiURL } from '../index.js';
import CaixaFechamento from '#models/caixa_fechamento';
import findMovementCashDeskByIdCore from '../../../functions/find_id_core_in_rows/find_movement_cash_desk_by_id_core.js';
import findUserByIdCore from '../../../functions/find_id_core_in_rows/find_user_by_id_core.js';
import findPaymentMethodTypeByIdCore from '../../../functions/find_id_core_in_rows/find_payment_method_type_by_id_core.js';
const fieldsToShow = [
    'id',
    'id_prime',
    'id_usuario',
    'id_caixa_movimento',
    'id_forma_de_pagamento_tipo',
    'historico',
    'valor_sistema',
    'valor_informado',
    'tipo_movimento',
    'data_fechamento',
    'hora_fechamento',
    'deleted_at',
];
export default class CloseCashDeskCoreService {
    async syncCore() {
        try {
            let closeCashDeskNotSyncPrime = [];
            const closeCashDesksNotSync = await CaixaFechamento.query()
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${closeCashDesksNotSync.length} CAIXA FECHAMENTO ENCONTRADOS PARA SINCRONIZAR | CORE --> PRIME`);
            if (closeCashDesksNotSync && closeCashDesksNotSync.length > 0) {
                for (const closeCashDeskNotSync of closeCashDesksNotSync) {
                    const idUser = await findUserByIdCore(closeCashDeskNotSync.id_usuario ?? 0);
                    const idMovementCashDesk = await findMovementCashDeskByIdCore(closeCashDeskNotSync.id_caixa_movimento ?? 0);
                    const idPaymentMethodType = await findPaymentMethodTypeByIdCore(closeCashDeskNotSync.id_forma_de_pagamento_tipo ?? 0);
                    if (idMovementCashDesk) {
                        closeCashDeskNotSyncPrime.push({
                            id_core: closeCashDeskNotSync.id,
                            id_prime: closeCashDeskNotSync.id_prime,
                            id_caixa_movimento_core: closeCashDeskNotSync.id_caixa_movimento,
                            id_caixa_movimento_prime: idMovementCashDesk,
                            id_forma_de_pagamento_tipo_core: closeCashDeskNotSync.id_forma_de_pagamento_tipo,
                            id_forma_de_pagamento_tipo_prime: idPaymentMethodType,
                            id_usuario_core: closeCashDeskNotSync.id_usuario,
                            id_usuario_prime: idUser,
                            historico: closeCashDeskNotSync.historico,
                            valor_sistema: closeCashDeskNotSync.valor_sistema,
                            valor_informado: closeCashDeskNotSync.valor_informado,
                            tipo_movimento: closeCashDeskNotSync.tipo_movimento,
                            data_fechamento: closeCashDeskNotSync.data_fechamento,
                            hora_fechamento: closeCashDeskNotSync.hora_fechamento,
                            deleted_at: closeCashDeskNotSync.deleted_at,
                        });
                    }
                }
            }
            const response = await axios.post(apiURL + '/v1/core/up/close_cash_desk', { data: closeCashDeskNotSyncPrime }, {
                params: {
                    key: process.env.API_CORE_KEY,
                },
            });
            if (response && response.data) {
                const returnSync = response.data;
                const closeCashDesks = returnSync.dataCloseCashDesksAlreadySynchronized;
                if (closeCashDesks && closeCashDesks.length > 0) {
                    for (const closeCashDesk of closeCashDesks) {
                        await CaixaFechamento.query().where('id', closeCashDesk.id_core).update({
                            sync_prime: true,
                            id_prime: closeCashDesk.id_prime,
                        });
                    }
                    console.log(`${closeCashDesks.length} CAIXA FECHAMENTO | CORE --> PRIME SINCRONIZADOS`);
                }
            }
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=caixa_fechamento.js.map