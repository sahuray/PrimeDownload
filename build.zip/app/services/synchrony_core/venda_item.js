import VendaItem from '#models/venda_item';
import axios from 'axios';
import { apiURL } from '../index.js';
import findSaleByIdCore from '../../../functions/find_id_core_in_rows/find_sale_by_id_core.js';
import findProductByIdCore from '../../../functions/find_id_core_in_rows/find_product_by_id_core.js';
import findProductByIdPrime from '../../../functions/find_product_by_id_prime.js';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
let fieldsToShow = [
    'id',
    'idPrime',
    'idProduto',
    'idVenda',
    'syncPrime',
    'status',
    'productDescription',
    'comissaoPorcentagem',
    'saledQuantity',
    'unitaryValue',
    'totalValue',
    'totalDescountValue',
    'ncm',
    'cfop',
    'csosn',
    'aliquotIcms',
    'observacao',
    'deletedAt',
];
export default class SaleItemCoreService {
    async syncCore() {
        try {
            let saleItemsNotSyncPrime = [];
            const saleItemsNotSync = await VendaItem.query()
                .whereNotNull('id_venda')
                .whereNotNull('id_produto')
                .whereHas('venda', (subQuery) => {
                subQuery.whereNotNull('id_prime');
            })
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${saleItemsNotSync.length} VENDA ITEM(S) ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleItemsNotSync && saleItemsNotSync.length) {
                for (const saleItem of saleItemsNotSync) {
                    const idSalePrime = await findSaleByIdCore(saleItem.idVenda);
                    const idProductPrime = await findProductByIdCore(saleItem.idProduto);
                    if (idProductPrime && idSalePrime) {
                        saleItemsNotSyncPrime.push({
                            id_core: saleItem.id,
                            id_prime: saleItem.idPrime,
                            id_produto_prime: idProductPrime,
                            id_venda_prime: idSalePrime,
                            status: saleItem.status,
                            product_description: saleItem.productDescription,
                            comissao_porcentagem: saleItem.comissaoPorcentagem,
                            saled_quantity: saleItem.saledQuantity,
                            unitary_value: saleItem.unitaryValue,
                            total_value: saleItem.totalValue,
                            total_descount_value: saleItem.totalDescountValue,
                            observacao: saleItem.observacao,
                            ncm: saleItem.ncm,
                            cfop: saleItem.cfop,
                            csosn: saleItem.csosn,
                            aliquot_icms: saleItem.aliquotIcms,
                            deleted_at: saleItem.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_item', { data: saleItemsNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleItems = returnSync.dataSaleItemsAlreadySynchronized;
                    if (saleItems && saleItems.length > 0) {
                        for (const saleItem of saleItems) {
                            const idCore = saleItem.id_core;
                            const idProductCore = await findProductByIdPrime(saleItem.id_produto_prime);
                            const idSaleCore = await findSaleByIdPrime(saleItem.id_venda_prime);
                            if (idCore && idSaleCore && idProductCore) {
                                await VendaItem.query().where('id', idCore).update({
                                    sync_prime: true,
                                    idPrime: saleItem.id_prime,
                                    idProduto: idProductCore,
                                    idVenda: idSaleCore,
                                    status: saleItem.status,
                                    productDescription: saleItem.product_description,
                                    comissaoPorcentagem: saleItem.comissao_porcentagem,
                                    saledQuantity: saleItem.saled_quantity,
                                    unitaryValue: saleItem.unitary_value,
                                    totalValue: saleItem.total_value,
                                    totalDescountValue: saleItem.total_descount_value,
                                    ncm: saleItem.ncm,
                                    cfop: saleItem.cfop,
                                    csosn: saleItem.csosn,
                                    aliquotIcms: saleItem.aliquot_icms,
                                    deletedAt: saleItem.deleted_at,
                                });
                            }
                        }
                        console.log(`${saleItems.length} VENDA ITEM(S) | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA ITEM(S) | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_item.js.map