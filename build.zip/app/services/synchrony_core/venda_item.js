import VendaItem from '#models/venda_item';
import axios from 'axios';
import { apiURL } from '../index.js';
import findSaleByIdCore from '../../../functions/find_id_core_in_rows/find_sale_by_id_core.js';
import findProductByIdCore from '../../../functions/find_id_core_in_rows/find_product_by_id_core.js';
let fieldsToShow = [
    'id',
    'idPrime',
    'idProduto',
    'idVenda',
    'syncPrime',
    'status',
    'productDescription',
    'comissaoPorcentagem',
    'saledQuantity',
    'unitaryValue',
    'totalValue',
    'totalDescountValue',
    'ncm',
    'cfop',
    'csosn',
    'aliquotIcms',
    'observacao',
    'desconto_rateio_venda',
    'deletedAt',
];
export default class SaleItemCoreService {
    async syncCore() {
        try {
            let saleItemsNotSyncPrime = [];
            const saleItemsNotSync = await VendaItem.query()
                .whereNotNull('id_venda')
                .whereNotNull('id_produto')
                .whereHas('venda', (subQuery) => {
                subQuery.whereNotNull('id_prime');
            })
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${saleItemsNotSync.length} VENDA ITEM(S) ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleItemsNotSync && saleItemsNotSync.length) {
                for (const saleItem of saleItemsNotSync) {
                    const idSalePrime = await findSaleByIdCore(saleItem.idVenda);
                    const idProductPrime = await findProductByIdCore(saleItem.idProduto);
                    if (idProductPrime && idSalePrime) {
                        saleItemsNotSyncPrime.push({
                            id_core: saleItem.id,
                            id_prime: saleItem.idPrime,
                            id_produto_prime: idProductPrime,
                            id_venda_prime: idSalePrime,
                            status: saleItem.status,
                            product_description: saleItem.productDescription,
                            comissao_porcentagem: saleItem.comissaoPorcentagem,
                            saled_quantity: saleItem.saledQuantity,
                            unitary_value: saleItem.unitaryValue,
                            total_value: saleItem.totalValue,
                            total_descount_value: saleItem.totalDescountValue,
                            observacao: saleItem.observacao,
                            ncm: saleItem.ncm,
                            cfop: saleItem.cfop,
                            csosn: saleItem.csosn,
                            aliquot_icms: saleItem.aliquotIcms,
                            desconto_rateio_venda: saleItem.desconto_rateio_venda,
                            deleted_at: saleItem.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_item', { data: saleItemsNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleItems = returnSync.returnDataSaleItemAlreadySynchronized;
                    if (saleItems && saleItems.length > 0) {
                        for (const saleItem of saleItems) {
                            const idCore = saleItem.id_core;
                            if (idCore) {
                                await VendaItem.query().where('id', idCore).update({
                                    sync_prime: true,
                                    idPrime: saleItem.id_prime,
                                });
                            }
                        }
                        console.log(`${saleItems.length} VENDA ITEM(S) | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA ITEM(S) | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_item.js.map