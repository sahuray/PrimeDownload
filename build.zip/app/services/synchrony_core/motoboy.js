import axios from 'axios';
import { apiURL } from '../index.js';
import Motoboy from '#models/motoboy';
import findGroupByIdCore from '../../../functions/find_id_core_in_rows/find_group_by_id_core.js';
import findCompanyByIdCore from '../../../functions/find_id_core_in_rows/find_company_by_id_core.js';
let fieldsToShow = [
    'id',
    'id_prime',
    'id_grupo',
    'id_empresa',
    'nome',
    'codigo',
    'rg',
    'cnh',
    'telefone',
    'email',
    'endereco',
    'numero',
    'complemento',
    'bairro',
    'cidade',
    'uf',
    'cep',
    'placa',
    'ano',
    'modelo',
];
export default class MotoboyCoreService {
    async syncCore() {
        try {
            let motoboysNotSyncPrime = [];
            const motoboysNotSync = await Motoboy.query().where('sync_prime', false).select(fieldsToShow);
            console.log(`${motoboysNotSync.length} MOTOBOY ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (motoboysNotSync && motoboysNotSync.length) {
                for (const motoboyNotSync of motoboysNotSync) {
                    const idGroup = await findGroupByIdCore(motoboyNotSync.id_grupo);
                    const idCompany = await findCompanyByIdCore(motoboyNotSync.id_empresa);
                    if (idGroup && idCompany) {
                        motoboysNotSyncPrime.push({
                            id_core: motoboyNotSync.id,
                            id_prime: motoboyNotSync.id_prime,
                            id_grupo_core: motoboyNotSync.id_grupo,
                            id_grupo_prime: idGroup,
                            id_empresa_core: motoboyNotSync.id_empresa,
                            id_empresa_prime: idCompany,
                            nome: motoboyNotSync.nome,
                            codigo: motoboyNotSync.codigo,
                            rg: motoboyNotSync.rg,
                            cnh: motoboyNotSync.cnh,
                            telefone: motoboyNotSync.telefone,
                            email: motoboyNotSync.email,
                            endereco: motoboyNotSync.endereco,
                            numero: motoboyNotSync.numero,
                            complemento: motoboyNotSync.complemento,
                            bairro: motoboyNotSync.bairro,
                            cidade: motoboyNotSync.cidade,
                            uf: motoboyNotSync.uf,
                            cep: motoboyNotSync.cep,
                            placa: motoboyNotSync.placa,
                            ano: motoboyNotSync.ano,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/motoboy', { data: motoboysNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const motoboys = returnSync.dataMotoboysAlreadySynchronized;
                    if (motoboys && motoboys.length > 0) {
                        for (const motoboy of motoboys) {
                            await Motoboy.query().where('id', motoboy.id_core).update({
                                sync_prime: true,
                                id_prime: motoboy.id_prime,
                            });
                        }
                        console.log(`${motoboys.length} MOTOBOY | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO MOTOBOY | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=motoboy.js.map