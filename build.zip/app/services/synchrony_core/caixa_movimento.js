import CaixaMovimento from '#models/caixa_movimento';
import axios from 'axios';
import { apiURL } from '../index.js';
import findTerminalByIdCore from '../../../functions/find_id_core_in_rows/find_terminal_by_id_core.js';
import findEmployeeByIdUser from '../../../functions/find_employee_by_id_funcionario_usuario.js';
let fieldsToShow = [
    'idcaixamovimento',
    'id_prime',
    'idfuncionariousuarioabertura',
    'idfuncionariousuariofechamento',
    'idterminal',
    'dataabertura',
    'horaabertura',
    'datafechamento',
    'horafechamento',
    'totalvenda',
    'totalsaida',
    'totalestorno',
    'totaldinheirocaixa',
    'suprimentoatual',
    'saldoanterior',
    'saldofinal',
    'status',
    'justificativa',
    'datasync',
    'sync_prime',
];
export default class MovementCashDeskCoreService {
    async syncCore() {
        try {
            let movementCashDeskNotSyncPrime = [];
            const movementCashDesksNotSync = await CaixaMovimento.query()
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${movementCashDesksNotSync.length} CAIXA MOVIMENTO ENCONTRADOS PARA SINCRONIZAR | CORE --> PRIME`);
            if (movementCashDesksNotSync && movementCashDesksNotSync.length > 0) {
                for (const movementCashDeskNotSync of movementCashDesksNotSync) {
                    const idUserEmployeeOpen = await findEmployeeByIdUser(movementCashDeskNotSync.idfuncionariousuarioabertura ?? 0);
                    const idUserEmployeeClose = await findEmployeeByIdUser(movementCashDeskNotSync.idfuncionariousuariofechamento ?? 0);
                    const idTerminal = await findTerminalByIdCore(movementCashDeskNotSync.idterminal ?? 0);
                    if (idTerminal && idUserEmployeeOpen) {
                        movementCashDeskNotSyncPrime.push({
                            id_core: movementCashDeskNotSync.idcaixamovimento,
                            id_prime: movementCashDeskNotSync.id_prime,
                            id_terminal_core: movementCashDeskNotSync.idterminal,
                            id_terminal_prime: idTerminal,
                            id_funcionario_abertura_core: movementCashDeskNotSync.idfuncionariousuarioabertura,
                            id_funcionario_abertura_prime: idUserEmployeeOpen,
                            id_funcionario_fechamento_core: movementCashDeskNotSync.idfuncionariousuariofechamento,
                            id_funcionario_fechamento_prime: idUserEmployeeClose,
                            dataabertura: movementCashDeskNotSync.dataabertura,
                            horaabertura: movementCashDeskNotSync.horaabertura,
                            datafechamento: movementCashDeskNotSync.datafechamento,
                            horafechamento: movementCashDeskNotSync.horafechamento,
                            totalvenda: movementCashDeskNotSync.totalvenda,
                            totalsaida: movementCashDeskNotSync.totalsaida,
                            totalestorno: movementCashDeskNotSync.totalestorno,
                            totaldinheirocaixa: movementCashDeskNotSync.totaldinheirocaixa,
                            suprimentoatual: movementCashDeskNotSync.suprimentoatual,
                            saldoanterior: movementCashDeskNotSync.saldoanterior,
                            saldofinal: movementCashDeskNotSync.saldofinal,
                            status: movementCashDeskNotSync.status,
                            justificativa: movementCashDeskNotSync.justificativa,
                            datasync: movementCashDeskNotSync.datasync,
                        });
                    }
                }
            }
            const response = await axios.post(apiURL + '/v1/core/up/movement_cash_desk', { data: movementCashDeskNotSyncPrime }, {
                params: {
                    key: process.env.API_CORE_KEY,
                },
            });
            if (response && response.data) {
                const returnSync = response.data;
                const movementCashDesks = returnSync.dataMovementCashDesksAlreadySynchronized;
                if (movementCashDesks && movementCashDesks.length > 0) {
                    for (const movementCashDesk of movementCashDesks) {
                        await CaixaMovimento.query()
                            .where('idcaixamovimento', movementCashDesk.id_core)
                            .update({
                            sync_prime: true,
                            id_prime: movementCashDesk.id_prime,
                        });
                    }
                    console.log(`${movementCashDesks.length} CAIXA MOVIMENTO | CORE --> PRIME SINCRONIZADOS`);
                }
            }
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=caixa_movimento.js.map