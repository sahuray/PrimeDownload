import axios from 'axios';
import { apiURL } from '../index.js';
import Contato from '#models/contato';
import findCompanyByIdCore from '../../../functions/find_id_core_in_rows/find_company_by_id_core.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
let fieldsToShow = [
    'id',
    'id_fk',
    'id_prime',
    'tipo_relacionamento',
    'email',
    'nome',
    'telefone',
    'observacao',
    'tipo_contato',
    'deletedAt',
];
export default class ContactCoreService {
    async syncCore() {
        try {
            let contactNotSyncPrime = [];
            const contactNotSync = await Contato.query().where('sync_prime', false).select(fieldsToShow);
            console.log(`${contactNotSync.length} CONTATOS ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (contactNotSync && contactNotSync.length > 0) {
                for (const contact of contactNotSync) {
                    const idCompanyPrime = await findCompanyByIdCore(contact.id_fk);
                    contactNotSyncPrime.push({
                        id_core: contact.id,
                        id_prime: contact.id_prime,
                        id_company_prime: idCompanyPrime,
                        tipo_relacionamento: contact.tipo_relacionamento,
                        email: contact.email,
                        nome: contact.nome,
                        telefone: contact.telefone,
                        observacao: contact.observacao,
                        tipo_contato: contact.tipo_contato,
                        deleted_at: contact.deletedAt,
                    });
                }
            }
            const response = await axios.post(apiURL + '/v1/core/up/contact', { data: contactNotSyncPrime }, {
                params: {
                    key: process.env.API_CORE_KEY,
                },
            });
            if (response && response.data) {
                const returnSync = response.data;
                const contacts = returnSync.dataContactsAlreadySynchronized;
                if (contacts && contacts.length > 0) {
                    for (const contact of contacts) {
                        const idCompanyCore = await findCompanyByIdPrime(contact.id_company_prime);
                        if (idCompanyCore) {
                            await Contato.query().where('id', contact.id_core).update({
                                sync_prime: true,
                                id_prime: contact.id_prime,
                                id_fk: idCompanyCore,
                                tipo_relacionamento: contact.tipo_relacionamento,
                                email: contact.email,
                                nome: contact.nome,
                                telefone: contact.telefone,
                                observacao: contact.observacao,
                                tipo_contato: contact.tipo_contato,
                                deletedAt: contact.deletedAt,
                            });
                        }
                    }
                    console.log(`${contacts.length} ENDERECO(S) | CORE --> PRIME SINCRONIZADOS`);
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO CONTATO(S) | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=contato.js.map