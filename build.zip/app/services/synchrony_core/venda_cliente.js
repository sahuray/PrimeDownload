import VendaCliente from '#models/venda_cliente';
import axios from 'axios';
import { apiURL } from '../index.js';
import findCompanyByIdCore from '../../../functions/find_id_core_in_rows/find_company_by_id_core.js';
import findSaleByIdCore from '../../../functions/find_id_core_in_rows/find_sale_by_id_core.js';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
let fieldsToShow = [
    'id',
    'idPrime',
    'idVenda',
    'idEmpresa',
    'nomeFantasia',
    'razaoSocial',
    'apelido',
    'cnpjCpf',
    'ieRg',
    'im',
    'email',
    'telefone',
    'codigo',
    'tipo',
    'origem',
    'aniversario',
    'tipoEndereco',
    'cep',
    'uf',
    'cidade',
    'bairro',
    'logradouro',
    'numero',
    'complemento',
    'codigoCidade',
    'codigoUf',
    'referencia',
    'contatoNome',
    'contatoEmail',
    'contatoTelefone',
    'contatoObservacao',
    'tipoContato',
    'deletedAt',
];
export default class SaleClientCoreService {
    async syncCore() {
        try {
            let saleClientNotSyncPrime = [];
            const saleClientNotSync = await VendaCliente.query()
                .whereNotNull('id_venda')
                .whereNotNull('id_empresa')
                .where('sync_prime', false)
                .whereHas('venda', (subQuery) => {
                subQuery.whereNotNull('id_prime');
            })
                .select(fieldsToShow);
            console.log(`${saleClientNotSync.length} VENDA CLIENTE ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleClientNotSync && saleClientNotSync.length) {
                for (const saleClient of saleClientNotSync) {
                    const idSalePrime = await findSaleByIdCore(saleClient.idVenda);
                    const idCompanyPrime = await findCompanyByIdCore(saleClient.idEmpresa);
                    if (idCompanyPrime && idSalePrime) {
                        saleClientNotSyncPrime.push({
                            id_core: saleClient.id,
                            id_prime: saleClient.idPrime,
                            id_empresa_prime: idCompanyPrime,
                            id_venda_prime: idSalePrime,
                            nome_fantasia: saleClient.nomeFantasia,
                            razao_social: saleClient.razaoSocial,
                            apelido: saleClient.apelido,
                            cnpj_cpf: saleClient.cnpjCpf,
                            ie_rg: saleClient.ieRg,
                            im: saleClient.im,
                            email: saleClient.email,
                            telefone: saleClient.telefone,
                            codigo: saleClient.codigo,
                            tipo: saleClient.tipo,
                            origem: saleClient.origem,
                            aniversario: saleClient.aniversario,
                            tipo_endereco: saleClient.tipoEndereco,
                            cep: saleClient.cep,
                            uf: saleClient.uf,
                            cidade: saleClient.cidade,
                            bairro: saleClient.bairro,
                            logradouro: saleClient.logradouro,
                            numero: saleClient.numero,
                            complemento: saleClient.complemento,
                            codigo_cidade: saleClient.codigoCidade,
                            codigo_uf: saleClient.codigoUf,
                            referencia: saleClient.referencia,
                            contato_nome: saleClient.contatoNome,
                            contato_email: saleClient.contatoEmail,
                            contato_telefone: saleClient.contatoTelefone,
                            contato_observacao: saleClient.contatoObservacao,
                            tipo_contato: saleClient.tipoContato,
                            deleted_at: saleClient.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_client', { data: saleClientNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleClients = returnSync.dataSaleClientsAlreadySynchronized;
                    if (saleClients && saleClients.length > 0) {
                        for (const saleClient of saleClients) {
                            const idCore = saleClient.id_core;
                            const idCompanyCore = await findCompanyByIdPrime(saleClient.id_empresa_prime);
                            const idSaleCore = await findSaleByIdPrime(saleClient.id_venda_prime);
                            if (idCore && idSaleCore && idCompanyCore) {
                                await VendaCliente.query().where('id', idCore).update({
                                    sync_prime: true,
                                    idPrime: saleClient.id_prime,
                                    idVenda: idSaleCore,
                                    idEmpresa: idCompanyCore,
                                    nomeFantasia: saleClient.nome_fantasia,
                                    razaoSocial: saleClient.razao_social,
                                    apelido: saleClient.apelido,
                                    cnpjCpf: saleClient.cnpj_cpf,
                                    ieRg: saleClient.ie_rg,
                                    im: saleClient.im,
                                    email: saleClient.email,
                                    telefone: saleClient.telefone,
                                    codigo: saleClient.codigo,
                                    tipo: saleClient.tipo,
                                    origem: saleClient.origem,
                                    aniversario: saleClient.aniversario,
                                    tipoEndereco: saleClient.tipo_endereco,
                                    cep: saleClient.cep,
                                    uf: saleClient.uf,
                                    cidade: saleClient.cidade,
                                    bairro: saleClient.bairro,
                                    logradouro: saleClient.logradouro,
                                    numero: saleClient.numero,
                                    complemento: saleClient.complemento,
                                    codigoCidade: saleClient.codigo_cidade,
                                    codigoUf: saleClient.codigo_uf,
                                    referencia: saleClient.referencia,
                                    contatoNome: saleClient.contato_nome,
                                    contatoEmail: saleClient.contato_email,
                                    contatoTelefone: saleClient.contato_telefone,
                                    contatoObservacao: saleClient.contato_observacao,
                                    tipoContato: saleClient.tipo_contato,
                                    deletedAt: saleClient.deleted_at,
                                });
                            }
                        }
                        console.log(`${saleClients.length} VENDA CLIENTE | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA CLIENTE | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_cliente.js.map