import VendaFormaPagamento from '#models/venda_forma_de_pagamento';
import axios from 'axios';
import { apiURL } from '../index.js';
import findSaleByIdCore from '../../../functions/find_id_core_in_rows/find_sale_by_id_core.js';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findPaymentMethodByIdCore from '../../../functions/find_id_core_in_rows/find_payment_method_by_id_core.js';
import findPaymentMethodByIdPrime from '../../../functions/find_payment_method_by_id_prime.js';
let fieldsToShow = [
    'id',
    'idPrime',
    'idVenda',
    'idFormaDePagamento',
    'installmentValue',
    'deletedAt',
];
export default class SalePaymentMethodCoreService {
    async syncCore() {
        try {
            let salePaymentMethodNotSyncPrime = [];
            const salePaymentMethodsNotSync = await VendaFormaPagamento.query()
                .whereNotNull('id_venda')
                .whereNotNull('id_forma_de_pagamento')
                .whereHas('venda', (subQuery) => {
                subQuery.whereNotNull('id_prime');
            })
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${salePaymentMethodsNotSync.length} VENDA FORMA DE PAGAMENTO ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (salePaymentMethodsNotSync && salePaymentMethodsNotSync.length) {
                for (const salePaymentMethod of salePaymentMethodsNotSync) {
                    const idSalePrime = await findSaleByIdCore(salePaymentMethod.idVenda);
                    const idPaymentMethodPrime = await findPaymentMethodByIdCore(salePaymentMethod.idFormaDePagamento);
                    if (idSalePrime && idPaymentMethodPrime) {
                        salePaymentMethodNotSyncPrime.push({
                            id_core: salePaymentMethod.id,
                            id_prime: salePaymentMethod.idPrime,
                            id_venda_prime: idSalePrime,
                            id_forma_de_pagamento_prime: idPaymentMethodPrime,
                            installment_value: salePaymentMethod.installmentValue,
                            deleted_at: salePaymentMethod.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_payment_method', { data: salePaymentMethodNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const salePaymentMethods = returnSync.dataSalePaymentMethodsAlreadySynchronized;
                    if (salePaymentMethods && salePaymentMethods.length > 0) {
                        for (const salePaymentMethod of salePaymentMethods) {
                            const idCore = salePaymentMethod.id_core;
                            const idSaleCore = await findSaleByIdPrime(salePaymentMethod.id_venda_prime);
                            const idPaymentMethodCore = await findPaymentMethodByIdPrime(salePaymentMethod.id_forma_de_pagamento_prime);
                            if (idCore && idSaleCore && idPaymentMethodCore) {
                                await VendaFormaPagamento.query().where('id', idCore).update({
                                    sync_prime: true,
                                    idPrime: salePaymentMethod.id_prime,
                                    idFormaDePagamento: idPaymentMethodCore,
                                    idVenda: idSaleCore,
                                    installmentValue: salePaymentMethod.installmentValue,
                                    deletedAt: salePaymentMethod.deleted_at,
                                });
                            }
                        }
                        console.log(`${salePaymentMethods.length} VENDA FORMA DE PAGAMENTO | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA FORMA DE PAGAMENTO | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_forma_de_pagamento.js.map