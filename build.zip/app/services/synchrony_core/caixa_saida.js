import axios from 'axios';
import { apiURL } from '../index.js';
import CaixaMovimentoSaida from '#models/caixa_entrada_e_saida';
import findEmployeeByIdUser from '../../../functions/find_employee_by_id_funcionario_usuario.js';
import findMovementCashDeskByIdCore from '../../../functions/find_id_core_in_rows/find_movement_cash_desk_by_id_core.js';
import findPaymentMethodTypeByIdCore from '../../../functions/find_id_core_in_rows/find_payment_method_type_by_id_core.js';
const fieldsToShow = [
    'id',
    'id_prime',
    'id_caixa_movimento',
    'id_forma_pagamento_tipo',
    'id_funcionario_usuario',
    'tipo',
    'dataemissao',
    'horaemissao',
    'descricao',
    'valor',
    'sangria',
    'deleted_at',
];
export default class ExitCashDeskCoreService {
    async syncCore() {
        try {
            let exitCashDeskNotSyncPrime = [];
            const exitCashDesksNotSync = await CaixaMovimentoSaida.query()
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${exitCashDesksNotSync.length} CAIXA SAIDA ENCONTRADOS PARA SINCRONIZAR | CORE --> PRIME`);
            if (exitCashDesksNotSync && exitCashDesksNotSync.length > 0) {
                for (const exitCashDeskNotSync of exitCashDesksNotSync) {
                    const idMovementCashDesk = await findMovementCashDeskByIdCore(exitCashDeskNotSync.id_caixa_movimento);
                    const idPaymentMethodType = await findPaymentMethodTypeByIdCore(exitCashDeskNotSync.id_forma_pagamento_tipo);
                    const idUserEmployeeClose = await findEmployeeByIdUser(exitCashDeskNotSync.id_funcionario_usuario ?? 0);
                    if (idMovementCashDesk && idPaymentMethodType) {
                        exitCashDeskNotSyncPrime.push({
                            id_core: exitCashDeskNotSync.id,
                            id_prime: exitCashDeskNotSync.id_prime,
                            id_caixa_movimento_core: exitCashDeskNotSync.id_caixa_movimento,
                            id_caixa_movimento_prime: idMovementCashDesk,
                            id_forma_pagamento_tipo_core: exitCashDeskNotSync.id_forma_pagamento_tipo,
                            id_forma_pagamento_tipo_prime: idPaymentMethodType,
                            id_funcionario_usuario_core: exitCashDeskNotSync.id_funcionario_usuario,
                            id_funcionario_usuario_prime: idUserEmployeeClose,
                            valor: exitCashDeskNotSync.valor,
                            descricao: exitCashDeskNotSync.descricao,
                            sangria: exitCashDeskNotSync.sangria,
                            data_emissao: exitCashDeskNotSync.dataemissao,
                            hora_emissao: exitCashDeskNotSync.horaemissao,
                            tipo: exitCashDeskNotSync.tipo,
                            deleted_at: exitCashDeskNotSync.deleted_at,
                        });
                    }
                }
            }
            const response = await axios.post(apiURL + '/v1/core/up/exit_cash_desk', { data: exitCashDeskNotSyncPrime }, {
                params: {
                    key: process.env.API_CORE_KEY,
                },
            });
            if (response && response.data) {
                const returnSync = response.data;
                const exitCashDesks = returnSync.dataExitCashDesksAlreadySynchronized;
                if (exitCashDesks && exitCashDesks.length > 0) {
                    for (const closeCashDesk of exitCashDesks) {
                        await CaixaMovimentoSaida.query().where('id', closeCashDesk.id_core).update({
                            sync_prime: true,
                            id_prime: closeCashDesk.id_prime,
                        });
                    }
                    console.log(`${exitCashDesks.length} CAIXA SAÍDA | CORE --> PRIME SINCRONIZADOS`);
                }
            }
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=caixa_saida.js.map