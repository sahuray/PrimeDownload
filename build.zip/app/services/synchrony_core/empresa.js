import Empresa from '#models/empresa';
import axios from 'axios';
import { apiURL } from '../index.js';
let fieldsToShow = [
    'id',
    'id_prime_empresa',
    'telefone',
    'codigo',
    'nome_fantasia',
    'cnpj_cpf',
    'ie_rg',
    'email',
    'contato',
    'aniversario',
    'tipo',
    'origem',
];
export default class CompanyCoreService {
    async syncCore() {
        try {
            const companiesNotSyncPrime = await Empresa.query()
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${companiesNotSyncPrime.length} EMPRESAS ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            const response = await axios.post(apiURL + '/v1/core/up/company', { data: companiesNotSyncPrime }, {
                params: {
                    key: process.env.API_CORE_KEY,
                },
            });
            if (response && response.data) {
                const returnSync = response.data;
                const companies = returnSync.dataCompaniesAlreadySynchronized;
                if (companies && companies.length > 0) {
                    for (const company of companies) {
                        await Empresa.query().where('id', company.idCore).update({
                            sync_prime: true,
                            id_prime_empresa: company.idPrimeEmpresa,
                            codigo: company.codigo,
                            cnpj_cpf: company.cnpjCpf,
                            aniversario: company.aniversario,
                            telefone: company.telefone,
                            contato: company.contato,
                            email: company.email,
                            ie_rg: company.ieRg,
                            nome_fantasia: company.nomeFantasia,
                            razao_social: company.razaoSocial,
                            apelido: company.apelido,
                            origem: company.origem,
                            tipo: company.tipo,
                        });
                    }
                    console.log(`${companies.length} EMPRESA(S) | CORE --> PRIME SINCRONIZADOS`);
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO EMPRESA(S) | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=empresa.js.map