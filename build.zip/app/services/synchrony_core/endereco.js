import Endereco from '#models/endereco';
import axios from 'axios';
import { apiURL } from '../index.js';
import findCompanyByIdCore from '../../../functions/find_id_core_in_rows/find_company_by_id_core.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
let fieldsToShow = [
    'id',
    'id_fk',
    'id_prime',
    'bairro',
    'cep',
    'cidade',
    'codigo_cidade',
    'codigo_uf',
    'complemento',
    'logradouro',
    'numero',
    'referencia',
    'sync_prime',
    'tipo',
    'tipo_relacionamento',
    'uf',
];
export default class AddressCoreService {
    async syncCore() {
        try {
            let addressNotSyncPrime = [];
            const addressesNotSync = await Endereco.query()
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${addressesNotSync.length} ENDERECO(S) ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (addressesNotSync && addressesNotSync.length) {
                for (const address of addressesNotSync) {
                    const idCompanyPrime = await findCompanyByIdCore(address.id_fk);
                    addressNotSyncPrime.push({
                        id_core: address.id,
                        id_prime: address.id_prime,
                        id_company_prime: idCompanyPrime,
                        bairro: address.bairro,
                        cep: address.cep,
                        cidade: address.cidade,
                        codigo_cidade: address.codigo_cidade,
                        codigo_uf: address.codigo_uf,
                        complemento: address.complemento,
                        logradouro: address.logradouro,
                        numero: address.numero,
                        tipo: address.tipo,
                        uf: address.uf,
                    });
                }
                const response = await axios.post(apiURL + '/v1/core/up/address', { data: addressNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const addresses = returnSync.dataAddressAlreadySynchronized;
                    if (addresses && addresses.length > 0) {
                        for (const address of addresses) {
                            const idCompanyCore = await findCompanyByIdPrime(address.id_company_prime);
                            if (idCompanyCore) {
                                await Endereco.query().where('id', address.id_core).update({
                                    sync_prime: true,
                                    id_fk: idCompanyCore,
                                    id_prime: address.id_prime,
                                    bairro: address.bairro,
                                    cep: address.cep,
                                    cidade: address.cidade,
                                    codigo_cidade: address.codigo_cidade,
                                    codigo_uf: address.codigo_uf,
                                    complemento: address.complemento,
                                    logradouro: address.logradouro,
                                    numero: address.numero,
                                    referencia: address.referencia,
                                    tipo: address.tipo,
                                    tipo_relacionamento: address.tipo_relacionamento,
                                    uf: address.uf,
                                });
                            }
                        }
                        console.log(`${addresses.length} ENDERECO(S) | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO ENDERECO(S) | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=endereco.js.map