import Venda from '#models/venda';
import axios from 'axios';
import { apiURL } from '../index.js';
import findCompanyByIdCore from '../../../functions/find_id_core_in_rows/find_company_by_id_core.js';
import findCompanyByIdPrime from '../../../functions/find_company_by_id_prime.js';
import findMovemntCashDeskByIdCore from '../../../functions/find_id_core_in_rows/find_movement_cash_desk_by_id_core.js';
import findUserByIdCore from '../../../functions/find_id_core_in_rows/find_user_by_id_core.js';
import findTerminalByIdCore from '../../../functions/find_id_core_in_rows/find_terminal_by_id_core.js';
import findSellerByIdCore from '../../../functions/find_id_core_in_rows/find_seller_by_id_core.js';
import findMovementCashDeskByIdPrime from '../../../functions/find_movement_cash_desk_by_id_prime.js';
import findUserByIdPrime from '../../../functions/find_user_by_id_prime.js';
import findTerminalByIdPrime from '../../../functions/find_terminal_by_id_prime.js';
import findEmployeeByIdPrime from '../../../functions/find_employee_by_id_prime.js';
import findGroupByIdCore from '../../../functions/find_id_core_in_rows/find_group_by_id_core.js';
let fieldsToShow = [
    'id',
    'idPrime',
    'idGrupo',
    'idCliente',
    'idCaixaMovimento',
    'idUsuarioInativar',
    'idUsuarioCriacao',
    'idTerminal',
    'idVendedor',
    'idEmpresa',
    'syncPrime',
    'e_orcamento',
    'comissaoPorcentagem',
    'totalValue',
    'totalDescountValue',
    'cpf',
    'motivoCancelamento',
    'codigo',
    'observacao',
    'finalizado',
    'status',
    'origem',
    'deletedAt',
    'code',
    'satXml',
    'satXmlPath',
    'satNumeroSerie',
    'satXmlCancelamento',
    'satXmlPathCancelamento',
    'cooCancelamento',
];
export default class SaleCoreService {
    async syncCore() {
        try {
            let salesNotSyncPrime = [];
            const salesNotSync = await Venda.query()
                .where('status', 'FINALIZADO')
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${salesNotSync.length} VENDA(S) ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (salesNotSync && salesNotSync.length) {
                for (const sale of salesNotSync) {
                    const idCompanyPrime = await findCompanyByIdCore(sale.idEmpresa || 0);
                    const idClientPrime = await findCompanyByIdCore(sale.idCliente || 0);
                    const idMovementCashDeskPrime = await findMovemntCashDeskByIdCore(sale.idCaixaMovimento || 0);
                    const idUserInativedPrime = await findUserByIdCore(sale.idUsuarioInativar || 0);
                    const idUserCreatedPrime = await findUserByIdCore(sale.idUsuarioCriacao || 0);
                    const idTerminalPrime = await findTerminalByIdCore(sale.idTerminal || 0);
                    const idSellerPrime = await findSellerByIdCore(sale.idVendedor || 0);
                    const idGroupPrime = await findGroupByIdCore(sale.idGrupo);
                    salesNotSyncPrime.push({
                        id_core: sale.id,
                        id_prime: sale.idPrime,
                        id_grupo_prime: idGroupPrime,
                        id_cliente_prime: idClientPrime,
                        id_empresa_prime: idCompanyPrime,
                        id_caixa_movimento_prime: idMovementCashDeskPrime,
                        id_usuario_inativar_prime: idUserInativedPrime,
                        id_usuario_criacao_prime: idUserCreatedPrime,
                        id_terminal_prime: idTerminalPrime,
                        id_vendedor_prime: idSellerPrime,
                        comissao_porcentagem: sale.comissaoPorcentagem,
                        total_value: sale.totalValue,
                        total_descount_value: sale.totalDescountValue,
                        e_orcamento: sale.e_orcamento,
                        cpf: sale.cpf,
                        motivo_cancelamento: sale.motivoCancelamento,
                        codigo: sale.codigo,
                        observacao: sale.observacao,
                        finalizado: sale.finalizado,
                        status: sale.status,
                        origem: sale.origem,
                        deleted_at: sale.deletedAt,
                        code: sale.code,
                        sat_xml: sale.satXml,
                        sat_xml_path: sale.satXmlPath,
                        sat_numero_serie: sale.satNumeroSerie,
                        sat_xml_cancelamento: sale.satXmlCancelamento,
                        sat_xml_path_cancelamento: sale.satXmlPathCancelamento,
                        coo_cancelamento: sale.cooCancelamento,
                    });
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale', { data: salesNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const sales = returnSync.dataSalesAlreadySynchronized;
                    if (sales && sales.length > 0) {
                        for (const sale of sales) {
                            const idSaleCore = sale.id_core;
                            const idTerminalCore = await findTerminalByIdPrime(sale.id_terminal_prime);
                            const idCompanyCore = await findCompanyByIdPrime(sale.id_empresa_prime);
                            const idClientCore = await findCompanyByIdPrime(sale.id_cliente_prime);
                            const idMovementCashDeskCore = await findMovementCashDeskByIdPrime(sale.id_caixa_movimento_prime);
                            const idUserInativatedCore = await findUserByIdPrime(sale.id_usuario_inativar_prime);
                            const idUserCreatedCore = await findUserByIdPrime(sale.id_usuario_criacao_prime);
                            const idSellerCore = await findEmployeeByIdPrime(sale.id_vendedor_prime);
                            if (idSaleCore) {
                                await Venda.query().where('id', idSaleCore).update({
                                    sync_prime: true,
                                    idPrime: sale.id_prime,
                                    idCliente: idClientCore,
                                    idCaixaMovimento: idMovementCashDeskCore,
                                    idUsuarioInativar: idUserInativatedCore,
                                    idUsuarioCriacao: idUserCreatedCore,
                                    idTerminal: idTerminalCore,
                                    idVendedor: idSellerCore,
                                    idEmpresa: idCompanyCore,
                                    comissaoPorcentagem: sale.comissao_porcentagem,
                                    totalValue: sale.total_value,
                                    totalDescountValue: sale.total_descount_value,
                                    cpf: sale.cpf,
                                    motivoCancelamento: sale.motivo_cancelamento,
                                    codigo: sale.codigo,
                                    observacao: sale.observacao,
                                    finalizado: sale.finalizado,
                                    status: sale.status,
                                    origem: sale.origem,
                                    deletedAt: sale.deleted_at,
                                    code: sale.code,
                                    satXml: sale.sat_xml,
                                    satXmlPath: sale.sat_xml_path,
                                    satNumeroSerie: sale.sat_numero_serie,
                                    satXmlCancelamento: sale.sat_xml_cancelamento,
                                    satXmlPathCancelamento: sale.sat_xml_path_cancelamento,
                                    cooCancelamento: sale.coo_cancelamento,
                                });
                            }
                        }
                        console.log(`${sales.length} VENDA(S) | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA(S) | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda.js.map