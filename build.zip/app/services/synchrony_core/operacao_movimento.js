import OperacaoMovimento from '#models/operacao_movimento';
import axios from 'axios';
import { apiURL } from '../index.js';
import findTerminalByIdCore from '../../../functions/find_id_core_in_rows/find_terminal_by_id_core.js';
import findEmployeeByIdUser from '../../../functions/find_employee_by_id_funcionario_usuario.js';
import findTypeOperationByIdCore from '../../../functions/find_id_core_in_rows/find_type_operation_by_id_core.js';
let fieldsToShow = [
    'id',
    'id_usuario',
    'id_terminal',
    'id_operacao_tipo',
    'observacao',
    'deleted_at',
];
export default class MovementOpearationCoreService {
    async syncCore() {
        try {
            let movementOperationsNotSyncPrime = [];
            const movementOperationsNotSync = await OperacaoMovimento.query()
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${movementOperationsNotSync.length} OPERAÇÃO MOVIMENTO ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (movementOperationsNotSync && movementOperationsNotSync.length) {
                for (const movementOperation of movementOperationsNotSync) {
                    const idTerminal = await findTerminalByIdCore(movementOperation.id_terminal);
                    const idEmployee = await findEmployeeByIdUser(movementOperation.id_usuario ?? 0);
                    const idTypeOperation = await findTypeOperationByIdCore(movementOperation.id ?? 0);
                    movementOperationsNotSyncPrime.push({
                        id_core: movementOperation.id,
                        id_prime: movementOperation.id_prime,
                        id_usuario_core: movementOperation.id_usuario,
                        id_usuario_prime: idEmployee,
                        id_terminal_core: movementOperation.id_terminal,
                        id_terminal_prime: idTerminal,
                        id_operacao_tipo_core: movementOperation.id_operacao_tipo,
                        id_operacao_tipo_prime: idTypeOperation,
                        observacao: movementOperation.observacao,
                        deleted_at: movementOperation.deletedAt,
                    });
                }
                const response = await axios.post(apiURL + '/v1/core/up/movement_operation', { data: movementOperationsNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const movementOperations = returnSync.dataMovementOperationsAlreadySynchronized;
                    if (movementOperations && movementOperations.length > 0) {
                        for (const movementOperation of movementOperations) {
                            await OperacaoMovimento.query().where('id', movementOperation.id_core).update({
                                sync_prime: true,
                                id_prime: movementOperation.id_prime,
                            });
                        }
                        console.log(`${movementOperations.length} OPERACAO MOVIMENTO | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO OPERACAO MOVIMENTO | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=operacao_movimento.js.map