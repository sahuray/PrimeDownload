import VendaFormaDePagParcela from '#models/venda_pagamento_a_prazo';
import axios from 'axios';
import { apiURL } from '../index.js';
import findSaleByIdCore from '../../../functions/find_id_core_in_rows/find_sale_by_id_core.js';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
import findSalePaymentMethodByIdCore from '../../../functions/find_id_core_in_rows/find_sale_payment_method_by_id_core.js';
import findPaymentMethodConditionByIdCore from '../../../functions/find_id_core_in_rows/find_payment_method_condition_by_id_core.js';
import findPaymentMethodConditionByIdPrime from '../../../functions/find_payment_method_condition_by_id_prime.js';
import findPaymentMethodTypeByIdCore from '../../../functions/find_id_core_in_rows/find_payment_method_type_by_id_core.js';
let fieldsToShow = [
    'id',
    'idPrime',
    'idVenda',
    'idVendaFormaDePagamento',
    'idFormaDePagamentoTipo',
    'idFormaDePagamentoCondicao',
    'syncPrime',
    'installmentValue',
    'installmentDate',
    'tax_percentage',
    'count',
    'deletedAt',
];
export default class SaleTermPaymentCoreService {
    async syncCore() {
        try {
            let saleTermPaymentNotSyncPrime = [];
            const saleTermPaymentsNotSync = await VendaFormaDePagParcela.query()
                .whereNotNull('id_venda')
                .whereNotNull('id_venda_forma_de_pagamento')
                .whereNotNull('id_forma_de_pagamento_condicao')
                .whereHas('venda', (subQuery) => {
                subQuery.whereNotNull('id_prime');
            })
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${saleTermPaymentsNotSync.length} VENDA PAG. A PRAZO ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleTermPaymentsNotSync && saleTermPaymentsNotSync.length) {
                for (const salePaymentInstallment of saleTermPaymentsNotSync) {
                    const idSalePrime = await findSaleByIdCore(salePaymentInstallment.idVenda);
                    const idSalePaymentMethod = await findSalePaymentMethodByIdCore(salePaymentInstallment.idVendaFormaDePagamento);
                    const idPaymentMethodCondition = await findPaymentMethodConditionByIdCore(salePaymentInstallment.idFormaDePagamentoCondicao || 0);
                    const idPaymentMethodType = await findPaymentMethodTypeByIdCore(salePaymentInstallment.idFormaDePagamentoTipo);
                    if (idSalePrime && idSalePaymentMethod && idPaymentMethodType) {
                        saleTermPaymentNotSyncPrime.push({
                            id_core: salePaymentInstallment.id,
                            id_prime: salePaymentInstallment.idPrime,
                            id_venda_prime: idSalePrime,
                            id_venda_forma_de_pagamento_prime: idSalePaymentMethod,
                            id_forma_de_pagamento_condicao_prime: idPaymentMethodCondition,
                            id_forma_de_pagamento_tipo_prime: idPaymentMethodType,
                            installment_value: salePaymentInstallment.installmentValue,
                            installment_date: salePaymentInstallment.installmentDate,
                            tax_percentage: salePaymentInstallment.tax_percentage,
                            count: salePaymentInstallment.count,
                            deleted_at: salePaymentInstallment.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_term_payment', { data: saleTermPaymentNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleTermPayments = returnSync.dataSaleTermPayemntsAlreadySynchronized;
                    if (saleTermPayments && saleTermPayments.length > 0) {
                        for (const saleTermPayment of saleTermPayments) {
                            const idCore = saleTermPayment.id_core;
                            const idSaleCore = await findSaleByIdPrime(saleTermPayment.id_venda_prime);
                            const idPaymentMethodCondition = await findPaymentMethodConditionByIdPrime(saleTermPayment.id_forma_de_pagamento_condicao_prime);
                            if (idCore && idSaleCore && idPaymentMethodCondition) {
                                await VendaFormaDePagParcela.query().where('id', idCore).update({
                                    syncPrime: true,
                                    idPrime: saleTermPayment.id_prime,
                                });
                            }
                        }
                        console.log(`${saleTermPayments.length} VENDA PAG. A PRAZO | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA PAG. A PRAZO | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_pagamento_a_prazo.js.map