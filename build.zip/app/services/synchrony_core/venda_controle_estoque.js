import VendaControleEstoque from '#models/prime_venda_controle_estoque';
import axios from 'axios';
import { apiURL } from '../index.js';
export default class SaleControlInventoryCoreService {
    async syncCore() {
        try {
            let saleControlInventoryNotSyncPrime = [];
            const saleControlInventoryNotSync = await VendaControleEstoque.query()
                .whereNotNull('id_estoque')
                .whereNotNull('id_estoque_prime')
                .select('*');
            console.log(`${saleControlInventoryNotSync.length} VENDA CONTROLE ESTOQUE ENCONTRADOS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleControlInventoryNotSync && saleControlInventoryNotSync.length) {
                for (const saleControlInventory of saleControlInventoryNotSync) {
                    saleControlInventoryNotSyncPrime.push(saleControlInventory);
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_control_inventory', { data: saleControlInventoryNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleControlInventories = returnSync.dataSaleControlInventoriesAlreadySynchronized;
                    console.log(`${saleControlInventoryNotSync.length} VENDA CONTROLE ESTOQUE SINCRONIZADOS | CORE --> PRIME`);
                    if (saleControlInventories && saleControlInventories.length > 0) {
                        const idsSaleControlInventories = saleControlInventories.map((item) => item.id_core);
                        await VendaControleEstoque.query().whereIn('id', idsSaleControlInventories).delete();
                    }
                }
            }
        }
        catch (error) {
            console.log(error);
        }
    }
}
//# sourceMappingURL=venda_controle_estoque.js.map