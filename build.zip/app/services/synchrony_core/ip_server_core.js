import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
import axios from 'axios';
import { apiURL } from '../index.js';
const fieldsToShow = ['id', 'id_prime', 'ip_server_core'];
export default class IpServerCoreService {
    async syncCore() {
        try {
            let ipServerCoreNotSyncPrime = [];
            const ipServerCoreNotSync = await EmpresaPdvConfig.query()
                .whereNotNull('ip_server_core')
                .select(fieldsToShow);
            console.log(`${ipServerCoreNotSync.length} IP SERVER CORE ENCONTRADO PARA SINCRONIZAR | CORE --> PRIME`);
            if (ipServerCoreNotSync && ipServerCoreNotSync.length) {
                for (const item of ipServerCoreNotSync) {
                    ipServerCoreNotSyncPrime.push({
                        id_core: item.id,
                        id_prime: item.id_prime,
                        ip_server_core: item.ip_server_core,
                    });
                }
                const response = await axios.post(apiURL + '/v1/core/up/ip_server_core', { data: ipServerCoreNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const data = returnSync.dataIpServerCoreAlreadySynchronized;
                    console.log(`${data.length} IP SERVER CORE | CORE --> PRIME SINCRONIZADO`);
                }
            }
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=ip_server_core.js.map