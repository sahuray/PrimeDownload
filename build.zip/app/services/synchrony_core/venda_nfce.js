import VendaNfce from '#models/venda_nfce';
import axios from 'axios';
import { apiURL } from '../index.js';
import findSaleByIdCore from '../../../functions/find_id_core_in_rows/find_sale_by_id_core.js';
import findSaleByIdPrime from '../../../functions/find_sale_by_id_prime.js';
let fieldsToShow = ['id', 'idPrime', 'idVenda', 'syncPrime', 'status', 'message', 'data'];
export default class SaleNfceCoreService {
    async syncCore() {
        try {
            let saleNfceNotSyncPrime = [];
            const saleNfceNotSync = await VendaNfce.query()
                .whereNotNull('id_venda')
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${saleNfceNotSync.length} VENDA NFCE ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (saleNfceNotSync && saleNfceNotSync.length) {
                for (const saleNfce of saleNfceNotSync) {
                    const idSalePrime = await findSaleByIdCore(saleNfce.idVenda);
                    if (idSalePrime) {
                        saleNfceNotSyncPrime.push({
                            id_core: saleNfce.id,
                            id_prime: saleNfce.idPrime,
                            id_venda_prime: idSalePrime,
                            status: saleNfce.status,
                            message: saleNfce.message,
                            data: saleNfce.data,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/sale_nfce', { data: saleNfceNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const saleNfces = returnSync.dataSaleNfcesAlreadySynchronized;
                    if (saleNfces && saleNfces.length > 0) {
                        for (const saleNfce of saleNfces) {
                            const idCore = saleNfce.id_core;
                            const idSaleCore = await findSaleByIdPrime(saleNfce.id_venda_prime);
                            if (idCore && idSaleCore) {
                                await VendaNfce.query().where('id', idCore).update({
                                    sync_prime: true,
                                    idPrime: saleNfce.id_prime,
                                    idVenda: idSaleCore,
                                    status: saleNfce.status,
                                    message: saleNfce.message,
                                    data: saleNfce.data,
                                });
                            }
                        }
                        console.log(`${saleNfces.length} VENDA NFCE | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO VENDA NFCE | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=venda_nfce.js.map