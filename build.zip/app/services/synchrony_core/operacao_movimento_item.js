import OperacaoMovimentoItem from '#models/operacao_movimento_item';
import axios from 'axios';
import { apiURL } from '../index.js';
import findProductByIdCore from '../../../functions/find_id_core_in_rows/find_product_by_id_core.js';
import findMovementOperationByIdCore from '../../../functions/find_id_core_in_rows/find_movement_operation_by_id_core.js';
let fieldsToShow = [
    'id',
    'id_prime',
    'id_produto',
    'id_operacao_movimento',
    'quantidade',
    'desconto_produto',
    'valor_produto',
    'deleted_at',
];
export default class MovementOpearationItemCoreService {
    async syncCore() {
        try {
            let movementOperationItemsNotSyncPrime = [];
            const movementOperationItemsNotSync = await OperacaoMovimentoItem.query()
                .where('sync_prime', false)
                .select(fieldsToShow);
            console.log(`${movementOperationItemsNotSync.length} OPERAÇÃO MOVIMENTO ITEM ENCONTRADAS PARA SINCRONIZAR | CORE --> PRIME`);
            if (movementOperationItemsNotSync && movementOperationItemsNotSync.length) {
                for (const movementOperationItem of movementOperationItemsNotSync) {
                    const idProduct = await findProductByIdCore(movementOperationItem.id_produto);
                    const idMovementOperation = await findMovementOperationByIdCore(movementOperationItem.id_operacao_movimento);
                    if (idMovementOperation && idProduct) {
                        movementOperationItemsNotSyncPrime.push({
                            id_core: movementOperationItem.id,
                            id_prime: movementOperationItem.id_prime,
                            id_produto_core: movementOperationItem.id_produto,
                            id_produto_prime: idProduct,
                            id_operacao_movimento_core: movementOperationItem.id_operacao_movimento,
                            id_operacao_movimento_prime: idMovementOperation,
                            quantidade: movementOperationItem.quantidade,
                            desconto_produto: movementOperationItem.desconto_produto,
                            valor_produto: movementOperationItem.valor_produto,
                            deleted_at: movementOperationItem.deletedAt,
                        });
                    }
                }
                const response = await axios.post(apiURL + '/v1/core/up/movement_operation_item', { data: movementOperationItemsNotSyncPrime }, {
                    params: {
                        key: process.env.API_CORE_KEY,
                    },
                });
                if (response && response.data) {
                    const returnSync = response.data;
                    const movementOperationItems = returnSync.dataMovementOperationItemsAlreadySynchronized;
                    if (movementOperationItems && movementOperationItems.length > 0) {
                        for (const movementOperationItem of movementOperationItems) {
                            await OperacaoMovimentoItem.query()
                                .where('id', movementOperationItem.id_core)
                                .update({
                                sync_prime: true,
                                id_prime: movementOperationItem.id_prime,
                            });
                        }
                        console.log(`${movementOperationItems.length} OPERACAO MOVIMENTO ITEM | CORE --> PRIME SINCRONIZADOS`);
                    }
                }
            }
        }
        catch (err) {
            console.log('ERRO NA SINCRONIZAÇÃO OPERACAO MOVIMENTO | CORE --> PRIME' + err);
        }
    }
}
//# sourceMappingURL=operacao_movimento_item.js.map