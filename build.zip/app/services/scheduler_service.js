import { CronJob } from 'cron';
import logger from '@adonisjs/core/services/logger';
export default class SchedulerService {
    jobs = [];
    addJob(jobConfig) {
        this.jobs.push(jobConfig);
    }
    scheduleSingleJob(jobConfig) {
        const cronJob = new CronJob(jobConfig.cronExpression, async () => {
            try {
                await jobConfig.job.run();
            }
            catch (e) {
                logger.error(`[Scheduler] - An error occurred during the execution of job ${jobConfig.key}`);
            }
        });
        cronJob.start();
    }
    scheduleAllJobs() {
        this.jobs.forEach((jobConfig) => {
            this.scheduleSingleJob(jobConfig);
        });
        logger.info(`[Scheduler] - ${this.jobs.length} registered ${this.jobs.length === 1 ? 'job has' : 'jobs have'} been scheduled`);
    }
}
//# sourceMappingURL=scheduler_service.js.map