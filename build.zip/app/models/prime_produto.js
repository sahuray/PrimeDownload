var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo, hasMany } from '@adonisjs/lucid/orm';
import Grupo from '#models/grupo';
import Empresa from '#models/empresa';
import PrimeProdutoEmpresa from '#models/prime_produto_empresa';
import PrimeProdutoInformacaoNutricional from '#models/prime_produto_informacao_nutricional';
import PrimeProdutoUnidade from '#models/prime_produto_unidade';
import PrimeMarca from '#models/prime_marca';
import PrimeProdutoCodigoDeBarra from '#models/prime_produto_codigo_de_barra';
import PrimeProdutoEstoque from '#models/prime_produto_estoque';
import PrimeProdutoPreco from '#models/prime_produto_preco';
import PrimeProdutoComposto from '#models/prime_produto_composto';
import PrimeProdutoCompativel from '#models/prime_produto_compativel';
import PrimeProdutoCategoriaSetor from '#models/prime_produto_categoria_setor';
import PrimeProdutoCategoriaGrupo from '#models/prime_produto_categoria_grupo';
import PrimeProdutoCategoriaSubgrupo from '#models/prime_produto_categoria_subgrupo';
import PrimeProdutoCategoriaLinha from '#models/prime_produto_categoria_linha';
import Upload from '#models/upload';
export default class PrimeProduto extends BaseModel {
    static table = 'prime_produto';
    id;
    id_prime;
    sync_prime;
    id_grupo;
    id_unidade_comercial;
    id_unidade_tributavel;
    id_marca;
    id_produto_informacao_nutricional;
    id_fornecedor;
    id_produto_categoria_setor;
    id_produto_categoria_grupo;
    id_produto_categoria_subgrupo;
    id_produto_categoria_linha;
    code;
    codigo_barra_1;
    codigo_barra_2;
    packing_width;
    packing_heigth;
    packing_depth;
    packing_weight;
    reference;
    name;
    short_name;
    use_gride;
    characteristics;
    created_at;
    updated_at;
    deleted_at;
    Grupo;
    UnidadeComercial;
    UnidadeTributavel;
    Marca;
    Empresa;
    InformacaoNutricional;
    CategoriaSetor;
    CategoriaGrupo;
    CategoriaSubgrupo;
    CategoriaLinha;
    CodigoBarra;
    ProdutoEmpresa;
    Estoque;
    Preco;
    ProdutoComposto;
    ProdutoCompativel;
    Upload;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProduto.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProduto.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProduto.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProduto.prototype, "id_grupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_unidade_comercial", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_unidade_tributavel", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_marca", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_produto_informacao_nutricional", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_fornecedor", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_produto_categoria_setor", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_produto_categoria_grupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_produto_categoria_subgrupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "id_produto_categoria_linha", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProduto.prototype, "code", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProduto.prototype, "codigo_barra_1", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProduto.prototype, "codigo_barra_2", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProduto.prototype, "packing_width", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProduto.prototype, "packing_heigth", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProduto.prototype, "packing_depth", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProduto.prototype, "packing_weight", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProduto.prototype, "reference", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProduto.prototype, "name", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProduto.prototype, "short_name", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProduto.prototype, "use_gride", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProduto.prototype, "characteristics", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProduto.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProduto.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => Grupo, {
        foreignKey: 'id_grupo',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "Grupo", void 0);
__decorate([
    belongsTo(() => PrimeProdutoUnidade, {
        foreignKey: 'id_unidade_comercial',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "UnidadeComercial", void 0);
__decorate([
    belongsTo(() => PrimeProdutoUnidade, {
        foreignKey: 'id_unidade_tributavel',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "UnidadeTributavel", void 0);
__decorate([
    belongsTo(() => PrimeMarca, {
        foreignKey: 'id_marca',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "Marca", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "Empresa", void 0);
__decorate([
    belongsTo(() => PrimeProdutoInformacaoNutricional, {
        foreignKey: 'id_produto_informacao_nutricional',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "InformacaoNutricional", void 0);
__decorate([
    belongsTo(() => PrimeProdutoCategoriaSetor, {
        foreignKey: 'id_produto_categoria_setor',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "CategoriaSetor", void 0);
__decorate([
    belongsTo(() => PrimeProdutoCategoriaGrupo, {
        foreignKey: 'id_produto_categoria_grupo',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "CategoriaGrupo", void 0);
__decorate([
    belongsTo(() => PrimeProdutoCategoriaSubgrupo, {
        foreignKey: 'id_produto_categoria_subgrupo',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "CategoriaSubgrupo", void 0);
__decorate([
    belongsTo(() => PrimeProdutoCategoriaLinha, {
        foreignKey: 'id_produto_categoria_linha',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "CategoriaLinha", void 0);
__decorate([
    hasMany(() => PrimeProdutoCodigoDeBarra, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "CodigoBarra", void 0);
__decorate([
    hasMany(() => PrimeProdutoEmpresa, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "ProdutoEmpresa", void 0);
__decorate([
    hasMany(() => PrimeProdutoEstoque, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "Estoque", void 0);
__decorate([
    hasMany(() => PrimeProdutoPreco, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "Preco", void 0);
__decorate([
    hasMany(() => PrimeProdutoComposto, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "ProdutoComposto", void 0);
__decorate([
    hasMany(() => PrimeProdutoCompativel, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "ProdutoCompativel", void 0);
__decorate([
    hasMany(() => Upload, {
        foreignKey: 'id_fk',
        localKey: 'id',
    }),
    __metadata("design:type", Object)
], PrimeProduto.prototype, "Upload", void 0);
//# sourceMappingURL=prime_produto.js.map