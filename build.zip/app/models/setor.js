var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, belongsTo, column, hasMany } from '@adonisjs/lucid/orm';
import Empresa from '#models/empresa';
import Mesa from './prime_mesa.js';
export default class Setor extends BaseModel {
    static table = 'prime_setor';
    id;
    id_prime;
    id_empresa;
    nome_setor;
    observacao_setor;
    status;
    favorite;
    createdAt;
    updatedAt;
    deletedAt;
    empresa;
    mesas;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Setor.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Setor.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Setor.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Setor.prototype, "nome_setor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Setor.prototype, "observacao_setor", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Setor.prototype, "status", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Setor.prototype, "favorite", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Setor.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Setor.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Setor.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], Setor.prototype, "empresa", void 0);
__decorate([
    hasMany(() => Mesa, {
        foreignKey: 'id_setor',
    }),
    __metadata("design:type", Object)
], Setor.prototype, "mesas", void 0);
//# sourceMappingURL=setor.js.map