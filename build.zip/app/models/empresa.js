var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, hasMany } from '@adonisjs/lucid/orm';
import Endereco from '#models/endereco';
import Contato from '#models/contato';
export default class Empresa extends BaseModel {
    static table = 'prime_empresa';
    id;
    id_prime_empresa;
    sync_prime;
    id_focus;
    focus_token_producao;
    focus_token_homologacao;
    url_logo;
    regime_tributario;
    regime_especial_tributacao;
    grupo_id;
    funcionarioUsuarioIdResponsavelCadastro;
    funcionarioUsuarioIdResponsavelUltimaAlteracao;
    situacao_cadastral;
    tipo;
    origem;
    descricao_servico;
    ativo;
    nome_fantasia;
    razao_social;
    apelido;
    emissao_nfse_nothos_prime_completo;
    emissao_nfce_nothos_prime_completo;
    emissao_nfe_nothos_prime_completo;
    cnpj_aguardando;
    ie_isento;
    ie_aguardando;
    im_isento;
    im_aguardando;
    prazo_bloqueado;
    cnpj_cpf;
    ie_rg;
    im;
    suframa;
    sexo;
    email;
    telefone;
    representante_nome;
    representante_tipo;
    representante_cpf;
    representante_rg;
    representante_celular;
    representante_email;
    representante_data_nascimento;
    cartao_preferencial_utiliza;
    cartao_preferencial_numero;
    cartao_preferencial_saldo;
    prazo_tipo;
    prazo_dias;
    prazo_limite;
    codigo;
    cliente_athos;
    quantity_decimal_places;
    price_decimal_places;
    rounding_type;
    user_repos_id;
    permitir_item_duplicado;
    permitir_ajustar_quantidade;
    associar_cliente_orcamento;
    pedir_observacao_venda;
    pedir_observacao_orcamento;
    estoque_zerado_orcamento;
    associar_transportadora;
    exibir_observacao_cliente;
    utilizar_data_entrega;
    periodo_orcamento;
    controle_estoque_reservado;
    vencimento_orcamento;
    quantidade_dia_orcamento;
    data_vencimento_orcamento;
    desconto_maximo;
    associar_cliente_venda_inicio;
    associar_cliente_venda_final;
    aceitar_cpf_invalido;
    pedir_codigo_vendedor;
    limite_items_venda;
    ponto_sangria;
    focar_preco_unitario;
    permitir_escolha_preco_venda;
    informar_diferenca_entre_valores;
    utiliza_balanca_retaguarda;
    quantidade_digitos;
    tipo_codigo_barras;
    observacao_venda;
    observacao_orcamento;
    site;
    carga_portal;
    permission_show_vehicular_plate;
    contato;
    aniversario;
    createdAt;
    updatedAt;
    deletedAt;
    data_constituicao;
    enderecos;
    contatos;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Empresa.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "id_prime_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "id_focus", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "focus_token_producao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "focus_token_homologacao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "url_logo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "regime_tributario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "regime_especial_tributacao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "grupo_id", void 0);
__decorate([
    column({ columnName: 'funcionario_usuario_id_responsavel_cadastro' }),
    __metadata("design:type", Object)
], Empresa.prototype, "funcionarioUsuarioIdResponsavelCadastro", void 0);
__decorate([
    column({ columnName: 'funcionario_usuario_id_responsavel_ultima_alteracao' }),
    __metadata("design:type", Object)
], Empresa.prototype, "funcionarioUsuarioIdResponsavelUltimaAlteracao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "situacao_cadastral", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "origem", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "descricao_servico", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "ativo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "nome_fantasia", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "razao_social", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "apelido", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "emissao_nfse_nothos_prime_completo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "emissao_nfce_nothos_prime_completo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "emissao_nfe_nothos_prime_completo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "cnpj_aguardando", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "ie_isento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "ie_aguardando", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "im_isento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "im_aguardando", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "prazo_bloqueado", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "cnpj_cpf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "ie_rg", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "im", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "suframa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "sexo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "email", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "telefone", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "representante_nome", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "representante_tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "representante_cpf", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "representante_rg", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "representante_celular", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "representante_email", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "representante_data_nascimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "cartao_preferencial_utiliza", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "cartao_preferencial_numero", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "cartao_preferencial_saldo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "prazo_tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "prazo_dias", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "prazo_limite", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "cliente_athos", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "quantity_decimal_places", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "price_decimal_places", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "rounding_type", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "user_repos_id", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "permitir_item_duplicado", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "permitir_ajustar_quantidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "associar_cliente_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "pedir_observacao_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "pedir_observacao_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "estoque_zerado_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "associar_transportadora", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "exibir_observacao_cliente", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "utilizar_data_entrega", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "periodo_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "controle_estoque_reservado", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "vencimento_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "quantidade_dia_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], Empresa.prototype, "data_vencimento_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "desconto_maximo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "associar_cliente_venda_inicio", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "associar_cliente_venda_final", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "aceitar_cpf_invalido", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "pedir_codigo_vendedor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "limite_items_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "ponto_sangria", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "focar_preco_unitario", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "permitir_escolha_preco_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "informar_diferenca_entre_valores", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "utiliza_balanca_retaguarda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "quantidade_digitos", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Empresa.prototype, "tipo_codigo_barras", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "observacao_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "observacao_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Empresa.prototype, "site", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "carga_portal", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Empresa.prototype, "permission_show_vehicular_plate", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "contato", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "aniversario", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Empresa.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Empresa.prototype, "updatedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "deletedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Empresa.prototype, "data_constituicao", void 0);
__decorate([
    hasMany(() => Endereco, {
        foreignKey: 'id_fk',
    }),
    __metadata("design:type", Object)
], Empresa.prototype, "enderecos", void 0);
__decorate([
    hasMany(() => Contato, {
        foreignKey: 'id_fk',
    }),
    __metadata("design:type", Object)
], Empresa.prototype, "contatos", void 0);
//# sourceMappingURL=empresa.js.map