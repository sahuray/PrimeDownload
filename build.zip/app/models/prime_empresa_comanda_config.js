var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import Empresa from '#models/empresa';
export default class PrimeEmpresaComandaConfig extends BaseModel {
    static table = 'prime_empresa_comanda_config';
    id;
    id_prime;
    id_empresa;
    utiliza_comanda;
    pedir_mesa_lancamento_comanda;
    imprimir_item_composicao;
    utiliza_observacao_comanda;
    utiliza_couvert;
    utiliza_taxa_de_servico;
    ativar_busca_comandas_campo_lancamento_produtos_pdv;
    codigo_taxa_servico;
    digito_controle_comanda;
    percentual_taxa_servico;
    quantidade_caracteres_comanda;
    utiliza_chip_comanda;
    createdAt;
    updatedAt;
    deletedAt;
    company;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeEmpresaComandaConfig.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeEmpresaComandaConfig.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeEmpresaComandaConfig.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "utiliza_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "pedir_mesa_lancamento_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "imprimir_item_composicao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "utiliza_observacao_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "utiliza_couvert", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "utiliza_taxa_de_servico", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "ativar_busca_comandas_campo_lancamento_produtos_pdv", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeEmpresaComandaConfig.prototype, "codigo_taxa_servico", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeEmpresaComandaConfig.prototype, "digito_controle_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeEmpresaComandaConfig.prototype, "percentual_taxa_servico", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeEmpresaComandaConfig.prototype, "quantidade_caracteres_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaComandaConfig.prototype, "utiliza_chip_comanda", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeEmpresaComandaConfig.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeEmpresaComandaConfig.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeEmpresaComandaConfig.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimeEmpresaComandaConfig.prototype, "company", void 0);
//# sourceMappingURL=prime_empresa_comanda_config.js.map