var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import Grupo from '#models/grupo';
export default class PrimeProdutoInformacaoNutricional extends BaseModel {
    static table = 'prime_produto_informacao_nutricional';
    id;
    id_prime;
    sync_prime;
    id_grupo;
    description;
    portion;
    liquid_weight;
    origin;
    calories_grams;
    calories_vd;
    carbohydrates_grams;
    carbohydrates_vd;
    proteins_grams;
    proteins_vd;
    fats_grams;
    fats_vd;
    fats_totals;
    fats_totals_vd;
    fats_saturated_grams;
    fats_saturated_vd;
    fats_trans_grams;
    fats_trans_vd;
    dietary_fiber_grams;
    dietary_fiber_vd;
    sodium_miligrams;
    sodium_vd;
    complementary_attributes;
    ingredients;
    created_at;
    updated_at;
    deleted_at;
    Grupo;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoInformacaoNutricional.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "id_grupo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoInformacaoNutricional.prototype, "description", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "portion", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "liquid_weight", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoInformacaoNutricional.prototype, "origin", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "calories_grams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "calories_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "carbohydrates_grams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "carbohydrates_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "proteins_grams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "proteins_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_grams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_totals", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_totals_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_saturated_grams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_saturated_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_trans_grams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "fats_trans_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "dietary_fiber_grams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "dietary_fiber_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "sodium_miligrams", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoInformacaoNutricional.prototype, "sodium_vd", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoInformacaoNutricional.prototype, "complementary_attributes", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoInformacaoNutricional.prototype, "ingredients", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoInformacaoNutricional.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoInformacaoNutricional.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProdutoInformacaoNutricional.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => Grupo, {
        foreignKey: 'id_grupo',
    }),
    __metadata("design:type", Object)
], PrimeProdutoInformacaoNutricional.prototype, "Grupo", void 0);
//# sourceMappingURL=prime_produto_informacao_nutricional.js.map