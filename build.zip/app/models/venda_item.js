var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column, hasMany } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import PrimeProduto from '#models/prime_produto';
import Venda from '#models/venda';
import VendaSubItem from '#models/venda_sub_item';
import VendaItemCaracteristica from '#models/venda_item_caracteristica';
import Comanda from './comanda.js';
import Mesa from './prime_mesa.js';
import Funcionario from './funcionario.js';
export default class VendaItem extends BaseModel {
    static table = 'prime_venda_item';
    id;
    idPrime;
    idProduto;
    idVenda;
    syncPrime;
    status;
    productDescription;
    comissaoPorcentagem;
    saledQuantity;
    unitaryValue;
    totalValue;
    totalDescountValue;
    codigo;
    ncm;
    cfop;
    csosn;
    aliquotIcms;
    observacao;
    taxaDeEntrega;
    listar_na_comanda;
    listar_na_mesa;
    id_mesa;
    id_venda_anterior;
    id_garcon;
    createdAt;
    updatedAt;
    deletedAt;
    produto;
    venda;
    id_comanda;
    comanda;
    mesa;
    data_lancamento;
    subItens;
    caracteristicas;
    garcon;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], VendaItem.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "idProduto", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "idVenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], VendaItem.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaItem.prototype, "status", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaItem.prototype, "productDescription", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "comissaoPorcentagem", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "saledQuantity", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "unitaryValue", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "totalValue", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "totalDescountValue", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaItem.prototype, "ncm", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaItem.prototype, "cfop", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaItem.prototype, "csosn", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaItem.prototype, "aliquotIcms", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaItem.prototype, "observacao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], VendaItem.prototype, "taxaDeEntrega", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], VendaItem.prototype, "listar_na_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], VendaItem.prototype, "listar_na_mesa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "id_mesa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "id_venda_anterior", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "id_garcon", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], VendaItem.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], VendaItem.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], VendaItem.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => PrimeProduto, {
        foreignKey: 'idProduto',
    }),
    __metadata("design:type", Object)
], VendaItem.prototype, "produto", void 0);
__decorate([
    belongsTo(() => Venda, {
        foreignKey: 'idVenda',
    }),
    __metadata("design:type", Object)
], VendaItem.prototype, "venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaItem.prototype, "id_comanda", void 0);
__decorate([
    belongsTo(() => Comanda, {
        foreignKey: 'id_comanda',
    }),
    __metadata("design:type", Object)
], VendaItem.prototype, "comanda", void 0);
__decorate([
    belongsTo(() => Mesa, {
        foreignKey: 'id_mesa',
    }),
    __metadata("design:type", Object)
], VendaItem.prototype, "mesa", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], VendaItem.prototype, "data_lancamento", void 0);
__decorate([
    hasMany(() => VendaSubItem, {
        foreignKey: 'idVendaItem',
    }),
    __metadata("design:type", Object)
], VendaItem.prototype, "subItens", void 0);
__decorate([
    hasMany(() => VendaItemCaracteristica, {
        foreignKey: 'id_venda_item',
    }),
    __metadata("design:type", Object)
], VendaItem.prototype, "caracteristicas", void 0);
__decorate([
    belongsTo(() => Funcionario, {
        foreignKey: 'id_garcon',
    }),
    __metadata("design:type", Object)
], VendaItem.prototype, "garcon", void 0);
//# sourceMappingURL=venda_item.js.map