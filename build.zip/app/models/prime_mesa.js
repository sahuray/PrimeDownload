var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, belongsTo, column, hasMany } from '@adonisjs/lucid/orm';
import Empresa from '#models/empresa';
import Setor from '#models/setor';
import VendaItem from './venda_item.js';
import Funcionario from './funcionario.js';
export default class Mesa extends BaseModel {
    static table = 'prime_mesa';
    id;
    id_prime;
    id_empresa;
    id_setor;
    id_garcon;
    id_agrupamento;
    numero_mesa;
    numero_cadeiras;
    observacao;
    status;
    active;
    favorite;
    identificacao_mesa;
    quantidade_pessoas;
    hora_abertura;
    hora_ultimo_atendimento;
    hora_fechamento;
    grupo_mesas;
    total_atendimento;
    createdAt;
    updatedAt;
    deletedAt;
    empresa;
    setor;
    itens;
    garcon;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Mesa.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Mesa.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Mesa.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Mesa.prototype, "id_setor", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Mesa.prototype, "id_garcon", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Mesa.prototype, "id_agrupamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Mesa.prototype, "numero_mesa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Mesa.prototype, "numero_cadeiras", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Mesa.prototype, "observacao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Mesa.prototype, "status", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Mesa.prototype, "active", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Mesa.prototype, "favorite", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Mesa.prototype, "identificacao_mesa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Mesa.prototype, "quantidade_pessoas", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Mesa.prototype, "hora_abertura", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Mesa.prototype, "hora_ultimo_atendimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Mesa.prototype, "hora_fechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Mesa.prototype, "grupo_mesas", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Mesa.prototype, "total_atendimento", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Mesa.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Mesa.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Mesa.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], Mesa.prototype, "empresa", void 0);
__decorate([
    belongsTo(() => Setor, {
        foreignKey: 'id_setor',
    }),
    __metadata("design:type", Object)
], Mesa.prototype, "setor", void 0);
__decorate([
    hasMany(() => VendaItem, {
        foreignKey: 'id_mesa',
    }),
    __metadata("design:type", Object)
], Mesa.prototype, "itens", void 0);
__decorate([
    belongsTo(() => Funcionario, {
        foreignKey: 'id_garcon',
    }),
    __metadata("design:type", Object)
], Mesa.prototype, "garcon", void 0);
//# sourceMappingURL=prime_mesa.js.map