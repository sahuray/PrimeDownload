var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import Empresa from '#models/empresa';
import PrimeProduto from './prime_produto.js';
export default class PrimeProdutoPreco extends BaseModel {
    static table = 'prime_produto_preco';
    id;
    id_prime;
    id_empresa;
    id_produto;
    sync_prime;
    discount_max;
    margin;
    value;
    commission_value;
    commission_percentage;
    description;
    main_price;
    ecommerce;
    is_promotion;
    promotion_started_at;
    promotion_ended_at;
    created_at;
    updated_at;
    deleted_at;
    Empresa;
    PrimeProduto;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "id_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoPreco.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "discount_max", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "margin", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "value", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "commission_value", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoPreco.prototype, "commission_percentage", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoPreco.prototype, "description", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoPreco.prototype, "main_price", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoPreco.prototype, "ecommerce", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoPreco.prototype, "is_promotion", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], PrimeProdutoPreco.prototype, "promotion_started_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], PrimeProdutoPreco.prototype, "promotion_ended_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoPreco.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoPreco.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProdutoPreco.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimeProdutoPreco.prototype, "Empresa", void 0);
__decorate([
    belongsTo(() => PrimeProduto, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProdutoPreco.prototype, "PrimeProduto", void 0);
//# sourceMappingURL=prime_produto_preco.js.map