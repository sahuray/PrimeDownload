var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column, hasMany, hasOne } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import Grupo from '#models/grupo';
import Empresa from '#models/empresa';
import FuncionarioUsuario from '#models/funcionario_usuario';
import Terminal from '#models/terminal';
import Funcionario from '#models/funcionario';
import VendaItem from '#models/venda_item';
import VendaCliente from '#models/venda_cliente';
import TaxaDeEntrega from '#models/taxa_de_entrega';
import Motoboy from '#models/motoboy';
import VendaFormaDePagamento from '#models/venda_forma_de_pagamento';
export default class Venda extends BaseModel {
    static table = 'prime_venda';
    id;
    idVendaOrcamento;
    idPrime;
    idGrupo;
    idCliente;
    idCaixaMovimento;
    idUsuarioInativar;
    idUsuarioCriacao;
    idTerminal;
    idVendedor;
    idEmpresa;
    syncPrime;
    comissaoPorcentagem;
    totalValue;
    totalDescountValue;
    e_orcamento;
    cpf;
    motivoCancelamento;
    codigo;
    observacao;
    finalizado;
    status;
    origem;
    createdAt;
    updatedAt;
    deletedAt;
    code;
    satXml;
    satXmlPath;
    satNumeroSerie;
    coo;
    satXmlCancelamento;
    satXmlPathCancelamento;
    cooCancelamento;
    senhaDelivery;
    horaPedido;
    valorTaxaDelivery;
    valorTaxaServico;
    valorCouvert;
    valorTroco;
    prestarConta;
    retirada;
    valorProdutos;
    idMotoboy;
    idTaxaDeEntrega;
    satArquivo;
    satCodigoDeRetorno;
    satNumeroSessao;
    satResultado;
    satRetornoStr;
    satNCFe;
    cobrar_taxa_servico;
    cobrar_taxa_covert;
    quantidade_pessoas_covert;
    grupo;
    cliente;
    usuarioInativar;
    UsuarioCriacao;
    terminal;
    vendedor;
    empresa;
    vendaCliente;
    vendaItem;
    motoboy;
    taxaDeEntrega;
    vendaFormaDePagamento;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Venda.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "idVendaOrcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "idGrupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Venda.prototype, "idCliente", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Venda.prototype, "idCaixaMovimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Venda.prototype, "idUsuarioInativar", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Venda.prototype, "idUsuarioCriacao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "idTerminal", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Venda.prototype, "idVendedor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "idEmpresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Venda.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "comissaoPorcentagem", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "totalValue", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "totalDescountValue", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Venda.prototype, "e_orcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "cpf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "motivoCancelamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "observacao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Venda.prototype, "finalizado", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "status", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "origem", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Venda.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Venda.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], Venda.prototype, "deletedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "code", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satXml", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satXmlPath", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satNumeroSerie", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "coo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satXmlCancelamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satXmlPathCancelamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "cooCancelamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "senhaDelivery", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "horaPedido", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "valorTaxaDelivery", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "valorTaxaServico", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "valorCouvert", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "valorTroco", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "prestarConta", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Venda.prototype, "retirada", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "valorProdutos", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "idMotoboy", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "idTaxaDeEntrega", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satArquivo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satCodigoDeRetorno", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satNumeroSessao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satResultado", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satRetornoStr", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Venda.prototype, "satNCFe", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Venda.prototype, "cobrar_taxa_servico", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Venda.prototype, "cobrar_taxa_covert", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Venda.prototype, "quantidade_pessoas_covert", void 0);
__decorate([
    belongsTo(() => Grupo, {
        foreignKey: 'idGrupo',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "grupo", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'idCliente',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "cliente", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'idUsuarioInativar',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "usuarioInativar", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'idUsuarioCriacao',
        localKey: 'idfuncionariousuario',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "UsuarioCriacao", void 0);
__decorate([
    belongsTo(() => Terminal, {
        foreignKey: 'idTerminal',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "terminal", void 0);
__decorate([
    belongsTo(() => Funcionario, {
        foreignKey: 'idVendedor',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "vendedor", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'idEmpresa',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "empresa", void 0);
__decorate([
    hasOne(() => VendaCliente, {
        foreignKey: 'idVenda',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "vendaCliente", void 0);
__decorate([
    hasMany(() => VendaItem, {
        foreignKey: 'idVenda',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "vendaItem", void 0);
__decorate([
    belongsTo(() => Motoboy, {
        foreignKey: 'idMotoboy',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "motoboy", void 0);
__decorate([
    belongsTo(() => TaxaDeEntrega, {
        foreignKey: 'idTaxaDeEntrega',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "taxaDeEntrega", void 0);
__decorate([
    hasMany(() => VendaFormaDePagamento, {
        foreignKey: 'idVenda',
    }),
    __metadata("design:type", Object)
], Venda.prototype, "vendaFormaDePagamento", void 0);
//# sourceMappingURL=venda.js.map