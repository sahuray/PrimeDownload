var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import Empresa from '#models/empresa';
export default class Terminal extends BaseModel {
    static table = 'terminal';
    idterminal;
    id_prime;
    nome;
    descricaoTerminal;
    caixa;
    terminalDestino;
    utilizaControleDeEntrega;
    imprimirControleDeEntrega;
    travarSistemaComGavetaAberta;
    desativarConsultaDeProdutoPdv;
    emitirNotaPromissoriaVendaPrazo;
    emitirCarneDeCobrancaVendaParcela;
    balcaoGeraOrcamento;
    balcaoGeraVenda;
    balcaoFazRecebimento;
    exigirSenhaVendedorBalcao;
    nomeImgPdv;
    tipoPapel;
    tamanhoPapel;
    impressoraPdvBalcao;
    modeloImpressoraEcf;
    velocidadePorta;
    portaImpressao;
    mensagemRodapeEcf;
    portaImpCodBarra;
    linguagemImpCodBarra;
    velocidadePortaCodBarra;
    concomitante;
    colunasImpressoraBalcao;
    colunasImpressoraEcf;
    modeloImpNaoFiscal;
    controlaGaveta;
    fecharOrcamentoRapido;
    modelobalanca;
    portabalanca;
    baundratebalanca;
    databitsbalanca;
    paridadebalanca;
    stopbitsbalanca;
    handshakingbalanca;
    timeoutbalanca;
    linhasAvancoPapelImpressaoBalcao;
    debugImpressao;
    gavetaSinalInvertido;
    usaGavetaDinheiro;
    paridadeEcf;
    leitorSerialPorta;
    leitorSerialVelocidade;
    utilizaTef;
    modeloImpressoraOrcamento;
    maqChequePorta;
    maqChequeVelocidade;
    maqChequeModelo;
    ecfNumeroLoja;
    ecfNumeroCaixa;
    ecfModeloCompleto;
    ecfNumSerie;
    finalizaComandaMesa;
    codigoIlha;
    atalhoTeclado;
    comandoGuilhotina;
    comandoGaveta;
    pdvGeraVenda;
    tipoCalculoEcf;
    tipoCalculoEcfValor;
    solucaoFiscal;
    sfTipoImpressao;
    sfImpModelo;
    sfImpPorta;
    sfImpVelocidade;
    sfImpParidade;
    sfImpGraficoCaminho;
    mtImpressaoLerBanco;
    enderecoImpressora;
    colunasImpressoraFechamento;
    avancoImpressoraFechamento;
    comandoGuilhotinaImpressoraFechamento;
    touch;
    ptoEmiFaccturacionElectronica;
    desativarConsultaDeProdutoBalcao;
    atc;
    tipoImpressaoNotaEntrada;
    sitefIpServidor;
    sitefCodigoLoja;
    sitefNumeroTerminal;
    idSat;
    sitefPortaImpressora;
    numeroTransacaoTef;
    qrCodeLateral;
    sfImpGraficoMargemSuperior;
    sfImpGraficoMargemInferior;
    sfImpGraficoMargemDireita;
    sfImpGraficoMargemEsquerda;
    enderecoMac;
    numero;
    caixa_destino;
    id_empresa;
    idVisitor;
    syncPrime;
    liberarEditarValor;
    solicitarQuantidade;
    deleted;
    nfce;
    tipoImpressaoSatNfce;
    desativarConsultaProduto;
    exigirSenhaVendedor;
    solicitarCodigoVendedor;
    tiposDeImpressaoEscolhaImpressora;
    pedirObsFechamentoOrcamento;
    selecionarImpressoraOrcamento;
    imprimirItensCupom2Linhas;
    solicitarConfirmacaoDoValorDoItem;
    acbr_caminho;
    qztray_certificado;
    qztray_chave;
    hostname;
    pedhos;
    empresa;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Terminal.prototype, "idterminal", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "nome", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "descricaoTerminal", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "caixa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "terminalDestino", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "utilizaControleDeEntrega", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "imprimirControleDeEntrega", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "travarSistemaComGavetaAberta", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "desativarConsultaDeProdutoPdv", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "emitirNotaPromissoriaVendaPrazo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "emitirCarneDeCobrancaVendaParcela", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "balcaoGeraOrcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "balcaoGeraVenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "balcaoFazRecebimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "exigirSenhaVendedorBalcao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "nomeImgPdv", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "tipoPapel", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "tamanhoPapel", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "impressoraPdvBalcao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "modeloImpressoraEcf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "velocidadePorta", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "portaImpressao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "mensagemRodapeEcf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "portaImpCodBarra", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "linguagemImpCodBarra", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "velocidadePortaCodBarra", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "concomitante", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "colunasImpressoraBalcao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "colunasImpressoraEcf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "modeloImpNaoFiscal", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "controlaGaveta", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "fecharOrcamentoRapido", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "modelobalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "portabalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "baundratebalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "databitsbalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "paridadebalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "stopbitsbalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "handshakingbalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "timeoutbalanca", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "linhasAvancoPapelImpressaoBalcao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "debugImpressao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "gavetaSinalInvertido", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "usaGavetaDinheiro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "paridadeEcf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "leitorSerialPorta", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "leitorSerialVelocidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "utilizaTef", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "modeloImpressoraOrcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "maqChequePorta", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "maqChequeVelocidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "maqChequeModelo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "ecfNumeroLoja", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "ecfNumeroCaixa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "ecfModeloCompleto", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "ecfNumSerie", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "finalizaComandaMesa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "codigoIlha", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "atalhoTeclado", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "comandoGuilhotina", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "comandoGaveta", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "pdvGeraVenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "tipoCalculoEcf", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "tipoCalculoEcfValor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "solucaoFiscal", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "sfTipoImpressao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "sfImpModelo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sfImpPorta", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sfImpVelocidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sfImpParidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sfImpGraficoCaminho", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "mtImpressaoLerBanco", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "enderecoImpressora", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "colunasImpressoraFechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "avancoImpressoraFechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "comandoGuilhotinaImpressoraFechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "touch", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "ptoEmiFaccturacionElectronica", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "desativarConsultaDeProdutoBalcao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "atc", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "tipoImpressaoNotaEntrada", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sitefIpServidor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sitefCodigoLoja", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sitefNumeroTerminal", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "idSat", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "sitefPortaImpressora", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "numeroTransacaoTef", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "qrCodeLateral", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "sfImpGraficoMargemSuperior", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "sfImpGraficoMargemInferior", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "sfImpGraficoMargemDireita", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "sfImpGraficoMargemEsquerda", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "enderecoMac", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "numero", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "caixa_destino", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Terminal.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "idVisitor", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "liberarEditarValor", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "solicitarQuantidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "deleted", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "nfce", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "tipoImpressaoSatNfce", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "desativarConsultaProduto", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "exigirSenhaVendedor", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "solicitarCodigoVendedor", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "tiposDeImpressaoEscolhaImpressora", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "pedirObsFechamentoOrcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "selecionarImpressoraOrcamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "imprimirItensCupom2Linhas", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "solicitarConfirmacaoDoValorDoItem", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "acbr_caminho", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "qztray_certificado", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "qztray_chave", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Terminal.prototype, "hostname", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Terminal.prototype, "pedhos", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], Terminal.prototype, "empresa", void 0);
//# sourceMappingURL=terminal.js.map