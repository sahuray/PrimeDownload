var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import FuncionarioUsuario from './funcionario_usuario.js';
import FormaDePagamentoTipo from './forma_de_pagamento_tipo.js';
export default class CaixaMovimentoSaida extends BaseModel {
    static table = 'caixa_saida';
    id;
    id_caixa_movimento;
    id_forma_pagamento_tipo;
    id_funcionario_usuario;
    id_prime;
    valor;
    descricao;
    sangria;
    dataemissao;
    horaemissao;
    tipo;
    sync_prime;
    createdAt;
    updatedAt;
    deleted_at;
    formaDePagTipo;
    usuario;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "id_caixa_movimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "id_forma_pagamento_tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "id_funcionario_usuario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "valor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaMovimentoSaida.prototype, "descricao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaMovimentoSaida.prototype, "sangria", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimentoSaida.prototype, "dataemissao", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimentoSaida.prototype, "horaemissao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaMovimentoSaida.prototype, "tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaMovimentoSaida.prototype, "sync_prime", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], CaixaMovimentoSaida.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], CaixaMovimentoSaida.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], CaixaMovimentoSaida.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => FormaDePagamentoTipo, {
        foreignKey: 'id_forma_pagamento_tipo',
    }),
    __metadata("design:type", Object)
], CaixaMovimentoSaida.prototype, "formaDePagTipo", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'id_funcionario_usuario',
    }),
    __metadata("design:type", Object)
], CaixaMovimentoSaida.prototype, "usuario", void 0);
//# sourceMappingURL=caixa_movimento_saida.js.map