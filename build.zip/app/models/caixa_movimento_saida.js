var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, column, hasOne } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import FormaDePagamento from '#models/forma_de_pagamento';
import Funcionario from '#models/funcionario_usuario';
export default class CaixaMovimentoSaida extends BaseModel {
    static table = 'caixa_movimento_saida';
    idcaixamovimentosaida;
    idcaixamovimento;
    idformapagamento;
    idfuncionariousuario;
    valor;
    descricao;
    sangria;
    dataemissao;
    horaemissao;
    tipo;
    formaDePagamento;
    funcionario;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "idcaixamovimentosaida", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "idcaixamovimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "idformapagamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "idfuncionariousuario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimentoSaida.prototype, "valor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaMovimentoSaida.prototype, "descricao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaMovimentoSaida.prototype, "sangria", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimentoSaida.prototype, "dataemissao", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimentoSaida.prototype, "horaemissao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaMovimentoSaida.prototype, "tipo", void 0);
__decorate([
    hasOne(() => FormaDePagamento, {
        localKey: 'idformapagamento',
        foreignKey: 'id',
    }),
    __metadata("design:type", Object)
], CaixaMovimentoSaida.prototype, "formaDePagamento", void 0);
__decorate([
    hasOne(() => Funcionario, {
        localKey: 'idfuncionariousuario',
        foreignKey: 'idfuncionariousuario',
    }),
    __metadata("design:type", Object)
], CaixaMovimentoSaida.prototype, "funcionario", void 0);
//# sourceMappingURL=caixa_movimento_saida.js.map