var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import Funcionario from '#models/funcionario';
export default class FuncionarioUsuario extends BaseModel {
    static table = 'funcionario_usuario';
    idfuncionariousuario;
    idFuncionario;
    usuario;
    senha;
    tema;
    biometria;
    ultimaalteracao;
    sincronizado;
    id_prime;
    empresaId;
    funcionario;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], FuncionarioUsuario.prototype, "idfuncionariousuario", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], FuncionarioUsuario.prototype, "idFuncionario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], FuncionarioUsuario.prototype, "usuario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], FuncionarioUsuario.prototype, "senha", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FuncionarioUsuario.prototype, "tema", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], FuncionarioUsuario.prototype, "biometria", void 0);
__decorate([
    column(),
    __metadata("design:type", Date)
], FuncionarioUsuario.prototype, "ultimaalteracao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], FuncionarioUsuario.prototype, "sincronizado", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FuncionarioUsuario.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FuncionarioUsuario.prototype, "empresaId", void 0);
__decorate([
    belongsTo(() => Funcionario, {
        foreignKey: 'idFuncionario',
    }),
    __metadata("design:type", Object)
], FuncionarioUsuario.prototype, "funcionario", void 0);
//# sourceMappingURL=funcionario_usuario.js.map