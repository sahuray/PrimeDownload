var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import PrimePermissao from '#models/prime_permissao';
import FuncionarioUsuario from '#models/funcionario_usuario';
import Empresa from '#models/empresa';
import Grupo from '#models/grupo';
export default class PrimePermissaoUsuario extends BaseModel {
    static table = 'prime_permissao_usuario';
    id;
    id_prime;
    id_permissao;
    id_usuario;
    id_empresa;
    id_grupo;
    createdAt;
    updatedAt;
    deletedAt;
    permissao;
    usuario;
    empresa;
    grupo;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimePermissaoUsuario.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimePermissaoUsuario.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimePermissaoUsuario.prototype, "id_permissao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimePermissaoUsuario.prototype, "id_usuario", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimePermissaoUsuario.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimePermissaoUsuario.prototype, "id_grupo", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimePermissaoUsuario.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimePermissaoUsuario.prototype, "updatedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimePermissaoUsuario.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => PrimePermissao, {
        foreignKey: 'id_permissao',
    }),
    __metadata("design:type", Object)
], PrimePermissaoUsuario.prototype, "permissao", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'id_usuario',
    }),
    __metadata("design:type", Object)
], PrimePermissaoUsuario.prototype, "usuario", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimePermissaoUsuario.prototype, "empresa", void 0);
__decorate([
    belongsTo(() => Grupo, {
        foreignKey: 'id_grupo',
    }),
    __metadata("design:type", Object)
], PrimePermissaoUsuario.prototype, "grupo", void 0);
//# sourceMappingURL=prime_permissao_usuario.js.map