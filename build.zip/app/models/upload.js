var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import FuncionarioUsuario from '#models/funcionario_usuario';
export default class Upload extends BaseModel {
    static table = 'prime_upload';
    id;
    id_prime;
    sync_prime;
    id_funcionario_usuario;
    url;
    type;
    id_fk;
    description;
    name;
    expiration_date;
    createdAt;
    funcionarioUsuario;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Upload.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Upload.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Upload.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Upload.prototype, "id_funcionario_usuario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Upload.prototype, "url", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Upload.prototype, "type", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Upload.prototype, "id_fk", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Upload.prototype, "description", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Upload.prototype, "name", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], Upload.prototype, "expiration_date", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Upload.prototype, "createdAt", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'id_funcionario_usuario',
    }),
    __metadata("design:type", Object)
], Upload.prototype, "funcionarioUsuario", void 0);
//# sourceMappingURL=upload.js.map