var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import FuncionarioUsuario from './funcionario_usuario.js';
export default class CaixaMovimento extends BaseModel {
    static table = 'caixa_movimento';
    idcaixamovimento;
    id_prime;
    idfuncionariousuarioabertura;
    idfuncionariousuariofechamento;
    idterminal;
    dataabertura;
    horaabertura;
    datafechamento;
    horafechamento;
    totalvenda;
    totalsaida;
    totalestorno;
    totaldinheirocaixa;
    suprimentoatual;
    valor_abertura;
    saldoanterior;
    saldofinal;
    status;
    justificativa;
    sync_prime;
    datasync;
    funcionarioUsuarioAbertura;
    funcionarioUsuarioFechamento;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "idcaixamovimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CaixaMovimento.prototype, "idfuncionariousuarioabertura", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CaixaMovimento.prototype, "idfuncionariousuariofechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CaixaMovimento.prototype, "idterminal", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimento.prototype, "dataabertura", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimento.prototype, "horaabertura", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimento.prototype, "datafechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaMovimento.prototype, "horafechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "totalvenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "totalsaida", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "totalestorno", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "totaldinheirocaixa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "suprimentoatual", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "valor_abertura", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "saldoanterior", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaMovimento.prototype, "saldofinal", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaMovimento.prototype, "status", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaMovimento.prototype, "justificativa", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaMovimento.prototype, "sync_prime", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], CaixaMovimento.prototype, "datasync", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'idfuncionariousuarioabertura',
        localKey: 'idfuncionariousuario',
    }),
    __metadata("design:type", Object)
], CaixaMovimento.prototype, "funcionarioUsuarioAbertura", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'idfuncionariousuariofechamento',
        localKey: 'idfuncionariousuario',
    }),
    __metadata("design:type", Object)
], CaixaMovimento.prototype, "funcionarioUsuarioFechamento", void 0);
//# sourceMappingURL=caixa_movimento.js.map