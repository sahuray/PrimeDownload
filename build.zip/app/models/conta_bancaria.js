var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import PrimeFuncionarioUsuario from '#models/funcionario_usuario';
import PrimeBanco from '#models/banco';
import PrimeEmpresa from '#models/empresa';
import PrimeGrupo from '#models/grupo';
export default class ContaBancaria extends BaseModel {
    static table = 'prime_conta_bancaria';
    id;
    id_prime;
    id_grupo;
    id_banco;
    id_empresa;
    id_provider;
    e_caixa_central;
    updatedBy;
    agencia;
    conta_corrente;
    tipo_pessoa;
    titular_conta;
    socio_titular_conta;
    gerente_conta;
    telefone_gerente;
    email_gerente;
    operadora;
    status;
    boleto_registrado_status;
    utiliza_desconto_pontualidade;
    padrao_para_todas_as_vendas;
    boleto_carteira_registrado;
    especie_padrao;
    boleto_carteira_registrado_codigo;
    boleto_nosso_numero_automatico;
    boleto_nosso_numero;
    boleto_dias_devolucao;
    boleto_carteira_variacao;
    boleto_instrucao;
    boleto_instrucao_remessa_1;
    boleto_instrucao_remessa_2;
    boleto_instrucao_remessa_3;
    boleto_dias_carencia;
    boleto_dias_negativacao;
    boleto_tipo_cobranca;
    boleto_layout;
    boleto_especie_padrao;
    boleto_aceite_padrao;
    boleto_codigo_cedente;
    boleto_porcentagem_mora;
    boleto_porcentagem_multa;
    dias_carencia;
    boleto_convenio;
    boleto_tipo_numero_documento;
    boleto_layoutremessa;
    boleto_codigo_transmissao;
    boleto_tipo_nome_pagador;
    boleto_tipo_cliente_arquivo_remessa;
    agencia_digito;
    conta_digito;
    permite_boleto;
    instruction_six;
    instruction_seven;
    instruction_eight;
    local_pagamento;
    sync_prime;
    createdAt;
    updatedAt;
    deletedAt;
    updatedUser;
    grupo;
    banco;
    empresa;
    fornecedor;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "id_grupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "id_banco", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "id_provider", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "e_caixa_central", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], ContaBancaria.prototype, "updatedBy", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "agencia", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "conta_corrente", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "tipo_pessoa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "titular_conta", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "socio_titular_conta", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "gerente_conta", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "telefone_gerente", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "email_gerente", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "operadora", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "status", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "boleto_registrado_status", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "utiliza_desconto_pontualidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "padrao_para_todas_as_vendas", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_carteira_registrado", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "especie_padrao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_carteira_registrado_codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_nosso_numero_automatico", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_nosso_numero", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_dias_devolucao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_carteira_variacao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_instrucao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_instrucao_remessa_1", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_instrucao_remessa_2", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_instrucao_remessa_3", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_dias_carencia", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_dias_negativacao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_tipo_cobranca", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_layout", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_especie_padrao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "boleto_aceite_padrao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_codigo_cedente", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_porcentagem_mora", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_porcentagem_multa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "dias_carencia", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_convenio", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_tipo_numero_documento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_layoutremessa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_codigo_transmissao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_tipo_nome_pagador", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "boleto_tipo_cliente_arquivo_remessa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "agencia_digito", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], ContaBancaria.prototype, "conta_digito", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "permite_boleto", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "instruction_six", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "instruction_seven", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "instruction_eight", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], ContaBancaria.prototype, "local_pagamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], ContaBancaria.prototype, "sync_prime", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], ContaBancaria.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], ContaBancaria.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], ContaBancaria.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => PrimeFuncionarioUsuario, {
        foreignKey: 'updated_by',
    }),
    __metadata("design:type", Object)
], ContaBancaria.prototype, "updatedUser", void 0);
__decorate([
    belongsTo(() => PrimeGrupo, {
        foreignKey: 'id_grupo',
    }),
    __metadata("design:type", Object)
], ContaBancaria.prototype, "grupo", void 0);
__decorate([
    belongsTo(() => PrimeBanco, {
        foreignKey: 'id_banco',
    }),
    __metadata("design:type", Object)
], ContaBancaria.prototype, "banco", void 0);
__decorate([
    belongsTo(() => PrimeEmpresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], ContaBancaria.prototype, "empresa", void 0);
__decorate([
    belongsTo(() => PrimeEmpresa, {
        foreignKey: 'id_provider',
    }),
    __metadata("design:type", Object)
], ContaBancaria.prototype, "fornecedor", void 0);
//# sourceMappingURL=conta_bancaria.js.map