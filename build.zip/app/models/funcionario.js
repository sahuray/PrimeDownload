var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import Empresa from '#models/empresa';
import Revenda from '#models/revenda';
export default class Funcionario extends BaseModel {
    static table = 'funcionario';
    idfuncionario;
    idfuncionariofuncao;
    idfuncionariousuario;
    nome;
    nascimento;
    cpf;
    rg;
    salario;
    telefone;
    celular;
    foto;
    statusfuncionario;
    enderecoCep;
    enderecoLogradouro;
    enderecoNumero;
    enderecoComplemento;
    enderecoBairro;
    enderecoCidade;
    enderecoUf;
    tipoComissao;
    comissao;
    observacao;
    descontoMaximo;
    email;
    setor;
    prontuario;
    datademissao;
    tituloEleitor;
    ctps;
    pis;
    nomePai;
    nomeMae;
    sexo;
    codigoLoginTerminal;
    idCbo;
    horaCriacao;
    horaAlteracao;
    listarPorCarteira;
    dddTelefone;
    operadoraTelefone;
    dddCelular;
    operadoraCelular;
    miniCurriculo;
    exibeNoCardapio;
    codigoFuncaoCardapio;
    podeGerarChave;
    podeGerarChavePendencia;
    podeGerarChaveProvisoria;
    funcionarioUsuario;
    enderecoProvincia;
    corporativo;
    dddCorporativo;
    operadoraCorporativo;
    dataExameAdmissional;
    dataExamePeriodico;
    idFuncionarioUsuarioGrupo;
    agenteNocivo;
    atividadeDesenvolvida;
    calculaPericulosidade;
    calculaSalarioFamilia;
    calculaDsrAdicionais;
    dataExpedicaoCarteiraProfissional;
    categoriaGfip;
    categoriaEsocial;
    codigoDaEmpresa;
    codigoIbgeNascimento;
    condicaoFuncionarioAtual;
    dataOpcaoFgts;
    desejaAdiantamentoAutomatico;
    empregoAnterior;
    estadoCivil;
    grauDeInstrucao;
    localDeNascimento;
    localDeTrabalhoNumero;
    localDeTrabalhoLogradouro;
    localDeTrabalhoTipoLogradouro;
    localDeTrabalhoBairro;
    localDeTrabalhoCidade;
    localDeTrabalhoCep;
    localDeTrabalhoUf;
    racaCor;
    recolheSindical;
    rgDataEmissao;
    rgEstadoEmissor;
    rgOrgaoEmissor;
    tipoAdmissao;
    tipoLogradouro;
    tipoRegimePrevidenciario;
    tipoRegimeTrabalhista;
    tipoDoPagamento;
    tipoDoSalario;
    tributaFgts;
    tributaInss;
    tributaIrrf;
    vinculoEmpregaticio;
    tituloEleitorDataDeEmissao;
    tituloEleitorZona;
    tituloEleitorSecao;
    sincronizado;
    localDeTrabalhoCodigoCidade;
    enderecoCodigoCidade;
    exibirVendasRealizadasVendedor;
    idPrime;
    idEmpresa;
    idRevenda;
    syncPrime;
    code_seller;
    funcionario_venda_permission;
    seller;
    empresa;
    revenda;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Funcionario.prototype, "idfuncionario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "idfuncionariofuncao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "idfuncionariousuario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "nome", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], Funcionario.prototype, "nascimento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "cpf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "rg", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "salario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "telefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "celular", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "foto", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "statusfuncionario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoCep", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoLogradouro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoNumero", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoComplemento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoBairro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoCidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoUf", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "tipoComissao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "comissao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "observacao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "descontoMaximo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "email", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "setor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "prontuario", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Funcionario.prototype, "datademissao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "tituloEleitor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "ctps", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "pis", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "nomePai", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "nomeMae", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "sexo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "codigoLoginTerminal", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "idCbo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "horaCriacao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "horaAlteracao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "listarPorCarteira", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "dddTelefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "operadoraTelefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "dddCelular", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "operadoraCelular", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "miniCurriculo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "exibeNoCardapio", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "codigoFuncaoCardapio", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "podeGerarChave", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "podeGerarChavePendencia", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "podeGerarChaveProvisoria", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "funcionarioUsuario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoProvincia", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "corporativo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "dddCorporativo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "operadoraCorporativo", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Funcionario.prototype, "dataExameAdmissional", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Funcionario.prototype, "dataExamePeriodico", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "idFuncionarioUsuarioGrupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "agenteNocivo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "atividadeDesenvolvida", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "calculaPericulosidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "calculaSalarioFamilia", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "calculaDsrAdicionais", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], Funcionario.prototype, "dataExpedicaoCarteiraProfissional", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "categoriaGfip", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "categoriaEsocial", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "codigoDaEmpresa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "codigoIbgeNascimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "condicaoFuncionarioAtual", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], Funcionario.prototype, "dataOpcaoFgts", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "desejaAdiantamentoAutomatico", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "empregoAnterior", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "estadoCivil", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "grauDeInstrucao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeNascimento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoNumero", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoLogradouro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoTipoLogradouro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoBairro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoCidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoCep", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoUf", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "racaCor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "recolheSindical", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], Funcionario.prototype, "rgDataEmissao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "rgEstadoEmissor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "rgOrgaoEmissor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tipoAdmissao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "tipoLogradouro", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tipoRegimePrevidenciario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tipoRegimeTrabalhista", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tipoDoPagamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tipoDoSalario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tributaFgts", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tributaInss", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "tributaIrrf", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "vinculoEmpregaticio", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], Funcionario.prototype, "tituloEleitorDataDeEmissao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "tituloEleitorZona", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "tituloEleitorSecao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "sincronizado", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "localDeTrabalhoCodigoCidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "enderecoCodigoCidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "exibirVendasRealizadasVendedor", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Funcionario.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "idEmpresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Funcionario.prototype, "idRevenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Funcionario.prototype, "code_seller", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "funcionario_venda_permission", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Funcionario.prototype, "seller", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Funcionario.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Funcionario.prototype, "dataalteraca", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Funcionario.prototype, "deleted_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Funcionario.prototype, "dataadmissao", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'idEmpresa',
    }),
    __metadata("design:type", Object)
], Funcionario.prototype, "empresa", void 0);
__decorate([
    belongsTo(() => Revenda, {
        foreignKey: 'idRevenda',
    }),
    __metadata("design:type", Object)
], Funcionario.prototype, "revenda", void 0);
//# sourceMappingURL=funcionario.js.map