var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import Venda from './venda.js';
export default class VendaCliente extends BaseModel {
    static table = 'prime_venda_cliente';
    id;
    idPrime;
    idVenda;
    idEmpresa;
    syncPrime;
    nomeFantasia;
    razaoSocial;
    apelido;
    cnpjCpf;
    ieRg;
    im;
    email;
    telefone;
    codigo;
    tipo;
    origem;
    aniversario;
    tipoEndereco;
    cep;
    uf;
    cidade;
    bairro;
    logradouro;
    numero;
    complemento;
    codigoCidade;
    codigoUf;
    referencia;
    contatoNome;
    contatoEmail;
    contatoTelefone;
    contatoObservacao;
    tipoContato;
    contato;
    createdAt;
    updatedAt;
    deletedAt;
    venda;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], VendaCliente.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaCliente.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaCliente.prototype, "idVenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaCliente.prototype, "idEmpresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], VendaCliente.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "nomeFantasia", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "razaoSocial", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "apelido", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "cnpjCpf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "ieRg", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "im", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "email", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "telefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "origem", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], VendaCliente.prototype, "aniversario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "tipoEndereco", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "cep", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "uf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "cidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "bairro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "logradouro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "numero", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "complemento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "codigoCidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "codigoUf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "referencia", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "contatoNome", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "contatoEmail", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "contatoTelefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "contatoObservacao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "tipoContato", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaCliente.prototype, "contato", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], VendaCliente.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], VendaCliente.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], VendaCliente.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Venda, {
        foreignKey: 'idVenda',
    }),
    __metadata("design:type", Object)
], VendaCliente.prototype, "venda", void 0);
//# sourceMappingURL=venda_cliente.js.map