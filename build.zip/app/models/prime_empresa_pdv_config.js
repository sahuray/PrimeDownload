var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import Empresa from '#models/empresa';
export default class EmpresaPdvConfig extends BaseModel {
    static table = 'prime_empresa_pdv_config';
    id;
    id_prime;
    id_empresa;
    tipo_de_prazo;
    limite_qtd_itens_venda;
    qtd_vias_cupom_prazo;
    qtd_vias_cupom_vista;
    limite_vendas_a_prazo;
    desconto_maximo_na_venda;
    dia_do_prazo;
    nao_pedir_valor_caixa;
    gerar_comissao;
    imprimir_codigo_produto;
    utiliza_numero_serie;
    solicitar_confirmacao_exclusao_estoque;
    imprimir_observacao_produto;
    desconto_maximo_venda;
    exigir_senha_sangria;
    imprimir_comprovante_operacao;
    fechar_venda_com_enter;
    imprimir_obs_peso;
    imprimir_endereco_cliente_detalhado;
    nao_permitir_orcamento_estoque_zerado;
    permitir_escolher_preco_venda;
    imprimir_comprovante_venda_prazo;
    confirmar_impressao_comprovante_venda_prazo;
    msg_rodape_impresso_gerado_sistema;
    bloquear_vendas_a_prazo_por_limite;
    bloquear_vendas_a_prazo_por_atraso_do_cliente;
    lancar_mesa_fechamento;
    divisao_maior_valor;
    arredondamento_padrao_valor;
    utiliza_taxa;
    utiliza_couvert;
    id_servico_taxa;
    nome_produto_taxa;
    codigo_produto_taxa;
    id_servico_couvert;
    nome_produto_couvert;
    codigo_produto_couvert;
    valor_taxa;
    valor_couvert;
    utiliza_mesa_com_comanda;
    ip_server_core;
    createdAt;
    updatedAt;
    deletedAt;
    company;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], EmpresaPdvConfig.prototype, "tipo_de_prazo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "limite_qtd_itens_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "qtd_vias_cupom_prazo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "qtd_vias_cupom_vista", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "limite_vendas_a_prazo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "desconto_maximo_na_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "dia_do_prazo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "nao_pedir_valor_caixa", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "gerar_comissao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "imprimir_codigo_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "utiliza_numero_serie", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "solicitar_confirmacao_exclusao_estoque", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "imprimir_observacao_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "desconto_maximo_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "exigir_senha_sangria", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "imprimir_comprovante_operacao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "fechar_venda_com_enter", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "imprimir_obs_peso", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "imprimir_endereco_cliente_detalhado", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "nao_permitir_orcamento_estoque_zerado", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "permitir_escolher_preco_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "imprimir_comprovante_venda_prazo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "confirmar_impressao_comprovante_venda_prazo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "msg_rodape_impresso_gerado_sistema", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "bloquear_vendas_a_prazo_por_limite", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "bloquear_vendas_a_prazo_por_atraso_do_cliente", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "lancar_mesa_fechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "divisao_maior_valor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "arredondamento_padrao_valor", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "utiliza_taxa", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "utiliza_couvert", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], EmpresaPdvConfig.prototype, "id_servico_taxa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], EmpresaPdvConfig.prototype, "nome_produto_taxa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], EmpresaPdvConfig.prototype, "codigo_produto_taxa", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], EmpresaPdvConfig.prototype, "id_servico_couvert", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], EmpresaPdvConfig.prototype, "nome_produto_couvert", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], EmpresaPdvConfig.prototype, "codigo_produto_couvert", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "valor_taxa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], EmpresaPdvConfig.prototype, "valor_couvert", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], EmpresaPdvConfig.prototype, "utiliza_mesa_com_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], EmpresaPdvConfig.prototype, "ip_server_core", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], EmpresaPdvConfig.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], EmpresaPdvConfig.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], EmpresaPdvConfig.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], EmpresaPdvConfig.prototype, "company", void 0);
//# sourceMappingURL=prime_empresa_pdv_config.js.map