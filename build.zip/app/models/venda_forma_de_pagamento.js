var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column, hasMany } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import Venda from '#models/venda';
import FormaDePagamento from '#models/forma_de_pagamento';
import VendaFormaDePagamentoParcela from './venda_pagamento_a_prazo.js';
export default class VendaFormaDePagamento extends BaseModel {
    static table = 'prime_venda_forma_de_pagamento';
    id;
    idPrime;
    idVenda;
    idFormaDePagamento;
    syncPrime;
    installmentValue;
    createdAt;
    updatedAt;
    deletedAt;
    venda;
    formaDePagamento;
    vendaFormaDePagamentoParcela;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], VendaFormaDePagamento.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamento.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamento.prototype, "idVenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamento.prototype, "idFormaDePagamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], VendaFormaDePagamento.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamento.prototype, "installmentValue", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], VendaFormaDePagamento.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], VendaFormaDePagamento.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], VendaFormaDePagamento.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Venda, {
        foreignKey: 'idVenda',
    }),
    __metadata("design:type", Object)
], VendaFormaDePagamento.prototype, "venda", void 0);
__decorate([
    belongsTo(() => FormaDePagamento, {
        foreignKey: 'idFormaDePagamento',
    }),
    __metadata("design:type", Object)
], VendaFormaDePagamento.prototype, "formaDePagamento", void 0);
__decorate([
    hasMany(() => VendaFormaDePagamentoParcela, {
        foreignKey: 'idVendaFormaDePagamento',
    }),
    __metadata("design:type", Object)
], VendaFormaDePagamento.prototype, "vendaFormaDePagamentoParcela", void 0);
//# sourceMappingURL=venda_forma_de_pagamento.js.map