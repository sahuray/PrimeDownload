var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
export default class CaixaEntrada extends BaseModel {
    static table = 'caixa_entrada';
    idcaixaentrada;
    idcaixacentral;
    idcaixamovimentosaida;
    datadocumento;
    datalancamento;
    horalancamento;
    descricao;
    valor;
    numerodocumento;
    tipopagamento;
    observacao;
    idcontarecebida;
    sangria;
    idorigemlancamento;
    integracontabilidade;
    idrevenda;
    sincronizado;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "idcaixaentrada", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "idcaixacentral", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "idcaixamovimentosaida", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaEntrada.prototype, "datadocumento", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaEntrada.prototype, "datalancamento", void 0);
__decorate([
    column(),
    __metadata("design:type", DateTime)
], CaixaEntrada.prototype, "horalancamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaEntrada.prototype, "descricao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "valor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaEntrada.prototype, "numerodocumento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaEntrada.prototype, "tipopagamento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaEntrada.prototype, "observacao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "idcontarecebida", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaEntrada.prototype, "sangria", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "idorigemlancamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "integracontabilidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaEntrada.prototype, "idrevenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaEntrada.prototype, "sincronizado", void 0);
//# sourceMappingURL=caixa_entrada.js.map