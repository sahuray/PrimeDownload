var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import Empresa from '#models/empresa';
import PrimeProduto from './prime_produto.js';
export default class PrimeProdutoLoteExpiracao extends BaseModel {
    static table = 'prime_produto_lote_expiracao';
    id;
    id_prime;
    sync_prime;
    id_empresa;
    id_produto;
    lot;
    expiration_date;
    elaboration_date;
    created_at;
    updated_at;
    deleted_at;
    Empresa;
    PrimeProduto;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProdutoLoteExpiracao.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoLoteExpiracao.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoLoteExpiracao.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoLoteExpiracao.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoLoteExpiracao.prototype, "id_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoLoteExpiracao.prototype, "lot", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], PrimeProdutoLoteExpiracao.prototype, "expiration_date", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], PrimeProdutoLoteExpiracao.prototype, "elaboration_date", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoLoteExpiracao.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoLoteExpiracao.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProdutoLoteExpiracao.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimeProdutoLoteExpiracao.prototype, "Empresa", void 0);
__decorate([
    belongsTo(() => PrimeProduto, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProdutoLoteExpiracao.prototype, "PrimeProduto", void 0);
//# sourceMappingURL=prime_produto_lote_expiracao.js.map