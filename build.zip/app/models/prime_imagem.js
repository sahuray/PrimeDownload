var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import FuncionarioUsuario from './funcionario_usuario.js';
export default class PrimeImagem extends BaseModel {
    static table = 'prime_imagem';
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeImagem.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "nomeDoArquivo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "caminhoDoArquivo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "ordemDeExecucao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "tamanhoDoArquivo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "extensaoDoArquivo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "descricao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "base64", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeImagem.prototype, "duracaoExibicaoMinutos", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeImagem.prototype, "idUsuario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeImagem.prototype, "idTerminal", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeImagem.prototype, "status", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeImagem.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeImagem.prototype, "updatedAt", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'idUsuario',
        localKey: 'idfuncionariousuario',
    }),
    __metadata("design:type", Object)
], PrimeImagem.prototype, "usuario", void 0);
//# sourceMappingURL=prime_imagem.js.map