var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column } from '@adonisjs/lucid/orm';
export default class PrimeUpload extends BaseModel {
    static table = 'prime_upload';
    id;
    id_prime;
    id_funcionario_usuario;
    url;
    type;
    id_fk;
    description;
    name;
    expiration_date;
    created_at;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeUpload.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeUpload.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeUpload.prototype, "id_funcionario_usuario", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeUpload.prototype, "url", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeUpload.prototype, "type", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeUpload.prototype, "id_fk", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeUpload.prototype, "description", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeUpload.prototype, "name", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", DateTime)
], PrimeUpload.prototype, "expiration_date", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeUpload.prototype, "created_at", void 0);
//# sourceMappingURL=prime_upload.js.map