var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import PrimeEmpresa from '#models/empresa';
import Comanda from '#models/comanda';
import Venda from '#models/venda';
import FuncionarioUsuario from '#models/funcionario_usuario';
export default class CloseComandas extends BaseModel {
    static table = 'prime_close_comandas';
    id;
    id_comanda;
    id_empresa;
    id_usuario;
    id_venda;
    numero_comanda;
    valor_total;
    valor_taxa_servico;
    valor_couvert;
    empresa;
    comanda;
    venda;
    usuario;
    created_at;
    updated_at;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], CloseComandas.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CloseComandas.prototype, "id_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CloseComandas.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CloseComandas.prototype, "id_usuario", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CloseComandas.prototype, "id_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CloseComandas.prototype, "numero_comanda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CloseComandas.prototype, "valor_total", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CloseComandas.prototype, "valor_taxa_servico", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CloseComandas.prototype, "valor_couvert", void 0);
__decorate([
    belongsTo(() => PrimeEmpresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], CloseComandas.prototype, "empresa", void 0);
__decorate([
    belongsTo(() => Comanda, {
        foreignKey: 'id_comanda',
    }),
    __metadata("design:type", Object)
], CloseComandas.prototype, "comanda", void 0);
__decorate([
    belongsTo(() => Venda, {
        foreignKey: 'id_venda',
    }),
    __metadata("design:type", Object)
], CloseComandas.prototype, "venda", void 0);
__decorate([
    belongsTo(() => FuncionarioUsuario, {
        foreignKey: 'id_usuario',
        localKey: 'idfuncionariousuario',
    }),
    __metadata("design:type", Object)
], CloseComandas.prototype, "usuario", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], CloseComandas.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], CloseComandas.prototype, "updated_at", void 0);
//# sourceMappingURL=comandas_fechadas.js.map