var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import PrimeProduto from '#models/prime_produto';
import Empresa from '#models/empresa';
export default class PrimeProdutoComposto extends BaseModel {
    static table = 'prime_produto_composto';
    id;
    id_prime;
    sync_prime;
    id_detalhe;
    id_empresa;
    id_produto;
    quantity;
    composicao;
    custo_unitario;
    custo_total;
    estoque;
    restante;
    perda_real;
    perda_porcentagem;
    custo_perda;
    custo_real_com_perdas;
    codigo;
    created_at;
    updated_at;
    deleted_at;
    PrimeProdutoDetalhe;
    Empresa;
    PrimeProduto;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoComposto.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "id_detalhe", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "id_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoComposto.prototype, "quantity", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoComposto.prototype, "composicao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "custo_unitario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "custo_total", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "estoque", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "restante", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "perda_real", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "perda_porcentagem", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "custo_perda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoComposto.prototype, "custo_real_com_perdas", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoComposto.prototype, "codigo", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoComposto.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoComposto.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProdutoComposto.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => PrimeProduto, {
        foreignKey: 'id_detalhe',
    }),
    __metadata("design:type", Object)
], PrimeProdutoComposto.prototype, "PrimeProdutoDetalhe", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimeProdutoComposto.prototype, "Empresa", void 0);
__decorate([
    belongsTo(() => PrimeProduto, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProdutoComposto.prototype, "PrimeProduto", void 0);
//# sourceMappingURL=prime_produto_composto.js.map