var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import Venda from '#models/venda';
import VendaFormaDePagamento from '#models/venda_forma_de_pagamento';
import FormaDePagamentoCondicao from '#models/forma_de_pagamento_condicao';
export default class VendaFormaDePagamentoParcela extends BaseModel {
    static table = 'prime_venda_pagamento_a_prazo';
    id;
    idPrime;
    idVenda;
    idVendaFormaDePagamento;
    idFormaDePagamentoCondicao;
    syncPrime;
    installmentValue;
    count;
    tax_percentage;
    installmentDate;
    createdAt;
    updatedAt;
    deletedAt;
    venda;
    vendaFormaDePagamento;
    formaDePagamentoCondicao;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], VendaFormaDePagamentoParcela.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamentoParcela.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamentoParcela.prototype, "idVenda", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamentoParcela.prototype, "idVendaFormaDePagamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], VendaFormaDePagamentoParcela.prototype, "idFormaDePagamentoCondicao", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], VendaFormaDePagamentoParcela.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamentoParcela.prototype, "installmentValue", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaFormaDePagamentoParcela.prototype, "count", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaFormaDePagamentoParcela.prototype, "tax_percentage", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], VendaFormaDePagamentoParcela.prototype, "installmentDate", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], VendaFormaDePagamentoParcela.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], VendaFormaDePagamentoParcela.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], VendaFormaDePagamentoParcela.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Venda, {
        foreignKey: 'idVenda',
    }),
    __metadata("design:type", Object)
], VendaFormaDePagamentoParcela.prototype, "venda", void 0);
__decorate([
    belongsTo(() => VendaFormaDePagamento, {
        foreignKey: 'idVendaFormaDePagamento',
    }),
    __metadata("design:type", Object)
], VendaFormaDePagamentoParcela.prototype, "vendaFormaDePagamento", void 0);
__decorate([
    belongsTo(() => FormaDePagamentoCondicao, {
        foreignKey: 'idFormaDePagamentoCondicao',
    }),
    __metadata("design:type", Object)
], VendaFormaDePagamentoParcela.prototype, "formaDePagamentoCondicao", void 0);
//# sourceMappingURL=venda_pagamento_a_prazo.js.map