var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import ContaBancaria from '#models/conta_bancaria';
export default class Revenda extends BaseModel {
    static table = 'prime_revenda';
    id;
    idPrime;
    idContaBancaria;
    syncPrime;
    nome;
    razaoSocial;
    ie;
    ieIsento;
    ieAguardando;
    im;
    imIsento;
    imAguardando;
    cnpj;
    cnpjAguardando;
    telefone;
    site;
    contatoNome;
    contatoTelefone;
    contatoEmail;
    contatoRg;
    contatoProfissao;
    estadoCivil;
    constituicaoFirma;
    cnae;
    atividadePrincipal;
    createdAt;
    updatedAt;
    deletedAt;
    contaBancaria;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Revenda.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Revenda.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Revenda.prototype, "idContaBancaria", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Revenda.prototype, "syncPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "nome", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "razaoSocial", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "ie", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Revenda.prototype, "ieIsento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Revenda.prototype, "ieAguardando", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "im", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Revenda.prototype, "imIsento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Revenda.prototype, "imAguardando", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "cnpj", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Revenda.prototype, "cnpjAguardando", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "telefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "site", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "contatoNome", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "contatoTelefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "contatoEmail", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "contatoRg", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "contatoProfissao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Revenda.prototype, "estadoCivil", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Revenda.prototype, "constituicaoFirma", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "cnae", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Revenda.prototype, "atividadePrincipal", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Revenda.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Revenda.prototype, "updatedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], Revenda.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => ContaBancaria, {
        foreignKey: 'idContaBancaria',
    }),
    __metadata("design:type", Object)
], Revenda.prototype, "contaBancaria", void 0);
//# sourceMappingURL=revenda.js.map