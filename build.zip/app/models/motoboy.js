var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import Grupo from '#models/grupo';
import Empresa from '#models/empresa';
export default class Motoboy extends BaseModel {
    static table = 'prime_motoboy';
    id;
    id_prime;
    id_grupo;
    id_empresa;
    nome;
    codigo;
    rg;
    cnh;
    telefone;
    email;
    endereco;
    numero;
    complemento;
    bairro;
    cidade;
    uf;
    cep;
    placa;
    ano;
    modelo;
    logradouro;
    sync_prime;
    createdAt;
    updatedAt;
    deletedAt;
    grupo;
    empresa;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Motoboy.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Motoboy.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Motoboy.prototype, "id_grupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Motoboy.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "nome", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "rg", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "cnh", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "telefone", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "email", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "endereco", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "numero", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "complemento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "bairro", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "cidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "uf", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "cep", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "placa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "ano", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "modelo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Motoboy.prototype, "logradouro", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Motoboy.prototype, "sync_prime", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Motoboy.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Motoboy.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Motoboy.prototype, "deletedAt", void 0);
__decorate([
    belongsTo(() => Grupo, {
        foreignKey: 'id_grupo',
    }),
    __metadata("design:type", Object)
], Motoboy.prototype, "grupo", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], Motoboy.prototype, "empresa", void 0);
//# sourceMappingURL=motoboy.js.map