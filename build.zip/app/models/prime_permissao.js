var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, hasMany } from '@adonisjs/lucid/orm';
import PrimePermissaoUsuario from '#models/prime_permissao_usuario';
export default class PrimePermissao extends BaseModel {
    static table = 'prime_permissao';
    id;
    id_prime;
    slug;
    pagina;
    icon;
    index;
    name;
    description;
    por_grupo;
    internalAccess;
    agrupamentoCor;
    createdAt;
    updatedAt;
    deletedAt;
    permissaoUsuario;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimePermissao.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimePermissao.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimePermissao.prototype, "slug", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimePermissao.prototype, "pagina", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimePermissao.prototype, "icon", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimePermissao.prototype, "index", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimePermissao.prototype, "name", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimePermissao.prototype, "description", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimePermissao.prototype, "por_grupo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimePermissao.prototype, "internalAccess", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimePermissao.prototype, "agrupamentoCor", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimePermissao.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimePermissao.prototype, "updatedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimePermissao.prototype, "deletedAt", void 0);
__decorate([
    hasMany(() => PrimePermissaoUsuario, {
        foreignKey: 'id_permissao',
    }),
    __metadata("design:type", Object)
], PrimePermissao.prototype, "permissaoUsuario", void 0);
//# sourceMappingURL=prime_permissao.js.map