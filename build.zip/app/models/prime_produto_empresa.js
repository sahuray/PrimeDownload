var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import Empresa from '#models/empresa';
import PrimeProduto from './prime_produto.js';
export default class PrimeProdutoEmpresa extends BaseModel {
    static table = 'prime_produto_empresa';
    id;
    id_prime;
    id_empresa;
    id_produto;
    id_departamento;
    sell;
    active;
    control_inventory;
    control_number_serie;
    permit_fractionate;
    use_characteristic;
    weight_balance;
    by_kg;
    control_lot_expiration;
    control_serial_number;
    custom_name;
    custom_short_name;
    descrition;
    price_cost_box_cost;
    price_cost_box_quantity;
    price_cost_unit_cost;
    tax_expenses;
    ipi_expenses;
    shipping_expenses;
    other_expenses;
    value_st_extenses;
    real_cost_real_cost_box;
    real_cost_real_cost_unitary;
    real_cost_margin_loss;
    nfe_aliquot_ipi;
    nfe_ipi_framing;
    nfe_aliquot_icms;
    nfe_origin;
    nfe_csosn;
    nfe_taxation;
    nfe_ipi_cst;
    nfe_ipi_control_seal;
    nfe_reduction;
    nfe_tributacao_icms;
    beneficio_fiscal;
    desoneracao_motivo;
    desoneracao_porcentagem;
    nfe_use_cfop;
    uf_origem_combustivel;
    indicador_importacao_combustivel;
    originario_para_uf_porcentagem_combustivel;
    indice_mistura_combustivel;
    nfe_use_reduction;
    nfe_cfop_state;
    nfe_cfop_interstate;
    nfe_cfop_fuel_code_anp;
    nfe_pis_cst;
    nfe_pis_aliquot;
    nfe_cofins_cst;
    nfe_cofins_aliquot;
    ex;
    tipo;
    nfe_cst;
    nfe_pis_base_calculo;
    nfe_pis_bc_quantidade;
    nfe_pis_aliquot_porc;
    nfe_pis_valor;
    nfe_cofins_base_calculo;
    nfe_cofins_bc_quantidade;
    nfe_cofins_aliquot_porc;
    nfe_cofins_valor;
    nfe_base_ipi;
    nfe_enquadramento_ipi;
    nfe_valor_devolvido_ipi;
    nfe_porc_devolvido_ipi;
    nfe_valor_ipi;
    nfe_aliquota_issqn;
    nfe_base_icms;
    nfe_valor_operacao_icms;
    nfe_diferimento_porc_icms;
    nfe_diferimento_icms;
    nfe_valor_icms;
    nfe_issqn_aliquota;
    nfe_issqn_indicador_incentivo;
    nfe_issqn_indicador_exigibilidade;
    nfe_issqn_item_lista_servico;
    sat_nfce_cfop;
    sat_nfce_cfop_exchange;
    sat_nfce_aliquot_icms;
    sat_nfce_origin;
    sat_nfce_csosn;
    sat_nfce_taxation;
    sat_nfce_pis_cst;
    sat_nfce_pis_aliquot;
    sat_nfce_cofins_cst;
    sat_nfce_cofins_aliquot;
    nfse_code_service;
    nfse_code_activity;
    nfse_aliquot;
    sped_item_type;
    sped_accounting_account;
    sped_income_tax_amount;
    sped_genre_item;
    product_composite;
    ncm;
    cest;
    created_at;
    updated_at;
    deleted_at;
    sync_prime;
    Empresa;
    PrimeProduto;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "id_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeProdutoEmpresa.prototype, "id_departamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "sell", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "active", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "control_inventory", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "control_number_serie", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "permit_fractionate", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "use_characteristic", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "weight_balance", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "by_kg", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "control_lot_expiration", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "control_serial_number", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "custom_name", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "custom_short_name", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "descrition", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "price_cost_box_cost", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "price_cost_box_quantity", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "price_cost_unit_cost", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "tax_expenses", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "ipi_expenses", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "shipping_expenses", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "other_expenses", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "value_st_extenses", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "real_cost_real_cost_box", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "real_cost_real_cost_unitary", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "real_cost_margin_loss", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_aliquot_ipi", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_ipi_framing", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_aliquot_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_origin", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_csosn", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_taxation", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_ipi_cst", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_ipi_control_seal", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_reduction", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_tributacao_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "beneficio_fiscal", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "desoneracao_motivo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "desoneracao_porcentagem", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "nfe_use_cfop", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "uf_origem_combustivel", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "indicador_importacao_combustivel", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "originario_para_uf_porcentagem_combustivel", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "indice_mistura_combustivel", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "nfe_use_reduction", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_cfop_state", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_cfop_interstate", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_cfop_fuel_code_anp", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_pis_cst", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_pis_aliquot", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_cofins_cst", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_cofins_aliquot", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "ex", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_cst", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_pis_base_calculo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_pis_bc_quantidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_pis_aliquot_porc", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_pis_valor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_cofins_base_calculo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_cofins_bc_quantidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_cofins_aliquot_porc", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_cofins_valor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_base_ipi", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_enquadramento_ipi", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_valor_devolvido_ipi", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_porc_devolvido_ipi", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_valor_ipi", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_aliquota_issqn", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_base_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_valor_operacao_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_diferimento_porc_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_diferimento_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_valor_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_issqn_aliquota", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfe_issqn_indicador_incentivo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_issqn_indicador_exigibilidade", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfe_issqn_item_lista_servico", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "sat_nfce_cfop", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "sat_nfce_cfop_exchange", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "sat_nfce_aliquot_icms", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "sat_nfce_origin", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "sat_nfce_csosn", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "sat_nfce_taxation", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "sat_nfce_pis_cst", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "sat_nfce_pis_aliquot", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "sat_nfce_cofins_cst", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "sat_nfce_cofins_aliquot", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfse_code_service", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "nfse_code_activity", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "nfse_aliquot", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "sped_item_type", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "sped_accounting_account", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoEmpresa.prototype, "sped_income_tax_amount", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "sped_genre_item", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "product_composite", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "ncm", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoEmpresa.prototype, "cest", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoEmpresa.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoEmpresa.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProdutoEmpresa.prototype, "deleted_at", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoEmpresa.prototype, "sync_prime", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimeProdutoEmpresa.prototype, "Empresa", void 0);
__decorate([
    belongsTo(() => PrimeProduto, {
        foreignKey: 'id_produto',
    }),
    __metadata("design:type", Object)
], PrimeProdutoEmpresa.prototype, "PrimeProduto", void 0);
//# sourceMappingURL=prime_produto_empresa.js.map