var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo, hasMany } from '@adonisjs/lucid/orm';
import PrimeProdutoCategoriaGrupo from '#models/prime_produto_categoria_grupo';
import PrimeProdutoCategoriaLinha from '#models/prime_produto_categoria_linha';
export default class PrimeProdutoCategoriaSubgrupo extends BaseModel {
    static table = 'prime_produto_categoria_subgrupo';
    id;
    id_prime;
    sync_prime;
    name;
    id_produto_categoria_grupo;
    created_at;
    updated_at;
    deleted_at;
    PrimeProdutoCategoriaGrupo;
    PrimeProdutoCategoriaLinha;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProdutoCategoriaSubgrupo.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoCategoriaSubgrupo.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoCategoriaSubgrupo.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoCategoriaSubgrupo.prototype, "name", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoCategoriaSubgrupo.prototype, "id_produto_categoria_grupo", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoCategoriaSubgrupo.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoCategoriaSubgrupo.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProdutoCategoriaSubgrupo.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => PrimeProdutoCategoriaGrupo, {
        foreignKey: 'id_produto_categoria_grupo',
    }),
    __metadata("design:type", Object)
], PrimeProdutoCategoriaSubgrupo.prototype, "PrimeProdutoCategoriaGrupo", void 0);
__decorate([
    hasMany(() => PrimeProdutoCategoriaLinha),
    __metadata("design:type", Object)
], PrimeProdutoCategoriaSubgrupo.prototype, "PrimeProdutoCategoriaLinha", void 0);
//# sourceMappingURL=prime_produto_categoria_subgrupo.js.map