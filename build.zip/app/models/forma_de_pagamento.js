var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column, belongsTo, hasOne } from '@adonisjs/lucid/orm';
import PrimeEmpresa from '#models/empresa';
import PrimeFormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
import PrimeFormaDePagamentoCondicao from '#models/forma_de_pagamento_condicao';
import PrimeBandeira from '#models/bandeira';
import PrimeContaBancaria from '#models/conta_bancaria';
export default class FormaDePagamento extends BaseModel {
    static table = 'prime_forma_de_pagamento';
    id;
    id_prime;
    id_empresa;
    id_forma_de_pagamento_tipo;
    id_forma_de_pagamento_condicao;
    id_bandeira;
    id_conta_bancaria;
    quantidade;
    prazo;
    tarifa;
    description;
    code;
    inativo;
    created_at;
    updated_at;
    deleted_at;
    sync_prime;
    empresa;
    formaDePagamentoTipo;
    formaDePagamentoCondicao;
    bandeira;
    contaBancaria;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], FormaDePagamento.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FormaDePagamento.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FormaDePagamento.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FormaDePagamento.prototype, "id_forma_de_pagamento_tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "id_forma_de_pagamento_condicao", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "id_bandeira", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "id_conta_bancaria", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FormaDePagamento.prototype, "quantidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], FormaDePagamento.prototype, "prazo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], FormaDePagamento.prototype, "tarifa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], FormaDePagamento.prototype, "description", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], FormaDePagamento.prototype, "code", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], FormaDePagamento.prototype, "inativo", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], FormaDePagamento.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], FormaDePagamento.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "deleted_at", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], FormaDePagamento.prototype, "sync_prime", void 0);
__decorate([
    belongsTo(() => PrimeEmpresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "empresa", void 0);
__decorate([
    hasOne(() => PrimeFormaDePagamentoTipo, {
        foreignKey: 'id',
        localKey: 'id_forma_de_pagamento_tipo',
    }),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "formaDePagamentoTipo", void 0);
__decorate([
    belongsTo(() => PrimeFormaDePagamentoCondicao, {
        foreignKey: 'id_forma_de_pagamento_condicao',
    }),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "formaDePagamentoCondicao", void 0);
__decorate([
    belongsTo(() => PrimeBandeira, {
        foreignKey: 'id_bandeira',
    }),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "bandeira", void 0);
__decorate([
    belongsTo(() => PrimeContaBancaria, {
        foreignKey: 'id_conta_bancaria',
    }),
    __metadata("design:type", Object)
], FormaDePagamento.prototype, "contaBancaria", void 0);
//# sourceMappingURL=forma_de_pagamento.js.map