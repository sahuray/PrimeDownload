var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column } from '@adonisjs/lucid/orm';
export default class PrimeProdutoCaracteristica extends BaseModel {
    static table = 'prime_produto_caracteristica';
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeProdutoCaracteristica.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoCaracteristica.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoCaracteristica.prototype, "id_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeProdutoCaracteristica.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoCaracteristica.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoCaracteristica.prototype, "descricao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeProdutoCaracteristica.prototype, "categoria", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeProdutoCaracteristica.prototype, "fixo", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoCaracteristica.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeProdutoCaracteristica.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeProdutoCaracteristica.prototype, "deletedAt", void 0);
//# sourceMappingURL=prime_produto_caracteristica.js.map