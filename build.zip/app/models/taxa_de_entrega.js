var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column } from '@adonisjs/lucid/orm';
export default class TaxasDeEntrega extends BaseModel {
    static table = 'prime_taxa_de_entrega';
    id;
    id_prime;
    valor;
    descricao;
    tempo_previsao;
    grupo_id;
    user_created_id;
    user_updated_id;
    user_created_name;
    user_updated_name;
    codigo;
    empresa_id;
    createdAt;
    updatedAt;
    deleted_at;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], TaxasDeEntrega.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], TaxasDeEntrega.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], TaxasDeEntrega.prototype, "valor", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], TaxasDeEntrega.prototype, "descricao", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], TaxasDeEntrega.prototype, "tempo_previsao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], TaxasDeEntrega.prototype, "grupo_id", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], TaxasDeEntrega.prototype, "user_created_id", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], TaxasDeEntrega.prototype, "user_updated_id", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], TaxasDeEntrega.prototype, "user_created_name", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], TaxasDeEntrega.prototype, "user_updated_name", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], TaxasDeEntrega.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], TaxasDeEntrega.prototype, "empresa_id", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], TaxasDeEntrega.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], TaxasDeEntrega.prototype, "updatedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], TaxasDeEntrega.prototype, "deleted_at", void 0);
//# sourceMappingURL=taxa_de_entrega.js.map