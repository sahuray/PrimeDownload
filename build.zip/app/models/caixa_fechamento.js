var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import CaixaMovimento from '#models/caixa_movimento';
import { BaseModel, column, belongsTo } from '@adonisjs/lucid/orm';
export default class CaixaFechamento extends BaseModel {
    static table = 'caixa_fechamento';
    id;
    id_prime;
    id_caixa_movimento;
    id_forma_de_pagamento_tipo;
    id_usuario;
    sync_prime;
    data_fechamento;
    hora_fechamento;
    tipo_movimento;
    historico;
    valor_sistema;
    valor_informado;
    createdAt;
    updatedAt;
    deleted_at;
    caixaMovimento;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], CaixaFechamento.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaFechamento.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaFechamento.prototype, "id_caixa_movimento", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaFechamento.prototype, "id_forma_de_pagamento_tipo", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaFechamento.prototype, "id_usuario", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaFechamento.prototype, "sync_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CaixaFechamento.prototype, "data_fechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], CaixaFechamento.prototype, "hora_fechamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], CaixaFechamento.prototype, "tipo_movimento", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], CaixaFechamento.prototype, "historico", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaFechamento.prototype, "valor_sistema", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], CaixaFechamento.prototype, "valor_informado", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], CaixaFechamento.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], CaixaFechamento.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], CaixaFechamento.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => CaixaMovimento, {
        foreignKey: 'idcaixamovimento',
    }),
    __metadata("design:type", Object)
], CaixaFechamento.prototype, "caixaMovimento", void 0);
//# sourceMappingURL=caixa_fechamento.js.map