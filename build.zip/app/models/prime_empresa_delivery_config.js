var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, belongsTo, column } from '@adonisjs/lucid/orm';
import Empresa from '#models/empresa';
export default class PrimeEmpresaDeliveryConfig extends BaseModel {
    static table = 'prime_empresa_delivery_config';
    id;
    id_prime;
    id_empresa;
    id_produto_vinculado;
    utiliza_delivery;
    trazer_ultima_observacao_pedido;
    confirmar_impressao_caminho_entrega;
    alterar_valor_produto;
    trazer_endereco_delivery_cupom_venda;
    confirmacao_geral_delivery_pedidos_aplicativo;
    utiliza_ifood;
    utiliza_pedido_whatsapp;
    utiliza_pedido_anota_ai;
    impressao_por_departamento;
    epadoca;
    ifood;
    app_delivery;
    multi_pedidos;
    anota_ai;
    divisao_de_pizza_maior_valor;
    tempo_medio;
    taxa_ao_produto;
    valor_utilizado_na_venda;
    label_produto_vinculado;
    created_at;
    updated_at;
    deleted_at;
    company;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], PrimeEmpresaDeliveryConfig.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeEmpresaDeliveryConfig.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeEmpresaDeliveryConfig.prototype, "id_empresa", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], PrimeEmpresaDeliveryConfig.prototype, "id_produto_vinculado", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "utiliza_delivery", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "trazer_ultima_observacao_pedido", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "confirmar_impressao_caminho_entrega", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "alterar_valor_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "trazer_endereco_delivery_cupom_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "confirmacao_geral_delivery_pedidos_aplicativo", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "utiliza_ifood", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "utiliza_pedido_whatsapp", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "utiliza_pedido_anota_ai", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "impressao_por_departamento", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "epadoca", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "ifood", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "app_delivery", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "multi_pedidos", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "anota_ai", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], PrimeEmpresaDeliveryConfig.prototype, "divisao_de_pizza_maior_valor", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], PrimeEmpresaDeliveryConfig.prototype, "tempo_medio", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeEmpresaDeliveryConfig.prototype, "taxa_ao_produto", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeEmpresaDeliveryConfig.prototype, "valor_utilizado_na_venda", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], PrimeEmpresaDeliveryConfig.prototype, "label_produto_vinculado", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], PrimeEmpresaDeliveryConfig.prototype, "created_at", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], PrimeEmpresaDeliveryConfig.prototype, "updated_at", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], PrimeEmpresaDeliveryConfig.prototype, "deleted_at", void 0);
__decorate([
    belongsTo(() => Empresa, {
        foreignKey: 'id_empresa',
    }),
    __metadata("design:type", Object)
], PrimeEmpresaDeliveryConfig.prototype, "company", void 0);
//# sourceMappingURL=prime_empresa_delivery_config.js.map