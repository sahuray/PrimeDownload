var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { DateTime } from 'luxon';
import { BaseModel, column } from '@adonisjs/lucid/orm';
export default class Banco extends BaseModel {
    static table = 'prime_banco';
    id;
    id_prime;
    codigo;
    nome;
    createdAt;
    updatedAt;
    deletedAt;
    homologado;
    sync_prime;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], Banco.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], Banco.prototype, "id_prime", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Banco.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], Banco.prototype, "nome", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], Banco.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], Banco.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], Banco.prototype, "deletedAt", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Banco.prototype, "homologado", void 0);
__decorate([
    column(),
    __metadata("design:type", Boolean)
], Banco.prototype, "sync_prime", void 0);
//# sourceMappingURL=banco.js.map