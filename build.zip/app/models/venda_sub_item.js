var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
import { BaseModel, column, hasMany, belongsTo } from '@adonisjs/lucid/orm';
import { DateTime } from 'luxon';
import VendaItemCaracteristica from '#models/venda_item_caracteristica';
import PrimeProduto from '#models/prime_produto';
export default class VendaSubItem extends BaseModel {
    static table = 'prime_venda_sub_item';
    caracteristicas;
    produto;
}
__decorate([
    column({ isPrimary: true }),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "id", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "idPrime", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "idVendaItem", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "idProduto", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "idVenda", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaSubItem.prototype, "status", void 0);
__decorate([
    column(),
    __metadata("design:type", String)
], VendaSubItem.prototype, "descricao", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "comissaoPorcentagem", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "quantidade", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "valorUnitario", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "valorTotal", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "valorDesconto", void 0);
__decorate([
    column(),
    __metadata("design:type", Number)
], VendaSubItem.prototype, "codigo", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "ncm", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "cfop", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "csosn", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "aliquotaIcms", void 0);
__decorate([
    column(),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "observacao", void 0);
__decorate([
    column.dateTime({ autoCreate: true }),
    __metadata("design:type", DateTime)
], VendaSubItem.prototype, "createdAt", void 0);
__decorate([
    column.dateTime({ autoCreate: true, autoUpdate: true }),
    __metadata("design:type", DateTime)
], VendaSubItem.prototype, "updatedAt", void 0);
__decorate([
    column.dateTime(),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "deletedAt", void 0);
__decorate([
    hasMany(() => VendaItemCaracteristica, {
        foreignKey: 'id_venda_sub_item',
    }),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "caracteristicas", void 0);
__decorate([
    belongsTo(() => PrimeProduto, {
        foreignKey: 'idProduto',
    }),
    __metadata("design:type", Object)
], VendaSubItem.prototype, "produto", void 0);
//# sourceMappingURL=venda_sub_item.js.map