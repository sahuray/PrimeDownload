import OperacaoMovimentoTipo from '#models/operacao_movimento_tipo';
import Venda from '#models/venda';
import OperacaoMovimento from '#models/operacao_movimento';
import OperacaoMovimentoItem from '#models/operacao_movimento_item';
import PrimeProdutoEstoque from '#models/prime_produto_estoque';
import PrimeVendaControleEstoque from '#models/prime_venda_controle_estoque';
import VendaCliente from '#models/venda_cliente';
import VendaFormaDePagamento from '#models/venda_forma_de_pagamento';
import VendaItem from '#models/venda_item';
import VendaSubItem from '#models/venda_sub_item';
import VendaNfce from '#models/venda_nfce';
import VendaFormaDePagamentoParcela from '#models/venda_pagamento_a_prazo';
import VendaItemCaracteristica from '#models/venda_item_caracteristica';
export default class OperacaoMovimentoController {
    async select({ request, response }) {
        const data = request.all();
        const filter = data.value;
        const typeOperations = await OperacaoMovimentoTipo.query()
            .if(filter, (query) => {
            query.where('descricao', 'ilike', `%${filter}%`).orWhere('tipo', 'ilike', `%${filter}%`);
        })
            .whereNull('deleted_at')
            .select(['id', 'descricao', 'tipo'])
            .limit(10);
        return response.json(typeOperations);
    }
    async create({ request, response }) {
        const body = request.body();
        const idType = body.id_type;
        const idTerminal = body.id_terminal;
        const idUser = body.id_user;
        const observation = body.observation;
        if (!idTerminal) {
            return response.badRequest('TERMINAL NÃO INFORMADO');
        }
        const findTypeOperation = await OperacaoMovimentoTipo.query()
            .where('id', idType)
            .select('tipo')
            .first();
        if (!findTypeOperation) {
            return response.badRequest('TIPO DE OPERAÇÃO MOVIMENTO NÃO ENCONTRADO');
        }
        const findSale = await Venda.query()
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('produto')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            });
        })
            .where('id_terminal', idTerminal)
            .where('status', 'PROVISORIO')
            .where('e_orcamento', false)
            .select(['id', 'status'])
            .first();
        if (!findSale) {
            return response.badRequest('NÃO POSSUI VENDA PROVISORIA NO MOMENTO');
        }
        const saleItems = findSale.vendaItem;
        if (!saleItems || saleItems.length === 0) {
            return response.badRequest('ESTÁ VENDA NÃO POSSUI PRODUTOS VINCULADOS');
        }
        const movementOperation = await OperacaoMovimento.create({
            id_operacao_tipo: idType,
            id_terminal: idTerminal,
            id_usuario: idUser,
            observacao: observation,
        });
        for (const saleItem of saleItems) {
            await OperacaoMovimentoItem.create({
                id_operacao_movimento: movementOperation.id,
                id_produto: saleItem.idProduto,
                desconto_produto: saleItem.totalDescountValue,
                quantidade: saleItem.saledQuantity,
                valor_produto: saleItem.unitaryValue,
            });
            const findInventory = await PrimeProdutoEstoque.query()
                .where('id_produto', saleItem.idProduto)
                .where('main_inventory', true)
                .select('*')
                .first();
            if (findInventory) {
                if (findTypeOperation.tipo === 'entrada') {
                    findInventory.quantity = Number(findInventory.quantity) + Number(saleItem.saledQuantity);
                    await findInventory.save();
                    await PrimeVendaControleEstoque.create({
                        id_estoque: findInventory.id,
                        tipo: 'addition',
                        id_estoque_prime: findInventory.id_prime,
                        quantidade: saleItem.saledQuantity,
                    });
                }
                if (findTypeOperation.tipo === 'saida') {
                    findInventory.quantity = Number(findInventory.quantity) - Number(saleItem.saledQuantity);
                    await findInventory.save();
                    await PrimeVendaControleEstoque.create({
                        id_estoque: findInventory.id,
                        tipo: 'removal',
                        id_estoque_prime: findInventory.id_prime,
                        quantidade: Number(saleItem.saledQuantity),
                    });
                }
            }
        }
        await VendaCliente.query().where('id_venda', findSale.id).delete();
        await VendaNfce.query().where('id_venda', findSale.id).delete();
        await VendaFormaDePagamentoParcela.query().where('id_venda', findSale.id).delete();
        await VendaFormaDePagamento.query().where('id_venda', findSale.id).delete();
        const findSaleSubItems = await VendaSubItem.query().where('id_venda', findSale.id);
        const findSaleItems = await VendaItem.query().where('id_venda', findSale.id);
        if (findSaleSubItems && findSaleSubItems.length > 0) {
            for (const findSaleSubItem of findSaleSubItems) {
                await VendaItemCaracteristica.query()
                    .where('id_venda_sub_item', findSaleSubItem.id)
                    .delete();
            }
            await VendaSubItem.query().where('id_venda', findSale.id).delete();
        }
        if (findSaleItems && findSaleItems.length > 0) {
            for (const findSaleItem of findSaleItems) {
                await VendaItemCaracteristica.query().where('id_venda_item', findSaleItem.id).delete();
            }
            await VendaItem.query().where('id_venda', findSale.id).delete();
        }
        await Venda.query().where('id', findSale.id).delete();
        return response.status(201);
    }
}
//# sourceMappingURL=operacao_movimento_controller.js.map