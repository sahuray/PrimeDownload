import Imagem from '#models/prime_imagem';
export default class ImagemController {
    async selectImage(ctx) {
        const data = ctx.request.all();
        const imagem = await Imagem.query()
            .where('tipo', data.tipo)
            .if(data.id_terminal, (query) => {
            query.where('id_terminal', data.id_terminal);
        })
            .select('*')
            .orderByRaw('CAST(ordem_de_execucao AS INTEGER) DESC')
            .limit(10);
        if (!imagem) {
            return ctx.response.status(404).json({ message: 'Imagem não encontrada' });
        }
        return ctx.response.status(200).json(imagem);
    }
}
//# sourceMappingURL=imagem_controller.js.map