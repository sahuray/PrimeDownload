import Comanda from '#models/comanda';
import VendaItem from '#models/venda_item';
import PrimeEmpresaComandaConfig from '#models/prime_empresa_comanda_config';
import Venda from '#models/venda';
import { DateTime } from 'luxon';
import PrimeProduto from '#models/prime_produto';
import PrimeProdutoUnidade from '#models/prime_produto_unidade';
import FuncionarioUsuario from '#models/funcionario_usuario';
export default class ComandaController {
    async assignItemsComanda(ctx) {
        const { empresaId, comandaId, terminalId } = ctx.request.only([
            'empresaId',
            'comandaId',
            'items',
            'terminalId',
        ]);
        try {
            const config = await PrimeEmpresaComandaConfig.query().where('id_empresa', empresaId).first();
            if (!config) {
                return ctx.response.status(400).json({ message: 'Configuração da empresa não encontrada.' });
            }
            if (config.utiliza_chip_comanda) {
                const comandaExistente = await Comanda.query()
                    .where('id_empresa', empresaId)
                    .where('comanda', comandaId)
                    .whereIn('status', ['ABERTO', 'FECHADO'])
                    .first();
                if (!comandaExistente) {
                    return ctx.response
                        .status(400)
                        .json({ message: 'Comanda não encontrada com o código fornecido.' });
                }
                await this.atualizarVendaItems(comandaExistente.id, terminalId);
                return ctx.response.status(200).json({
                    message: 'Comanda com chip encontrada, itens atualizados.',
                    comanda: comandaExistente,
                });
            }
            else {
                const comandaAberta = await Comanda.query()
                    .where('id_empresa', empresaId)
                    .where('status', 'ABERTO')
                    .where('comanda', comandaId)
                    .first();
                if (!comandaAberta) {
                    const novaComanda = await Comanda.create({
                        id_empresa: empresaId,
                        status: 'ABERTO',
                        comanda: comandaId,
                    });
                    await this.atualizarVendaItems(novaComanda.id, terminalId);
                    return ctx.response
                        .status(201)
                        .json({ message: 'Comanda criada com sucesso!', comanda: novaComanda });
                }
                else {
                    await this.atualizarVendaItems(comandaAberta.id, terminalId);
                    return ctx.response
                        .status(200)
                        .json({ message: 'Comanda já está ABERTA, itens atualizados.' });
                }
            }
        }
        catch (error) {
            console.error('Erro ao criar comanda:', error);
            return ctx.response.status(500).json({ message: 'Erro ao criar comanda' });
        }
    }
    async atualizarVendaItems(idComanda, terminalId) {
        const primeVenda = await Venda.query()
            .where('id_terminal', terminalId)
            .where('status', 'PROVISORIO')
            .first();
        if (primeVenda) {
            const primeVendaItems = await VendaItem.query().where('id_venda', primeVenda.id);
            const dateTime = DateTime.now();
            for (const item of primeVendaItems) {
                item.id_comanda = idComanda;
                item.data_lancamento = dateTime;
                await item.save();
            }
            primeVenda.status = 'REVOGADO';
            await primeVenda.save();
        }
    }
    async bringItemsFromComandaToSale(ctx) {
        const { empresaId, comandaId, terminalId } = ctx.request.only([
            'empresaId',
            'comandaId',
            'terminalId',
        ]);
        try {
            let primeVenda = await Venda.query()
                .where('id_terminal', terminalId)
                .where('status', 'PROVISORIO')
                .first();
            if (!primeVenda) {
                primeVenda = await Venda.create({
                    idTerminal: terminalId,
                    status: 'PROVISORIO',
                });
            }
            const comanda = await Comanda.query()
                .where('id_empresa', empresaId)
                .where('comanda', comandaId)
                .first();
            if (!comanda) {
                return ctx.response.status(400).json({ message: 'Comanda não encontrada.' });
            }
            const itensComanda = await VendaItem.query().where('id_comanda', comanda.id);
            for (const item of itensComanda) {
                const totalValue = item.totalValue;
                const saledQuantity = item.saledQuantity;
                const itemExistente = await VendaItem.query()
                    .where('idProduto', item.idProduto)
                    .where('idVenda', primeVenda.id)
                    .first();
                if (itemExistente) {
                    itemExistente.saledQuantity += saledQuantity;
                    itemExistente.totalValue += totalValue;
                    itemExistente.id_venda_anterior = itemExistente.idVenda;
                    itemExistente.idVenda = primeVenda.id;
                    await itemExistente.save();
                }
                else {
                    await VendaItem.create({
                        idProduto: item.idProduto,
                        saledQuantity: saledQuantity,
                        totalValue: totalValue,
                        listar_na_comanda: false,
                        id_venda_anterior: primeVenda.id,
                        idVenda: primeVenda.id,
                    });
                }
            }
            return ctx.response
                .status(200)
                .json({ message: 'Itens da comanda movidos para a venda com sucesso!', venda: primeVenda });
        }
        catch (error) {
            console.error('Erro ao trazer itens da comanda para a venda:', error);
            return ctx.response
                .status(500)
                .json({ message: 'Erro ao trazer itens da comanda para a venda' });
        }
    }
    async getComandasAbertas(ctx) {
        try {
            const comandas = await Comanda.query().where('status', 'ABERTO').select('*');
            const comandasComTotal = await Promise.all(comandas.map(async (comanda) => {
                const totalValue = await VendaItem.query()
                    .where('id_comanda', comanda.id)
                    .sum('total_value as totalValue');
                return {
                    ...comanda,
                    total_value: totalValue[0]?.totalValue || 0,
                };
            }));
            return ctx.response.json(comandasComTotal);
        }
        catch (error) {
            console.error('Erro ao buscar comandas abertas:', error);
            return ctx.response.status(500).json({ message: 'Erro ao buscar comandas abertas' });
        }
    }
    async getItems(ctx) {
        try {
            const itens = await VendaItem.query().whereNotNull('id_comanda').select('*');
            return ctx.response.json(itens);
        }
        catch (error) {
            console.error('Erro ao buscar itens da comanda:', error);
            return ctx.response.status(500).json({ message: 'Erro interno no servidor' });
        }
    }
    async getItemsComanda(ctx) {
        try {
            const { id } = ctx.params;
            if (!id || Number.isNaN(Number(id))) {
                return ctx.response.status(400).json({
                    message: 'ID da comanda inválido ou não informado',
                });
            }
            const comandaId = Number(id);
            const comanda = await Comanda.find(comandaId);
            if (!comanda) {
                return ctx.response.status(404).json({
                    message: 'Comanda não encontrada',
                });
            }
            const items = await VendaItem.query().where('id_comanda', comandaId).select('*');
            if (items.length === 0) {
                return ctx.response.status(404).json({
                    message: 'Nenhum item encontrado para esta comanda.',
                });
            }
            const itemsWithDetails = await Promise.all(items.map(async (item) => {
                if (!item.idProduto) {
                    console.warn(`Item comanda ${item.id} não possui idProduto definido.`);
                    return item;
                }
                const produto = await PrimeProduto.query().where('id', item.idProduto).first();
                if (produto) {
                    if (!produto.id_unidade_comercial) {
                        console.warn(`Produto ${produto.id} não possui id_unidade_comercial definido.`);
                        return {
                            ...item,
                            sigla: null,
                        };
                    }
                    const unidade = await PrimeProdutoUnidade.query()
                        .where('id', produto.id_unidade_comercial)
                        .first();
                    const venda = await Venda.query().where('id', item.idVenda).first();
                    if (!venda || !venda.idUsuarioCriacao) {
                        return {
                            ...item,
                            produtoId: produto ? produto.id : null,
                            sigla: unidade ? unidade.sigla : null,
                            usuario: null,
                        };
                    }
                    const funcionarioUsuario = await FuncionarioUsuario.query()
                        .where('idfuncionariousuario', venda.idUsuarioCriacao)
                        .first();
                    return {
                        ...item,
                        produtoId: produto ? produto.id : null,
                        sigla: unidade ? unidade.sigla : null,
                        usuario: funcionarioUsuario ? funcionarioUsuario.usuario : null,
                    };
                }
                return item;
            }));
            return ctx.response.json(itemsWithDetails);
        }
        catch (error) {
            console.error('Erro ao buscar itens da comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao buscar itens da comanda',
            });
        }
    }
    async getTotalValueComanda(ctx) {
        try {
            const { comandaId } = ctx.params;
            const items = await VendaItem.query().where('id_comanda', comandaId).select('total_value');
            const totalValue = items.reduce((total, item) => total + item.totalValue, 0);
            return ctx.response.json({ totalValue });
        }
        catch (error) {
            console.error('Erro ao calcular o total da comanda:', error);
            return ctx.response.status(500).json({ message: 'Erro ao calcular o total da comanda' });
        }
    }
    async getComanda(ctx) {
        const { comanda } = ctx.params;
        const comandaData = await Comanda.query().where('comanda', comanda).first();
        if (comandaData) {
            return ctx.response.json(comandaData);
        }
        else {
            return ctx.response.status(404).json({ message: 'Comanda não encontrada' });
        }
    }
    async transferirItemComanda(ctx) {
        try {
            const { items, comandaDestino, empresaId, quantidade } = ctx.request.only([
                'items',
                'comandaDestino',
                'empresaId',
                'quantidade',
            ]);
            if (!Array.isArray(items) || items.length === 0) {
                return ctx.response.status(400).json({
                    message: 'É necessário enviar ao menos um item para transferência',
                });
            }
            const config = await PrimeEmpresaComandaConfig.query().where('id_empresa', empresaId).first();
            if (!config) {
                return ctx.response.status(400).json({
                    message: 'Configuração da empresa não encontrada.',
                });
            }
            let comanda;
            if (config.utiliza_chip_comanda) {
                comanda = await Comanda.query().where('comanda', comandaDestino).first();
                if (!comanda) {
                    return ctx.response.status(404).json({
                        message: 'Comanda de destino não encontrada. Não é possível criar nova comanda quando usa chip.',
                    });
                }
            }
            else {
                comanda = await Comanda.query().where('comanda', comandaDestino).first();
                if (!comanda) {
                    comanda = await Comanda.create({
                        id_empresa: empresaId,
                        status: 'ABERTO',
                        comanda: comandaDestino,
                    });
                }
            }
            const itemComandaDestino = await VendaItem.query()
                .where('id_comanda', comanda.id)
                .orderBy('id', 'desc')
                .first();
            let idVendaDestino;
            if (!itemComandaDestino) {
                const novaVenda = await Venda.create({
                    status: 'ABERTO',
                    idEmpresa: empresaId,
                });
                idVendaDestino = novaVenda.id;
            }
            else {
                idVendaDestino = itemComandaDestino.idVenda;
            }
            const transferredItems = [];
            for (const idItem of items) {
                const itemOriginal = await VendaItem.findOrFail(idItem);
                if (items.length === 1 && quantidade) {
                    const quantidadeTransfer = Number(quantidade);
                    if (quantidadeTransfer > itemOriginal.saledQuantity) {
                        return ctx.response.status(400).json({
                            message: 'Quantidade informada maior que a disponível',
                        });
                    }
                    const remainingQuantity = itemOriginal.saledQuantity - quantidadeTransfer;
                    if (remainingQuantity === 0) {
                        itemOriginal.id_venda_anterior = itemOriginal.idVenda;
                        itemOriginal.idVenda = idVendaDestino;
                        itemOriginal.id_comanda = comanda.id;
                        await itemOriginal.save();
                        transferredItems.push(itemOriginal);
                        continue;
                    }
                    const itemDestino = await VendaItem.create({
                        idProduto: itemOriginal.idProduto,
                        saledQuantity: quantidadeTransfer,
                        unitaryValue: itemOriginal.unitaryValue,
                        totalValue: itemOriginal.unitaryValue * quantidadeTransfer,
                        id_comanda: comanda.id,
                        idVenda: idVendaDestino,
                        data_lancamento: DateTime.now(),
                        productDescription: itemOriginal.productDescription,
                        listar_na_comanda: itemOriginal.listar_na_comanda,
                    });
                    itemOriginal.saledQuantity = remainingQuantity;
                    itemOriginal.totalValue = itemOriginal.unitaryValue * remainingQuantity;
                    await itemOriginal.save();
                    transferredItems.push(itemDestino);
                    continue;
                }
                itemOriginal.id_venda_anterior = itemOriginal.idVenda;
                itemOriginal.idVenda = idVendaDestino;
                itemOriginal.id_comanda = comanda.id;
                await itemOriginal.save();
                transferredItems.push(itemOriginal);
            }
            return ctx.response.json({
                message: `Itens transferidos para comanda ${comandaDestino}`,
                items: transferredItems,
            });
        }
        catch (error) {
            console.error('Erro ao transferir item:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao realizar transferência do item',
            });
        }
    }
    async updateComandaStatus(ctx) {
        try {
            const { id } = ctx.params;
            const { status } = ctx.request.only(['status']);
            if (!['ABERTO', 'FECHADO'].includes(status)) {
                return ctx.response.status(400).json({
                    message: 'Status inválido. Use ABERTO ou FECHADO',
                });
            }
            const comanda = await Comanda.findOrFail(id);
            comanda.status = status;
            await comanda.save();
            return ctx.response.json({
                message: `Status da comanda atualizado para ${status}`,
                comanda,
            });
        }
        catch (error) {
            console.error('Erro ao atualizar status da comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao atualizar status da comanda',
            });
        }
    }
}
//# sourceMappingURL=comanda_controller.js.map