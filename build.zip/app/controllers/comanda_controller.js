import Comanda from '#models/comanda';
import VendaItem from '#models/venda_item';
import PrimeEmpresaComandaConfig from '#models/prime_empresa_comanda_config';
import Venda from '#models/venda';
import { DateTime } from 'luxon';
import PrimeProduto from '#models/prime_produto';
import PrimeProdutoUnidade from '#models/prime_produto_unidade';
import FuncionarioUsuario from '#models/funcionario_usuario';
import VendaItemCaracteristica from '#models/venda_item_caracteristica';
import VendaSubItem from '#models/venda_sub_item';
import CloseComandas from '#models/comandas_fechadas';
import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
import Terminal from '#models/terminal';
import PrimePermissao from '#models/prime_permissao';
import PrimePermissaoUsuario from '#models/prime_permissao_usuario';
export default class ComandaController {
    async checkComandaPermission(ctx) {
        try {
            const { userId, empresaId, grupoId, terminalId } = ctx.request.only([
                'userId',
                'empresaId',
                'grupoId',
                'terminalId',
            ]);
            if (!userId || !empresaId) {
                return ctx.response.status(200).json({
                    message: 'ID do usuário e ID da empresa são obrigatórios',
                    success: false,
                });
            }
            const permissao = await PrimePermissao.query().where('slug', 'index_command_launch').first();
            if (!permissao) {
                return ctx.response.status(200).json({
                    message: 'Permissão index_command_launch não encontrada',
                    success: false,
                });
            }
            let query = PrimePermissaoUsuario.query()
                .where('id_permissao', permissao.id)
                .where('id_usuario', userId)
                .where('id_empresa', empresaId);
            if (grupoId) {
                query = query.where('id_grupo', grupoId);
            }
            const hasPermission = await query.first();
            if (!hasPermission) {
                return ctx.response.status(200).json({
                    message: 'Usuário não possui permissão para acessar a comanda',
                    success: false,
                    params: { userId, empresaId, grupoId, terminalId },
                });
            }
            return ctx.response.status(200).json({
                message: 'Usuário possui permissão para acessar a comanda',
                success: true,
            });
        }
        catch (error) {
            console.error('Erro ao verificar permissão de comanda:', error);
            return ctx.response.status(200).json({
                message: 'Erro ao verificar permissão de comanda',
                error: error instanceof Error ? error.message : 'Erro desconhecido',
                success: false,
            });
        }
    }
    async assignItemsComanda(ctx) {
        try {
            const { empresaId, comandaId, terminalId, observacao } = ctx.request.only([
                'empresaId',
                'comandaId',
                'items',
                'terminalId',
                'observacao',
            ]);
            const config = await PrimeEmpresaComandaConfig.query().where('id_empresa', empresaId).first();
            if (!config) {
                return ctx.response.status(400).json({
                    message: 'Configuração da empresa não encontrada.',
                });
            }
            let comandaToUse = await Comanda.query()
                .where('id_empresa', empresaId)
                .where('comanda', comandaId)
                .whereIn('status', ['ABERTO', 'FECHADO'])
                .first();
            if (!comandaToUse) {
                if (config.utiliza_chip_comanda) {
                    return ctx.response.status(400).json({
                        message: 'Comanda não encontrada com o código fornecido.',
                    });
                }
                else {
                    comandaToUse = await Comanda.create({
                        id_empresa: empresaId,
                        status: 'ABERTO',
                        comanda: comandaId,
                        dataLancamento: DateTime.now(),
                        observacao: observacao,
                    });
                }
            }
            else if (comandaToUse.status === 'FECHADO') {
                comandaToUse.status = 'ABERTO';
                comandaToUse.dataLancamento = DateTime.now();
                if (observacao !== undefined && observacao !== null && observacao !== '') {
                    comandaToUse.observacao = observacao;
                }
                await comandaToUse.save();
            }
            else {
                comandaToUse.dataLancamento = DateTime.now();
                if (observacao !== undefined && observacao !== null && observacao !== '') {
                    comandaToUse.observacao = observacao;
                }
                await comandaToUse.save();
            }
            await VendaItem.query()
                .whereNotNull('id_comanda')
                .where((query) => {
                query.where('taxaDeServico', true).orWhere('couvert', true);
            })
                .delete();
            await this.atualizarVendaItems(comandaToUse.id, terminalId);
            return ctx.response.status(200).json({
                message: 'Itens atualizados na comanda com sucesso.',
                comanda: comandaToUse,
            });
        }
        catch (error) {
            console.error('Erro ao processar comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao processar comanda',
                error: error.message,
            });
        }
    }
    async atualizarVendaItems(idComanda, terminalId) {
        const primeVenda = await Venda.query()
            .where('id_terminal', terminalId)
            .where('status', 'PROVISORIO')
            .first();
        if (!primeVenda) {
            console.warn('Venda provisória não encontrada para o terminal:', terminalId);
            return;
        }
        const primeVendaItems = await VendaItem.query().where('id_venda', primeVenda.id);
        if (primeVendaItems.length === 0) {
            console.warn('Nenhum item encontrado na venda provisória');
            return;
        }
        await VendaItem.query()
            .where('idVenda', primeVenda.id)
            .where((query) => {
            query.where('taxaDeServico', true).orWhere('couvert', true);
        })
            .delete();
        const dateTime = DateTime.now();
        const existingHiddenItems = await VendaItem.query()
            .where('id_comanda', idComanda)
            .where('listar_na_comanda', false)
            .select('*');
        for (const item of primeVendaItems) {
            try {
                const matchingHiddenItem = existingHiddenItems.find((hiddenItem) => hiddenItem.idProduto === item.idProduto &&
                    hiddenItem.unitaryValue === item.unitaryValue &&
                    hiddenItem.productDescription === item.productDescription);
                if (matchingHiddenItem) {
                    matchingHiddenItem.saledQuantity += Number.parseFloat(item.saledQuantity.toString());
                    matchingHiddenItem.totalValue += Number.parseFloat(item.totalValue.toString());
                    matchingHiddenItem.listar_na_comanda = true;
                    matchingHiddenItem.data_lancamento = dateTime;
                    await matchingHiddenItem.save();
                    await item.delete();
                }
                else {
                    item.id_comanda = idComanda;
                    item.data_lancamento = dateTime;
                    item.listar_na_comanda = true;
                    await item.save();
                }
            }
            catch (error) {
                console.error(`Error processing item #${item.id}:`, error);
            }
        }
        primeVenda.status = 'REVOGADO';
        await primeVenda.save();
    }
    async countUniqueComandas(vendaId) {
        const items = await VendaItem.query()
            .where('idVenda', vendaId)
            .whereNotNull('id_comanda')
            .distinct('id_comanda')
            .select('id_comanda')
            .exec();
        const uniqueComandasIds = new Set(items.map((item) => item.id_comanda));
        return uniqueComandasIds.size;
    }
    async bringItemsFromComandaToSale(ctx) {
        const { empresaId, comandaId, terminalId, useTax, useCouvert } = ctx.request.only([
            'empresaId',
            'comandaId',
            'items',
            'terminalId',
            'useTax',
            'useCouvert',
        ]);
        try {
            if (!comandaId || !terminalId) {
                return ctx.response.status(400).json({
                    message: 'Comanda e terminal são obrigatórios',
                });
            }
            const config = await EmpresaPdvConfig.query().where('id_empresa', empresaId).first();
            const comanda = await Comanda.query()
                .where('id_empresa', empresaId)
                .where('comanda', comandaId)
                .where('status', 'ABERTO')
                .first();
            if (!comanda) {
                return ctx.response.status(400).json({
                    message: 'Comanda não encontrada ou não está aberta',
                });
            }
            const comandaItems = await VendaItem.query().where('id_comanda', comanda.id).select('*');
            if (!comandaItems || comandaItems.length === 0) {
                return ctx.response.status(400).json({
                    message: 'Não há itens para transferir da comanda',
                });
            }
            const totalValue = comandaItems.reduce((sum, item) => sum + Number(item.totalValue || 0), 0);
            let valorTaxaServico = 0;
            let valorCouvertTotal = 0;
            if (useTax && config?.utiliza_taxa) {
                valorTaxaServico = Number(totalValue) * (Number(config.valor_taxa) / 100);
            }
            if (useCouvert && config?.utiliza_couvert) {
                valorCouvertTotal = Number(config.valor_couvert);
            }
            const existingDelivery = await Venda.query()
                .where('status', 'PROVISORIO')
                .where('origem', 'DELIVERY')
                .where('id_terminal', terminalId)
                .first();
            if (existingDelivery) {
                return ctx.response.status(409).json({
                    message: 'Existe uma venda DELIVERY em andamento',
                    hasDelivery: true,
                    deliveryId: existingDelivery.id,
                    comandaId: comandaId,
                });
            }
            let primeVenda = await Venda.query()
                .where('id_terminal', terminalId)
                .where('status', 'PROVISORIO')
                .first();
            console.log(comandaItems[0].idVenda);
            const vendaOriginal = await Venda.findOrFail(comandaItems[0].idVenda);
            if (!primeVenda) {
                primeVenda = await Venda.create({
                    idTerminal: terminalId,
                    idEmpresa: empresaId,
                    status: 'PROVISORIO',
                    valorTaxaServico: valorTaxaServico,
                    valorCouvert: valorCouvertTotal,
                    valorProdutos: totalValue,
                    idGrupo: vendaOriginal.idGrupo,
                    idUsuarioCriacao: vendaOriginal.idUsuarioCriacao,
                    origem: 'COMANDA',
                    cobrar_taxa_servico: useTax && config?.utiliza_taxa,
                    cobrar_taxa_covert: useCouvert && config?.utiliza_couvert,
                });
                if (useTax && config?.utiliza_taxa && config.id_servico_taxa) {
                    await VendaItem.create({
                        idProduto: config.id_servico_taxa,
                        idVenda: primeVenda.id,
                        saledQuantity: 1,
                        unitaryValue: valorTaxaServico,
                        totalValue: valorTaxaServico,
                        productDescription: 'TAXA DE SERVIÇO',
                        data_lancamento: DateTime.now(),
                        listar_na_comanda: true,
                        taxaDeServico: true,
                        syncPrime: false,
                    });
                }
                if (useCouvert && config?.utiliza_couvert && config.id_servico_couvert) {
                    await VendaItem.create({
                        idProduto: config.id_servico_couvert,
                        idVenda: primeVenda.id,
                        saledQuantity: 1,
                        unitaryValue: valorCouvertTotal,
                        totalValue: valorCouvertTotal,
                        productDescription: config.nome_produto_couvert || 'COUVERT',
                        data_lancamento: DateTime.now(),
                        listar_na_comanda: true,
                        couvert: true,
                        syncPrime: false,
                    });
                }
            }
            else {
                let newTaxaServico = 0;
                const newCouvert = Number(primeVenda.valorCouvert || 0) + valorCouvertTotal;
                const newTotal = Number(primeVenda.valorProdutos || 0) + totalValue;
                if (useTax && config?.utiliza_taxa) {
                    newTaxaServico = Number(newTotal) * (Number(config.valor_taxa) / 100);
                }
                await VendaItem.query()
                    .where('idVenda', primeVenda.id)
                    .where('taxaDeServico', true)
                    .delete();
                if (useTax && config?.utiliza_taxa && config.id_servico_taxa) {
                    await VendaItem.create({
                        idProduto: config.id_servico_taxa,
                        idVenda: primeVenda.id,
                        saledQuantity: 1,
                        unitaryValue: newTaxaServico,
                        totalValue: newTaxaServico,
                        productDescription: 'TAXA DE SERVIÇO',
                        data_lancamento: DateTime.now(),
                        listar_na_comanda: true,
                        taxaDeServico: true,
                        syncPrime: false,
                    });
                }
                if (useCouvert && config?.utiliza_couvert && config.id_servico_couvert) {
                    await VendaItem.create({
                        idProduto: config.id_servico_couvert,
                        idVenda: primeVenda.id,
                        saledQuantity: 1,
                        unitaryValue: valorCouvertTotal,
                        totalValue: valorCouvertTotal,
                        productDescription: config.nome_produto_couvert || 'COUVERT',
                        data_lancamento: DateTime.now(),
                        listar_na_comanda: true,
                        couvert: true,
                        syncPrime: false,
                    });
                }
                primeVenda.valorTaxaServico = newTaxaServico;
                primeVenda.valorCouvert = newCouvert;
                primeVenda.valorProdutos = newTotal;
                primeVenda.origem = 'COMANDA';
                primeVenda.cobrar_taxa_servico = useTax && config?.utiliza_taxa;
                primeVenda.cobrar_taxa_covert = useCouvert && config?.utiliza_couvert;
                await primeVenda.save();
            }
            const processedItems = [];
            for (const item of comandaItems) {
                item.id_venda_anterior = item.idVenda;
                item.idVenda = primeVenda.id;
                item.listar_na_comanda = false;
                await item.save();
                processedItems.push(item);
            }
            const uniqueComandasCount = await this.countUniqueComandas(primeVenda.id);
            primeVenda.quantidade_pessoas_covert = uniqueComandasCount;
            await primeVenda.save();
            comanda.status = 'FECHADO';
            comanda.observacao = '';
            await comanda.save();
            return ctx.response.status(200).json({
                message: 'Itens da comanda movidos para a venda com sucesso!',
                venda: primeVenda,
                comanda: comanda,
                items: processedItems,
                taxaServico: valorTaxaServico,
                couvert: valorCouvertTotal,
                total: totalValue,
            });
        }
        catch (error) {
            console.error('Erro ao trazer itens da comanda para a venda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao trazer itens da comanda para a venda',
                error: error.message || 'Unknown error',
            });
        }
    }
    async getComandasAbertas(ctx) {
        try {
            const comandas = await Comanda.query().where('status', 'ABERTO').select('*');
            const comandasComTotal = await Promise.all(comandas.map(async (comanda) => {
                const totalValue = await VendaItem.query()
                    .where('id_comanda', comanda.id)
                    .sum('total_value as totalValue');
                return {
                    ...comanda,
                    total_value: totalValue[0]?.totalValue || 0,
                };
            }));
            return ctx.response.json(comandasComTotal);
        }
        catch (error) {
            console.error('Erro ao buscar comandas abertas:', error);
            return ctx.response.status(500).json({ message: 'Erro ao buscar comandas abertas' });
        }
    }
    async getItems(ctx) {
        try {
            const itens = await VendaItem.query()
                .whereNotNull('id_comanda')
                .where('listar_na_comanda', true)
                .select('*');
            return ctx.response.json(itens);
        }
        catch (error) {
            console.error('Erro ao buscar itens da comanda:', error);
            return ctx.response.status(500).json({ message: 'Erro interno no servidor' });
        }
    }
    async getItemsComanda(ctx) {
        try {
            const { id } = ctx.params;
            if (!id || Number.isNaN(Number(id))) {
                return ctx.response.status(400).json({
                    message: 'ID da comanda inválido ou não informado',
                });
            }
            const comandaId = Number(id);
            const comanda = await Comanda.find(comandaId);
            if (!comanda) {
                return ctx.response.status(404).json({
                    message: 'Comanda não encontrada',
                });
            }
            const items = await VendaItem.query()
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            })
                .preload('comanda')
                .where('id_comanda', comandaId)
                .where('listar_na_comanda', true)
                .select('*');
            if (items.length === 0) {
                return ctx.response.json([]);
            }
            const itemsWithDetails = await Promise.all(items.map(async (item) => {
                if (!item.idProduto) {
                    console.warn(`Item comanda ${item.id} não possui idProduto definido.`);
                    return item;
                }
                const produto = await PrimeProduto.query().where('id', item.idProduto).first();
                if (produto) {
                    if (!produto.id_unidade_comercial) {
                        console.warn(`Produto ${produto.id} não possui id_unidade_comercial definido.`);
                        return {
                            ...item,
                            sigla: null,
                        };
                    }
                    const unidade = await PrimeProdutoUnidade.query()
                        .where('id', produto.id_unidade_comercial)
                        .first();
                    const venda = await Venda.query().where('id', item.idVenda).first();
                    if (!venda || !venda.idUsuarioCriacao) {
                        return {
                            ...item,
                            produtoId: produto ? produto.id : null,
                            sigla: unidade ? unidade.sigla : null,
                            usuario: null,
                        };
                    }
                    const funcionarioUsuario = await FuncionarioUsuario.query()
                        .where('idfuncionariousuario', venda.idUsuarioCriacao)
                        .first();
                    return {
                        ...item,
                        produtoId: produto ? produto.id : null,
                        sigla: unidade ? unidade.sigla : null,
                        usuario: funcionarioUsuario ? funcionarioUsuario.usuario : null,
                    };
                }
                return item;
            }));
            return ctx.response.json(itemsWithDetails);
        }
        catch (error) {
            console.error('Erro ao buscar itens da comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao buscar itens da comanda',
            });
        }
    }
    async getTotalValueComanda(ctx) {
        try {
            const { comandaId } = ctx.params;
            const items = await VendaItem.query().where('id_comanda', comandaId).select('total_value');
            const totalValue = items.reduce((total, item) => total + item.totalValue, 0);
            return ctx.response.json({ totalValue });
        }
        catch (error) {
            console.error('Erro ao calcular o total da comanda:', error);
            return ctx.response.status(500).json({ message: 'Erro ao calcular o total da comanda' });
        }
    }
    async getComanda(ctx) {
        try {
            const { comanda } = ctx.params;
            const { empresaId } = ctx.request.qs();
            if (!comanda || !empresaId) {
                return ctx.response.status(400).json({
                    message: 'Comanda e empresaId são obrigatórios',
                    received: { comanda, empresaId },
                });
            }
            const decodedComanda = decodeURIComponent(comanda);
            let comandaData = await Comanda.query()
                .where('comanda', decodedComanda)
                .where('id_empresa', empresaId)
                .first();
            if (!comandaData) {
                return ctx.response.status(404).json({
                    message: 'Comanda não encontrada',
                    searched: { comanda: decodedComanda, empresaId },
                });
            }
            return ctx.response.json(comandaData);
        }
        catch (error) {
            console.error('Erro ao buscar comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao buscar comanda',
                error: error instanceof Error ? error.message : 'Erro desconhecido',
            });
        }
    }
    async transferirItemComanda(ctx) {
        try {
            const { items, comandaDestino, empresaId, quantidade } = ctx.request.only([
                'items',
                'comandaDestino',
                'empresaId',
                'quantidade',
            ]);
            const config = await PrimeEmpresaComandaConfig.query().where('id_empresa', empresaId).first();
            let comanda;
            if (config?.utiliza_chip_comanda) {
                comanda = await Comanda.query()
                    .where('comanda', comandaDestino)
                    .where('id_empresa', empresaId)
                    .first();
                if (!comanda) {
                    return ctx.response.status(404).json({
                        message: 'Comanda de destino não encontrada. Não é possível criar nova comanda quando usa chip.',
                    });
                }
            }
            else {
                comanda = await Comanda.query()
                    .where('comanda', comandaDestino)
                    .where('id_empresa', empresaId)
                    .first();
                if (!comanda) {
                    comanda = await Comanda.create({
                        id_empresa: empresaId,
                        status: 'ABERTO',
                        comanda: comandaDestino,
                        dataLancamento: DateTime.now(),
                    });
                }
            }
            if (comanda.status === 'FECHADO') {
                comanda.status = 'ABERTO';
                comanda.dataLancamento = DateTime.now();
                await comanda.save();
            }
            const itemOriginal = await VendaItem.findOrFail(items[0]);
            const vendaOriginal = await Venda.findOrFail(itemOriginal.idVenda);
            const novaVenda = await Venda.create({
                origem: 'COMANDA',
                idTerminal: vendaOriginal.idTerminal,
                idEmpresa: empresaId,
                idGrupo: vendaOriginal.idGrupo,
                idUsuarioCriacao: vendaOriginal.idUsuarioCriacao,
                status: 'ABERTO',
                finalizado: false,
                e_orcamento: false,
                syncPrime: false,
                totalValue: 0,
                valorProdutos: 0,
                totalDescountValue: 0,
                observacao: `Venda criada via comanda ${comandaDestino}`,
            });
            const transferredItems = [];
            for (const idItem of items) {
                const currentItem = await VendaItem.findOrFail(idItem);
                const caracteristicas = await VendaItemCaracteristica.query().where('id_venda_item', currentItem.id);
                if (items.length === 1 && quantidade) {
                    const quantidadeTransfer = Number(quantidade);
                    if (quantidadeTransfer > currentItem.saledQuantity) {
                        return ctx.response.status(400);
                    }
                    if (currentItem.saledQuantity === quantidadeTransfer) {
                        currentItem.id_venda_anterior = currentItem.idVenda;
                        currentItem.idVenda = novaVenda.id;
                        currentItem.id_comanda = comanda.id;
                        await currentItem.save();
                        for (const carac of caracteristicas) {
                            await VendaItemCaracteristica.create({
                                id_venda_item: Number(currentItem.id),
                                id_produto_caracteristica: Number(carac.id_produto_caracteristica),
                                codigo: carac.codigo,
                                descricao: carac.descricao,
                                categoria: carac.categoria,
                                fixo: carac.fixo,
                                sync_prime: false,
                            });
                        }
                        transferredItems.push(currentItem);
                        continue;
                    }
                    const itemDestino = await VendaItem.create({
                        idProduto: itemOriginal.idProduto,
                        saledQuantity: quantidadeTransfer,
                        unitaryValue: itemOriginal.unitaryValue,
                        totalValue: itemOriginal.unitaryValue * quantidadeTransfer,
                        id_comanda: comanda.id,
                        idVenda: novaVenda.id,
                        data_lancamento: DateTime.now(),
                        productDescription: itemOriginal.productDescription,
                        listar_na_comanda: true,
                    });
                    for (const carac of caracteristicas) {
                        await VendaItemCaracteristica.create({
                            id_venda_item: Number(itemDestino.id),
                            id_produto_caracteristica: Number(carac.id_produto_caracteristica),
                            codigo: carac.codigo,
                            descricao: carac.descricao,
                            categoria: carac.categoria,
                            fixo: carac.fixo,
                            sync_prime: false,
                        });
                    }
                    const newQuantity = itemOriginal.saledQuantity - quantidadeTransfer;
                    if (newQuantity <= 0) {
                        await VendaItemCaracteristica.query().where('id_venda_item', itemOriginal.id).delete();
                        await itemOriginal.delete();
                    }
                    else {
                        itemOriginal.saledQuantity = newQuantity;
                        itemOriginal.totalValue = itemOriginal.unitaryValue * newQuantity;
                        await itemOriginal.save();
                    }
                    transferredItems.push(itemDestino);
                    continue;
                }
                itemOriginal.id_venda_anterior = itemOriginal.idVenda;
                itemOriginal.idVenda = novaVenda.id;
                itemOriginal.id_comanda = comanda.id;
                await itemOriginal.save();
                transferredItems.push(itemOriginal);
                currentItem.id_venda_anterior = currentItem.idVenda;
                currentItem.idVenda = novaVenda.id;
                currentItem.id_comanda = comanda.id;
                await currentItem.save();
                transferredItems.push(currentItem);
            }
            return ctx.response.json({
                message: `Itens transferidos para comanda ${comandaDestino}`,
                items: transferredItems,
                venda: novaVenda,
            });
        }
        catch (error) {
            console.error('Erro ao transferir item:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao realizar transferência do item',
                error: error.message,
            });
        }
    }
    async updateComandaStatus(ctx) {
        try {
            const { id } = ctx.params;
            const { status } = ctx.request.only(['status']);
            if (!['ABERTO', 'FECHADO'].includes(status)) {
                return ctx.response.status(400).json({
                    message: 'Status inválido. Use ABERTO ou FECHADO',
                });
            }
            const comanda = await Comanda.findOrFail(id);
            comanda.status = status;
            await comanda.save();
            return ctx.response.json({
                message: `Status da comanda atualizado para ${status}`,
                comanda,
            });
        }
        catch (error) {
            console.error('Erro ao atualizar status da comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao atualizar status da comanda',
            });
        }
    }
    async closeComanda(ctx) {
        try {
            const { comandaId, addTax, addCouvert, terminalId } = ctx.request.only([
                'comandaId',
                'addTax',
                'addCouvert',
                'terminalId',
            ]);
            const terminal = await Terminal.query().where('idterminal', terminalId).first();
            if (!terminal || !terminal.id_empresa) {
                console.error('Terminal não encontrado ou sem empresa:', { terminalId });
                return ctx.response.status(404).json({
                    message: 'Terminal não encontrado ou sem empresa associada',
                });
            }
            const config = await EmpresaPdvConfig.query().where('id_empresa', terminal.id_empresa).first();
            const items = await VendaItem.query().where('id_comanda', comandaId);
            if (!items || items.length === 0) {
                return ctx.response.status(404).json({
                    message: 'Nenhum item encontrado para esta comanda',
                });
            }
            let valorTaxaServico = 0;
            let valorCouvertTotal = 0;
            if (addTax && config?.utiliza_taxa) {
                valorTaxaServico = config.valor_taxa;
            }
            if (addCouvert && config?.utiliza_couvert) {
                valorCouvertTotal = config.valor_couvert;
            }
            const existingDelivery = await Venda.query()
                .where('status', 'PROVISORIO')
                .where('origem', 'DELIVERY')
                .where('id_terminal', terminalId)
                .first();
            if (existingDelivery) {
                return ctx.response.status(409).json({
                    message: 'Existe uma venda DELIVERY em andamento',
                    hasDelivery: true,
                    deliveryId: existingDelivery.id,
                    comandaId: comandaId,
                });
            }
            const currentVendaId = items[0].idVenda;
            const existingProvisorio = await Venda.query()
                .where('status', 'PROVISORIO')
                .whereNot('id', currentVendaId)
                .whereNot('origem', 'DELIVERY')
                .first();
            for (const item of items) {
                item.listar_na_comanda = false;
                await item.save();
            }
            let targetVenda;
            if (existingProvisorio) {
                targetVenda = existingProvisorio;
                for (const item of items) {
                    item.id_venda_anterior = item.idVenda;
                    item.idVenda = existingProvisorio.id;
                    await item.save();
                }
            }
            else {
                targetVenda = await Venda.findOrFail(currentVendaId);
                targetVenda.status = 'PROVISORIO';
                targetVenda.origem = 'COMANDA';
                await targetVenda.save();
            }
            targetVenda.valorTaxaServico = valorTaxaServico;
            targetVenda.valorCouvert = valorCouvertTotal;
            await targetVenda.save();
            const comanda = await Comanda.findOrFail(comandaId);
            comanda.status = 'FECHADO';
            comanda.observacao = '';
            await comanda.save();
            if (addTax) {
            }
            if (addCouvert) {
            }
            return ctx.response.json({
                message: 'Comanda fechada com sucesso',
                venda: targetVenda,
                comanda,
            });
        }
        catch (error) {
            console.error('Erro ao fechar comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao fechar comanda:',
            });
        }
    }
    async closeComandas(ctx) {
        try {
            const { comandas, terminalId, idUsuarioCriacao, idEmpresa, usaTaxa, usaCouvert } = ctx.request.only([
                'comandas',
                'terminalId',
                'idUsuarioCriacao',
                'idEmpresa',
                'usaTaxa',
                'usaCouvert',
            ]);
            const config = await EmpresaPdvConfig.query().where('id_empresa', idEmpresa).first();
            let totalValue = 0;
            for (const comandaId of comandas) {
                const items = await VendaItem.query().where('id_comanda', comandaId).select('total_value');
                totalValue = totalValue + items.reduce((sum, item) => sum + Number(item.totalValue), 0);
            }
            let valorTaxaServico = 0;
            let valorCouvertTotal = 0;
            if (usaTaxa && config?.valor_taxa) {
                valorTaxaServico = Number(totalValue) * (Number(config.valor_taxa) / 100);
            }
            if (usaCouvert && config?.valor_couvert) {
                valorCouvertTotal = Number(config.valor_couvert) * Number(comandas.length);
            }
            const existingDelivery = await Venda.query()
                .where('status', 'PROVISORIO')
                .where('origem', 'DELIVERY')
                .where('id_terminal', terminalId)
                .first();
            if (existingDelivery) {
                return ctx.response.status(409).json({
                    message: 'Necessário fechar a venda em andamento',
                    hasDelivery: true,
                    deliveryId: existingDelivery.id,
                    comandas: comandas,
                });
            }
            const existingProvisorio = await Venda.query()
                .where('status', 'PROVISORIO')
                .where('id_terminal', terminalId)
                .whereNot('origem', 'DELIVERY')
                .first();
            let targetVenda = existingProvisorio;
            const firstComandaItems = await VendaItem.query().where('id_comanda', comandas[0]).select('*');
            if (!firstComandaItems?.length) {
                return ctx.response.status(400).json({
                    message: 'Nenhum item encontrado na primeira comanda',
                });
            }
            if (comandas.length > 1 && !existingProvisorio) {
                targetVenda = await Venda.create({
                    status: 'PROVISORIO',
                    idEmpresa,
                    idTerminal: terminalId,
                    idUsuarioCriacao,
                    origem: 'COMANDA',
                    valorTaxaServico: valorTaxaServico || 0,
                    valorCouvert: valorCouvertTotal || 0,
                    valorProdutos: totalValue,
                    cobrar_taxa_servico: usaTaxa && config?.utiliza_taxa,
                    cobrar_taxa_covert: usaCouvert && config?.utiliza_couvert,
                });
                await VendaItem.create({
                    productDescription: 'TAXA DE SERVIÇO',
                    idProduto: config.id_servico_taxa,
                    totalValue: valorTaxaServico || 0,
                    unitaryValue: valorTaxaServico || 0,
                    saledQuantity: 1,
                    id_comanda: comandas[0],
                    idVenda: targetVenda.id,
                    data_lancamento: DateTime.now(),
                    listar_na_comanda: true,
                    taxaDeServico: true,
                    syncPrime: false,
                });
            }
            else if (!targetVenda) {
                targetVenda = await Venda.findOrFail(firstComandaItems[0].idVenda);
                targetVenda.status = 'PROVISORIO';
                targetVenda.origem = 'COMANDA';
                targetVenda.valorTaxaServico = valorTaxaServico || 0;
                targetVenda.valorCouvert = valorCouvertTotal || 0;
                targetVenda.valorProdutos = totalValue;
                await targetVenda.save();
                if (usaTaxa && config?.utiliza_taxa && config.id_servico_taxa) {
                    await VendaItem.create({
                        productDescription: 'TAXA DE SERVIÇO',
                        idProduto: config.id_servico_taxa,
                        totalValue: valorTaxaServico || 0,
                        unitaryValue: valorTaxaServico || 0,
                        saledQuantity: 1,
                        id_comanda: comandas[0],
                        idVenda: targetVenda.id,
                        data_lancamento: DateTime.now(),
                        listar_na_comanda: true,
                        taxaDeServico: true,
                        syncPrime: false,
                    });
                }
            }
            for (const comandaId of comandas) {
                if (!comandaId)
                    continue;
                const items = await VendaItem.query().where('id_comanda', comandaId).select('*');
                if (!items?.length)
                    continue;
                await VendaItem.query().where('id_comanda', comandaId).update({
                    id_venda_anterior: items[0].idVenda,
                    idVenda: targetVenda.id,
                });
                if (usaCouvert && config?.utiliza_couvert && config.id_servico_couvert) {
                    await VendaItem.create({
                        idProduto: config.id_servico_couvert,
                        id_comanda: comandaId,
                        idVenda: targetVenda.id,
                        saledQuantity: 1,
                        unitaryValue: config.valor_couvert,
                        totalValue: config.valor_couvert,
                        productDescription: config.nome_produto_couvert || 'COUVERT',
                        data_lancamento: DateTime.now(),
                        listar_na_comanda: true,
                        couvert: true,
                        syncPrime: false,
                    });
                }
                await Comanda.query().where('id', comandaId).update({
                    status: 'FECHADO',
                    observacao: '',
                });
            }
            if (targetVenda) {
                const uniqueComandasCount = await this.countUniqueComandas(targetVenda.id);
                targetVenda.quantidade_pessoas_covert = uniqueComandasCount;
                await targetVenda.save();
            }
            return ctx.response.json({
                message: `${comandas.length} comanda(s) fechada(s) com sucesso`,
                targetVenda,
            });
        }
        catch (error) {
            console.error('Erro ao fechar comandas:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao fechar comandas',
                error: error.message,
            });
        }
    }
    async deleteItems(ctx) {
        try {
            const { itemIds } = ctx.request.only(['itemIds']);
            if (!itemIds || !Array.isArray(itemIds) || itemIds.length === 0) {
                return ctx.response.status(400).json({
                    message: 'Nenhum item selecionado para exclusão',
                });
            }
            const firstItem = await VendaItem.findOrFail(itemIds[0]);
            const vendaId = firstItem.idVenda;
            const comandaId = firstItem.id_comanda;
            for (const itemId of itemIds) {
                await VendaItemCaracteristica.query().where('id_venda_item', itemId).delete();
                await VendaSubItem.query().where('id_venda_item', itemId).delete();
                await VendaItem.query().where('id', itemId).delete();
            }
            const remainingItems = await VendaItem.query().where('id_venda', vendaId).first();
            if (!remainingItems) {
                await Venda.query().where('id', vendaId).delete();
                if (comandaId) {
                    const remainingComandaItems = await VendaItem.query()
                        .where('id_comanda', comandaId)
                        .first();
                    if (!remainingComandaItems) {
                        const comanda = await Comanda.find(comandaId);
                        if (comanda) {
                            comanda.status = 'FECHADO';
                            comanda.observacao = '';
                            await comanda.save();
                        }
                    }
                }
            }
            return ctx.response.json({
                message: 'Items excluídos com sucesso',
                deletedCount: itemIds.length,
                deletedIds: itemIds,
                vendaDeleted: !remainingItems,
                comandaFechada: !remainingItems && comandaId ? true : false,
            });
        }
        catch (error) {
            console.error('Erro ao excluir items:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao excluir items',
            });
        }
    }
    async getEmpresaComandaConfig(ctx) {
        try {
            const { empresaId } = ctx.request.qs();
            if (!empresaId || Number.isNaN(Number(empresaId))) {
                return ctx.response.status(400).json({
                    message: 'ID da empresa inválido ou não informado',
                });
            }
            try {
                const config = await PrimeEmpresaComandaConfig.query()
                    .where('id_empresa', empresaId)
                    .first();
                if (!config) {
                    return ctx.response.json({
                        id: null,
                        idEmpresa: Number(empresaId),
                        utilizaTaxaDeServico: false,
                        utilizaCouvert: false,
                        utilizaChipComanda: false,
                        percentualTaxaServico: 0,
                        createdAt: null,
                        updatedAt: null,
                    });
                }
                return ctx.response.json(config);
            }
            catch (dbError) {
                console.error('Erro específico no banco de dados:', dbError);
                return ctx.response.json({
                    id: null,
                    idEmpresa: Number(empresaId),
                    utilizaTaxaDeServico: false,
                    utilizaCouvert: false,
                    utilizaChipComanda: false,
                    percentualTaxaServico: 0,
                    createdAt: null,
                    updatedAt: null,
                });
            }
        }
        catch (error) {
            console.error('Erro detalhado ao buscar configuração de comanda:', error);
            if (error instanceof Error) {
                console.error('Stack trace:', error.stack);
            }
            return ctx.response.status(500).json({
                message: 'Erro ao buscar configuração de comanda',
                error: error instanceof Error ? error.message : 'Unknown error',
                success: false,
            });
        }
    }
    async getComandasFechadasPorData(ctx) {
        try {
            const { data } = ctx.request.qs();
            if (!data) {
                return ctx.response.status(400).json({
                    message: 'Data é obrigatória',
                });
            }
            const startDate = DateTime.fromISO(`${data}T00:00:00`);
            const endDate = DateTime.fromISO(`${data}T23:59:59`);
            if (!startDate.isValid || !endDate.isValid) {
                return ctx.response.status(400).json({
                    message: 'Formato de data inválido. Use o formato YYYY-MM-DD',
                });
            }
            const registros = await CloseComandas.query()
                .whereBetween('created_at', [startDate.toSQL(), endDate.toSQL()])
                .select('*');
            const count = registros.length;
            return ctx.response.json({
                count,
                registros,
                period: {
                    start: startDate.toISO(),
                    end: endDate.toISO(),
                },
            });
        }
        catch (error) {
            console.error('Erro ao buscar comandas fechadas:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao buscar comandas fechadas',
                error: error.message,
            });
        }
    }
    async registerClosedComandas(ctx) {
        try {
            const { comandasIds, vendaId } = ctx.request.body();
            if (!Array.isArray(comandasIds) || !vendaId) {
                return ctx.response.status(400).json({
                    message: 'Dados obrigatórios: coeemandasIds (array) e vendaId',
                    received: ctx.request.body(),
                });
            }
            const venda = await Venda.findOrFail(vendaId);
            const registros = [];
            for (const comandaId of comandasIds) {
                try {
                    const comanda = await Comanda.query().where('id', comandaId).first();
                    if (!comanda) {
                        console.warn(`Comanda ${comandaId} não encontrada`);
                        continue;
                    }
                    const items = await VendaItem.query().where('id_comanda', comandaId).select('total_value');
                    const totalValue = items.reduce((total, item) => total + Number(item.totalValue), 0);
                    const registro = await CloseComandas.create({
                        id_comanda: comandaId,
                        id_venda: vendaId,
                        numero_comanda: comanda.comanda,
                        valor_total: totalValue,
                        valor_taxa_servico: venda.valorTaxaServico || 0,
                        valor_couvert: venda.valorCouvert || 0,
                        id_empresa: comanda.id_empresa,
                    });
                    registros.push(registro);
                    await Comanda.query().where('id', comandaId).update({
                        status: 'FECHADO',
                        observacao: '',
                    });
                }
                catch (err) {
                    console.error(`Erro ao processar comanda ${comandaId}:`, err);
                }
            }
            return ctx.response.json({
                success: true,
                message: `${registros.length} comandas registradas com sucesso`,
                registros: registros.map((r) => r.toJSON()),
            });
        }
        catch (error) {
            console.error('Erro ao registrar comandas:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao registrar comandas',
                error: error instanceof Error ? error.message : 'Erro desconhecido',
            });
        }
    }
    async getPdvConfig(ctx) {
        try {
            const { idEmpresa } = ctx.params;
            if (!idEmpresa || Number.isNaN(Number(idEmpresa))) {
                return ctx.response.status(400).json({
                    message: 'ID da empresa inválido ou não informado',
                });
            }
            const config = await EmpresaPdvConfig.query().where('id_empresa', idEmpresa).first();
            if (!config) {
                return ctx.response.status(404).json({
                    message: 'Configuração PDV não encontrada para esta empresa',
                    idEmpresa,
                });
            }
            return ctx.response.json({
                id: config.id,
                id_empresa: config.id_empresa,
                utiliza_taxa: config.utiliza_taxa,
                utiliza_couvert: config.utiliza_couvert,
                valor_taxa: config.valor_taxa,
                valor_couvert: config.valor_couvert,
                nome_produto_taxa: config.nome_produto_taxa,
                nome_produto_couvert: config.nome_produto_couvert,
            });
        }
        catch (error) {
            console.error('Erro ao buscar configuração PDV:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao buscar configuração PDV',
                error: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    }
    async getVendaByComanda(ctx) {
        try {
            const { comandaId } = ctx.params;
            if (!comandaId) {
                return ctx.response.status(400).json({
                    message: 'ID da comanda é obrigatório',
                });
            }
            let items = await VendaItem.query()
                .where('id_comanda', comandaId)
                .where('listar_na_comanda', true)
                .select('*')
                .first();
            if (!items) {
                items = await VendaItem.query().where('id_comanda', comandaId).select('*').first();
            }
            if (!items) {
                return ctx.response.json(null);
            }
            const venda = await Venda.query()
                .where('id', items.idVenda)
                .preload('vendaItem', (subQuery) => {
                subQuery
                    .preload('caracteristicas')
                    .preload('subItens', (subQuerySubItem) => {
                    subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                        subQueryProduct.preload('ProdutoEmpresa');
                    });
                })
                    .preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('vendaFormaDePagamento', (subQuery) => {
                subQuery
                    .preload('vendaFormaDePagamentoParcela')
                    .preload('formaDePagamento', (subPayMethod) => {
                    subPayMethod
                        .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                        subQueryPayMethodCondition.select(['id', 'nome']);
                    })
                        .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                        subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                    })
                        .preload('bandeira', (subQueryFlag) => {
                        subQueryFlag.select(['id', 'nome']);
                    })
                        .preload('contaBancaria', (subQueryAccountBank) => {
                        subQueryAccountBank.select(['id']);
                    });
                });
            })
                .preload('vendedor')
                .preload('UsuarioCriacao')
                .preload('empresa', (subQueryCompany) => {
                subQueryCompany.preload('enderecos', (subQueryAddress) => {
                    subQueryAddress.select('*').first();
                });
            })
                .select('*')
                .first();
            if (!venda) {
                return ctx.response.json(null);
            }
            return ctx.response.json(venda);
        }
        catch (error) {
            console.error('Erro ao buscar venda da comanda:', error);
            return ctx.response.status(500).json({
                message: 'Erro ao buscar venda da comanda',
                error: error instanceof Error ? error.message : 'Unknown error',
            });
        }
    }
}
//# sourceMappingURL=comanda_controller.js.map