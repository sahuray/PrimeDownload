import { DateTime } from 'luxon';
import hash from '@adonisjs/core/services/hash';
import Venda from '#models/venda';
import VendaItem from '#models/venda_item';
import PrimeProduto from '#models/prime_produto';
import PrimeProdutoEstoque from '#models/prime_produto_estoque';
import VendaCliente from '#models/venda_cliente';
import Empresa from '#models/empresa';
import Endereco from '#models/endereco';
import Contato from '#models/contato';
import Mesa from '#models/prime_mesa';
import VendaFormaDePagamento from '#models/venda_forma_de_pagamento';
import VendaFormaDePagamentoParcela from '#models/venda_pagamento_a_prazo';
import PrimeVendaControleEstoque from '#models/prime_venda_controle_estoque';
import Funcionario from '#models/funcionario';
import FuncionarioUsuario from '#models/funcionario_usuario';
import VendaSubItem from '#models/venda_sub_item';
import VendaItemCaracteristica from '#models/venda_item_caracteristica';
import VendaNfce from '#models/venda_nfce';
import PrimeProdutoComposto from '#models/prime_produto_composto';
import PrimeProdutoEmpresa from '#models/prime_produto_empresa';
import Terminal from '#models/terminal';
import fs from 'node:fs';
import path from 'node:path';
import Comanda from '#models/comanda';
import { writeFile, readFile } from 'node:fs/promises';
import SequenceController from './sequence_controller.js';
import CaixaFechamento from '#models/caixa_fechamento';
import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
import CaixaMovimento from '#models/caixa_movimento';
import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
import PrimeClienteBloqueado from '#models/prime_cliente_bloqueado';
export default class VendaPdvController {
    async finishSale(ctx) {
        const params = ctx.params;
        const idSale = params.id_sale;
        const idMovementCashDesk = params.id_cash_movement_desk;
        if (idSale) {
            const findSale = await Venda.query().where('id', idSale).first();
            if (!findSale) {
                return ctx.response.badRequest('VENDA NÃO ENCONTRADA');
            }
            const blockedResponse = await this.verifyBlockedCustomers(idSale, ctx);
            if (blockedResponse) {
                return;
            }
            if (findSale.origem === 'COMANDA') {
                await VendaItem.query()
                    .where('id_venda', idSale)
                    .whereNotNull('id_comanda')
                    .update({ listar_na_comanda: false });
            }
            if (idMovementCashDesk) {
                findSale.idCaixaMovimento = idMovementCashDesk;
            }
            const valueAddition = Number(findSale.valorTaxaDelivery) +
                Number(findSale.valorTaxaServico) +
                Number(findSale.valorCouvert);
            const valueDiscount = Number(findSale.totalDescountValue);
            const valueProducts = Number(findSale.valorProdutos);
            findSale.totalValue = valueProducts - valueDiscount + valueAddition;
            if (findSale.idUsuarioCriacao) {
                const user = await FuncionarioUsuario.query()
                    .preload('funcionario')
                    .where('idfuncionariousuario', findSale.idUsuarioCriacao)
                    .first();
                if (user.funcionario.idfuncionario) {
                    findSale.idVendedor = user.funcionario.idfuncionario;
                }
            }
            await findSale.save();
            const findProducts = await VendaItem.query()
                .where('id_venda', idSale)
                .where('taxa_de_entrega', false)
                .preload('produto');
            if (findProducts && findProducts.length > 0) {
                for (const product of findProducts) {
                    const findInventory = await PrimeProdutoEstoque.query()
                        .where('id_produto', product.idProduto)
                        .where('main_inventory', true)
                        .select('*')
                        .first();
                    if (findInventory) {
                        findInventory.quantity -= product.saledQuantity;
                        await findInventory.save();
                        await PrimeVendaControleEstoque.create({
                            id_estoque: findInventory.id,
                            tipo: 'removal',
                            id_estoque_prime: findInventory.id_prime,
                            quantidade: product.saledQuantity,
                        });
                    }
                }
            }
            if (findProducts && findProducts.length > 0) {
                for (const product of findProducts) {
                    const productsComposites = await PrimeProdutoComposto.query()
                        .where('id_produto', product.idProduto)
                        .where('id_empresa', findSale.idEmpresa)
                        .whereNull('deleted_at')
                        .select('*');
                    if (productsComposites && productsComposites.length > 0) {
                        for (const productComposite of productsComposites) {
                            const findInventoryComposite = await PrimeProdutoEstoque.query()
                                .where('id_empresa', productComposite.id_empresa)
                                .where('id_produto', productComposite.id_detalhe)
                                .where('main_inventory', true)
                                .whereNull('deleted_at')
                                .select('*')
                                .first();
                            const findProductCompanyComposite = await PrimeProdutoEmpresa.query()
                                .where('id_empresa', productComposite.id_empresa)
                                .where('id_produto', productComposite.id_detalhe)
                                .whereNull('deleted_at')
                                .select('*')
                                .first();
                            let amountInventory = 0;
                            const amountProdComposite = Number(productComposite.quantity) * Number(product.saledQuantity);
                            if (findInventoryComposite) {
                                amountInventory =
                                    Number(findInventoryComposite.quantity) - Number(amountProdComposite);
                                findInventoryComposite.quantity =
                                    amountInventory - Number(productComposite.perda_real);
                                await PrimeVendaControleEstoque.create({
                                    id_estoque: findInventoryComposite.id,
                                    tipo: 'removal',
                                    id_estoque_prime: findInventoryComposite.id_prime,
                                    quantidade: amountProdComposite - Number(productComposite.perda_real),
                                });
                                findInventoryComposite.save();
                            }
                            if (findProductCompanyComposite) {
                                const remainder = Number(amountInventory) -
                                    (Number(amountProdComposite) +
                                        Number(amountProdComposite) *
                                            (Number(findProductCompanyComposite.real_cost_margin_loss) / 100));
                                productComposite.estoque = amountInventory;
                                productComposite.restante = Number(remainder.toFixed(4));
                                await productComposite.save();
                            }
                        }
                    }
                }
            }
            findSale.prestarConta = Number(findSale.valorTroco) + Number(findSale.totalValue);
            if (findSale.origem === 'DELIVERY') {
                findSale.horaPedido = DateTime.now().toFormat('HH:mm:ss');
                findSale.status = 'INICIADO';
            }
            else if (findSale.origem === 'MESA') {
                const mesaItens = await VendaItem.query().where('id_venda', findSale.id).first();
                if (!mesaItens) {
                    return ctx.response.badRequest('ITENS DA MESA NÃO ENCOTRADOS!');
                }
                const mesa = await Mesa.query().where('id', mesaItens.id_mesa).first();
                if (!mesa) {
                    return ctx.response.badRequest('MESA NÃO ENCOTRADA!');
                }
                mesa.status = 'LIVRE';
                mesa.hora_abertura = null;
                mesa.hora_ultimo_atendimento = null;
                mesa.hora_fechamento = null;
                mesa.identificacao_mesa = null;
                mesa.id_garcon = null;
                mesa.quantidade_pessoas = 0;
                mesa.grupo_mesas = null;
                mesa.deletedAt = null;
                mesa.active = true;
                await mesa.save();
                findSale.status = 'FINALIZADO';
                findSale.finalizado = true;
                findSale.horaPedido = DateTime.now().toFormat('HH:mm:ss');
            }
            else {
                findSale.status = 'FINALIZADO';
                findSale.finalizado = true;
                findSale.horaPedido = DateTime.now().toFormat('HH:mm:ss');
            }
            await findSale.save();
            const findPayMnethodType = await FormaDePagamentoTipo.query().where('cmp', '01').first();
            if (findPayMnethodType) {
                const findInstallment = await VendaFormaDePagamentoParcela.query()
                    .where('id_forma_de_pagamento_tipo', findPayMnethodType.id)
                    .where('id_venda', findSale.id)
                    .select('*');
                if (findInstallment && findInstallment.length > 0) {
                    let valueTotal = 0;
                    for (const installment of findInstallment) {
                        if (Number(installment.installmentValue)) {
                            valueTotal = Number(valueTotal) + Number(installment.installmentValue);
                        }
                    }
                    const findMovemntCashDesk = await CaixaMovimento.query()
                        .where('idcaixamovimento', idMovementCashDesk)
                        .first();
                    if (findMovemntCashDesk) {
                        findMovemntCashDesk.suprimentoatual =
                            Number(findMovemntCashDesk.suprimentoatual) + Number(valueTotal);
                        await findMovemntCashDesk.save();
                    }
                }
            }
            await this.fillTheClosingCashDesk(idMovementCashDesk);
            const venda = await Venda.query()
                .preload('vendedor', (query) => query.select('nome'))
                .where('id', idSale)
                .first();
            return ctx.response.json(venda);
        }
    }
    async verifyBlockedCustomers(idSale, ctx) {
        const configBloquearClienteVendaAPrazo = await EmpresaPdvConfig.query()
            .select([
            'bloquear_vendas_a_prazo_por_atraso_do_cliente',
            'bloquear_vendas_a_prazo_por_limite',
        ])
            .first();
        if (configBloquearClienteVendaAPrazo &&
            (configBloquearClienteVendaAPrazo.bloquear_vendas_a_prazo_por_limite ||
                configBloquearClienteVendaAPrazo.bloquear_vendas_a_prazo_por_atraso_do_cliente)) {
            const findPaymentMethodType = await FormaDePagamentoTipo.query()
                .where('cmp', 90)
                .select(['id'])
                .first();
            if (findPaymentMethodType) {
                const findInstallments = await VendaFormaDePagamentoParcela.query()
                    .where('id_forma_de_pagamento_tipo', findPaymentMethodType.id)
                    .where('id_venda', idSale);
                if (findInstallments.length > 0) {
                    const findClient = await VendaCliente.query()
                        .where('id_venda', idSale)
                        .select(['id_empresa'])
                        .first();
                    if (findClient) {
                        const findBlockedClient = await PrimeClienteBloqueado.query()
                            .where('id_empresa', findClient.idEmpresa)
                            .first();
                        if (findBlockedClient) {
                            ctx.response.badRequest('CLIENTE BLOQUEADO!');
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    async verifyExistSaleStatusProvisional(ctx) {
        const data = ctx.params;
        const idTerminal = data.id_terminal;
        const sale = await Venda.query()
            .where('id_terminal', idTerminal)
            .where('status', 'PROVISORIO')
            .where('e_orcamento', false)
            .select(['id'])
            .first();
        if (sale) {
            return ctx.response.json(sale.id);
        }
        else {
            return ctx.response.json(0);
        }
    }
    async getAllSalesByIdMovementCashDesk(ctx) {
        const params = ctx.params;
        const idMovementCashDesk = params.id_movement_cash_desk;
        const sales = await Venda.query()
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('formaDePagamento', (subQueryPayment) => {
                subQueryPayment
                    .preload('formaDePagamentoTipo', (subQueryPaymentType) => {
                    subQueryPaymentType.select(['id', 'nome', 'cmp']);
                })
                    .select(['id', 'id_forma_de_pagamento_tipo', 'description']);
            })
                .select(['id', 'id_venda', 'id_forma_de_pagamento', 'installment_value']);
        })
            .where('id_caixa_movimento', idMovementCashDesk)
            .select(['id', 'id_caixa_movimento', 'status', 'codigo']);
        const calcToAddThePaymentMethodValue = sales
            .flatMap((venda) => venda.vendaFormaDePagamento)
            .reduce((acc, pagamento) => {
            const { formaDePagamento, installmentValue } = pagamento;
            const existente = acc.find((item) => item.id === formaDePagamento.id_forma_de_pagamento_tipo);
            if (existente) {
                existente.value = Number(existente.value) + Number(installmentValue);
            }
            else {
                acc.push({
                    id: formaDePagamento.id_forma_de_pagamento_tipo,
                    name: formaDePagamento.description,
                    value: installmentValue,
                });
            }
            return acc;
        }, []);
        return ctx.response.json({ calcToAddThePaymentMethodValue });
    }
    async getSaleStatusProvisional(ctx) {
        const data = ctx.params;
        const idTerminal = data.id_terminal;
        const saleData = {
            id: 0,
            codigo: 0,
            code: 0,
            senha_delivery: 0,
            cpf: '',
            status: '',
            id_vendedor: null,
            id_caixa_movimento: null,
            id_venda_orcamento: null,
            id_usuario_criacao: null,
            itens: [],
            origem: '',
            venda_cliente: {
                id: 0,
                cliente: {
                    id: 0,
                    nome_fantasia: '',
                },
                telefone: '',
                logradouro: '',
                numero: '',
                complemento: '',
                bairro: '',
                cidade: '',
                uf: '',
                cep: '',
                codigo_cidade: '',
                codigo_uf: '',
                referencia: '',
            },
            UsuarioCriacao: {
                id: 0,
                nome: '',
            },
            empresa: {
                id: 0,
                nome_fantasia: '',
                telefone: '',
                cpf_cnpj: '',
                ie_rg: '',
                logradouro: '',
                numero: '',
                complemento: '',
                bairro: '',
                cidade: '',
                uf: '',
                cep: '',
            },
            itens_para_deletar: [],
            venda_forma_de_pagamento_para_deletar: [],
            venda_forma_de_pagamento: [],
            sub_total: 0,
            acrescimo: 0,
            desconto_geral: 0,
            total_a_pagar: 0,
            saldo_a_pagar: 0,
            valor_pago: 0,
            troco: 0,
        };
        const sale = await Venda.query()
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .where('id_terminal', idTerminal)
            .where('status', 'PROVISORIO')
            .where('e_orcamento', false)
            .first();
        if (sale) {
            saleData.codigo = sale.codigo;
            saleData.senha_delivery = sale.senhaDelivery;
            saleData.code = sale.code;
            saleData.id_vendedor = sale.idVendedor;
            saleData.id_caixa_movimento = sale.idCaixaMovimento;
            saleData.id_venda_orcamento = sale.idVendaOrcamento;
            saleData.id_usuario_criacao = sale.idUsuarioCriacao;
            saleData.origem = sale.origem;
            saleData.UsuarioCriacao = {
                id: sale.UsuarioCriacao?.idfuncionariousuario || 0,
                nome: sale.UsuarioCriacao?.usuario || '',
            };
            saleData.empresa = {
                id: sale.empresa?.id || 0,
                nome_fantasia: sale.empresa?.nome_fantasia || '',
                telefone: sale.empresa?.telefone || '',
                cpf_cnpj: sale.empresa?.cnpj_cpf || '',
                ie_rg: sale.empresa?.ie_rg || '',
                logradouro: sale.empresa?.enderecos[0]?.logradouro || '',
                numero: sale.empresa?.enderecos[0]?.numero || '',
                complemento: sale.empresa?.enderecos[0]?.complemento || '',
                bairro: sale.empresa?.enderecos[0]?.bairro || '',
                cidade: sale.empresa?.enderecos[0]?.cidade || '',
                uf: sale.empresa?.enderecos[0]?.uf || '',
                cep: sale.empresa?.enderecos[0]?.cep || '',
            };
            const client = await VendaCliente.query().where('id_venda', sale.id).first();
            if (client) {
                saleData.venda_cliente.id = client.id;
                saleData.venda_cliente.codigo = client.codigo;
                saleData.venda_cliente.cliente.id = client.idEmpresa;
                saleData.venda_cliente.nome_fantasia = client.nomeFantasia;
                saleData.venda_cliente.razao_social = client.razaoSocial;
                saleData.venda_cliente.apelido = client.apelido;
                saleData.venda_cliente.cnpj_cpf = client.cnpjCpf;
                saleData.venda_cliente.ie_rg = client.ieRg;
                saleData.venda_cliente.im = client.im;
                saleData.venda_cliente.telefone = client.telefone;
                saleData.venda_cliente.tipo_endereco = client.tipoEndereco;
                saleData.venda_cliente.logradouro = client.logradouro;
                saleData.venda_cliente.numero = client.numero;
                saleData.venda_cliente.complemento = client.complemento;
                saleData.venda_cliente.bairro = client.bairro;
                saleData.venda_cliente.cidade = client.cidade;
                saleData.venda_cliente.uf = client.uf;
                saleData.venda_cliente.cep = client.cep;
                saleData.venda_cliente.codigo_cidade = client.codigoCidade;
                saleData.venda_cliente.codigo_uf = client.codigoUf;
                saleData.venda_cliente.referencia = client.referencia;
            }
            saleData.id = sale.id;
            saleData.cpf = sale.cpf;
            saleData.status = sale.status;
            saleData.itens_para_deletar = [];
            saleData.venda_forma_de_pagamento_para_deletar = [];
            saleData.itens = sale.vendaItem.map((item) => {
                return {
                    id: item.id,
                    id_produto: item.produto.id,
                    nome: item.productDescription,
                    quantidade: Number(item.saledQuantity),
                    valor: Number(item.unitaryValue),
                    total: Number(item.totalValue),
                    desconto: Number(item.totalDescountValue),
                    observacao: item.observacao,
                    taxa_de_entrega: item.taxaDeEntrega,
                    taxa_de_couvert: item.couvert,
                    taxa_de_servico: item.taxaDeServico,
                    produto: {
                        ...item.produto,
                    },
                    caracteristicas: item.caracteristicas.map((car) => ({
                        idProdutoCaracteristica: car.id_produto_caracteristica,
                        categoria: car.categoria,
                        codigo: car.codigo,
                        descricao: car.descricao,
                        fixo: car.fixo,
                    })),
                    sub_itens: item.subItens.map((subItem) => ({
                        id: subItem.id,
                        id_produto: subItem.idProduto,
                        quantidade: subItem.quantidade,
                        valor: subItem.valorUnitario,
                        total: subItem.valorTotal,
                        descricao: subItem.descricao,
                        codigo: Number(subItem.codigo),
                        observacao: subItem.observacao || '',
                        produto: {
                            ...subItem.produto,
                        },
                        caracteristicas: subItem.caracteristicas.map((car) => ({
                            idProdutoCaracteristica: car.id_produto_caracteristica,
                            categoria: car.categoria,
                            codigo: car.codigo,
                            descricao: car.descricao,
                            fixo: car.fixo,
                        })),
                    })),
                };
            });
            saleData.venda_forma_de_pagamento = sale.vendaFormaDePagamento.map((item) => {
                let labelDescription = '';
                const type = item.formaDePagamento.formaDePagamentoTipo;
                const condition = item.formaDePagamento.formaDePagamentoCondicao;
                const paymentMethod = item.formaDePagamento;
                const flag = item.formaDePagamento.bandeira;
                const accountBank = item.formaDePagamento.contaBancaria;
                const installments = item.vendaFormaDePagamentoParcela;
                if ((type.nome === 'CARTÃO DE CRÉDITO' || type.nome === 'CARTÃO DE DÉBITO') &&
                    flag &&
                    flag.nome) {
                    labelDescription = String(`${type.nome} | ${condition.nome} | BANDEIRA ${flag.nome} | QUANTIDADE ${Number(paymentMethod.quantidade)}`);
                }
                else {
                    labelDescription = String(`${type.nome} | ${condition.nome} | QUANTIDADE ${Number(paymentMethod.quantidade)}`);
                }
                return {
                    id: item.id,
                    description: labelDescription,
                    payment_method: {
                        id: paymentMethod.id,
                        amount: paymentMethod.quantidade,
                        term: paymentMethod.prazo,
                        type: type.nome,
                        condition: condition.nome,
                        flag: flag.nome,
                        rate: paymentMethod.tarifa,
                        id_bank_account: accountBank ? accountBank.id : null,
                        cmp: type.cmp,
                        label_description: labelDescription,
                    },
                    value: Number(item.installmentValue),
                    installments: installments.map((installment) => {
                        return {
                            id: installment.id,
                            id_sale_payment_method: installment.idVendaFormaDePagamento,
                            id_payment_method_type: installment.idFormaDePagamentoTipo,
                            id_payment_method_condition: installment.idFormaDePagamentoCondicao,
                            value: installment.installmentValue,
                            date: installment.installmentDate,
                            count: installment.count,
                            tax_percentage: installment.tax_percentage,
                        };
                    }),
                };
            });
            const totalPaid = sale.vendaFormaDePagamento.reduce((sum, item) => sum + Number(item.installmentValue), 0);
            const addition = Number(sale.valorTaxaDelivery) + Number(sale.valorCouvert) + Number(sale.valorTaxaServico);
            const totalToPay = Number(sale.valorProdutos) - Number(sale.totalDescountValue) + addition;
            const change = totalPaid - totalToPay < 0 ? 0 : totalPaid - totalToPay;
            const descontoItens = sale.vendaItem.reduce((acc, item) => {
                return acc + Number(item.totalDescountValue);
            }, 0);
            saleData.sub_total = Number(sale.valorProdutos) + descontoItens;
            saleData.acrescimo = addition;
            saleData.desconto_geral = Number(sale.totalDescountValue);
            saleData.total_a_pagar = totalToPay;
            saleData.saldo_a_pagar = totalToPay - totalPaid <= 0 ? 0 : totalToPay - totalPaid;
            saleData.valor_pago = totalPaid;
            saleData.troco = change;
        }
        return ctx.response.json({ saleData });
    }
    async getSaleStatusProvisionalOnlyTheClient(ctx) {
        const data = ctx.params;
        const idTerminal = data.id_terminal;
        const saleDataOnlyClient = {
            id: 0,
            codigo: 0,
            status: '',
            venda_cliente: {
                id: 0,
                nome_fantasia: '',
                cliente: {
                    id: 0,
                    nome_fantasia: '',
                },
            },
        };
        const sale = await Venda.query()
            .where('id_terminal', idTerminal)
            .where('status', 'PROVISORIO')
            .where('e_orcamento', false)
            .select(['id'])
            .first();
        if (sale) {
            const existClient = await VendaCliente.query().where('id_venda', sale.id).first();
            saleDataOnlyClient.id = sale.id;
            if (existClient) {
                saleDataOnlyClient.venda_cliente.id = existClient.id;
                saleDataOnlyClient.venda_cliente.nome_fantasia = existClient.nomeFantasia;
                saleDataOnlyClient.venda_cliente.cliente.id = existClient?.idEmpresa;
                saleDataOnlyClient.venda_cliente.cliente.nome_fantasia = existClient.nomeFantasia;
            }
            else {
                saleDataOnlyClient.venda_cliente.cliente = null;
            }
            return ctx.response.json(saleDataOnlyClient);
        }
        else {
            return ctx.response.badRequest('VENDA NÃO ENCONTRADA');
        }
    }
    async getSaleStatusProvisionalOnlyTheItems(ctx) {
        const data = ctx.params;
        const idTerminal = data.id_terminal;
        const saleDataOnlyItems = {
            id: 0,
            codigo: 0,
            code: 0,
            senha_delivery: 0,
            status: '',
            itens: [],
            id_usuario_criacao: 0,
            UsuarioCriacao: {
                id: 0,
                nome: '',
            },
            itens_para_deletar: [],
            sub_total: 0,
            acrescimo: 0,
            total_a_pagar: 0,
            taxa_de_entrega: 0,
            taxa_servico: 0,
            taxa_couvert: 0,
            origem: 'PDV',
        };
        const sale = await Venda.query()
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            })
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            });
        })
            .preload('UsuarioCriacao')
            .where('id_terminal', idTerminal)
            .where('status', 'PROVISORIO')
            .where('e_orcamento', false)
            .select([
            'id',
            'status',
            'codigo',
            'valor_produtos',
            'valor_taxa_delivery',
            'total_descount_value',
            'valor_taxa_servico',
            'valor_couvert',
            'id_usuario_criacao',
            'origem',
        ])
            .first();
        if (sale) {
            const addition = Number(sale.valorTaxaDelivery || 0) +
                Number(sale.valorTaxaServico || 0) +
                Number(sale.valorCouvert || 0);
            const totalToPay = Number(sale.valorProdutos) - Number(sale.totalDescountValue || 0) + addition;
            saleDataOnlyItems.id = sale.id;
            saleDataOnlyItems.codigo = sale.codigo;
            saleDataOnlyItems.code = sale.code;
            saleDataOnlyItems.origem = sale.origem;
            saleDataOnlyItems.senha_delivery = sale.senhaDelivery;
            saleDataOnlyItems.status = sale.status;
            saleDataOnlyItems.sub_total = Number(sale.valorProdutos);
            saleDataOnlyItems.acrescimo = addition;
            saleDataOnlyItems.total_a_pagar = totalToPay;
            saleDataOnlyItems.taxa_de_entrega = sale.valorTaxaDelivery
                ? Number(sale.valorTaxaDelivery)
                : 0;
            saleDataOnlyItems.taxa_servico = sale.valorTaxaServico ? Number(sale.valorTaxaServico) : 0;
            saleDataOnlyItems.taxa_couvert = sale.valorCouvert ? Number(sale.valorCouvert) : 0;
            saleDataOnlyItems.itens_para_deletar = [];
            saleDataOnlyItems.id_usuario_criacao = sale.idUsuarioCriacao;
            saleDataOnlyItems.UsuarioCriacao = {
                id: sale.UsuarioCriacao?.idfuncionariousuario || 0,
                nome: sale.UsuarioCriacao?.usuario || '',
            };
            saleDataOnlyItems.itens = sale.vendaItem.map((item) => {
                return {
                    id: item.id,
                    id_produto: item.produto.id,
                    id_comanda: item.id_comanda,
                    nome: item.productDescription,
                    quantidade: Number(item.saledQuantity),
                    valor: Number(item.unitaryValue),
                    total: Number(item.totalValue),
                    desconto: Number(item.totalDescountValue),
                    observacao: item.observacao,
                    taxa_de_entrega: item.taxaDeEntrega,
                    taxa_de_couvert: item.couvert,
                    taxa_de_servico: item.taxaDeServico,
                    produto: {
                        ...item.produto,
                    },
                    caracteristicas: item.caracteristicas.map((car) => ({
                        idProdutoCaracteristica: car.id_produto_caracteristica,
                        categoria: car.categoria,
                        codigo: car.codigo,
                        descricao: car.descricao,
                        fixo: car.fixo,
                    })),
                    sub_itens: item.subItens.map((subItem) => ({
                        id: subItem.id,
                        id_produto: subItem.idProduto,
                        quantidade: subItem.quantidade,
                        valor: subItem.valorUnitario,
                        total: subItem.valorTotal,
                        descricao: subItem.descricao,
                        codigo: Number(subItem.codigo),
                        observacao: subItem.observacao || '',
                        produto: {
                            ...subItem.produto,
                        },
                        caracteristicas: subItem.caracteristicas.map((car) => ({
                            idProdutoCaracteristica: car.id_produto_caracteristica,
                            categoria: car.categoria,
                            codigo: car.codigo,
                            descricao: car.descricao,
                            fixo: car.fixo,
                        })),
                    })),
                };
            });
            return ctx.response.json(saleDataOnlyItems);
        }
        else {
            return ctx.response.status(204);
        }
    }
    async salesCreationInProgress(ctx) {
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const idCompany = sessionData.empresaId;
        const idUser = sessionData.idfuncionariousuario;
        const data = ctx.request.all();
        const idTerminal = data.data.id_terminal;
        const idSale = data.data.sale.id;
        const cpf = data.data.sale.cpf;
        const saleStatus = data.data.sale.status;
        const saleDiscountValue = data.data.sale.desconto_geral;
        const saleItems = data.data.sale.itens;
        const saleItemToDelete = data.data.sale.itens_para_deletar;
        const salePaymentMethod = data.data.sale.venda_forma_de_pagamento;
        const salePaymentMethodToDelete = data.data.sale.venda_forma_de_pagamento_para_deletar;
        const saleClient = data.data.sale.venda_cliente;
        if (idTerminal) {
            const existingSale = await Venda.query()
                .where('id_terminal', idTerminal)
                .where('id', idSale)
                .where('status', 'PROVISORIO')
                .where('e_orcamento', false)
                .first();
            if (existingSale) {
                if (saleDiscountValue) {
                    existingSale.totalDescountValue = saleDiscountValue;
                }
                else {
                    existingSale.totalDescountValue = 0;
                }
                if (saleItems) {
                    const calcvalueTaxDelivery = saleItems && saleItems.length > 0
                        ? saleItems
                            .filter((item) => item.taxa_de_entrega)
                            .reduce((sum, item) => sum + Number(item.total || 0), 0)
                        : 0;
                    const calcvalueTaxService = saleItems && saleItems.length > 0
                        ? saleItems
                            .filter((item) => item.taxa_de_servico)
                            .reduce((sum, item) => sum + Number(item.total || 0), 0)
                        : 0;
                    const calcvalueTaxCouvert = saleItems && saleItems.length > 0
                        ? saleItems
                            .filter((item) => item.taxa_de_couvert)
                            .reduce((sum, item) => sum + Number(item.total || 0), 0)
                        : 0;
                    const calcValueProduct = saleItems && saleItems.length > 0
                        ? saleItems
                            .filter((item) => !item.taxa_de_entrega && !item.taxa_de_couvert && !item.taxa_de_servico)
                            .reduce((sum, item) => sum + Number(item.total || 0), 0)
                        : 0;
                    existingSale.valorProdutos = calcValueProduct;
                    existingSale.valorTaxaDelivery = calcvalueTaxDelivery;
                    existingSale.valorTaxaServico = calcvalueTaxService;
                    existingSale.valorCouvert = calcvalueTaxCouvert;
                }
                await this.removeSaleItem(existingSale.id, saleStatus, saleItemToDelete);
                if (saleItems) {
                    const filterSaleitemHasId = saleItems.filter((item) => item.id !== undefined && item.id !== null && item.id !== 0);
                    await this.updatedSaleItem(filterSaleitemHasId);
                }
                if (saleItems) {
                    const filterSaleitemNoId = saleItems.filter((item) => item.id === undefined || item.id === null || item.id === 0);
                    await this.createdSaleItem(filterSaleitemNoId, idSale);
                }
                await this.removeSalePaymentMethod(saleStatus, salePaymentMethodToDelete);
                if (salePaymentMethod) {
                    const filterSalePaymentMethodHasId = salePaymentMethod.filter((item) => item.id === undefined || item.id === null || item.id === 0);
                    await this.createdSalePaymentMethod(filterSalePaymentMethodHasId, idSale);
                }
                if (salePaymentMethod && salePaymentMethod.length > 0) {
                    const totalPaid = salePaymentMethod.reduce((sum, item) => sum + Number(item.value), 0);
                    const addition = Number(existingSale.valorTaxaDelivery) +
                        Number(existingSale.valorTaxaServico) +
                        Number(existingSale.valorCouvert);
                    const totalToPay = Number(existingSale.valorProdutos) - Number(existingSale.totalDescountValue) + addition;
                    const change = totalPaid - totalToPay < 0 ? 0 : totalPaid - totalToPay;
                    existingSale.valorTroco = change;
                }
                const returnIdClient = await this.createSaleClient(saleClient, existingSale.id, existingSale.idCliente);
                if (returnIdClient) {
                    existingSale.idCliente = returnIdClient;
                }
                existingSale.cpf = cpf;
                await existingSale.save();
            }
            else {
                await this.ifSaleNotExist(saleItems, idTerminal, idCompany, idUser);
            }
        }
        return ctx.response.status(201);
    }
    async suspendedOrCancelSale(ctx) {
        const params = ctx.params;
        const data = ctx.request.all();
        const idSale = params.id_sale;
        const motive = data.motive;
        const status = data.status;
        try {
            const existSale = await Venda.query().where('id', idSale).first();
            if (existSale) {
                existSale.status = status;
                existSale.motivoCancelamento = motive;
                if (data.status === 'CANCELADO') {
                    if (data.voltaEstoque) {
                        const saleItems = await VendaItem.query().where('id_venda', existSale.id).select('*');
                        for (const saleItem of saleItems) {
                            const inventory = await PrimeProdutoEstoque.query()
                                .where('id_produto', saleItem.idProduto)
                                .where('main_inventory', true)
                                .select('*')
                                .first();
                            if (inventory) {
                                await PrimeVendaControleEstoque.create({
                                    id_estoque: inventory.id,
                                    tipo: 'addition',
                                    id_estoque_prime: inventory.id_prime,
                                    quantidade: saleItem.saledQuantity,
                                });
                            }
                        }
                    }
                }
                await existSale.save();
            }
            return ctx.response.status(200);
        }
        catch (err) {
            console.log(err);
            return ctx.response.badRequest(err);
        }
    }
    async cancelOperation(ctx) {
        try {
            const params = ctx.params;
            const data = ctx.request.all();
            const idSale = params.id_sale;
            const motivo = data.motivo;
            const venda = await Venda.query().where('id', idSale).first();
            if (!venda) {
                return ctx.response.status(404).json({
                    success: false,
                    message: 'Venda não encontrada',
                });
            }
            let comandasProcessadas = 0;
            if (venda.origem === 'DELIVERY') {
                venda.status = 'PROVISORIO_DELIVERY';
                const vendaItems = await VendaItem.query()
                    .where('id_venda', venda.id)
                    .preload('produto', (qryProduto) => {
                    qryProduto.preload('Preco', (qryPreco) => {
                        qryPreco.where('main_price', true);
                    });
                })
                    .select('*');
                for (const item of vendaItems) {
                    const precoPrincipal = item.produto.Preco[0];
                    if (precoPrincipal) {
                        item.totalDescountValue = 0;
                        item.unitaryValue = precoPrincipal.value;
                        item.totalValue = precoPrincipal.value * item.saledQuantity;
                        await item.save();
                    }
                }
                const totalVenda = await VendaItem.query()
                    .where('id_venda', venda.id)
                    .sum('total_value as total_value')
                    .first();
                if (totalVenda) {
                    venda.valorProdutos = Number(totalVenda.$attributes.total_value) || 0;
                    venda.totalValue = venda.valorProdutos - venda.totalDescountValue;
                    await venda.save();
                }
            }
            else if (venda.origem === 'MESA') {
                venda.status = 'PROVISORIO_MESA';
                const taxaServicoItem = await VendaItem.query()
                    .where('taxa_de_servico', true)
                    .where('id_venda', venda.id)
                    .first();
                if (taxaServicoItem) {
                    await taxaServicoItem.delete();
                }
                const couvertItem = await VendaItem.query()
                    .where('couvert', true)
                    .where('id_venda', venda.id)
                    .first();
                if (couvertItem) {
                    await couvertItem.delete();
                }
            }
            else if (venda.origem === 'COMANDA') {
                const itensVenda = await VendaItem.query()
                    .where('id_venda', idSale)
                    .whereNotNull('id_comanda')
                    .select('id', 'id_comanda');
                const comandasIds = [...new Set(itensVenda.map((item) => item.id_comanda))];
                for (const comandaId of comandasIds) {
                    await VendaItem.query()
                        .where('id_comanda', comandaId)
                        .where((query) => {
                        query.where('taxaDeServico', true).orWhere('couvert', true);
                    })
                        .delete();
                }
                for (const item of itensVenda) {
                    await VendaItem.query().where('id', item.id).update({ listar_na_comanda: true });
                }
                venda.status = 'REVOGADO';
                venda.valorTaxaServico = 0;
                venda.valorCouvert = 0;
                for (const comandaId of comandasIds) {
                    const comanda = await Comanda.query()
                        .where('id', comandaId)
                        .where('status', 'FECHADO')
                        .first();
                    if (comanda) {
                        comanda.status = 'ABERTO';
                        await comanda.save();
                        comandasProcessadas++;
                    }
                }
            }
            else {
                venda.status = data.status || 'CANCELADO';
            }
            venda.motivoCancelamento = motivo;
            await venda.save();
            return ctx.response.json({
                success: true,
                message: venda.origem === 'DELIVERY'
                    ? 'OPERAÇÃO CANCELADA COM SUCESSO'
                    : venda.origem === 'COMANDA'
                        ? 'OPERAÇÃO REVOGADA COM SUCESSO. OS ITENS FORAM DEVOLVIDOS ÀS COMANDAS.'
                        : 'OPERAÇÃO CANCELADA COM SUCESSO',
                data: {
                    id: venda.id,
                    status: venda.status,
                    origem: venda.origem,
                    comandasProcessadas: comandasProcessadas,
                },
            });
        }
        catch (error) {
            console.error('Erro ao processar operação:', error);
            return ctx.response.status(500).json({
                success: false,
                message: 'Erro ao processar operação',
                error: String(error),
            });
        }
    }
    async requestSeller(ctx) {
        const data = ctx.request.all();
        const codeSeller = data.code_seller;
        const passwordUserSeller = data.password_user;
        const permissionRequestPasswordSeller = data.terminal_exigir_senha_vendedor;
        const permissionRequestCodSeller = data.terminal_solicitar_codigo_vendedor;
        const idCompanyByTerminal = data.id_empresa;
        const sellers = await Funcionario.query()
            .whereNotNull('code_seller')
            .where('id_empresa', idCompanyByTerminal)
            .whereNull('deleted_at')
            .select(['idfuncionario', 'seller', 'id_empresa', 'deleted_at', 'nome', 'code_seller']);
        if (sellers.length > 0) {
            let findSellerOrUser = null;
            for (const seller of sellers) {
                if (permissionRequestCodSeller) {
                    if (seller.code_seller === codeSeller) {
                        findSellerOrUser = seller;
                        break;
                    }
                }
                else {
                    const findUsersBySeller = await FuncionarioUsuario.query().where('idFuncionario', seller.idfuncionario);
                    if (findUsersBySeller.length > 0) {
                        for (const user of findUsersBySeller) {
                            const isPasswordValid = await hash.verify(user.senha, passwordUserSeller);
                            if (isPasswordValid) {
                                findSellerOrUser = user;
                                break;
                            }
                        }
                    }
                }
            }
            if (findSellerOrUser && 'idfuncionario' in findSellerOrUser) {
                const findUserBySeller = await FuncionarioUsuario.query()
                    .where('idFuncionario', findSellerOrUser.idfuncionario)
                    .first();
                if (findUserBySeller && permissionRequestPasswordSeller) {
                    if (!(await hash.verify(findUserBySeller.senha, passwordUserSeller))) {
                        return ctx.response.badRequest('ACESSO NEGADO! SENHA INVÁLIDA.');
                    }
                    return ctx.response.json(findSellerOrUser);
                }
                else {
                    return ctx.response.json(findSellerOrUser);
                }
            }
            else if (!permissionRequestCodSeller && findSellerOrUser) {
                const findSeller = await Funcionario.query()
                    .whereNotNull('code_seller')
                    .where('idfuncionario', findSellerOrUser.idFuncionario)
                    .whereNull('deleted_at')
                    .select(['idfuncionario', 'seller', 'id_empresa', 'deleted_at', 'nome', 'code_seller'])
                    .first();
                return ctx.response.json(findSeller);
            }
            else if (!findSellerOrUser) {
                if (permissionRequestCodSeller) {
                    return ctx.response.badRequest('CÓDIGO DO VENDEDOR OU SENHA INFORMADA NÃO BATE COM NENHUM CADASTRADO!');
                }
                else {
                    return ctx.response.badRequest('SENHA INFORMADA NÃO BATE COM NENHUM VENDEDOR CADASTRADO!');
                }
            }
        }
        else {
            return ctx.response.badRequest('NENHUM VENDEDOR CADASTRADO!');
        }
    }
    async registerSellerInTheSale(ctx) {
        try {
            const data = ctx.request.all();
            const idTerminal = data.id_terminal;
            const idSale = data.id_sale;
            const idSeller = data.id_seller;
            if (idTerminal) {
                const existingSale = await Venda.query()
                    .where('id_terminal', idTerminal)
                    .where('id', idSale)
                    .where('status', 'PROVISORIO')
                    .first();
                if (existingSale) {
                    existingSale.idVendedor = idSeller;
                    await existingSale.save();
                }
            }
            return ctx.response.status(201);
        }
        catch (err) {
            console.log(err);
        }
    }
    async transformSaleIntoBudget(ctx) {
        const params = ctx.params;
        const data = ctx.request.all();
        const idSale = params.id_sale;
        const observation = data.observation;
        try {
            const existSale = await Venda.query().where('id', idSale).first();
            if (existSale) {
                const productWithInvetoryResponse = await this.verifyProductWithInvetoryZeroed(idSale, ctx);
                if (productWithInvetoryResponse) {
                    return;
                }
                existSale.status = 'PROVISORIO_ORCAMENTO';
                existSale.e_orcamento = true;
                existSale.observacao = observation;
                await existSale.save();
            }
            else {
                return ctx.response.badRequest('VENDA NÃO ENCONTRADA!');
            }
        }
        catch (err) {
            console.log(err);
        }
        return ctx.response.status(200);
    }
    async verifyProductWithInvetoryZeroed(idSale, ctx) {
        const configEstoqueZerado = await EmpresaPdvConfig.query()
            .select(['nao_permitir_orcamento_estoque_zerado'])
            .first();
        if (configEstoqueZerado && configEstoqueZerado.nao_permitir_orcamento_estoque_zerado) {
            const findSaleProducts = await VendaItem.query()
                .where('id_venda', idSale)
                .select(['id_produto']);
            if (findSaleProducts.length > 0) {
                for (const findSaleProduct of findSaleProducts) {
                    const findInventory = await PrimeProdutoEstoque.query()
                        .where('id_produto', findSaleProduct.idProduto)
                        .where('main_inventory', true)
                        .select(['quantity'])
                        .first();
                    if (findInventory) {
                        if (Number(findInventory.quantity) <= 0) {
                            ctx.response.badRequest('NÃO É PERMITIDO GERAR ORÇAMENTO COM ESTOQUE ZERADO!');
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }
    async transformBudgetIntoSale(ctx) {
        const params = ctx.params;
        const idSale = params.id_sale;
        if (idSale) {
            const findBudget = await Venda.query()
                .where('id', idSale)
                .select([
                'id',
                'id_terminal',
                'id_empresa',
                'id_usuario_criacao',
                'id_grupo',
                'id_vendedor',
                'total_descount_value',
            ])
                .first();
            if (findBudget) {
                const newSale = await Venda.create({
                    idVendaOrcamento: findBudget.id,
                    idTerminal: findBudget.idTerminal,
                    idEmpresa: findBudget.idEmpresa,
                    idUsuarioCriacao: findBudget.idUsuarioCriacao,
                    idGrupo: findBudget.idGrupo,
                    idVendedor: findBudget.idVendedor,
                    finalizado: false,
                    status: 'PROVISORIO',
                    origem: 'PDV',
                    e_orcamento: false,
                    totalValue: 0,
                    totalDescountValue: findBudget.totalDescountValue,
                });
                const findBudgetItems = await VendaItem.query()
                    .where('id_venda', findBudget.id)
                    .preload('subItens', (subQuery) => {
                    subQuery.preload('caracteristicas');
                })
                    .preload('caracteristicas');
                if (findBudgetItems && findBudgetItems.length > 0) {
                    for (const findBudgetItem of findBudgetItems) {
                        const newSaleItem = await VendaItem.create({
                            idVenda: newSale.id,
                            idProduto: findBudgetItem.idProduto,
                            aliquotIcms: findBudgetItem.aliquotIcms,
                            cfop: findBudgetItem.cfop,
                            codigo: findBudgetItem.codigo,
                            comissaoPorcentagem: findBudgetItem.comissaoPorcentagem,
                            csosn: findBudgetItem.csosn,
                            ncm: findBudgetItem.ncm,
                            observacao: findBudgetItem.observacao,
                            productDescription: findBudgetItem.productDescription,
                            saledQuantity: findBudgetItem.saledQuantity,
                            taxaDeEntrega: findBudgetItem.taxaDeEntrega,
                            unitaryValue: findBudgetItem.unitaryValue,
                            totalValue: findBudgetItem.totalValue,
                            status: findBudgetItem.status,
                            totalDescountValue: findBudgetItem.totalDescountValue,
                            syncPrime: false,
                        });
                        const findBudgetSubItems = findBudgetItem.subItens;
                        const findBudgetFeatures = findBudgetItem.caracteristicas;
                        if (findBudgetFeatures && findBudgetFeatures.length > 0) {
                            for (const findBudgetFeature of findBudgetFeatures) {
                                await VendaItemCaracteristica.create({
                                    id_produto_caracteristica: findBudgetFeature.id_produto_caracteristica,
                                    categoria: findBudgetFeature.categoria,
                                    descricao: findBudgetFeature.descricao,
                                    fixo: findBudgetFeature.fixo,
                                    id_venda_item: newSaleItem.id,
                                    id_venda_sub_item: null,
                                    sync_prime: false,
                                });
                            }
                        }
                        if (findBudgetSubItems && findBudgetSubItems.length > 0) {
                            for (const findBudgetSubItem of findBudgetSubItems) {
                                const newSaleSubItem = await VendaSubItem.create({
                                    idVenda: newSale.id,
                                    idVendaItem: newSaleItem.id,
                                    idProduto: findBudgetSubItem.idProduto,
                                    aliquotaIcms: findBudgetSubItem.aliquotaIcms,
                                    cfop: findBudgetSubItem.cfop,
                                    codigo: findBudgetSubItem.codigo,
                                    comissaoPorcentagem: findBudgetSubItem.comissaoPorcentagem,
                                    csosn: findBudgetSubItem.csosn,
                                    ncm: findBudgetSubItem.ncm,
                                    observacao: findBudgetSubItem.observacao,
                                    descricao: findBudgetSubItem.descricao,
                                    quantidade: findBudgetSubItem.quantidade,
                                    valorUnitario: findBudgetSubItem.valorUnitario,
                                    valorTotal: findBudgetSubItem.valorTotal,
                                    status: findBudgetSubItem.status,
                                    valorDesconto: findBudgetSubItem.valorDesconto,
                                });
                                const findBudgetSubItemFeatures = findBudgetSubItem.caracteristicas;
                                if (findBudgetSubItemFeatures && findBudgetSubItemFeatures.length > 0) {
                                    for (const findBudgetSubItemFeature of findBudgetSubItemFeatures) {
                                        await VendaItemCaracteristica.create({
                                            id_produto_caracteristica: findBudgetSubItemFeature.id_produto_caracteristica,
                                            categoria: findBudgetSubItemFeature.categoria,
                                            descricao: findBudgetSubItemFeature.descricao,
                                            fixo: findBudgetSubItemFeature.fixo,
                                            id_venda_item: null,
                                            id_venda_sub_item: newSaleSubItem.id,
                                            sync_prime: false,
                                        });
                                    }
                                }
                            }
                        }
                    }
                }
                const findBudgetPaymentMethods = await VendaFormaDePagamento.query()
                    .where('id_venda', findBudget.id)
                    .preload('vendaFormaDePagamentoParcela');
                if (findBudgetPaymentMethods && findBudgetPaymentMethods.length > 0) {
                    for (const findBudgetPaymentMethod of findBudgetPaymentMethods) {
                        const newSalePaymentMethod = await VendaFormaDePagamento.create({
                            idVenda: newSale.id,
                            idFormaDePagamento: findBudgetPaymentMethod.idFormaDePagamento,
                            installmentValue: findBudgetPaymentMethod.installmentValue,
                            syncPrime: false,
                        });
                        const findBudgetInstallments = findBudgetPaymentMethod.vendaFormaDePagamentoParcela;
                        if (findBudgetInstallments && findBudgetInstallments.length) {
                            for (const findBudgetInstallment of findBudgetInstallments) {
                                await VendaFormaDePagamentoParcela.create({
                                    idVenda: newSale.id,
                                    idVendaFormaDePagamento: newSalePaymentMethod.id,
                                    idFormaDePagamentoCondicao: findBudgetInstallment.idFormaDePagamentoCondicao,
                                    installmentDate: findBudgetInstallment.installmentDate,
                                    installmentValue: findBudgetInstallment.installmentValue,
                                    syncPrime: false,
                                });
                            }
                        }
                    }
                }
                const findBudgetClient = await VendaCliente.query().where('id_venda', findBudget.id).first();
                if (findBudgetClient) {
                    await VendaCliente.create({
                        idVenda: newSale.id,
                        idEmpresa: findBudgetClient.idEmpresa,
                        nomeFantasia: findBudgetClient.nomeFantasia,
                        razaoSocial: findBudgetClient.razaoSocial,
                        apelido: findBudgetClient.apelido,
                        cnpjCpf: findBudgetClient.cnpjCpf,
                        ieRg: findBudgetClient.ieRg,
                        im: findBudgetClient.im,
                        email: findBudgetClient.email,
                        telefone: findBudgetClient.telefone,
                        codigo: findBudgetClient.codigo,
                        tipo: findBudgetClient.tipo,
                        origem: findBudgetClient.origem,
                        aniversario: findBudgetClient.aniversario,
                        tipoEndereco: findBudgetClient.tipoEndereco,
                        cep: findBudgetClient.cep,
                        uf: findBudgetClient.uf,
                        cidade: findBudgetClient.cidade,
                        bairro: findBudgetClient.bairro,
                        logradouro: findBudgetClient.logradouro,
                        numero: findBudgetClient.numero,
                        complemento: findBudgetClient.complemento,
                        codigoCidade: findBudgetClient.codigoCidade,
                        codigoUf: findBudgetClient.codigoUf,
                        referencia: findBudgetClient.referencia,
                        contatoNome: findBudgetClient.contatoNome,
                        contatoEmail: findBudgetClient.contatoEmail,
                        contatoTelefone: findBudgetClient.contatoTelefone,
                        contatoObservacao: findBudgetClient.contatoObservacao,
                        tipoContato: findBudgetClient.tipoContato,
                        contato: findBudgetClient.contato,
                        syncPrime: false,
                    });
                }
                const findBudgetNfce = await VendaNfce.query().where('id_venda', findBudget.id).first();
                if (findBudgetNfce) {
                    await VendaNfce.create({
                        syncPrime: false,
                        idVenda: newSale.id,
                        data: findBudgetNfce.data,
                        status: findBudgetNfce.status,
                        message: findBudgetNfce.message,
                    });
                }
                const saleItemsToCalc = await VendaItem.query().where('id_venda', newSale.id);
                if (saleItemsToCalc) {
                    newSale.valorProdutos =
                        saleItemsToCalc && saleItemsToCalc.length > 0
                            ? saleItemsToCalc.reduce((sum, item) => sum + Number(item.totalValue || 0), 0)
                            : 0;
                }
                await newSale.save();
                return ctx.response.json(newSale);
            }
            else {
                return ctx.response.badRequest('ORÇAMENTO NÃO ENCONTRADO');
            }
        }
        else {
            return ctx.response.badRequest('ORÇAMENTO NÃO INFORMADO');
        }
    }
    async ifSaleNotExist(saleItems, idTerminal, idCompany, idUser) {
        const data = {
            id: 0,
            codigo: 0,
            status: '',
            itens: [],
            venda_cliente: {
                id: 0,
                cliente: null,
            },
            itens_para_deletar: [],
            venda_forma_de_pagamento_para_deletar: [],
            venda_forma_de_pagamento: [],
            sub_total: 0,
            acrescimo: 0,
            desconto_geral: 0,
            total_a_pagar: 0,
            saldo_a_pagar: 0,
            valor_pago: 0,
            troco: 0,
        };
        const code = await SequenceController.newCodeSale();
        const newSale = await Venda.create({
            idTerminal: idTerminal,
            idEmpresa: idCompany,
            idUsuarioCriacao: idUser,
            idGrupo: 1,
            finalizado: false,
            status: 'PROVISORIO',
            origem: 'PDV',
            code,
            e_orcamento: false,
            valorProdutos: saleItems && saleItems.length > 0
                ? saleItems
                    .filter((item) => !item.taxa_de_entrega)
                    .reduce((sum, item) => sum + Number(item.total || 0), 0)
                : 0,
            totalValue: saleItems && saleItems.length > 0
                ? saleItems
                    .filter((item) => !item.taxa_de_entrega)
                    .reduce((sum, item) => sum + Number(item.total || 0), 0)
                : 0,
        });
        if (newSale) {
            if (saleItems.length > 0 && saleItems[0].produto.id) {
                const idSale = newSale.id;
                const idProduct = saleItems[0].produto.id;
                const amount = saleItems[0].quantidade;
                const valueUnitary = saleItems[0].valor;
                const discount = saleItems[0].desconto;
                const totalValue = valueUnitary * amount;
                const description = saleItems[0].produto.shortName;
                const newSaleItem = await VendaItem.create({
                    idVenda: idSale,
                    idProduto: idProduct,
                    saledQuantity: amount,
                    unitaryValue: valueUnitary,
                    totalDescountValue: discount,
                    productDescription: description,
                    totalValue: totalValue,
                });
                if (saleItems[0].caracteristicas && saleItems[0].caracteristicas.length > 0) {
                    saleItems[0].caracteristicas.forEach(async (caracteristica) => {
                        await VendaItemCaracteristica.create({
                            id_venda_item: newSaleItem.id,
                            id_produto_caracteristica: caracteristica.idProdutoCaracteristica,
                            codigo: caracteristica.codigo,
                            descricao: caracteristica.descricao,
                            fixo: caracteristica.fixo,
                            categoria: caracteristica.categoria,
                        });
                    });
                }
                if (saleItems[0].sub_itens && saleItems[0].sub_itens.length > 0) {
                    saleItems[0].sub_itens.forEach(async (subItem) => {
                        const produto = await PrimeProduto.find(subItem.id_produto);
                        const newSaleSubItem = await VendaSubItem.create({
                            idVenda: idSale,
                            idVendaItem: newSaleItem.id,
                            idProduto: subItem.id_produto,
                            quantidade: subItem.quantidade,
                            valorUnitario: subItem.valor,
                            valorTotal: subItem.total,
                            descricao: subItem.descricao,
                            codigo: Number(produto?.code),
                            observacao: subItem.observacao,
                        });
                        if (subItem.caracteristicas && subItem.caracteristicas.length > 0) {
                            subItem.caracteristicas.forEach(async (caracteristica) => {
                                await VendaItemCaracteristica.create({
                                    id_venda_sub_item: newSaleSubItem.id,
                                    id_produto_caracteristica: caracteristica.idProdutoCaracteristica,
                                    codigo: caracteristica.codigo,
                                    descricao: caracteristica.descricao,
                                    fixo: caracteristica.fixo,
                                    categoria: caracteristica.categoria,
                                });
                            });
                        }
                    });
                }
                data.id = newSale.id;
                data.status = newSale.status;
                data.itens.push({
                    id: newSaleItem.id,
                    id_produto: idProduct,
                });
            }
            return { data };
        }
    }
    async fillTheClosingCashDesk(idMovementCashDesk) {
        const findCloseCashDesks = await CaixaFechamento.query().where('id_caixa_movimento', idMovementCashDesk);
        const sales = await Venda.query()
            .preload('VendaFormaDePagamentoParcela', (subQuery) => {
            subQuery.preload('vendaFormaDePagamento', (subQueryVendaForPag) => {
                subQueryVendaForPag
                    .preload('formaDePagamento', (subQueryPayment) => {
                    subQueryPayment
                        .preload('formaDePagamentoTipo', (subQueryPaymentType) => {
                        subQueryPaymentType.select(['id', 'nome', 'cmp']);
                    })
                        .select(['id', 'id_forma_de_pagamento_tipo', 'description']);
                })
                    .select(['id', 'id_venda', 'id_forma_de_pagamento', 'installment_value']);
            });
        })
            .where('id_caixa_movimento', idMovementCashDesk)
            .select(['id', 'id_caixa_movimento', 'status', 'codigo']);
        const calcToAddThePaymentMethodValues = sales
            .flatMap((venda) => venda.VendaFormaDePagamentoParcela)
            .reduce((acc, pagamento) => {
            const { installmentValue, vendaFormaDePagamento, idFormaDePagamentoTipo } = pagamento;
            const existente = acc.find((item) => item.id === vendaFormaDePagamento.formaDePagamento.id_forma_de_pagamento_tipo);
            if (existente) {
                existente.value = Number(existente.value) + Number(installmentValue);
            }
            else {
                acc.push({
                    id: idFormaDePagamentoTipo,
                    name: vendaFormaDePagamento.formaDePagamento.description,
                    value: Number(installmentValue),
                });
            }
            return acc;
        }, []);
        if (calcToAddThePaymentMethodValues.length === 0) {
            return;
        }
        for (const record of calcToAddThePaymentMethodValues) {
            const existCloseCashDesk = findCloseCashDesks.find((item) => item.id_forma_de_pagamento_tipo === record.id);
            if (existCloseCashDesk) {
                existCloseCashDesk.valor_sistema = Number(record.value);
                existCloseCashDesk.sync_prime = false;
                await existCloseCashDesk.save();
            }
            else {
                await CaixaFechamento.create({
                    id_caixa_movimento: idMovementCashDesk,
                    id_forma_de_pagamento_tipo: record.id,
                    id_usuario: null,
                    valor_sistema: Number(record.value),
                    valor_informado: 0,
                    sync_prime: false,
                });
            }
        }
    }
    async removeSaleItem(idSale, statusSale, arrayIdSaleItem) {
        if (arrayIdSaleItem && arrayIdSaleItem.length > 0) {
            if (statusSale === 'PROVISORIO' || statusSale === 'ORCAMENTO') {
                const subItems = await VendaSubItem.query()
                    .whereIn('id_venda_item', arrayIdSaleItem)
                    .select('id');
                const subItemIds = subItems.map((item) => item.id);
                if (subItemIds.length > 0) {
                    await VendaItemCaracteristica.query().whereIn('id_venda_sub_item', subItemIds).delete();
                }
                await VendaItemCaracteristica.query().whereIn('id_venda_item', arrayIdSaleItem).delete();
                await VendaSubItem.query().whereIn('id_venda_item', arrayIdSaleItem).delete();
                await VendaItem.query().where('id_venda', idSale).whereIn('id', arrayIdSaleItem).delete();
            }
        }
    }
    async removeSalePaymentMethod(statusSale, arrayIdSalePaymentMethod) {
        if (arrayIdSalePaymentMethod && arrayIdSalePaymentMethod.length > 0) {
            if (statusSale === 'PROVISORIO' || statusSale === 'ORCAMENTO') {
                await VendaFormaDePagamentoParcela.query()
                    .whereIn('id_venda_forma_de_pagamento', arrayIdSalePaymentMethod)
                    .delete();
                await VendaFormaDePagamento.query().whereIn('id', arrayIdSalePaymentMethod).delete();
            }
        }
    }
    async updatedSaleItem(saleItems) {
        if (saleItems && saleItems.length > 0) {
            for (const saleItem of saleItems) {
                const searchSaleItem = await VendaItem.query().where('id', saleItem.id).first();
                if (searchSaleItem) {
                    searchSaleItem.saledQuantity = saleItem.quantidade;
                    searchSaleItem.unitaryValue = saleItem.valor;
                    searchSaleItem.totalValue = saleItem.total;
                    searchSaleItem.totalDescountValue = saleItem.desconto;
                    searchSaleItem.observacao = saleItem.observacao;
                    searchSaleItem.syncPrime = false;
                    await searchSaleItem.save();
                }
            }
        }
    }
    async createdSaleItem(saleItems, idSale) {
        if (saleItems && saleItems.length > 0) {
            for (const saleItem of saleItems) {
                await VendaItem.create({
                    idVenda: idSale,
                    idProduto: saleItem.produto.id,
                    saledQuantity: saleItem.quantidade,
                    unitaryValue: saleItem.valor,
                    totalValue: saleItem.total,
                    totalDescountValue: saleItem.desconto,
                    productDescription: saleItem.produto.shortName,
                    observacao: saleItem.observacao,
                }).then(async (item) => {
                    if (saleItem.caracteristicas && saleItem.caracteristicas.length > 0) {
                        saleItem.caracteristicas.forEach(async (caracteristica) => {
                            await VendaItemCaracteristica.create({
                                id_venda_item: item.id,
                                id_produto_caracteristica: caracteristica.idProdutoCaracteristica,
                                codigo: caracteristica.codigo,
                                descricao: caracteristica.descricao,
                                fixo: caracteristica.fixo,
                                categoria: caracteristica.categoria,
                            });
                        });
                    }
                    if (saleItem.sub_itens && saleItem.sub_itens.length > 0) {
                        saleItem.sub_itens.forEach(async (subItem) => {
                            const produto = await PrimeProduto.find(subItem.id_produto);
                            await VendaSubItem.create({
                                idVenda: idSale,
                                idVendaItem: item.id,
                                idProduto: subItem.id_produto,
                                quantidade: subItem.quantidade,
                                valorUnitario: subItem.valor,
                                valorTotal: subItem.total,
                                descricao: subItem.descricao,
                                codigo: Number(produto?.code),
                                observacao: subItem.observacao,
                            }).then(async (e) => {
                                if (subItem.caracteristicas && subItem.caracteristicas.length > 0) {
                                    subItem.caracteristicas.forEach(async (caracteristica) => {
                                        await VendaItemCaracteristica.create({
                                            id_venda_sub_item: e.id,
                                            id_produto_caracteristica: caracteristica.idProdutoCaracteristica,
                                            codigo: caracteristica.codigo,
                                            descricao: caracteristica.descricao,
                                            fixo: caracteristica.fixo,
                                            categoria: caracteristica.categoria,
                                        });
                                    });
                                }
                            });
                        });
                    }
                });
            }
        }
    }
    async createdSalePaymentMethod(salePaymentMethods, idSale) {
        if (salePaymentMethods && salePaymentMethods.length > 0) {
            for (const salePaymentMethod of salePaymentMethods) {
                await VendaFormaDePagamento.create({
                    idVenda: idSale,
                    idFormaDePagamento: salePaymentMethod.payment_method.id,
                    installmentValue: salePaymentMethod.value,
                    syncPrime: false,
                }).then(async (paymentMethod) => {
                    if (salePaymentMethod.installments && salePaymentMethod.installments.length > 0) {
                        salePaymentMethod.installments.forEach(async (installment) => {
                            await VendaFormaDePagamentoParcela.create({
                                idVenda: idSale,
                                idVendaFormaDePagamento: paymentMethod.id,
                                idFormaDePagamentoTipo: installment.id_payment_method_type,
                                idFormaDePagamentoCondicao: installment.id_payment_method_condition,
                                installmentDate: installment.date,
                                installmentValue: installment.value,
                                count: installment.count,
                                tax_percentage: installment.tax_percentage,
                                syncPrime: false,
                            });
                        });
                    }
                });
            }
        }
    }
    async createAssociateClient(idSaleClient) {
        if (idSaleClient && idSaleClient !== 0) {
        }
    }
    async createSaleClient(saleClient, idSale, idClientRegister) {
        let idClient = 0;
        if (saleClient) {
            if (idClientRegister === saleClient.id) {
                idClient = idClientRegister;
            }
            if (saleClient.id && saleClient.cliente && idClientRegister !== saleClient.cliente.id) {
                await VendaCliente.query().where('id', saleClient.id).delete();
            }
            if (saleClient.cliente &&
                saleClient.cliente.id &&
                saleClient &&
                idClientRegister !== saleClient.cliente.id) {
                const client = await Empresa.query().where('id', saleClient.cliente.id).first();
                if (client) {
                    idClient = client.id;
                    let address = null;
                    let contact = null;
                    const selectedAddress = await Endereco.query()
                        .where('id_fk', client.id)
                        .where('tipo_relacionamento', 'empresa')
                        .where('tipo', 'PRINCIPAL')
                        .first();
                    if (selectedAddress) {
                        address = selectedAddress;
                    }
                    else {
                        const selectedAlternativeAddress = await Endereco.query()
                            .where('id_fk', client.id)
                            .where('tipo_relacionamento', 'empresa')
                            .first();
                        if (selectedAlternativeAddress) {
                            address = selectedAlternativeAddress;
                        }
                    }
                    const selectedContact = await Contato.query()
                        .where('id_fk', client.id)
                        .where('tipo_relacionamento', 'empresa')
                        .where('tipo_contato', 'WHATSAPP')
                        .first();
                    if (selectedContact) {
                        contact = selectedContact;
                    }
                    else {
                        const selectedAlternativeContact = await Contato.query()
                            .where('id_fk', client.id)
                            .where('tipo_relacionamento', 'empresa')
                            .first();
                        if (selectedAlternativeContact) {
                            contact = selectedAlternativeContact;
                        }
                    }
                    await VendaCliente.create({
                        idVenda: idSale,
                        idEmpresa: client.id,
                        codigo: client.codigo,
                        nomeFantasia: client.nome_fantasia,
                        razaoSocial: client.razao_social,
                        apelido: client.apelido,
                        cnpjCpf: client.cnpj_cpf,
                        ieRg: client.ie_rg,
                        im: client.im,
                        email: client.email,
                        aniversario: null,
                        telefone: client.telefone,
                        tipoEndereco: address ? address.tipo : '',
                        cep: address ? address.cep : '',
                        uf: address ? address.uf : '',
                        cidade: address ? address.cidade : '',
                        bairro: address ? address.bairro : '',
                        logradouro: address ? address.logradouro : '',
                        numero: address ? address.numero : '',
                        complemento: address ? address.complemento : '',
                        codigoCidade: address ? address.codigo_cidade : '',
                        codigoUf: address ? address.codigo_uf : '',
                        referencia: address ? address.referencia : '',
                        contatoNome: contact ? contact.nome : '',
                        contatoEmail: contact ? contact.email : '',
                        contatoTelefone: contact ? contact.telefone : '',
                        contatoObservacao: contact ? contact.observacao : '',
                        tipoContato: contact ? contact.tipo_contato : '',
                    });
                }
            }
            return idClient;
        }
    }
    async criarArquivo(filePath, data) {
        try {
            await writeFile(filePath, data, 'utf-8');
            console.log('Arquivo criado com sucesso!');
            return true;
        }
        catch (err) {
            console.error('Erro ao criar o arquivo:', err);
            return false;
        }
    }
    async getAcbrMonitorIni(acbrPath) {
        const pathIni = path.join(acbrPath, 'ACBrMonitor.ini');
        if (!fs.existsSync(pathIni)) {
            return false;
        }
        const iniContent = await readFile(pathIni, 'utf-8');
        const regexSatEmitCnpj = /\[SATEmit\][\s\S]*?CNPJ=([\d\.\/-]+)/;
        const regexSatEmitIE = /\[SATEmit\][\s\S]*?IE=([\d\.\/-]+)/;
        const regexSatEmitIM = /\[SATEmit\][\s\S]*?IM=([\d\.\/-]+)/;
        const regexSatEmitIndRatISSQN = /\[SATEmit\][\s\S]*?IndRatISSQN=([\d\.\/-]+)/;
        const regexSatSwh = /\[SATSwH\][\s\S]*?CNPJ=([\d\.\/-]+)/;
        const regexSatSwhAssinatura = /\[SATSwH\][\s\S]*?Assinatura=([^\r\n]+)/;
        const regexSatNumeroCaixa = /\[SAT\][\s\S]*?NumeroCaixa=([\d\.\/-]+)/;
        const regexSatPathCFe = /\[SAT\][\s\S]*?PathCFe=([^\r\n]+)/;
        let satEmitCnpj = iniContent.match(regexSatEmitCnpj);
        const satEmitIE = iniContent.match(regexSatEmitIE);
        const satEmitIM = iniContent.match(regexSatEmitIM);
        const satEmitIndRatISSQN = iniContent.match(regexSatEmitIndRatISSQN);
        let satSwhCnpj = iniContent.match(regexSatSwh);
        const satAssinatura = iniContent.match(regexSatSwhAssinatura);
        const satNumeroCaixa = iniContent.match(regexSatNumeroCaixa);
        const satPathCFe = iniContent.match(regexSatPathCFe);
        const satEmitCnpjClean = satEmitCnpj?.[1]?.replace(/[^\d]/g, '');
        const satSwhCnpjClean = satSwhCnpj?.[1]?.replace(/[^\d]/g, '');
        return {
            satEmitCnpj: satEmitCnpjClean,
            satEmitIE: satEmitIE?.[1],
            satEmitIM: satEmitIM?.[1],
            satEmitIndRatISSQN: satEmitIndRatISSQN?.[1],
            satSwhCnpj: satSwhCnpjClean,
            satSwhAssinatura: satAssinatura?.[1],
            satNumeroCaixa: satNumeroCaixa?.[1].padStart(2, '0'),
            satPathCFe: satPathCFe?.[1],
        };
    }
    async createSaleFiscal(ctx) {
        const data = ctx.params;
        const idSale = data.id_sale;
        const idTerminal = data.id_terminal;
        const command = ctx.request.body().command;
        const sale = await Venda.query().where('id', idSale).first();
        const terminal = await Terminal.query().where('idterminal', idTerminal).first();
        const acbrCaminho = terminal?.acbr_caminho || '';
        const variables = await this.getAcbrMonitorIni(acbrCaminho);
        if (typeof variables !== 'object') {
            return ctx.response.status(400).json({
                success: false,
                message: 'Não foi possível criar o arquivo de venda. Variáveis inválidas.',
            });
        }
        const pathVendaIni = path.join(acbrCaminho, 'venda.ini');
        if (!fs.existsSync(pathVendaIni)) {
            return ctx.response.status(400).json({
                success: false,
                message: 'Não foi possível criar o arquivo de venda, path do arquivo venda.ini não encontrado.',
            });
        }
        const payloadIsValid = sale && terminal && command;
        if (!payloadIsValid) {
            return ctx.response.status(400).json({
                success: false,
                message: 'Não foi possível criar o arquivo de venda. Parâmetros inválidos.',
            });
        }
        const commandHeader = `[Identificacao]
CNPJ=${variables.satSwhCnpj}
signAC=${variables.satSwhAssinatura}
numeroCaixa=${variables.satNumeroCaixa}
[Emitente]
CNPJ=${variables.satEmitCnpj}
IE=${variables.satEmitIE}
IM=${variables.satEmitIM}
indRatISSQN=${variables.satEmitIndRatISSQN}\n`;
        const result = await this.criarArquivo(pathVendaIni, commandHeader + command);
        if (result) {
            return ctx.response.status(200).json({
                success: true,
                acbr_caminho: acbrCaminho,
                pathVendaIni: pathVendaIni,
                message: 'Arquivo de venda criado com sucesso!',
                variables: variables,
            });
        }
        else {
            return ctx.response.status(400).json({
                success: false,
                message: 'Não foi possível criar o arquivo de venda. Erro ao criar o arquivo.',
            });
        }
    }
    convertWindowsPathToWSLPath(windowsPath) {
        let wslPath = windowsPath.replace(/^([a-zA-Z]):\\/, (_match, driveLetter) => {
            return `/mnt/${driveLetter.toLowerCase()}/`;
        });
        wslPath = wslPath.replace(/\\/g, '/');
        if (wslPath.endsWith('/')) {
            wslPath = wslPath.slice(0, -1);
        }
        return wslPath;
    }
    async updateSaleFiscal(ctx) {
        const data = ctx.params;
        const idSale = data.id_sale;
        const variables = ctx.request.body().variables;
        const sale = await Venda.query().where('id', idSale).first();
        if (!sale) {
            return ctx.response.status(400).json({
                success: false,
                message: 'Não foi possível atualizar o arquivo de venda. Venda não encontrada.',
            });
        }
        let xml = '';
        let arquivoPath = variables.Arquivo;
        if (variables.sat_xml_path_cancelamento) {
            arquivoPath = variables.sat_xml_path_cancelamento;
        }
        try {
            xml = await readFile(arquivoPath, 'utf-8');
        }
        catch (error) {
            const wslPath = this.convertWindowsPathToWSLPath(arquivoPath);
            xml = await readFile(wslPath, 'utf-8');
        }
        if (variables.sat_xml_path_cancelamento) {
            await Venda.query().where('id', idSale).update({
                sat_xml_path_cancelamento: variables.sat_xml_path_cancelamento,
                sat_xml_cancelamento: xml,
                coo_cancelamento: variables.coo_cancelamento,
            });
        }
        else {
            await Venda.query().where('id', idSale).update({
                satArquivo: arquivoPath,
                satCodigoDeRetorno: variables.CodigoDeRetorno,
                satNumeroSessao: variables.NumeroSessao,
                satResultado: variables.Resultado,
                satRetornoStr: variables.RetornoStr,
                satNCFe: variables.NCFe,
                satXml: xml,
                coo: variables.cNF,
                sat_numero_serie: variables.nserieSAT,
            });
        }
        return ctx.response.status(200).json({
            success: true,
            message: 'Venda atualizada com sucesso!',
        });
    }
}
//# sourceMappingURL=venda_pdv_controller.js.map