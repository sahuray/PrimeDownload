import Endereco from '#models/endereco';
import Empresa from '#models/empresa';
import EmpresaDeliveryConfig from '#models/prime_empresa_delivery_config';
import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
const fieldsToShowCompany = [
    'id',
    'telefone',
    'cnpj_cpf',
    'ie_rg',
    'razao_social',
    'nome_fantasia',
    'origem',
    'deleted_at',
    'im',
    'email',
    'telefone',
    'codigo',
    'tipo',
    'origem',
    'aniversario',
    'contato',
];
const fieldsToShowContacts = [
    'id',
    'id_fk',
    'tipo_contato',
    'tipo_relacionamento',
    'email',
    'nome',
    'telefone',
    'observacao',
];
const fieldsToShowAddress = [
    'id',
    'id_fk',
    'tipo',
    'tipo_relacionamento',
    'uf',
    'cep',
    'bairro',
    'logradouro',
    'cidade',
    'numero',
];
export default class EmpresasController {
    async index(ctx) {
        const companies = await Empresa.query().whereNull('deleted_at').orderBy('id', 'desc');
        return ctx.response.json(companies);
    }
    async create(ctx) {
        const data = ctx.request.all();
        const companyExists = await Empresa.findBy('cnpj_cpf', data.cnpj_cpf);
        if (companyExists) {
            return ctx.response.status(400).json({
                error: 'JÁ EXISTE UMA EMPRESA CADASTRADA COM ESTE CNPJ/CPF',
            });
        }
        const company = await Empresa.create({
            grupo_id: 1,
            codigo: data.codigo,
            nome_fantasia: data.nome_fantasia,
            razao_social: data.nome_fantasia,
            apelido: data.nome_fantasia,
            cnpj_cpf: data.cnpj_cpf,
            ie_rg: data.ie_rg,
            email: data.email,
            contato: data.venda.contato,
            aniversario: data.aniversario,
            telefone: data.telefone,
            tipo: 'F',
            origem: 'C',
        });
        if (company.id) {
            await Endereco.create({
                cep: data.endereco.cep || 0,
                logradouro: data.endereco.logradouro,
                numero: data.endereco.numero,
                bairro: data.endereco.bairro,
                cidade: data.endereco.cidade,
                complemento: data.endereco.complemento,
                referencia: data.endereco.referencia,
                id_fk: company.id,
                tipo: 'ENTREGA',
                tipo_relacionamento: 'empresa',
            });
        }
        return ctx.response.json(company);
    }
    async createByPdv(ctx) {
        const data = ctx.request.body();
        const companyExists = await Empresa.findBy('cnpj_cpf', data.cnpj_cpf);
        if (companyExists) {
            return ctx.response.badRequest('JÁ EXISTE UMA EMPRESA CADASTRADA COM ESTE CNPJ/CPF');
        }
        const newCompany = await Empresa.create({
            cliente_athos: false,
            grupo_id: 1,
            nome_fantasia: data.name_fantasy,
            razao_social: data.business_name,
            apelido: data.name_fantasy,
            cnpj_cpf: data.cnpj_cpf,
            cnpj_aguardando: false,
            ie_rg: data.ie_rg,
            ie_aguardando: data.im_waiting,
            ie_isento: data.ie_free,
            im: data.im,
            im_aguardando: data.im_waiting,
            im_isento: data.im_free,
            email: data.email,
            telefone: data.telephone,
            tipo: data.type,
            sexo: data.gender,
            origem: 'C',
        });
        if (newCompany && newCompany.id) {
            const address = data.address;
            if (address.cep && address.code_uf && address.code_city) {
                await Endereco.create({
                    cep: address.cep || 0,
                    logradouro: address.street,
                    numero: address.number,
                    bairro: address.neighborhood,
                    cidade: address.city,
                    codigo_cidade: address.code_city,
                    complemento: address.complement,
                    uf: address.uf,
                    codigo_uf: address.code_uf,
                    id_fk: newCompany.id,
                    tipo: 'PRINCIPAL',
                    tipo_relacionamento: 'empresa',
                });
            }
        }
        return ctx.response.status(201);
    }
    async update(ctx) {
        const data = ctx.request.all();
        if (data.endereco) {
            const addressExists = await Endereco.query()
                .where('id_fk', data.id)
                .where('tipo_relacionamento', 'empresa')
                .where('cep', data.endereco.cep)
                .where('numero', data.endereco.numero)
                .whereNull('deleted_at')
                .first();
            if (addressExists) {
                addressExists.bairro = data.endereco.bairro;
                addressExists.cep = data.endereco.cep || 0;
                addressExists.cidade = data.endereco.cidade;
                addressExists.codigo_cidade = data.endereco.codigo_cidade;
                addressExists.complemento = data.endereco.complemento;
                addressExists.logradouro = data.endereco.logradouro;
                addressExists.numero = data.endereco.numero;
                addressExists.uf = data.endereco.uf;
                addressExists.referencia = data.endereco.referencia;
                addressExists.sync_prime = false;
                await addressExists.save();
            }
            else {
                const addressDelivery = await Endereco.query()
                    .where('id_fk', data.id)
                    .where('tipo_relacionamento', 'empresa')
                    .where('tipo', 'ENTREGA')
                    .whereNull('deleted_at')
                    .first();
                if (addressDelivery) {
                    addressDelivery.tipo = 'OUTROS';
                    await addressDelivery.save();
                }
                await Endereco.create({
                    id_fk: data.id,
                    tipo_relacionamento: 'empresa',
                    tipo: 'ENTREGA',
                    bairro: data.endereco.bairro,
                    cep: data.endereco.cep || 0,
                    cidade: data.endereco.cidade,
                    codigo_cidade: data.endereco.codigo_cidade,
                    complemento: data.endereco.complemento,
                    logradouro: data.endereco.logradouro,
                    numero: data.endereco.numero,
                    uf: data.endereco.uf,
                    referencia: data.endereco.referencia,
                    sync_prime: false,
                });
            }
        }
        const company = await Empresa.find(data.id);
        if (company) {
            company.aniversario = data.aniversario;
            company.email = data.email;
            company.contato = data.venda.contato;
            company.sync_prime = false;
            await company.save();
            return ctx.response.json(company);
        }
    }
    async selectCliente(ctx) {
        const data = ctx.request.only([
            'showInactive',
            'showResponsibleCpf',
            'selectedButton',
            'search',
            'orderBy',
            'order',
        ]);
        const companies = await Empresa.query()
            .if(data.selectedButton === 'fone' && data.search, (query) => {
            const searchClean = data.search.replace(/[^0-9]/g, '');
            query.where((builder) => {
                builder
                    .whereRaw(`
            regexp_replace(
              regexp_replace(
                regexp_replace(telefone, '[()]', '', 'g'),
                '-', '', 'g'
              ),
              ' ', '', 'g'
            ) ILIKE ?
            `, [`%${searchClean}%`])
                    .orWhereHas('contatos', (contactBuilder) => {
                    contactBuilder
                        .where('tipo_relacionamento', 'empresa')
                        .whereIn('tipo_contato', ['DELIVERY', 'OUTROS'])
                        .whereRaw(`
                regexp_replace(
                  regexp_replace(
                    regexp_replace(telefone, '[()]', '', 'g'),
                    '-', '', 'g'
                  ),
                  ' ', '', 'g'
                ) ILIKE ?
                `, [`%${searchClean}%`]);
                });
            });
        })
            .if(data.selectedButton === 'cnpjCpf' && data.search, (query) => {
            query.where('cnpj_cpf', 'ilike', `%${data.search}%`);
        })
            .if(data.selectedButton === 'ieRg' && data.search, (query) => {
            query.where('ie_rg', 'like', `%${data.search}%`);
        })
            .if(data.selectedButton === 'razaoCompleto' && data.search, (query) => {
            query.where('razao_social', data.search);
        })
            .if(data.selectedButton === 'razaoAproximado' && data.search, (query) => {
            const searchTerms = data.search.toLowerCase().split(' ');
            query.where((builder) => {
                searchTerms.forEach((term) => {
                    builder.whereRaw('LOWER(razao_social) LIKE ?', [`%${term}%`]);
                });
            });
        })
            .if(data.selectedButton === 'fantasiaCompleto' && data.search, (query) => {
            query.where('nome_fantasia', data.search);
        })
            .if(data.selectedButton === 'fantasiaAproximado' && data.search, (query) => {
            const searchTerms = data.search.toLowerCase().split(' ');
            query.where((builder) => {
                searchTerms.forEach((term) => {
                    builder.whereRaw('LOWER(nome_fantasia) LIKE ?', [`%${term}%`]);
                });
            });
        })
            .if(data.selectedButton === 'codigoCliente' && data.search, (query) => {
            query.where('id', data.search);
        })
            .where('origem', 'C')
            .if(!data.showInactive, (query) => {
            query.whereNull('deleted_at');
        })
            .if(data.showInactive, (query) => {
            query.whereNotNull('deleted_at');
        })
            .preload('enderecos', (subQuery) => {
            subQuery.select(fieldsToShowAddress);
        })
            .preload('contatos', (subQuery) => {
            subQuery.select(fieldsToShowContacts);
        })
            .select(fieldsToShowCompany)
            .orderBy(data.orderBy, data.order)
            .limit(100);
        return ctx.response.json(companies);
    }
    async filterClients(ctx) {
        const data = ctx.request.all();
        const filter = data.value;
        const companies = await Empresa.query()
            .if(filter, (subQuery) => {
            subQuery.whereILike('nome_fantasia', `%${filter}%`);
        })
            .where('origem', 'C')
            .select(fieldsToShowCompany)
            .limit(15);
        return ctx.response.json(companies);
    }
    async getDeliveryConfig(ctx) {
        const deliveryConfig = await EmpresaDeliveryConfig.query()
            .whereNull('deleted_at')
            .select('*')
            .first();
        return ctx.response.json(deliveryConfig);
    }
    async getIpServerCore(ctx) {
        const ipServerCore = await EmpresaPdvConfig.query()
            .whereNull('deleted_at')
            .select('ip_server_core')
            .first();
        return ctx.response.json(ipServerCore);
    }
}
//# sourceMappingURL=empresa_controller.js.map