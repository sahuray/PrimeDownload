import VendaItem from '#models/venda_item';
import Venda from '#models/venda';
import VendaSubItem from '#models/venda_sub_item';
import VendaCliente from '#models/venda_cliente';
import VendaItemCaracteristica from '#models/venda_item_caracteristica';
import PrimeVendaControleEstoque from '#models/prime_venda_controle_estoque';
import PrimeProdutoEstoque from '#models/prime_produto_estoque';
import SequenceController from './sequence_controller.js';
import CaixaMovimento from '#models/caixa_movimento';
export default class VendaController {
    async selectSale(ctx) {
        const data = ctx.request.all();
        const sales = await VendaItem.query()
            .preload('produto')
            .preload('venda')
            .whereHas('venda', (query) => {
            query
                .where('id_cliente', data.cliente_id)
                .where('status', 'FINALIZADO')
                .where('origem', 'DELIVERY');
        })
            .select('*');
        return ctx.response.json(sales);
    }
    async getSale(ctx) {
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const sale = await Venda.query()
            .where('id_empresa', sessionData.empresaId)
            .where('idUsuarioCriacao', Number(sessionData.idfuncionariousuario))
            .where('status', 'PROVISORIO_DELIVERY')
            .where('origem', 'DELIVERY')
            .preload('cliente', (qryCliente) => {
            qryCliente.preload('enderecos').preload('contatos');
        })
            .preload('vendaItem', (qryVendaItem) => {
            qryVendaItem
                .preload('produto')
                .preload('caracteristicas')
                .preload('subItens', (qrySubItens) => {
                qrySubItens.preload('caracteristicas');
            });
        })
            .preload('vendaCliente')
            .preload('taxaDeEntrega')
            .preload('motoboy')
            .preload('UsuarioCriacao')
            .preload('vendaFormaDePagamento')
            .select('*')
            .first();
        if (!sale) {
            return false;
        }
        const updatedAt = new Date(sale.updatedAt.toString());
        const agora = new Date();
        const diferencaEmMinutos = Math.floor((agora.getTime() - updatedAt.getTime()) / (1000 * 60));
        if (diferencaEmMinutos > 120) {
            await sale.merge({ status: 'SUSPENSO' }).save();
            return false;
        }
        return ctx.response.json(sale);
    }
    async salesCreationInProgress(ctx) {
        const data = ctx.request.all();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const vendaClienteData = {
            idEmpresa: data.id,
            nomeFantasia: data.nome_fantasia,
            razaoSocial: data.empresa?.razaoSocial || '',
            apelido: data.empresa?.apelido || '',
            cnpjCpf: data.empresa?.cnpjCpf || '',
            ieRg: data.empresa?.ieRg || '',
            im: data.empresa?.im || '',
            email: data.email || '',
            telefone: data.telefone || '',
            codigo: data.codigo,
            origem: data.empresa?.origem || '',
            aniversario: data.aniversario,
            contato: data.venda.contato || '',
            tipoEndereco: data.endereco?.tipo || '',
            cep: data.endereco?.cep || '',
            uf: data.endereco?.uf || '',
            cidade: data.endereco?.cidade || '',
            bairro: data.endereco?.bairro || '',
            logradouro: data.endereco?.logradouro || '',
            numero: data.endereco?.numero || '',
            complemento: data.endereco?.complemento || '',
            codigoCidade: data.endereco?.codigoCidade || '',
            codigoUf: data.endereco?.codigoUf || '',
            referencia: data.endereco?.referencia || '',
            contatoTelefone: data.telefone || '',
            contatoObservacao: 'ORIGEM: DELIVERY',
            tipoContato: data.tipo_contato || '',
            syncPrime: false,
        };
        const existingSale = await Venda.query()
            .where('id_empresa', sessionData.empresaId)
            .where('idUsuarioCriacao', Number(sessionData.idfuncionariousuario))
            .where('origem', 'DELIVERY')
            .where('status', 'PROVISORIO_DELIVERY')
            .first();
        if (existingSale && existingSale.idCliente === Number(data.id)) {
            await VendaCliente.query().where('id_venda', existingSale.id).update(vendaClienteData);
            existingSale.observacao = data.venda.observacao;
            existingSale.idTaxaDeEntrega = data.venda.taxa_de_entrega
                ? data.venda.taxa_de_entrega.id
                : null;
            await existingSale.save();
            return ctx.response.json(existingSale);
        }
        if (existingSale) {
            await existingSale.merge({ idCliente: Number(data.id) }).save();
            await VendaCliente.query().where('id_venda', existingSale.id).update(vendaClienteData);
            existingSale.observacao = data.venda.observacao;
            existingSale.idTaxaDeEntrega = data.venda.taxa_de_entrega
                ? data.venda.taxa_de_entrega.id
                : null;
            await existingSale.save();
            return ctx.response.json(existingSale);
        }
        const caixaMovimento = await CaixaMovimento.query()
            .where('idfuncionariousuarioabertura', sessionData.idfuncionariousuario)
            .where('status', 'ABE')
            .first();
        const passwordDelivery = await SequenceController.newPasswordDeliverySale(caixaMovimento.idcaixamovimento);
        const newSale = await Venda.create({
            senhaDelivery: passwordDelivery,
            idCliente: Number(data.id),
            idEmpresa: sessionData.empresaId,
            idUsuarioCriacao: Number(sessionData.idfuncionariousuario),
            idGrupo: 1,
            observacao: data.venda.observacao,
            idTaxaDeEntrega: data.venda.taxa_de_entrega ? data.venda.taxa_de_entrega.id : null,
            finalizado: false,
            idTerminal: terminal.idterminal || terminal.idTerminal,
            idCaixaMovimento: caixaMovimento.idcaixamovimento,
            status: 'PROVISORIO_DELIVERY',
            origem: 'DELIVERY',
        });
        await VendaCliente.create({
            idVenda: newSale.id,
            ...vendaClienteData,
        });
        return ctx.response.json(newSale);
    }
    async deleteSale(ctx) {
        const { id } = ctx.params;
        await Venda.query().where('id', id).update({ status: 'SUSPENSO' }).first();
        return ctx.response.status(200).json({
            message: 'VENDA CANCELADA COM SUCESSO',
        });
    }
    async updateSale(ctx) {
        const data = ctx.request.all();
        const sale = await Venda.query().where('id', data.venda.id).select('*').first();
        if (!sale) {
            return ctx.response.status(400).json({
                message: 'VENDA NÃO ENCONTRADA',
            });
        }
        sale.totalValue = data.venda.total_pedido;
        sale.valorTaxaDelivery = data.venda.taxa_entrega_valor;
        sale.totalDescountValue = data.venda.voucher;
        sale.valorProdutos = data.venda.total_produtos;
        sale.observacao = data.venda.observacao;
        await sale.save();
        return ctx.response.json(sale);
    }
    async getSaleItem(ctx) {
        const { id } = ctx.params;
        const vendaItems = await VendaItem.query().where('id_venda', id).select('*');
        return ctx.response.json(vendaItems);
    }
    async createSaleItem(ctx) {
        const data = ctx.request.all();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        try {
            const venda = await Venda.query()
                .where('id_empresa', sessionData.empresaId)
                .where('idUsuarioCriacao', Number(sessionData.idfuncionariousuario))
                .where('status', 'PROVISORIO_DELIVERY')
                .where('origem', 'DELIVERY')
                .first();
            if (!venda) {
                return ctx.response.status(400).json({
                    message: 'Nenhuma venda em andamento encontrada',
                });
            }
            let vendaItem;
            if (data.id) {
                vendaItem = await VendaItem.findOrFail(data.id);
                await vendaItem
                    .merge({
                    saledQuantity: data.quantidade,
                    unitaryValue: data.valor,
                    totalValue: data.total,
                    productDescription: data.descricao,
                    codigo: data.codigo,
                    observacao: data.observacao,
                })
                    .save();
                if (data.caracteristicas) {
                    await VendaItemCaracteristica.query().where('id_venda_item', vendaItem.id).delete();
                    for (const caracteristica of data.caracteristicas) {
                        await VendaItemCaracteristica.create({
                            id_venda_item: vendaItem.id,
                            id_produto_caracteristica: caracteristica.caracteristica_id || caracteristica.idProdutoCaracteristica,
                            codigo: caracteristica.codigo,
                            descricao: caracteristica.descricao,
                            categoria: caracteristica.categoria,
                            fixo: caracteristica.fixo,
                            sync_prime: false,
                        });
                    }
                }
                if (data.isDivided && data.divisionItems) {
                    const subItensExistentes = await VendaSubItem.query().where('id_venda_item', vendaItem.id);
                    const idsExistentes = subItensExistentes.map((item) => item.id);
                    const idsNovos = data.divisionItems
                        .filter((item) => item.id)
                        .map((item) => item.id);
                    const idsParaRemover = idsExistentes.filter((id) => !idsNovos.includes(id));
                    for (const idRemover of idsParaRemover) {
                        await VendaItemCaracteristica.query().where('id_venda_sub_item', idRemover).delete();
                        await VendaSubItem.query().where('id', idRemover).delete();
                    }
                    for (const subItem of data.divisionItems) {
                        const subItemData = {
                            idVendaItem: vendaItem.id,
                            idProduto: subItem.id_produto,
                            idVenda: venda.id,
                            status: 'ATIVO',
                            descricao: subItem.descricao,
                            quantidade: Number(subItem.quantidade),
                            valorUnitario: Number(subItem.valor),
                            valorTotal: Number(subItem.valor) * Number(subItem.quantidade),
                            codigo: subItem.codigo,
                            observacao: subItem.observacao,
                        };
                        let vendaSubItem;
                        if (subItem.id) {
                            vendaSubItem = await VendaSubItem.findOrFail(subItem.id);
                            await vendaSubItem.merge(subItemData).save();
                            if (subItem.caracteristicas) {
                                await VendaItemCaracteristica.query()
                                    .where('id_venda_sub_item', subItem.id)
                                    .delete();
                            }
                        }
                        else {
                            vendaSubItem = await VendaSubItem.create(subItemData);
                        }
                        if (subItem.caracteristicas) {
                            for (const caracteristica of subItem.caracteristicas) {
                                await VendaItemCaracteristica.create({
                                    id_venda_sub_item: vendaSubItem.id,
                                    id_produto_caracteristica: caracteristica.caracteristica_id || caracteristica.idProdutoCaracteristica,
                                    codigo: caracteristica.codigo,
                                    descricao: caracteristica.descricao,
                                    categoria: caracteristica.categoria,
                                    fixo: caracteristica.fixo,
                                    sync_prime: false,
                                });
                            }
                        }
                    }
                }
            }
            else {
                vendaItem = await VendaItem.create({
                    idVenda: venda.id,
                    idProduto: data.id_produto,
                    saledQuantity: data.quantidade,
                    unitaryValue: data.valor,
                    totalValue: data.total,
                    productDescription: data.descricao,
                    codigo: data.codigo,
                    observacao: data.observacao,
                    taxaDeEntrega: data.taxaDeEntrega || false,
                });
                if (data.caracteristicas) {
                    for (const caracteristica of data.caracteristicas) {
                        await VendaItemCaracteristica.create({
                            id_venda_item: vendaItem.id,
                            id_produto_caracteristica: caracteristica.caracteristica_id || caracteristica.idProdutoCaracteristica,
                            codigo: caracteristica.codigo,
                            descricao: caracteristica.descricao,
                            categoria: caracteristica.categoria,
                            fixo: caracteristica.fixo,
                            sync_prime: false,
                        });
                    }
                }
                if (data.isDivided && data.divisionItems) {
                    for (const subItem of data.divisionItems) {
                        const vendaSubItem = await VendaSubItem.create({
                            idVendaItem: vendaItem.id,
                            idProduto: subItem.id_produto,
                            idVenda: venda.id,
                            status: 'ATIVO',
                            descricao: subItem.descricao,
                            quantidade: Number(subItem.quantidade),
                            valorUnitario: Number(subItem.valor),
                            valorTotal: Number(subItem.valor) * Number(subItem.quantidade),
                            codigo: subItem.codigo,
                            observacao: subItem.observacao,
                        });
                        if (subItem.caracteristicas) {
                            for (const caracteristica of subItem.caracteristicas) {
                                await VendaItemCaracteristica.create({
                                    id_venda_sub_item: vendaSubItem.id,
                                    id_produto_caracteristica: caracteristica.caracteristica_id || caracteristica.idProdutoCaracteristica,
                                    codigo: caracteristica.codigo,
                                    descricao: caracteristica.descricao,
                                    categoria: caracteristica.categoria,
                                    fixo: caracteristica.fixo,
                                    sync_prime: false,
                                });
                            }
                        }
                    }
                }
            }
            return ctx.response.json(vendaItem);
        }
        catch (error) {
            return ctx.response.status(400).json({
                message: 'Erro ao criar item da venda',
                error: error.message,
            });
        }
    }
    async deleteSaleItem(ctx) {
        const { id } = ctx.params;
        try {
            const vendaItem = await VendaItem.findOrFail(id);
            await VendaItemCaracteristica.query().where('id_venda_item', id).delete();
            const subItens = await VendaSubItem.query().where('id_venda_item', id);
            for (const subItem of subItens) {
                await VendaItemCaracteristica.query().where('id_venda_sub_item', subItem.id).delete();
            }
            await VendaSubItem.query().where('id_venda_item', id).delete();
            await vendaItem.delete();
            return ctx.response.status(204);
        }
        catch (error) {
            return ctx.response.status(400).json({
                message: 'Erro ao excluir item da venda',
                error: error.message,
            });
        }
    }
    async updateCharacteristics(ctx) {
        const { id } = ctx.params;
        const { caracteristicas, isSubItem = false } = ctx.request.all();
        try {
            if (isSubItem) {
                await VendaItemCaracteristica.query().where('id_venda_sub_item', id).delete();
                const caracteristicasParaAdicionar = caracteristicas.map((car) => ({
                    id_venda_sub_item: id,
                    id_produto_caracteristica: car.caracteristica_id || car.idProdutoCaracteristica,
                    codigo: car.codigo,
                    descricao: car.descricao,
                    categoria: car.categoria,
                    fixo: car.fixo || false,
                }));
                await VendaItemCaracteristica.createMany(caracteristicasParaAdicionar);
                const subItemAtualizado = await VendaSubItem.query()
                    .where('id', id)
                    .preload('caracteristicas')
                    .firstOrFail();
                return ctx.response.json({
                    message: 'Características atualizadas com sucesso',
                    data: subItemAtualizado,
                });
            }
            else {
                await VendaItemCaracteristica.query().where('id_venda_item', id).delete();
                const caracteristicasParaAdicionar = caracteristicas.map((car) => ({
                    id_venda_item: id,
                    id_produto_caracteristica: car.caracteristica_id || car.idProdutoCaracteristica,
                    codigo: car.codigo,
                    descricao: car.descricao,
                    categoria: car.categoria,
                    fixo: car.fixo || false,
                }));
                await VendaItemCaracteristica.createMany(caracteristicasParaAdicionar);
                const itemAtualizado = await VendaItem.query()
                    .where('id', id)
                    .preload('caracteristicas')
                    .firstOrFail();
                return ctx.response.json({
                    message: 'Características atualizadas com sucesso',
                    data: itemAtualizado,
                });
            }
        }
        catch (error) {
            return ctx.response.status(400).json({
                message: 'Erro ao atualizar características',
                error: error.message,
            });
        }
    }
    async finalizeOrder(ctx) {
        const data = ctx.request.all();
        const sale = await Venda.query().where('id', data.venda.id).select('*').first();
        if (!sale) {
            return ctx.response.status(400).json({
                message: 'VENDA NÃO ENCONTRADA',
            });
        }
        sale.status = 'PROVISORIO';
        await sale.save();
        return ctx.response.json(sale);
    }
    async getOrder(ctx) {
        const data = ctx.request.all();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const sale = await Venda.query()
            .if(data.search && data.type === 'id', (query) => query.where('id', data.search))
            .if(data.search && data.type === 'senhaDelivery', (query) => query.where('senha_delivery', data.search))
            .where('id_empresa', sessionData.empresaId)
            .where('idUsuarioCriacao', Number(sessionData.idfuncionariousuario))
            .where('status', data.status)
            .where('origem', 'DELIVERY')
            .select('*')
            .preload('cliente', (qryCliente) => {
            qryCliente.preload('enderecos').preload('contatos');
        })
            .preload('vendaItem', (qryVendaItem) => {
            qryVendaItem
                .preload('produto')
                .preload('caracteristicas')
                .preload('subItens', (qrySubItens) => {
                qrySubItens.preload('caracteristicas');
            });
        })
            .preload('vendaFormaDePagamento', (qryVendaFormaDePagamento) => {
            qryVendaFormaDePagamento.preload('formaDePagamento', (qryFormaDePagamento) => {
                qryFormaDePagamento.preload('formaDePagamentoTipo');
                qryFormaDePagamento.preload('formaDePagamentoCondicao');
                qryFormaDePagamento.preload('contaBancaria');
                qryFormaDePagamento.preload('bandeira');
            });
        })
            .preload('vendaCliente')
            .preload('motoboy')
            .preload('UsuarioCriacao')
            .select('*')
            .orderBy(data.orderBy, data.order);
        return ctx.response.json(sale);
    }
    async getSaleObservation(ctx) {
        const { id } = ctx.params;
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const sale = await Venda.query()
            .where('id_empresa', sessionData.empresaId)
            .where('idUsuarioCriacao', Number(sessionData.idfuncionariousuario))
            .where('status', 'FINALIZADO')
            .where('origem', 'DELIVERY')
            .where('id_cliente', id)
            .select('observacao')
            .orderBy('updatedAt', 'desc')
            .first();
        return ctx.response.json(sale);
    }
    async updateOrder(ctx) {
        const data = ctx.request.all();
        const { id } = ctx.params;
        const sale = await Venda.query().where('id', id).select('*').first();
        if (!sale) {
            return ctx.response.status(400).json({
                message: 'VENDA NÃO ENCONTRADA',
            });
        }
        sale.status = data.status;
        sale.motivoCancelamento = data.motivo || null;
        if (data.status === 'CANCELADO') {
            if (data.voltaEstoque) {
                const vendaItens = await VendaItem.query().where('id_venda', sale.id).select('*');
                for (const vendaItem of vendaItens) {
                    const estoque = await PrimeProdutoEstoque.query()
                        .where('id_produto', vendaItem.idProduto)
                        .where('main_inventory', true)
                        .select('*')
                        .first();
                    if (estoque) {
                        await PrimeVendaControleEstoque.create({
                            id_estoque: estoque.id,
                            tipo: 'addition',
                            id_estoque_prime: estoque.id_prime,
                            quantidade: vendaItem.saledQuantity,
                        });
                    }
                }
            }
        }
        if (data.idMotoboy) {
            sale.idMotoboy = data.idMotoboy;
        }
        await sale.save();
        return ctx.response.json(sale);
    }
    async getSaleCore(ctx) {
        const data = ctx.request.all();
        const sale = await Venda.query()
            .where('id_empresa', data.terminal.idEmpresa)
            .where('e_orcamento', data.e_orcamento)
            .if(data.numeroVenda, (query) => query.where('id', data.numeroVenda))
            .if(data.numeroCupom, (query) => query.where('coo', data.numeroCupom))
            .if(data.formasPagamento?.length > 0, (query) => {
            query.whereHas('vendaFormaDePagamento', (qryVendaFormaDePagamento) => {
                qryVendaFormaDePagamento.whereHas('formaDePagamento', (qryFormaDePagamento) => {
                    qryFormaDePagamento.whereHas('formaDePagamentoTipo', (qryFormaDePagamentoTipo) => {
                        qryFormaDePagamentoTipo.whereIn('id', data.formasPagamento);
                    });
                });
            });
        })
            .if(data.cliente, (query) => {
            query.whereHas('vendaCliente', (qryVendaCliente) => {
                qryVendaCliente.where('nome_fantasia', 'ilike', `%${data.cliente}%`);
            });
        })
            .if(data.vendedor, (query) => {
            query.whereHas('vendedor', (qryVendedor) => {
                qryVendedor.where('nome', data.vendedor);
            });
        })
            .if(data.periodoDesde && data.periodoAte, (query) => {
            query.whereBetween('createdAt', [data.periodoDesde, data.periodoAte]);
        })
            .if(data.status?.length > 0, (query) => {
            query.whereIn('status', data.status);
        })
            .if(data.valorMinimo, (query) => {
            query.where('totalValue', '>=', data.valorMinimo);
        })
            .if(data.valorMaximo, (query) => {
            query.where('totalValue', '<=', data.valorMaximo);
        })
            .preload('vendaItem', (qryVendaItem) => {
            qryVendaItem
                .preload('produto')
                .preload('caracteristicas')
                .preload('subItens', (qrySubItens) => {
                qrySubItens.preload('caracteristicas');
            });
        })
            .preload('vendaCliente')
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('cliente', (qryCliente) => {
            qryCliente.preload('enderecos').preload('contatos');
        })
            .preload('terminal', (qryTerminal) => {
            qryTerminal.preload('empresa');
        })
            .preload('vendaFormaDePagamento', (qryVendaFormaDePagamento) => {
            qryVendaFormaDePagamento.preload('formaDePagamento', (qryFormaDePagamento) => {
                qryFormaDePagamento.preload('formaDePagamentoTipo');
            });
        })
            .select('*')
            .limit(data.limiteVendas);
        return ctx.response.json(sale);
    }
}
//# sourceMappingURL=venda_delivery_controller.js.map