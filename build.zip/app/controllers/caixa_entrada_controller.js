import CaixaEntrada from '#models/caixa_entrada';
export default class CaixaEntradaController {
    async create({ request, response }) {
        const data = request.only(['datalancamento', 'horalancamento', 'valor']);
        await CaixaEntrada.create(data);
        response.ok({ message: 'Caixa entrada criado com sucesso' });
    }
}
//# sourceMappingURL=caixa_entrada_controller.js.map