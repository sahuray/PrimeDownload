import Contato from '#models/contato';
import Empresa from '#models/empresa';
export default class ContatoController {
    async selectContactCompany(ctx) {
        const data = ctx.request.all();
        const company = await Empresa.find(data.empresa_id);
        const contacts = await Contato.query()
            .where('id_fk', data.empresa_id)
            .where('tipo_relacionamento', 'empresa')
            .whereIn('tipo_contato', ['DELIVERY', 'OUTROS'])
            .whereNull('deleted_at')
            .orderBy('id', 'desc')
            .select('*');
        let newContacts = [];
        for (const contact of contacts) {
            newContacts.push(contact);
        }
        if (company?.telefone) {
            newContacts.push({
                id: 0,
                id_fk: company?.id,
                tipo_relacionamento: 'empresa',
                telefone: company?.telefone,
                tipoContato: 'PRINCIPAL',
                nome: company?.nome_fantasia,
            });
        }
        return ctx.response.json(newContacts);
    }
    async createContactCompany(ctx) {
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const data = ctx.request.all();
        if (data.tipoContato === 'DELIVERY') {
            const contactExists = await Contato.query()
                .where('id_fk', data.empresa_id)
                .where('tipo_relacionamento', 'empresa')
                .where('tipo_contato', 'DELIVERY')
                .whereNull('deleted_at')
                .first();
            if (contactExists) {
                contactExists.tipo_contato = 'OUTROS';
                await contactExists.save();
            }
        }
        const contact = await Contato.create({
            id_fk: data.empresa_id,
            tipo_relacionamento: 'empresa',
            telefone: data.telefone,
            tipo_contato: data.tipoContato,
            nome: sessionData.usuario,
            observacao: 'ORIGEM: DELIVERY',
            sync_prime: false,
        });
        return ctx.response.json(contact);
    }
    async destroyContactCompany(ctx) {
        const data = ctx.request.all();
        const contact = await Contato.find(data.id);
        await contact?.delete();
        return ctx.response.json({ message: 'CONTATO EXCLUÍDO COM SUCESSO' });
    }
    async updateContactCompany(ctx) {
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const data = ctx.request.all();
        const contact = await Contato.find(data.id);
        if (!contact) {
            return ctx.response.status(404).json({ message: 'CONTATO NÃO ENCONTRADO' });
        }
        if (data.tipoContato === 'DELIVERY') {
            const contactExists = await Contato.query()
                .where('id_fk', contact.id_fk)
                .where('tipo_relacionamento', 'empresa')
                .where('tipo_contato', 'DELIVERY')
                .whereNot('id', contact.id)
                .whereNull('deleted_at')
                .first();
            if (contactExists) {
                contactExists.tipo_contato = 'OUTROS';
                await contactExists.save();
            }
        }
        contact.nome = sessionData.usuario;
        contact.telefone = data.telefone;
        contact.observacao = 'ORIGEM: DELIVERY';
        contact.tipo_contato = data.tipoContato;
        contact.sync_prime = false;
        await contact.save();
        return ctx.response.json(contact);
    }
}
//# sourceMappingURL=contato_controller.js.map