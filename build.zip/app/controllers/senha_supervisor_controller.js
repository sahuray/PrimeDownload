import FuncionarioUsuario from '#models/funcionario_usuario';
import CryptoJS from 'crypto-js';
export default class SenhaSupervisorsController {
    async check({ request, response }) {
        const { senha } = request.body();
        const senhaSupervisor = await FuncionarioUsuario.findBy('password_special', CryptoJS.SHA256(senha).toString());
        if (!senhaSupervisor) {
            return response.status(401).json({ message: 'Senha inválida' });
        }
        return response.status(200).json({ message: 'Senha válida' });
    }
}
//# sourceMappingURL=senha_supervisor_controller.js.map