import CaixaMovimentoSaida from '#models/caixa_movimento_saida';
import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
export default class CaixaMovimentoSaidaController {
    async store({ request, response }) {
        const body = request.body();
        const newExitCashDesk = await CaixaMovimentoSaida.create({
            id_caixa_movimento: body.idcaixamovimento,
            id_forma_pagamento_tipo: body.idformapagamento,
            id_funcionario_usuario: body.idfuncionariousuario,
            valor: body.valor,
            descricao: body.descricao,
            tipo: body.tipo,
            horaemissao: body.horaemissao,
            dataemissao: body.dataemissao,
            sangria: body.sangria,
            sync_prime: false,
        });
        const findExitCashDesk = await CaixaMovimentoSaida.query()
            .preload('formaDePagTipo', (query) => query.select('nome'))
            .preload('usuario', (query) => query.select('usuario'))
            .where('id', newExitCashDesk.id)
            .first();
        return response.json(findExitCashDesk);
    }
    async index({ response, params }) {
        const { idcaixamovimento } = params;
        const data = await CaixaMovimentoSaida.query()
            .preload('formaDePagTipo', (query) => query.select('nome'))
            .preload('usuario', (query) => query.select('usuario'))
            .where('id_caixa_movimento', idcaixamovimento);
        response.ok(data);
    }
    async especieSaida({ response }) {
        const paymentMethodTypes = await FormaDePagamentoTipo.query().where('cmp', '01');
        return response.json(paymentMethodTypes);
    }
}
//# sourceMappingURL=caixa_movimento_saida_controller.js.map