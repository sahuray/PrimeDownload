import CaixaMovimentoSaida from '#models/caixa_movimento_saida';
import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
export default class CaixaMovimentoSaidaController {
    async store({ request, response }) {
        const { idcaixamovimento, idformapagamento, idfuncionariousuario, valor, descricao, sangria, tipo, dataemissao, horaemissao, } = request.only([
            'idcaixamovimento',
            'idformapagamento',
            'idfuncionariousuario',
            'valor',
            'descricao',
            'sangria',
            'tipo',
            'dataemissao',
            'horaemissao',
        ]);
        const saida = await CaixaMovimentoSaida.create({
            idcaixamovimento,
            idformapagamento,
            idfuncionariousuario,
            valor,
            descricao,
            sangria,
            tipo,
            dataemissao,
            horaemissao,
        });
        const data = await CaixaMovimentoSaida.query()
            .preload('formaDePagamento', (query) => query.select('description'))
            .preload('funcionario', (query) => query.select('usuario'))
            .where('idcaixamovimentosaida', saida.idcaixamovimentosaida);
        if (data.length) {
            response.ok(data[0]);
        }
        else {
            response.ok(saida);
        }
    }
    async index({ response, params }) {
        const { idcaixamovimento } = params;
        const data = await CaixaMovimentoSaida.query()
            .preload('formaDePagamento', (query) => query.select('description'))
            .preload('funcionario', (query) => query.select('usuario'))
            .where('idcaixamovimento', idcaixamovimento);
        response.ok(data);
    }
    async especieSaida({ response }) {
        const data = await FormaDePagamentoTipo.query().preload('formaDePagamento').where('cmp', '01');
        if (data.length) {
            response.ok(data.flatMap((item) => item.formaDePagamento));
        }
        else {
            response.notFound({ message: 'Nenhuma forma de pagamento encontrada' });
        }
    }
}
//# sourceMappingURL=caixa_movimento_saida_controller.js.map