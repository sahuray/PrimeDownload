import CaixaMovimentoSaida from '#models/caixa_entrada_e_saida';
import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
import CaixaFechamento from '#models/caixa_fechamento';
import CaixaMovimento from '#models/caixa_movimento';
export default class CaixaMovimentoSaidaController {
    async store({ request, response }) {
        const body = request.body();
        const idMovementCashDesk = body.idcaixamovimento;
        const type = body.tipo;
        const value = Number(body.valor);
        const idType = await FormaDePagamentoTipo.query()
            .whereNull('deleted_at')
            .where('cmp', '01')
            .select(['id'])
            .first();
        if (!idType) {
            return response.badRequest('NÃO POSSUI FORMA DE PAGAMENTO TIPO DINHEIRO CADASTRADO!');
        }
        const newExitCashDesk = await CaixaMovimentoSaida.create({
            id_caixa_movimento: idMovementCashDesk,
            id_forma_pagamento_tipo: idType.id,
            id_funcionario_usuario: body.idfuncionariousuario,
            valor: value,
            descricao: body.descricao,
            tipo: type,
            horaemissao: body.horaemissao,
            dataemissao: body.dataemissao,
            sangria: body.sangria,
            sync_prime: false,
        });
        const returnFormPagType = await FormaDePagamentoTipo.query()
            .where('id', idType.id)
            .whereNull('deleted_at')
            .select(['id', 'cmp', 'nome'])
            .first();
        if (returnFormPagType && body.idcaixamovimento) {
            if (returnFormPagType.cmp === '01' || returnFormPagType.nome === 'DINHEIRO') {
                const findCashDesk = await CaixaMovimento.query()
                    .where('idcaixamovimento', body.idcaixamovimento)
                    .first();
                if (findCashDesk) {
                    if (body.tipo === 'ENTRADA') {
                        findCashDesk.suprimentoatual = Number(findCashDesk.suprimentoatual) + body.valor;
                    }
                    else {
                        findCashDesk.suprimentoatual = Number(findCashDesk.suprimentoatual) - body.valor;
                    }
                    await findCashDesk.save();
                }
                const returnCloseCashDesk = await CaixaFechamento.query()
                    .where('id_forma_de_pagamento_tipo', idType.id)
                    .first();
                if (returnCloseCashDesk) {
                    if (body.tipo === 'ENTRADA') {
                        returnCloseCashDesk.valor_sistema =
                            Number(returnCloseCashDesk.valor_sistema) + Number(body.valor);
                    }
                    else {
                        returnCloseCashDesk.valor_sistema =
                            Number(returnCloseCashDesk.valor_sistema) - Number(body.valor);
                    }
                    returnCloseCashDesk.sync_prime = false;
                    await returnCloseCashDesk.save();
                }
                else {
                    await CaixaFechamento.create({
                        id_caixa_movimento: body.idcaixamovimento,
                        id_forma_de_pagamento_tipo: idType.id,
                        id_usuario: body.idfuncionariousuario,
                        valor_sistema: Number(body.valor),
                        valor_informado: 0,
                        sync_prime: false,
                    });
                }
            }
        }
        const findExitCashDesk = await CaixaMovimentoSaida.query()
            .preload('formaDePagTipo', (query) => query.select('nome'))
            .preload('usuario', (query) => query.select('usuario'))
            .where('id', newExitCashDesk.id)
            .first();
        return response.json(findExitCashDesk);
    }
    async index({ response, params }) {
        const { idcaixamovimento } = params;
        const data = await CaixaMovimentoSaida.query()
            .preload('formaDePagTipo', (query) => query.select('nome'))
            .preload('usuario', (query) => query.select('usuario'))
            .where('id_caixa_movimento', idcaixamovimento);
        response.ok(data);
    }
    async especieSaida({ response }) {
        const paymentMethodTypes = await FormaDePagamentoTipo.query()
            .whereNull('deleted_at')
            .where('cmp', '01');
        return response.json(paymentMethodTypes);
    }
}
//# sourceMappingURL=caixa_movimento_saida_controller.js.map