import Impressora from '#models/impressora';
import ImpressoraConfiguracao from '#models/impressora_configuracao';
import Departamento from '#models/departamento';
export default class ImpressoraController {
    async getPrinterConfig({ request, response }) {
        const data = request.all();
        const impressora = await ImpressoraConfiguracao.query()
            .preload('impressoras', (query) => {
            query.preload('departamento');
        })
            .if(data && data.nomeComputador, (query) => {
            query.where('nomeComputador', data.nomeComputador).first();
        })
            .select('*')
            .limit(10);
        const departamentos = await Departamento.query().whereNull('deletedAt').select('*').limit(10);
        return response.json({ impressora, departamentos });
    }
    async createOrUpdatePrinterConfig({ request, response }) {
        const data = request.all();
        let impressora = null;
        if (data.id) {
            impressora = await ImpressoraConfiguracao.find(data.id);
            if (!impressora) {
                return response.status(404).json({ message: 'IMPRESSORA NÃO ENCONTRADA' });
            }
            impressora.nomeConfiguracao = data.nomeConfiguracao;
            impressora.nomeComputador = data.nomeComputador;
            await impressora.save();
        }
        else {
            const existingConfig = await ImpressoraConfiguracao.query()
                .where('nomeComputador', data.nomeComputador)
                .first();
            if (existingConfig) {
                return response.status(400).json({
                    message: 'JÁ EXISTE UMA CONFIGURAÇÃO CADASTRADA PARA ESTE COMPUTADOR',
                });
            }
            impressora = await ImpressoraConfiguracao.create({
                nomeConfiguracao: data.nomeConfiguracao,
                nomeComputador: data.nomeComputador,
            });
        }
        return response.json(impressora);
    }
    async createOrUpdatePrinter({ request, response }) {
        const data = request.all();
        let impressora = null;
        const existingPrinters = await Impressora.query().where('idImpressoraConfiguracao', data.idImpressoraConfiguracao);
        if (existingPrinters.length === 0) {
            data.impressoraPadrao = true;
        }
        else if (!data.impressoraPadrao) {
            const hasAnotherDefault = await Impressora.query()
                .where('idImpressoraConfiguracao', data.idImpressoraConfiguracao)
                .where('impressoraPadrao', true)
                .where('id', '!=', data.id || 0)
                .first();
            if (!hasAnotherDefault) {
                data.impressoraPadrao = true;
            }
        }
        if (data.impressoraPadrao) {
            await Impressora.query()
                .where('idImpressoraConfiguracao', data.idImpressoraConfiguracao)
                .where('id', '!=', data.id || 0)
                .update({ impressoraPadrao: false });
        }
        if (data.id) {
            impressora = await Impressora.find(data.id);
            if (!impressora) {
                return response.status(404).json({ message: 'IMPRESSORA NÃO ENCONTRADA' });
            }
            impressora.nomeImpressora = data.impressora;
            impressora.colunas = data.colunas;
            impressora.idDepartamento = data.departamentos ? data.departamentos.id : null;
            impressora.impressoraPadrao = data.impressoraPadrao;
            impressora.apelido = data.apelido;
            await impressora.save();
        }
        else {
            impressora = await Impressora.create({
                idImpressoraConfiguracao: data.idImpressoraConfiguracao,
                nomeImpressora: data.impressora,
                colunas: data.colunas,
                idDepartamento: data.departamentos ? data.departamentos.id : null,
                impressoraPadrao: data.impressoraPadrao,
                apelido: data.apelido,
            });
        }
        const impressoras = await Impressora.query()
            .where('idImpressoraConfiguracao', data.idImpressoraConfiguracao)
            .preload('departamento')
            .select('*');
        return response.json({ impressoras });
    }
    async deletePrinter({ params, response }) {
        const impressora = await Impressora.find(params.id);
        await impressora?.delete();
        return response.json({ message: 'IMPRESSORA DELETADA COM SUCESSO' });
    }
}
//# sourceMappingURL=impressora_configuracao_controller.js.map