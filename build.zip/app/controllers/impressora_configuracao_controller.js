import Impressora from '#models/impressora';
import ImpressoraConfiguracao from '#models/impressora_configuracao';
import Departamento from '#models/departamento';
export default class ImpressoraController {
    async getPrinterConfig({ request, response }) {
        const data = request.all();
        const impressora = await ImpressoraConfiguracao.query()
            .preload('impressoras', (query) => {
            query.orderBy('updatedAt', 'desc').preload('departamento');
        })
            .if(data && data.nomeTerminal, (query) => {
            query.where('nomeTerminal', data.nomeTerminal);
        })
            .if(data && data.idTerminal, (query) => {
            const idTerminal = Number(data.idTerminal);
            query.where('idTerminal', idTerminal);
        })
            .select('*');
        const departamentos = await Departamento.query().whereNull('deletedAt').select('*').limit(10);
        return response.json({ impressora, departamentos });
    }
    async createOrUpdatePrinterConfig({ request, response }) {
        const data = request.all();
        let impressora = null;
        if (data.id) {
            impressora = await ImpressoraConfiguracao.find(data.id);
            if (!impressora) {
                return response.status(404).json({ message: 'IMPRESSORA NÃO ENCONTRADA' });
            }
            impressora.nomeConfiguracao = data.nomeConfiguracao;
            impressora.nomeTerminal = data.nomeTerminal;
            impressora.idTerminal = data.idTerminal;
            await impressora.save();
        }
        else {
            const existingConfig = await ImpressoraConfiguracao.query()
                .where('nomeTerminal', data.nomeTerminal)
                .first();
            if (existingConfig) {
                return response.status(400).json({
                    message: 'JÁ EXISTE UMA CONFIGURAÇÃO CADASTRADA PARA ESTE TERMINAL',
                });
            }
            impressora = await ImpressoraConfiguracao.create({
                nomeConfiguracao: data.nomeConfiguracao,
                nomeTerminal: data.nomeTerminal,
                idTerminal: data.idTerminal,
            });
        }
        return response.json(impressora);
    }
    async createOrUpdatePrinter({ request, response }) {
        const data = request.all();
        let impressora = null;
        const existingPrinters = await Impressora.query().where('idImpressoraConfiguracao', data.idImpressoraConfiguracao);
        if (existingPrinters.length === 0) {
            data.impressoraPadrao = true;
        }
        else if (!data.impressoraPadrao) {
            const hasAnotherDefault = await Impressora.query()
                .where('idImpressoraConfiguracao', data.idImpressoraConfiguracao)
                .where('impressoraPadrao', true)
                .where('id', '!=', data.id || 0)
                .first();
            if (!hasAnotherDefault) {
                data.impressoraPadrao = true;
            }
        }
        if (data.impressoraPadrao) {
            await Impressora.query()
                .where('idImpressoraConfiguracao', data.idImpressoraConfiguracao)
                .where('id', '!=', data.id || 0)
                .update({ impressoraPadrao: false });
        }
        if (data.id) {
            impressora = await Impressora.find(data.id);
            if (!impressora) {
                return response.status(404).json({ message: 'IMPRESSORA NÃO ENCONTRADA' });
            }
            impressora.nomeImpressora = data.impressora;
            impressora.colunas = data.colunas;
            impressora.idDepartamento = data.departamentos ? data.departamentos.id : null;
            impressora.impressoraPadrao = data.impressoraPadrao;
            impressora.apelido = data.apelido;
            impressora.codigoGaveta = data.codigoGaveta;
            await impressora.save();
        }
        else {
            impressora = await Impressora.create({
                idImpressoraConfiguracao: data.idImpressoraConfiguracao,
                nomeImpressora: data.impressora,
                colunas: data.colunas,
                idDepartamento: data.departamentos ? data.departamentos.id : null,
                impressoraPadrao: data.impressoraPadrao,
                apelido: data.apelido,
                codigoGaveta: data.codigoGaveta,
            });
        }
        const impressoras = await Impressora.query()
            .where('idImpressoraConfiguracao', data.idImpressoraConfiguracao)
            .preload('departamento')
            .orderBy('updatedAt', 'desc')
            .select('*');
        return response.json({ impressoras });
    }
    async deletePrinter({ params, response }) {
        const impressora = await Impressora.find(params.id);
        await impressora?.delete();
        return response.json({ message: 'IMPRESSORA DELETADA COM SUCESSO' });
    }
}
//# sourceMappingURL=impressora_configuracao_controller.js.map