import amqp from 'amqplib';
import PrimeFilaIfood from '#models/prime_fila_ifood';
import primeEmpresaDeliveryConfig from '#models/prime_empresa_delivery_config';
import Sale from '#models/venda';
import SaleClient from '#models/venda_cliente';
import SaleItem from '#models/venda_item';
import SaleSubItem from '#models/venda_sub_item';
import SalePaymentMethod from '#models/venda_forma_de_pagamento';
import Client from '#models/empresa';
import Company from '#models/empresa';
import Address from '#models/endereco';
import Product from '#models/prime_produto';
import Flag from '#models/bandeira';
import Condition from '#models/forma_de_pagamento_condicao';
import Type from '#models/forma_de_pagamento_tipo';
import PaymentMethod from '#models/forma_de_pagamento';
import { DateTime } from 'luxon';
import axios from 'axios';
import CaixaMovimento from '#models/caixa_movimento';
import SequenceController from './sequence_controller.js';
import DeliveryFee from '#models/taxa_de_entrega';
const RABBITMQ_URL = process.env.RABBITMQ_URL || 'amqp://localhost';
export default class IfoodsController {
    async syncFilaConsultaIfood() {
        try {
            const configEmpresa = await primeEmpresaDeliveryConfig
                .query()
                .select('id_athos_prime_ifood')
                .first();
            if (!configEmpresa) {
                console.error('Configuração da empresa não encontrada');
                return;
            }
            const connection = await amqp.connect(RABBITMQ_URL);
            const channel = await connection.createChannel();
            const queue = `ifood-orders-queue-${configEmpresa.id_athos_prime_ifood}`;
            await channel.assertQueue(queue, { durable: true });
            channel.consume(queue, async (msg) => {
                if (msg) {
                    try {
                        const order = JSON.parse(msg.content.toString());
                        for (const item of order) {
                            await PrimeFilaIfood.create({
                                conteudoJson: item,
                                status: 'PENDENTE',
                                tentativas: 0,
                                mensagemErro: undefined,
                                dataProcessamento: null,
                                funcao: 'syncFilaConsultaIfood',
                            });
                        }
                        channel.ack(msg);
                    }
                    catch (error) {
                        console.error('Erro ao processar a mensagem:', error);
                        channel.nack(msg, false, false);
                    }
                }
            });
            setTimeout(async () => {
                console.log('🚀 ~ channel.consume ~ FECHANDO CONEXÃO');
                await channel.close();
                await connection.close();
                await IfoodsController.processIfoodOrderQueue();
            }, 5000);
        }
        catch (error) {
            console.error('Erro ao iniciar o consumer:', error);
            process.exit(1);
        }
    }
    static async processIfoodOrderQueue() {
        console.log('🚀 ~ IfoodsController ~ processIfoodOrderQueue ~ processando fila');
        try {
            const pedidosPendentes = await PrimeFilaIfood.query()
                .where('status', '!=', 'PROCESSADO')
                .where('tentativas', '<', 1)
                .where('funcao', 'syncFilaConsultaIfood')
                .orderBy('createdAt', 'asc')
                .limit(10);
            for (const pedido of pedidosPendentes) {
                try {
                    await this.registerSale(pedido.conteudoJson);
                    pedido.status = 'PROCESSADO';
                    pedido.dataProcessamento = DateTime.now();
                    await pedido.save();
                }
                catch (error) {
                    pedido.tentativas += 1;
                    pedido.mensagemErro = error.message;
                    await pedido.save();
                }
            }
            return {
                message: 'PROCESSAMENTO DA FILA INICIADO COM SUCESSO',
                pedidosProcessados: pedidosPendentes.length,
            };
        }
        catch (error) {
            return {
                error: 'ERRO AO PROCESSAR A FILA',
                message: error.message,
            };
        }
    }
    static async registerSale(json) {
        const idClient = await this.checkAndRegisterClient(json);
        const client = await Client.find(idClient);
        const addressId = await this.checkAndRegisterAddress(json, idClient);
        const address = await Address.find(addressId);
        const company = await Company.query().where('cliente_athos', true).select('id').first();
        const change = json.order.payments.methods.find((e) => e.method === 'CASH')?.cash?.changeFor || 0;
        const valueCash = json.order.payments.methods.find((e) => e.method === 'CASH')?.value || 0;
        const totalChange = change > 0 ? Math.abs(Number(change) - Number(valueCash)) : 0;
        const sale = await Sale.create({
            idGrupo: 1,
            idCliente: Number(idClient),
            idEmpresa: Number(company.id),
            valorProdutos: json.order.total.subTotal,
            valorTroco: totalChange,
            totalValue: Number(json.order.total.orderAmount) - Number(json.order.total.deliveryFee),
            totalDescountValue: json.order.total.additionalFees,
            observacao: json.order.extraInfo || '',
            horaPedido: DateTime.fromISO(json.order.createdAt).toFormat('HH:mm:ss'),
            hora_preparo: json.order.preparationStartDateTime
                ? DateTime.fromISO(json.order.preparationStartDateTime)
                : null,
            hora_entrega: json.order.delivery?.deliveryDateTime
                ? DateTime.fromISO(json.order.delivery.deliveryDateTime)
                : null,
            agendado: json.order.orderTiming === 'SCHEDULED'
                ? DateTime.fromISO(json.order.scheduled?.deliveryDateTimeStart || json.order.createdAt)
                : null,
            origem: 'DELIVERY',
            status: 'PROVISORIO_APLICATIVO',
            status_aplicativo: 'PENDENTE',
            pedido_aplicativo: 'IFOOD',
            id_venda_aplicativo: json.order.id,
        });
        if (json.order.total.deliveryFee > 0) {
            const idDeliveryFee = await this.checkAndRegisterDeliveryFee(json);
            sale.idTaxaDeEntrega = idDeliveryFee;
            await sale.save();
        }
        await SaleClient.create({
            idVenda: sale.id,
            idEmpresa: Number(idClient),
            nomeFantasia: client?.nome_fantasia || '',
            apelido: client?.nome_fantasia || '',
            email: client?.email || '',
            telefone: client?.telefone || '',
            codigo: client?.codigo || '',
            tipo: client?.tipo,
            origem: 'C',
            aniversario: client?.aniversario,
            tipoEndereco: address?.tipo || 'DELIVERY',
            cep: address?.cep || '',
            uf: address?.uf || '',
            cidade: address?.cidade || '',
            bairro: address?.bairro || '',
            logradouro: address?.logradouro || '',
            numero: address?.numero || '',
            complemento: address?.complemento || '',
            codigoCidade: address?.codigo_cidade || '',
            codigoUf: address?.codigo_uf || '',
            referencia: address?.referencia || '',
        });
        for (const item of json.order.items) {
            const product = await Product.query()
                .where('code', Number(item.externalCode))
                .select('*')
                .first();
            let unitValue = 0;
            if (item.options && item.options.length > 0) {
                unitValue = item.options.reduce((acc, option) => acc + option.price, 0);
            }
            const saleItem = await SaleItem.create({
                idVenda: sale.id,
                idProduto: product?.id ? Number(product.id) : undefined,
                saledQuantity: item.quantity,
                unitaryValue: item.unitPrice === 0 ? unitValue : item.unitPrice,
                totalValue: item.totalPrice,
                productDescription: product?.short_name ? product?.short_name : 'PRODUTO NÃO ENCONTRADO',
                codigo: Number(item.externalCode),
                observacao: item.observations || '',
            });
            if (item.options && item.options.length > 0) {
                item.options?.forEach(async (option) => {
                    const productOption = await Product.query()
                        .where('code', Number(option.externalCode))
                        .select('*')
                        .first();
                    await SaleSubItem.create({
                        idVenda: sale.id,
                        idVendaItem: saleItem.id,
                        idProduto: productOption?.id ? Number(productOption.id) : undefined,
                        quantidade: option.quantity,
                        valorUnitario: option.unitPrice,
                        valorTotal: option.price,
                        descricao: productOption?.short_name
                            ? productOption?.short_name
                            : 'PRODUTO NÃO ENCONTRADO',
                    });
                });
            }
        }
        if (json.order.payments.methods.length > 0) {
            for (const method of json.order.payments.methods) {
                let flag = null;
                let condition = null;
                let type = null;
                if (method.card && method.card.brand) {
                    flag = await Flag.query()
                        .where('nome', method.card.brand)
                        .whereNull('deletedAt')
                        .select('id')
                        .first();
                }
                condition = await Condition.query()
                    .where('nome', 'PAGAMENTO À VISTA')
                    .whereNull('deletedAt')
                    .select('id')
                    .first();
                const paymentMethodMap = {
                    CASH: '01',
                    CREDIT: '03',
                    DEBIT: '04',
                    MEAL_VOUCHER: '11',
                    FOOD_VOUCHER: '10',
                    GIFT_CARD: '12',
                    PIX: '17',
                    OTHER: '99',
                };
                const cmp = paymentMethodMap[method.method];
                if (cmp) {
                    type = await Type.query().where('cmp', cmp).whereNull('deletedAt').select('id').first();
                }
                const paymentMethod = await PaymentMethod.query()
                    .if(flag, (query) => query.where('id_bandeira', flag.id))
                    .if(condition, (query) => query.where('id_forma_de_pagamento_condicao', condition.id))
                    .if(type, (query) => query.where('id_forma_de_pagamento_tipo', type.id))
                    .select('id')
                    .first();
                if (paymentMethod) {
                    await SalePaymentMethod.create({
                        idVenda: sale.id,
                        idFormaDePagamento: paymentMethod.id,
                        installmentValue: method.method === 'CASH' &&
                            method.cash?.changeFor &&
                            Number(method.cash?.changeFor) > 0
                            ? method.cash?.changeFor
                            : method.value,
                    });
                }
            }
        }
    }
    static async checkAndRegisterClient(json) {
        const client = await Client.query()
            .where('telefone', json.order.customer.phone.number)
            .select('id')
            .first();
        if (client) {
            this.checkAndRegisterAddress(json, client.id);
            return client.id;
        }
        const newClient = await Client.create({
            nome_fantasia: json.order.customer.name,
            razao_social: json.order.customer.name,
            apelido: json.order.customer.name,
            telefone: json.order.customer.phone.number,
            email: json.order.customer.email || '',
            tipo: 'F',
            origem: 'C',
        });
        this.checkAndRegisterAddress(json, newClient.id);
        return newClient.id;
    }
    static async checkAndRegisterAddress(json, idClient) {
        const data = json.order.delivery.deliveryAddress;
        const address = await Address.query()
            .where('id_fk', idClient)
            .where('tipo_relacionamento', 'empresa')
            .where('tipo', 'ENTREGA')
            .where('numero', data.streetNumber)
            .where('cep', data.postalCode)
            .select('id')
            .first();
        if (address) {
            return address.id;
        }
        const postalCode = data.postalCode.replace('-', '');
        const addressCep = await this.searchCep(postalCode);
        const cepAddress = addressCep;
        const ifoodAddress = data;
        const newAddress = await Address.create({
            id_fk: idClient,
            tipo_relacionamento: 'empresa',
            tipo: 'ENTREGA',
            cep: cepAddress?.cep ? cepAddress?.cep : ifoodAddress.postalCode,
            uf: cepAddress?.uf ? cepAddress?.uf : ifoodAddress.state,
            cidade: cepAddress?.cidade.nome ? cepAddress?.cidade.nome : ifoodAddress.city,
            bairro: cepAddress?.bairro ? cepAddress?.bairro : ifoodAddress.neighborhood,
            logradouro: cepAddress?.logradouro ? cepAddress?.logradouro : ifoodAddress.streetName,
            numero: cepAddress?.numero ? cepAddress?.numero : ifoodAddress.streetNumber,
            complemento: cepAddress?.complemento ? cepAddress?.complemento : ifoodAddress.complement,
            codigo_cidade: cepAddress?.cidade.id ? cepAddress?.cidade.id : '',
            codigo_uf: cepAddress?.uf ? cepAddress?.uf : '',
            referencia: '',
        });
        return newAddress.id;
    }
    static async checkAndRegisterDeliveryFee(json) {
        const avarageTime = Math.round((new Date(json.order.delivery.deliveryDateTime).getTime() -
            new Date(json.order.preparationStartDateTime).getTime()) /
            (1000 * 60));
        const deliveryFee = await DeliveryFee.query()
            .where('descricao', 'TAXA DE ENTREGA IFOOD')
            .select('id')
            .first();
        if (deliveryFee) {
            deliveryFee.valor = json.order.total.deliveryFee;
            deliveryFee.tempo_previsao = String(avarageTime);
            deliveryFee.user_updated_name = 'APLICATIVO';
            await deliveryFee.save();
            return deliveryFee.id;
        }
        const config = await primeEmpresaDeliveryConfig.query().select('id_empresa').first();
        const newDeliveryFee = await DeliveryFee.create({
            descricao: 'TAXA DE ENTREGA IFOOD',
            valor: json.order.total.deliveryFee,
            tempo_previsao: String(avarageTime),
            codigo: 0,
            grupo_id: 1,
            empresa_id: config?.id_empresa,
            user_created_name: 'APLICATIVO',
            user_updated_name: 'APLICATIVO',
        });
        return newDeliveryFee.id;
    }
    static async searchCep(postalCode) {
        const url = 'https://viacep.com.br/ws/' + postalCode + '/json/';
        try {
            const response = await axios.get(url);
            if (response.data.erro) {
                return null;
            }
            return {
                cep: response.data.cep,
                cidade: {
                    id: response.data.ibge,
                    nome: response.data.localidade,
                },
                uf: response.data.uf,
                bairro: response.data.bairro,
                logradouro: response.data.logradouro,
                numero: '',
                complemento: '',
            };
        }
        catch (error) {
            console.log('Erro ao buscar CEP:', error);
            return null;
        }
    }
    async startOrderIfood(ctx) {
        const data = ctx.request.params();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const caixaMovimento = await CaixaMovimento.query()
            .where('idfuncionariousuarioabertura', sessionData.idfuncionariousuario)
            .where('status', 'ABE')
            .first();
        const passwordDelivery = await SequenceController.newPasswordDeliverySale();
        const sale = await Sale.find(data.id);
        if (sale) {
            sale.idCaixaMovimento = caixaMovimento.idcaixamovimento;
            sale.idTerminal = terminal.idterminal || terminal.idTerminal;
            sale.status = 'PROVISORIO_DELIVERY';
            sale.idUsuarioCriacao = Number(sessionData.idfuncionariousuario);
            if (!sale.senhaDelivery) {
                sale.senhaDelivery = passwordDelivery;
            }
            await sale.save();
        }
        return ctx.response.json(sale);
    }
    async runConsumerOrdersStatus() {
        try {
            const configEmpresa = await primeEmpresaDeliveryConfig
                .query()
                .select('id_athos_prime_ifood')
                .first();
            if (!configEmpresa) {
                console.error('Configuração da empresa não encontrada');
                return;
            }
            const connection = await amqp.connect(RABBITMQ_URL);
            const channel = await connection.createChannel();
            const queue = `ifood-orders-statuses-queue-${configEmpresa.id_athos_prime_ifood}`;
            await channel.assertQueue(queue, { durable: true });
            const queueInfo = await channel.checkQueue(queue);
            console.log(`Iniciando consumo de ${queueInfo.messageCount} mensagens da fila: ${queue}`);
            if (queueInfo.messageCount > 0) {
                await channel.consume(queue, async (msg) => {
                    if (msg) {
                        try {
                            const ordersStatus = JSON.parse(msg.content.toString());
                            console.log('🚀 ~ ordersStatus:', ordersStatus);
                            await PrimeFilaIfood.create({
                                conteudoJson: ordersStatus,
                                status: 'PENDENTE',
                                tentativas: 0,
                                mensagemErro: undefined,
                                dataProcessamento: null,
                                funcao: 'runConsumerOrdersStatus',
                            });
                            channel.ack(msg);
                        }
                        catch (error) {
                            console.error('Erro ao processar a mensagem:', error);
                            try {
                                channel.nack(msg, false, false);
                            }
                            catch (nackError) {
                                console.error('Erro ao fazer nack da mensagem:', nackError);
                            }
                        }
                    }
                });
            }
            setTimeout(async () => {
                console.log('🚀 ~ channel.consume ~ FECHANDO CONEXÃO');
                await channel.close();
                await connection.close();
                await IfoodsController.processOrdersStatus();
            }, 5000);
        }
        catch (error) {
            console.error('Erro ao iniciar o consumer:', error);
            process.exit(1);
        }
    }
    static async processOrdersStatus() {
        try {
            const orderStatus = await PrimeFilaIfood.query()
                .where('status', '!=', 'PROCESSADO')
                .where('tentativas', '<', 1)
                .where('funcao', 'runConsumerOrdersStatus')
                .orderBy('createdAt', 'asc');
            if (orderStatus.length > 0) {
                for (const order of orderStatus) {
                    const statusData = order.conteudoJson;
                    const sale = await Sale.query()
                        .where('id_venda_aplicativo', statusData.orderId)
                        .select('id', 'status_aplicativo', 'status')
                        .first();
                    if (sale) {
                        const statusAppMap = {
                            confirmed: 'ACEITE IMEDIATO',
                            preparing: 'INICIADO',
                            ready: 'ENVIADO',
                            dispatched: 'ENVIADO',
                            delivered: 'FINALIZADO',
                            concluded: 'FINALIZADO',
                            cancelled: 'CANCELADO',
                            consumer_cancellation_requested: 'CANCELAMENTO SOLICITADO',
                            cancellation_request_failed: 'SOLICITACAO DE CANCELAMENTO NEGADO',
                        };
                        const statusPrimeMap = {
                            confirmed: 'CONFIRMADO',
                            preparing: 'INICIADO',
                            ready: 'ENVIADO',
                            dispatched: 'ENVIADO',
                            delivered: 'FINALIZADO',
                            concluded: 'FINALIZADO',
                            cancelled: 'CANCELADO',
                        };
                        const statusOrder = [
                            'confirmed',
                            'preparing',
                            'ready',
                            'dispatched',
                            'delivered',
                            'concluded',
                        ];
                        const specialStatuses = [
                            'cancelled',
                            'consumer_cancellation_requested',
                            'cancellation_request_failed',
                        ];
                        const currentStatusIfood = Object.keys(statusAppMap).find((key) => statusAppMap[key] === sale.status_aplicativo) || '';
                        const currentStatusIndex = statusOrder.indexOf(currentStatusIfood);
                        const newStatusIndex = statusOrder.indexOf(statusData.status);
                        if (specialStatuses.includes(statusData.status) ||
                            currentStatusIndex === -1 ||
                            newStatusIndex >= currentStatusIndex) {
                            sale.status_aplicativo = statusAppMap[statusData.status] || sale.status_aplicativo;
                            sale.status = statusPrimeMap[statusData.status] || sale.status;
                            await sale.save();
                        }
                        const primeFila = await PrimeFilaIfood.find(order.id);
                        if (primeFila) {
                            primeFila.status = 'PROCESSADO';
                            await primeFila.save();
                        }
                    }
                }
            }
        }
        catch (error) {
            console.error('Erro ao processar os status dos pedidos:', error);
        }
    }
    static async sendCustomerStatusToRabbitMQ(data) {
        try {
            const configEmpresa = await primeEmpresaDeliveryConfig
                .query()
                .select('id_athos_prime_ifood')
                .first();
            if (!configEmpresa) {
                console.error('Configuração da empresa não encontrada');
                return;
            }
            const connection = await amqp.connect(RABBITMQ_URL);
            const channel = await connection.createChannel();
            const queue = `ifood-customers-orders-statuses-queue-${configEmpresa.id_athos_prime_ifood}`;
            console.log('🚀 ~ sendCustomerStatusToRabbitMQ ~ queue:', queue);
            await channel.assertQueue(queue, { durable: true });
            const value = {
                athosPrimeId: configEmpresa.id_athos_prime_ifood,
                orderId: data.id_venda_aplicativo,
                status: data.status_api_integracao,
            };
            const customerStatusBuffer = Buffer.from(JSON.stringify(value));
            channel.sendToQueue(queue, customerStatusBuffer, { persistent: true });
            console.log('Pedido enviado para a fila:', value);
            setTimeout(async () => {
                await channel.close();
                await connection.close();
            }, 500);
        }
        catch (error) {
            console.error('Erro ao enviar status para o RabbitMQ:', error);
        }
    }
    async rejectOrder(ctx) {
        const data = ctx.request.body();
        const sale = await Sale.find(data.id_venda);
        sale.status_aplicativo = data.status_aplicativo;
        sale.status = data.status;
        await sale.save();
        const dataSend = {
            id_venda_aplicativo: sale.id_venda_aplicativo,
            status_api_integracao: data.status_api_integracao,
        };
        await IfoodsController.sendCustomerStatusToRabbitMQ(dataSend);
        return sale;
    }
    async getStatusLojaIfood() {
        const configEmpresa = await primeEmpresaDeliveryConfig.query().select('*').first();
        return configEmpresa;
    }
    async indexStatusLojaIfood() {
        const configEmpresa = await primeEmpresaDeliveryConfig.query().select('*').first();
        const env = process.env;
        const options = {
            method: 'GET',
            url: `${env.API_IFOOD}/merchants/status`,
            headers: {
                Authorization: `Basic ${Buffer.from(`${configEmpresa?.id_client_ifood}:${configEmpresa?.client_secret_ifood}`).toString('base64')}`,
            },
        };
        const response = await axios.request(options);
        return response;
    }
    async updateStatusLojaIfood(ctx) {
        const data = ctx.request.body();
        const configEmpresa = await primeEmpresaDeliveryConfig.query().select('*').first();
        configEmpresa.statusLojaIfood = data.statusLojaIfood;
        await configEmpresa.save();
        return configEmpresa;
    }
}
//# sourceMappingURL=prime_fila_ifood_controller.js.map