import axios from 'axios';
export default class CepController {
    async searchCep({ params, response }) {
        const url = 'https://viacep.com.br/ws/' + params.cep + '/json/';
        try {
            await axios.get(url).then(async (cep) => {
                if (cep.data.erro) {
                    return response.notFound('CEP NÃO ENCONTRADO!');
                }
                const result = {
                    cep: cep.data.cep,
                    cidade: {
                        id: cep.data.ibge,
                        nome: cep.data.localidade,
                    },
                    uf: cep.data.uf,
                    bairro: cep.data.bairro,
                    logradouro: cep.data.logradouro,
                    numero: '',
                    complemento: '',
                };
                return response.ok(result);
            });
        }
        catch (error) {
            console.log(error);
            return error;
        }
    }
}
//# sourceMappingURL=cep_controller.js.map