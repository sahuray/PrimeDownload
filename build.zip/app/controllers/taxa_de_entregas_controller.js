import TaxaDeEntrega from '#models/taxa_de_entrega';
export default class TaxaDeEntregasController {
    async index(ctx) {
        const data = ctx.request.all();
        const deliveryFee = await TaxaDeEntrega.query()
            .if(data.search, (query) => {
            query.where('descricao', 'like', `%${data.search}%`);
        })
            .whereNull('deleted_at')
            .select('*')
            .limit(10);
        return ctx.response.json(deliveryFee);
    }
    async show(ctx) {
        const id = ctx.params.id;
        const deliveryFee = await TaxaDeEntrega.find(id);
        return ctx.response.json(deliveryFee);
    }
}
//# sourceMappingURL=taxa_de_entregas_controller.js.map