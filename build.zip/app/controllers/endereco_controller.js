import Endereco from '#models/endereco';
export default class EnderecoController {
    async selectAddressCompany(ctx) {
        const data = ctx.request.all();
        const addresses = await Endereco.query()
            .where('id_fk', data.empresa_id)
            .where('tipo_relacionamento', 'empresa')
            .whereNull('deleted_at')
            .orderBy('id', 'desc')
            .select('*');
        return ctx.response.json(addresses);
    }
    async createAddressCompany(ctx) {
        const data = ctx.request.all();
        if (data.tipo === 'PRINCIPAL') {
            const addressExists = await Endereco.query()
                .where('id_fk', data.empresa_id)
                .where('tipo_relacionamento', 'empresa')
                .where('tipo', 'PRINCIPAL')
                .whereNull('deleted_at')
                .first();
            if (addressExists) {
                addressExists.tipo = 'OUTROS';
                await addressExists.save();
            }
        }
        if (data.tipo === 'ENTREGA') {
            const addressExists = await Endereco.query()
                .where('id_fk', data.empresa_id)
                .where('tipo_relacionamento', 'empresa')
                .where('tipo', 'ENTREGA')
                .whereNull('deleted_at')
                .first();
            if (addressExists) {
                addressExists.tipo = 'OUTROS';
                await addressExists.save();
            }
        }
        const address = await Endereco.create({
            id_fk: data.empresa_id,
            tipo_relacionamento: 'empresa',
            cep: data.cep || 0,
            logradouro: data.logradouro,
            numero: data.numero,
            complemento: data.complemento,
            bairro: data.bairro,
            codigo_cidade: data.codigo_cidade,
            cidade: data.cidade,
            referencia: data.referencia,
            tipo: data.tipo,
            uf: data.uf,
        });
        return ctx.response.json(address);
    }
    async destroyAddressCompany(ctx) {
        const data = ctx.request.all();
        const address = await Endereco.find(data.id);
        await address?.delete();
        return ctx.response.json({ message: 'ENDEREÇO EXCLUÍDO COM SUCESSO' });
    }
    async updateAddressCompany(ctx) {
        const data = ctx.request.all();
        const address = await Endereco.find(data.id);
        if (!address) {
            return ctx.response.status(404).json({ message: 'ENDEREÇO NÃO ENCONTRADO' });
        }
        if (data.tipo === 'PRINCIPAL') {
            const addressExists = await Endereco.query()
                .where('id_fk', address.id_fk)
                .where('tipo_relacionamento', 'empresa')
                .where('tipo', 'PRINCIPAL')
                .whereNot('id', address.id)
                .whereNull('deleted_at')
                .first();
            if (addressExists) {
                addressExists.tipo = 'OUTROS';
                await addressExists.save();
            }
        }
        if (data.tipo === 'ENTREGA') {
            const addressExists = await Endereco.query()
                .where('id_fk', address.id_fk)
                .where('tipo_relacionamento', 'empresa')
                .where('tipo', 'ENTREGA')
                .whereNot('id', address.id)
                .whereNull('deleted_at')
                .first();
            if (addressExists) {
                addressExists.tipo = 'OUTROS';
                await addressExists.save();
            }
        }
        address.cep = data.cep || 0;
        address.logradouro = data.logradouro;
        address.numero = data.numero;
        address.complemento = data.complemento;
        address.bairro = data.bairro;
        address.codigo_cidade = data.codigo_cidade;
        address.cidade = data.cidade;
        address.referencia = data.referencia;
        address.tipo = data.tipo;
        address.uf = data.uf;
        await address.save();
        return ctx.response.json(address);
    }
}
//# sourceMappingURL=endereco_controller.js.map