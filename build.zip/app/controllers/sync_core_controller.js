import CompanyCoreService from '#services/synchrony_core/empresa';
import AddressCoreService from '#services/synchrony_core/endereco';
import ContactCoreService from '#services/synchrony_core/contato';
import SaleCoreService from '#services/synchrony_core/venda';
import SaleItemCoreService from '#services/synchrony_core/venda_item';
import SaleSubItemCoreService from '#services/synchrony_core/venda_sub_item';
import SaleClientCoreService from '#services/synchrony_core/venda_cliente';
import SaleNfceCoreService from '#services/synchrony_core/venda_nfce';
import SalePaymentMethodCoreService from '#services/synchrony_core/venda_forma_de_pagamento';
import SaleTermPaymentCoreService from '#services/synchrony_core/venda_pagamento_a_prazo';
import SaleItemCharacteristicCoreService from '#services/synchrony_core/venda_item_caracteristica';
import SaleControlInventoryCoreService from '#services/synchrony_core/venda_controle_estoque';
import MovementCashDeskCoreService from '#services/synchrony_core/caixa_movimento';
import MotoboyCoreService from '#services/synchrony_core/motoboy';
export default class SyncController {
    companyCoreService;
    addressCoreService;
    contactCoreService;
    saleCoreService;
    saleItemCoreService;
    saleSubItemCoreService;
    saleClientCoreService;
    saleNfceCoreService;
    salePaymentMethodCoreService;
    saleTermPaymentCoreService;
    saleItemCharacteristicCoreService;
    saleControlInventoryCoreService;
    movementCashDeskCoreService;
    motoboyCoreService;
    constructor() {
        this.companyCoreService = new CompanyCoreService();
        this.addressCoreService = new AddressCoreService();
        this.contactCoreService = new ContactCoreService();
        this.saleCoreService = new SaleCoreService();
        this.saleItemCoreService = new SaleItemCoreService();
        this.saleSubItemCoreService = new SaleSubItemCoreService();
        this.saleClientCoreService = new SaleClientCoreService();
        this.saleNfceCoreService = new SaleNfceCoreService();
        this.salePaymentMethodCoreService = new SalePaymentMethodCoreService();
        this.saleTermPaymentCoreService = new SaleTermPaymentCoreService();
        this.saleItemCharacteristicCoreService = new SaleItemCharacteristicCoreService();
        this.saleControlInventoryCoreService = new SaleControlInventoryCoreService();
        this.movementCashDeskCoreService = new MovementCashDeskCoreService();
        this.motoboyCoreService = new MotoboyCoreService();
    }
    async syncCoreCompany(ctx) {
        try {
            await this.companyCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | EMPRESA',
            });
        }
        catch (err) {
            console.log(err);
        }
    }
    async syncCoreAddress(ctx) {
        try {
            await this.addressCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | ENDERECO',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | ENDERECO' + err);
        }
    }
    async syncCoreContact(ctx) {
        try {
            await this.contactCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | CONTATO',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | CONTATO' + err);
        }
    }
    async syncCoreSale(ctx) {
        try {
            await this.saleCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA' + err);
        }
    }
    async syncCoreSaleItem(ctx) {
        try {
            await this.saleItemCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA ITEM',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA ITEM' + err);
        }
    }
    async syncCoreSaleSubItem(ctx) {
        try {
            await this.saleSubItemCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA SUB ITEM',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA SUB ITEM' + err);
        }
    }
    async syncCoreSaleClient(ctx) {
        try {
            await this.saleClientCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA CLIENTE',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA CLIENTE' + err);
        }
    }
    async syncCoreSaleNfce(ctx) {
        try {
            await this.saleNfceCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA NFCE',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA NFCE' + err);
        }
    }
    async syncCoreSalePaymentMethod(ctx) {
        try {
            await this.salePaymentMethodCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA FORMA DE PAGAMENTO',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA FORMA DE PAGAMENTO' + err);
        }
    }
    async syncCoreSaleTermPayment(ctx) {
        try {
            await this.saleTermPaymentCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA PAG. A PRAZO',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA PAG. A PRAZO' + err);
        }
    }
    async syncCoreSaleItemCharacteristic(ctx) {
        try {
            await this.saleItemCharacteristicCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA ITEM CARACTERISTICA',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA ITEM CARACTERISTICA' + err);
        }
    }
    async syncCoreSaleControlInventory(ctx) {
        try {
            await this.saleControlInventoryCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | VENDA CONTROLE ESTOQUE',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | VENDA CONTROLE ESTOQUE' + err);
        }
    }
    async syncCoreMovementCashDesk(ctx) {
        try {
            await this.movementCashDeskCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | CAIXA MOVIMENTO',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | CAIXA MOVIMENTO' + err);
        }
    }
    async syncCoreMotoboy(ctx) {
        try {
            await this.motoboyCoreService.syncCore();
            return ctx.response.status(200).send({
                message: 'SINCRONIZAÇÃO CORE --> PRIME | MOTOBOY',
            });
        }
        catch (err) {
            console.log('SINCRONIZAÇÃO CORE --> PRIME | MOTOBOY' + err);
        }
    }
}
//# sourceMappingURL=sync_core_controller.js.map