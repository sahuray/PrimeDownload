import FormaDePagamento from '#models/forma_de_pagamento';
import FormaDePagamentoTipo from '#models/forma_de_pagamento_tipo';
import FormaDePagamentoCondicao from '#models/forma_de_pagamento_condicao';
const fieldsPaymentType = ['id', 'cmp', 'nome'];
const fieldsPaymentCondition = ['id', 'nome', 'code'];
const fieldsBankAccount = [
    'id',
    'id_banco',
    'conta_digito',
    'agencia_digito',
    'agencia',
    'conta_corrente',
];
const fieldsPaymentMethod = [
    'id',
    'id_empresa',
    'id_bandeira',
    'id_conta_bancaria',
    'id_forma_de_pagamento_tipo',
    'id_forma_de_pagamento_condicao',
    'quantidade',
    'prazo',
    'tarifa',
    'description',
    'code',
];
const fieldsFlag = ['id', 'nome'];
export default class FormaDePagamentoController {
    async selectPaymentMethodByType({ response, request }) {
        const type = request.all();
        try {
            const typePaymentMethods = await FormaDePagamento.query()
                .where('id_forma_de_pagamento_tipo', type.id)
                .preload('bandeira', (subQuery) => {
                subQuery.select(fieldsFlag);
            })
                .preload('formaDePagamentoCondicao', (subQuery) => {
                subQuery.select(fieldsPaymentCondition);
            })
                .preload('formaDePagamentoTipo', (subQuery) => {
                subQuery.select(fieldsPaymentType);
            })
                .preload('contaBancaria', (subQuery) => {
                subQuery.select(fieldsBankAccount);
            })
                .whereNull('deleted_at')
                .select(fieldsPaymentMethod);
            return response.json({ typePaymentMethods });
        }
        catch (err) {
            console.log(err);
        }
    }
    async selectTypePaymentIfPaymentMethodExists({ response }) {
        try {
            const typePayments = await FormaDePagamentoTipo.query()
                .whereExists((subquery) => {
                subquery
                    .select('id')
                    .from('prime_forma_de_pagamento')
                    .whereColumn('prime_forma_de_pagamento.id_forma_de_pagamento_tipo', 'prime_forma_de_pagamento_tipo.id')
                    .whereNull('prime_forma_de_pagamento.deleted_at');
            })
                .whereNull('deleted_at')
                .select(fieldsPaymentType);
            return response.json({ typePayments });
        }
        catch (err) {
            console.log(err);
        }
    }
    async indexCondition({ response }) {
        try {
            const typePayments = await FormaDePagamentoCondicao.query();
            return response.json({ typePayments });
        }
        catch (err) {
            console.log(err);
        }
    }
}
//# sourceMappingURL=forma_de_pagamento_controller.js.map