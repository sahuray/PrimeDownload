import Municipio from '#models/prime_municipio';
export default class MunicipioController {
    async searchMunicipality({ request, response }) {
        const localParams = request.qs();
        const searchUF = localParams.uf;
        const searchCity = localParams.city;
        const data = await Municipio.query()
            .if(searchCity, (subQuery) => {
            subQuery.whereRaw("(lower(cidade)) like '%' || (lower(?)) || '%'", [searchCity]);
        })
            .where('uf', searchUF)
            .whereNull('deleted_at')
            .select(['id', 'cidade', 'ibge'])
            .limit(15);
        return response.ok(data);
    }
}
//# sourceMappingURL=municipio_controller.js.map