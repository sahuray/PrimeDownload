import GrupoService from '#services/synchrony/group';
import EmpresaService from '#services/synchrony/empresa';
import EnderecoService from '#services/synchrony/endereco';
import FuncionarioUsuarioService from '#services/synchrony/funcionario_usuario';
import FuncionarioService from '#services/synchrony/funcionario';
import ContatoService from '#services/synchrony/contato';
import FormaDePagamentoService from '#services/synchrony/forma_de_pagamento';
import FormaDePagamentoTipoService from '#services/synchrony/forma_de_pagamento_tipo';
import FormaDePagamentoCondicaoService from '#services/synchrony/forma_de_pagamento_condicao';
import ContaBancariaService from '#services/synchrony/conta_bancaria';
import BandeiraService from '#services/synchrony/bandeira';
import BancoService from '#services/synchrony/banco';
import ProdCategoriaSetorService from '#services/synchrony/produto_categoria_setor';
import ProdCategoriaGrupoService from '#services/synchrony/produto_categoria_grupo';
import ProdCategoriaSubGrupoService from '#services/synchrony/produto_categoria_sub_grupo';
import ProdCategoriaLinhaService from '#services/synchrony/produto_categoria_linha';
import MarcaService from '#services/synchrony/marca';
import UnidadeService from '#services/synchrony/unidade';
import ProdutoInformacaoNutricionalService from '#services/synchrony/produto_informacao_nutricional';
import ProdutoService from '#services/synchrony/produto';
import ProdutoPrecoService from '#services/synchrony/produto_preco';
import ProdutoNumeroSerieService from '#services/synchrony/produto_numero_de_serie';
import ProdutoLoteExpiracaoService from '#services/synchrony/produto_lote_expiracao';
import ProdutoEstoqueService from '#services/synchrony/produto_estoque';
import ProdutoEmpresaService from '#services/synchrony/produto_empresa';
import ProdutoCompostoService from '#services/synchrony/produto_composto';
import ProdutoCompativelService from '#services/synchrony/produto_compativel';
import ProdutoCaracteristicaService from '#services/synchrony/produto_caracteristica';
import Terminalservice from '#services/synchrony/terminal';
import TaxaDeEntregaService from '#services/synchrony/taxa_de_entrega';
import MotoboyService from '#services/synchrony/motoboy';
import DepartamentoService from '#services/synchrony/departamento';
import SetorService from '#services/synchrony/setor';
import MesaService from '#services/synchrony/mesa';
import UploadService from '#services/synchrony/upload';
import EmpresaComandaConfigsService from '#services/synchrony/empresa_comanda_config';
import EmpresaPdvConfigService from '#services/synchrony/empresa_pdv_config';
import EmpresaDeliveryConfigService from '#services/synchrony/empresa_delivery_config';
import EmpresaPrathosConfigsService from '#services/synchrony/empresa_prathos_config';
import PermissaoService from '#services/synchrony/permissao';
import PermissaoUsuarioService from '#services/synchrony/permissao_usuario';
import ComandaService from '#services/synchrony/comanda';
import HealthCheckService from '#services/health_check_service';
import caixaMovimentoCoreService from '#services/synchrony_core/caixa_movimento';
import caixaFechamentoCoreService from '#services/synchrony_core/caixa_fechamento';
import caixaSaidaCoreService from '#services/synchrony_core/caixa_saida';
import empresaCoreService from '#services/synchrony_core/empresa';
import enderecoCoreService from '#services/synchrony_core/endereco';
import contatoCoreService from '#services/synchrony_core/contato';
import operacaoMovimentoCoreService from '#services/synchrony_core/operacao_movimento';
import operacaoMovimentoItemCoreService from '#services/synchrony_core/operacao_movimento_item';
import vendaCoreService from '#services/synchrony_core/venda';
import vendaClienteCoreService from '#services/synchrony_core/venda_cliente';
import vendaItemCoreService from '#services/synchrony_core/venda_item';
import vendaSubItemCoreService from '#services/synchrony_core/venda_sub_item';
import vendaItemCaracteristicaCoreService from '#services/synchrony_core/venda_item_caracteristica';
import vendaNfceCoreService from '#services/synchrony_core/venda_nfce';
import vendaFormaDePagamentoCoreService from '#services/synchrony_core/venda_forma_de_pagamento';
import vendaPagamentoAPrazoCoreService from '#services/synchrony_core/venda_pagamento_a_prazo';
import vendaControleEstoqueCoreService from '#services/synchrony_core/venda_controle_estoque';
import MotoboyCoreService from '#services/synchrony_core/motoboy';
import Sincronia from '#models/sincronia';
export default class SyncManualController {
    healthCheckService;
    bancoService;
    formaDePagamentoTipoService;
    formaDePagamentoCondicaoService;
    bandeiraService;
    grupoService;
    contaBancariaService;
    empresaService;
    formaDePagamentoService;
    funcionarioUsuarioService;
    prodCategoriaSetorService;
    prodCategoriaGrupoService;
    prodCategoriaSubGrupoService;
    prodCategoriaLinhaService;
    marcaService;
    unidadeService;
    produtoInformacaoNutricionalService;
    produtoPrecoService;
    produtoService;
    produtoNumeroSerieService;
    produtoLoteExpiracaoService;
    produtoEstoqueService;
    produtoEmpresaService;
    produtoCompostoService;
    produtoCompativelService;
    terminalService;
    funcionarioService;
    enderecoService;
    taxaDeEntregaService;
    motoboyService;
    setorService;
    contatoService;
    uploadService;
    empresaComandaConfigsService;
    empresaPdvConfigsService;
    empresaDeliveryConfigService;
    empresaPrathosConfigService;
    produtoCaracteristicaService;
    permissaoService;
    permissaoUsuarioService;
    mesaService;
    comandaService;
    departamentoService;
    caixaMovimentoCoreService;
    caixaFechamentoCoreService;
    caixaSaidaCoreService;
    empresaCoreService;
    enderecoCoreService;
    contatoCoreService;
    operacaoMovimentoCoreService;
    operacaoMovimentoItemCoreService;
    vendaCoreService;
    vendaClienteCoreService;
    vendaItemCoreService;
    vendaSubItemCoreService;
    vendaItemCaracteristicaCoreService;
    vendaNfceCoreService;
    vendaFormaDePagamentoCoreService;
    vendaPagamentoAPrazoCoreService;
    vendaControleEstoqueCoreService;
    motoboyCoreService;
    constructor() {
        this.healthCheckService = new HealthCheckService();
        this.bancoService = new BancoService();
        this.bandeiraService = new BandeiraService();
        this.grupoService = new GrupoService();
        this.empresaService = new EmpresaService();
        this.enderecoService = new EnderecoService();
        this.contatoService = new ContatoService();
        this.funcionarioService = new FuncionarioService();
        this.funcionarioUsuarioService = new FuncionarioUsuarioService();
        this.formaDePagamentoTipoService = new FormaDePagamentoTipoService();
        this.formaDePagamentoCondicaoService = new FormaDePagamentoCondicaoService();
        this.formaDePagamentoService = new FormaDePagamentoService();
        this.contaBancariaService = new ContaBancariaService();
        this.prodCategoriaSetorService = new ProdCategoriaSetorService();
        this.prodCategoriaGrupoService = new ProdCategoriaGrupoService();
        this.prodCategoriaSubGrupoService = new ProdCategoriaSubGrupoService();
        this.prodCategoriaLinhaService = new ProdCategoriaLinhaService();
        this.marcaService = new MarcaService();
        this.unidadeService = new UnidadeService();
        this.produtoInformacaoNutricionalService = new ProdutoInformacaoNutricionalService();
        this.produtoService = new ProdutoService();
        this.produtoCompativelService = new ProdutoCompativelService();
        this.produtoEmpresaService = new ProdutoEmpresaService();
        this.produtoEstoqueService = new ProdutoEstoqueService();
        this.produtoLoteExpiracaoService = new ProdutoLoteExpiracaoService();
        this.produtoPrecoService = new ProdutoPrecoService();
        this.produtoNumeroSerieService = new ProdutoNumeroSerieService();
        this.produtoCompostoService = new ProdutoCompostoService();
        this.produtoCaracteristicaService = new ProdutoCaracteristicaService();
        this.terminalService = new Terminalservice();
        this.taxaDeEntregaService = new TaxaDeEntregaService();
        this.motoboyService = new MotoboyService();
        this.setorService = new SetorService();
        this.mesaService = new MesaService();
        this.departamentoService = new DepartamentoService();
        this.uploadService = new UploadService();
        this.empresaComandaConfigsService = new EmpresaComandaConfigsService();
        this.empresaPdvConfigsService = new EmpresaPdvConfigService();
        this.empresaDeliveryConfigService = new EmpresaDeliveryConfigService();
        this.empresaPrathosConfigService = new EmpresaPrathosConfigsService();
        this.permissaoService = new PermissaoService();
        this.permissaoUsuarioService = new PermissaoUsuarioService();
        this.comandaService = new ComandaService();
        this.caixaMovimentoCoreService = new caixaMovimentoCoreService();
        this.caixaFechamentoCoreService = new caixaFechamentoCoreService();
        this.caixaSaidaCoreService = new caixaSaidaCoreService();
        this.empresaCoreService = new empresaCoreService();
        this.enderecoCoreService = new enderecoCoreService();
        this.contatoCoreService = new contatoCoreService();
        this.operacaoMovimentoCoreService = new operacaoMovimentoCoreService();
        this.operacaoMovimentoItemCoreService = new operacaoMovimentoItemCoreService();
        this.vendaCoreService = new vendaCoreService();
        this.vendaClienteCoreService = new vendaClienteCoreService();
        this.vendaItemCoreService = new vendaItemCoreService();
        this.vendaSubItemCoreService = new vendaSubItemCoreService();
        this.vendaItemCaracteristicaCoreService = new vendaItemCaracteristicaCoreService();
        this.vendaNfceCoreService = new vendaNfceCoreService();
        this.vendaFormaDePagamentoCoreService = new vendaFormaDePagamentoCoreService();
        this.vendaPagamentoAPrazoCoreService = new vendaPagamentoAPrazoCoreService();
        this.vendaControleEstoqueCoreService = new vendaControleEstoqueCoreService();
        this.motoboyCoreService = new MotoboyCoreService();
    }
    async getTableSynchrony(ctx) {
        try {
            const synchronys = await Sincronia.query();
            return ctx.response.json({ synchronys });
        }
        catch (err) {
            console.log(err);
        }
    }
    async syncManualGetDataAll(ctx) {
        try {
            console.log('SINCRONIZAÇÃO MANUAL INICIADA');
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                console.log('SINCRONIZAÇÃO MANUAL FALHOU, FALTA DE INTERNET');
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().delete();
            await this.grupoService.syncGroups();
            await this.empresaService.syncCompanies();
            await this.enderecoService.syncAddresses();
            await this.contatoService.syncContact();
            await this.funcionarioService.syncEmployees();
            await this.funcionarioUsuarioService.getUsers();
            await this.bancoService.syncBanks();
            await this.bandeiraService.syncFlags();
            await this.contaBancariaService.syncBankAccount();
            await this.empresaComandaConfigsService.syncCompanyCommandSetting();
            await this.empresaPdvConfigsService.syncCompanyPdvSetting();
            await this.empresaDeliveryConfigService.syncCompanyDeliverySetting();
            await this.empresaPrathosConfigService.syncCompanyPrathosSetting();
            await this.terminalService.syncTerminals();
            await this.taxaDeEntregaService.syncDeliveryFee();
            await this.motoboyService.syncMotoboy();
            await this.formaDePagamentoCondicaoService.syncPaymentsMethodCondition();
            await this.formaDePagamentoTipoService.syncPaymentsMethodType();
            await this.formaDePagamentoService.syncPaymentsMethod();
            await this.prodCategoriaSetorService.syncProdCategorySector();
            await this.prodCategoriaGrupoService.syncProdCategoryGroup();
            await this.prodCategoriaSubGrupoService.syncProdCategorySubGroup();
            await this.prodCategoriaLinhaService.syncProdCategoryLine();
            await this.marcaService.syncBrand();
            await this.unidadeService.syncUnit();
            await this.produtoInformacaoNutricionalService.syncInformationNutritional();
            await this.produtoService.syncProduct();
            await this.produtoCompativelService.syncProdutoCompativel();
            await this.produtoEmpresaService.syncProdutoEmpresa();
            await this.produtoEstoqueService.syncProdutoEstoque();
            await this.produtoLoteExpiracaoService.syncProdutoLoteExpiracao();
            await this.produtoPrecoService.syncProductPrice();
            await this.produtoNumeroSerieService.syncProdutoNumeroSerie();
            await this.produtoCompostoService.syncProdutoComposto();
            await this.produtoCaracteristicaService.syncProductCharacteristic();
            await this.setorService.syncSetor();
            await this.mesaService.syncMesa();
            await this.departamentoService.syncDepartament();
            await this.comandaService.syncComanda();
            await this.uploadService.syncUpload();
            await this.permissaoService.syncPermission();
            await this.permissaoUsuarioService.syncPermissionUser();
            console.log('SINCRONIZAÇÃO MANUAL FINALIZADA');
            return ctx.response.status(200);
        }
        catch (err) {
            console.log(err);
        }
    }
    async syncManualGetEmpresa(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'GRUPO').delete();
            await Sincronia.query().where('nome_tabela', 'EMPRESA').delete();
            await Sincronia.query().where('nome_tabela', 'ENDERECO').delete();
            await Sincronia.query().where('nome_tabela', 'CONTATO').delete();
            await Sincronia.query().where('nome_tabela', 'FUNCIONARIO').delete();
            await Sincronia.query().where('nome_tabela', 'USUARIO').delete();
            await Sincronia.query().where('nome_tabela', 'CONFIG EMPRESA PDV').delete();
            await Sincronia.query().where('nome_tabela', 'CONFIG EMPRESA DELIVERY').delete();
            await Sincronia.query().where('nome_tabela', 'CONFIG EMPRESA COMANDA').delete();
            await Sincronia.query().where('nome_tabela', 'CONFIG EMPRESA PRATHOS').delete();
            console.log('-----------------------------------------------------------------------');
            await this.grupoService.syncGroups();
            await this.empresaService.syncCompanies();
            await this.enderecoService.syncAddresses();
            await this.contatoService.syncContact();
            await this.funcionarioService.syncEmployees();
            await this.funcionarioUsuarioService.getUsers();
            await this.empresaComandaConfigsService.syncCompanyCommandSetting();
            await this.empresaPdvConfigsService.syncCompanyPdvSetting();
            await this.empresaDeliveryConfigService.syncCompanyDeliverySetting();
            await this.empresaPrathosConfigService.syncCompanyPrathosSetting();
            return ctx.response.status(200);
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualGetUsuarioAndFuncionarioAndPermissao(ctx) {
        const isOnline = await this.healthCheckService.verifyConnection();
        if (!isOnline) {
            return ctx.response.json({
                message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                status: 400,
            });
        }
        await Sincronia.query().where('nome_tabela', 'USUARIO').delete();
        await Sincronia.query().where('nome_tabela', 'FUNCIONARIO').delete();
        await Sincronia.query().where('nome_tabela', 'PERMISSAO').delete();
        await Sincronia.query().where('nome_tabela', 'PERMISSAO USUARIO').delete();
        console.log('-----------------------------------------------------------------------');
        await this.funcionarioUsuarioService.getUsers();
        await this.funcionarioService.syncEmployees();
        await this.permissaoService.syncPermission();
        await this.permissaoUsuarioService.syncPermissionUser();
    }
    async syncManualGetContaBancaria(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'BANDEIRA').delete();
            await Sincronia.query().where('nome_tabela', 'BANCO').delete();
            await Sincronia.query().where('nome_tabela', 'CONTA BANCARIA').delete();
            console.log('-----------------------------------------------------------------------');
            await this.bancoService.syncBanks();
            await this.bandeiraService.syncFlags();
            await this.contaBancariaService.syncBankAccount();
            return ctx.response.status(200);
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualGetTerminal(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'TERMINAL').delete();
            console.log('-----------------------------------------------------------------------');
            await this.terminalService.syncTerminals();
            return ctx.response.status(200);
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualGetMotoboy(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'TAXA DE ENTREGA').delete();
            await Sincronia.query().where('nome_tabela', 'MOTOBOY').delete();
            console.log('-----------------------------------------------------------------------');
            await this.taxaDeEntregaService.syncDeliveryFee();
            await this.motoboyService.syncMotoboy();
            return ctx.response.status(200);
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualGetFormaDePagamento(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'FORMA DE PAGAMENTO CONDICAO').delete();
            await Sincronia.query().where('nome_tabela', 'FORMA DE PAGAMENTO TIPO').delete();
            await Sincronia.query().where('nome_tabela', 'FORMA DE PAGAMENTO').delete();
            console.log('-----------------------------------------------------------------------');
            await this.formaDePagamentoCondicaoService.syncPaymentsMethodCondition();
            await this.formaDePagamentoTipoService.syncPaymentsMethodType();
            await this.formaDePagamentoService.syncPaymentsMethod();
            return ctx.response.status(200);
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualMercadologico(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'PRODUTO CATEGORIA SETOR').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO CATEGORIA GRUPO').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO CATEGORIA SUBGRUPO').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO CATEGORIA LINHA').delete();
            await Sincronia.query().where('nome_tabela', 'UPLOAD').delete();
            console.log('-----------------------------------------------------------------------');
            await this.uploadService.syncUpload();
            await this.prodCategoriaSetorService.syncProdCategorySector();
            await this.prodCategoriaGrupoService.syncProdCategoryGroup();
            await this.prodCategoriaSubGrupoService.syncProdCategorySubGroup();
            await this.prodCategoriaLinhaService.syncProdCategoryLine();
            return ctx.response.status(200);
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualGetProduto(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'MARCA').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO UNIDADE').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO INFORMACAO NUTRICIONAL').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO EMPRESA').delete();
            await Sincronia.query().where('nome_tabela', 'ESTOQUE').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO PRECO').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO COMPOSTO').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO CARACTERISTICA').delete();
            await Sincronia.query().where('nome_tabela', 'PRODUTO COMPATIVEL').delete();
            await Sincronia.query().where('nome_tabela', 'UPLOAD').delete();
            console.log('-----------------------------------------------------------------------');
            await this.marcaService.syncBrand();
            await this.unidadeService.syncUnit();
            await this.produtoInformacaoNutricionalService.syncInformationNutritional();
            await this.produtoService.syncProduct();
            await this.produtoCompativelService.syncProdutoCompativel();
            await this.produtoEmpresaService.syncProdutoEmpresa();
            await this.produtoEstoqueService.syncProdutoEstoque();
            await this.produtoLoteExpiracaoService.syncProdutoLoteExpiracao();
            await this.produtoPrecoService.syncProductPrice();
            await this.produtoNumeroSerieService.syncProdutoNumeroSerie();
            await this.produtoCompostoService.syncProdutoComposto();
            await this.produtoCaracteristicaService.syncProductCharacteristic();
            await this.uploadService.syncUpload();
            return ctx.response.status(200);
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualGetPrathosAndComanda(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await Sincronia.query().where('nome_tabela', 'SETOR').delete();
            await Sincronia.query().where('nome_tabela', 'MESA').delete();
            await Sincronia.query().where('nome_tabela', 'COMANDA').delete();
            await Sincronia.query().where('nome_tabela', 'DEPARTAMENTO').delete();
            console.log('-----------------------------------------------------------------------');
            await this.setorService.syncSetor();
            await this.departamentoService.syncDepartament();
            await this.mesaService.syncMesa();
            await this.comandaService.syncComanda();
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualSendDataAll(ctx) {
        try {
            console.log('SINCRONIZAÇÃO MANUAL INICIADA');
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                console.log('SINCRONIZAÇÃO MANUAL FALHOU, FALTA DE INTERNET');
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            await this.empresaCoreService.syncCore();
            await this.enderecoCoreService.syncCore();
            await this.contatoCoreService.syncCore();
            await this.operacaoMovimentoCoreService.syncCore();
            await this.operacaoMovimentoItemCoreService.syncCore();
            await this.caixaMovimentoCoreService.syncCore();
            await this.caixaFechamentoCoreService.syncCore();
            await this.caixaSaidaCoreService.syncCore();
            await this.vendaCoreService.syncCore();
            await this.vendaClienteCoreService.syncCore();
            await this.vendaItemCoreService.syncCore();
            await this.vendaSubItemCoreService.syncCore();
            await this.vendaItemCaracteristicaCoreService.syncCore();
            await this.vendaNfceCoreService.syncCore();
            await this.vendaFormaDePagamentoCoreService.syncCore();
            await this.vendaPagamentoAPrazoCoreService.syncCore();
            await this.vendaControleEstoqueCoreService.syncCore();
            await this.motoboyCoreService.syncCore();
            console.log('SINCRONIZAÇÃO MANUAL FINALIZADA');
            return ctx.response.status(200);
        }
        catch (err) {
            console.log(err);
        }
    }
    async syncManualSendEmpresa(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                console.log('SINCRONIZAÇÃO MANUAL FALHOU, FALTA DE INTERNET');
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            console.log('--------------------------------------------------------------------------');
            await this.empresaCoreService.syncCore();
            await this.enderecoCoreService.syncCore();
            await this.contatoCoreService.syncCore();
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualSendCaixaMovimento(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                console.log('SINCRONIZAÇÃO MANUAL FALHOU, FALTA DE INTERNET');
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            console.log('--------------------------------------------------------------------------');
            await this.caixaMovimentoCoreService.syncCore();
            await this.caixaFechamentoCoreService.syncCore();
            await this.caixaSaidaCoreService.syncCore();
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualSendVenda(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                console.log('SINCRONIZAÇÃO MANUAL FALHOU, FALTA DE INTERNET');
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            console.log('--------------------------------------------------------------------------');
            await this.vendaCoreService.syncCore();
            await this.vendaClienteCoreService.syncCore();
            await this.vendaItemCoreService.syncCore();
            await this.vendaSubItemCoreService.syncCore();
            await this.vendaItemCaracteristicaCoreService.syncCore();
            await this.vendaNfceCoreService.syncCore();
            await this.vendaFormaDePagamentoCoreService.syncCore();
            await this.vendaPagamentoAPrazoCoreService.syncCore();
            await this.vendaControleEstoqueCoreService.syncCore();
        }
        catch (error) {
            console.log(error);
        }
    }
    async syncManualSendMotoboy(ctx) {
        try {
            const isOnline = await this.healthCheckService.verifyConnection();
            if (!isOnline) {
                console.log('SINCRONIZAÇÃO MANUAL FALHOU, FALTA DE INTERNET');
                return ctx.response.status(400).json({
                    message: 'NÃO FOI POSSÍVEL SINCRONIZAR OS DADOS, VERIFIQUE A CONEXÃO COM A INTERNET',
                });
            }
            console.log('--------------------------------------------------------------------------');
            await this.motoboyCoreService.syncCore();
        }
        catch (error) {
            console.log(error);
        }
    }
}
//# sourceMappingURL=sync_manual_controller.js.map