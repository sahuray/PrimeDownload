import PrimeProdutoCaracteristica from '#models/prime_produto_caracteristica';
export default class PrimeProdutoCaracteristicaController {
    async selectProductCharacteristic(ctx) {
        const data = ctx.request.only(['id', 'search']);
        const produtoCaracteristicas = await PrimeProdutoCaracteristica.query()
            .innerJoin('prime_produto_empresa', 'prime_produto_empresa.id_produto', 'prime_produto_caracteristica.id_produto')
            .where('prime_produto_caracteristica.id_produto', data.id)
            .where('prime_produto_empresa.use_characteristic', true)
            .if(data.search, (query) => {
            query
                .where('prime_produto_caracteristica.descricao', 'ilike', `%${data.search}%`)
                .orWhere('prime_produto_caracteristica.codigo', 'ilike', `%${data.search}%`)
                .orWhere('prime_produto_caracteristica.categoria', 'ilike', `%${data.search}%`);
        })
            .whereNull('prime_produto_caracteristica.deleted_at')
            .select('*')
            .limit(100);
        return ctx.response.json(produtoCaracteristicas);
    }
}
//# sourceMappingURL=produto_caracteristica_controller.js.map