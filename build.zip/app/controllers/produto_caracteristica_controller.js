import PrimeProdutoCaracteristica from '#models/prime_produto_caracteristica';
export default class PrimeProdutoCaracteristicaController {
    async selectProductCharacteristic(ctx) {
        const data = ctx.request.only(['id', 'search']);
        const produtoCaracteristicas = await PrimeProdutoCaracteristica.query()
            .where('id_produto', data.id)
            .if(data.search, (query) => {
            query
                .where('descricao', 'ilike', `%${data.search}%`)
                .orWhere('codigo', 'ilike', `%${data.search}%`)
                .orWhere('categoria', 'ilike', `%${data.search}%`);
        })
            .whereNull('deleted_at')
            .select('*')
            .limit(100);
        return ctx.response.json(produtoCaracteristicas);
    }
}
//# sourceMappingURL=produto_caracteristica_controller.js.map