import CaixaFechamento from '#models/caixa_fechamento';
import { DateTime } from 'luxon';
export default class CaixaFechamentoController {
    async create({ request, response }) {
        try {
            let data = request.body();
            if (data && data.length > 0) {
                for (const item of data) {
                    await CaixaFechamento.create({
                        id_caixa_movimento: item.id_caixa_movimento,
                        id_forma_de_pagamento_tipo: item.id_forma_de_pagamento_tipo,
                        id_usuario: item.id_usuario,
                        data_fechamento: DateTime.now(),
                        hora_fechamento: DateTime.now(),
                        historico: item.history,
                        valor_sistema: item.value_system,
                        valor_informado: item.value_info,
                    });
                }
                return response.status(201);
            }
        }
        catch (error) {
            console.log(error);
        }
    }
}
//# sourceMappingURL=caixa_fechamento_controller.js.map