import CaixaFechamento from '#models/caixa_fechamento';
import { DateTime } from 'luxon';
export default class CaixaFechamentoController {
    async create({ request, response }) {
        try {
            let data = request.body();
            if (data && data.length > 0) {
                for (const item of data) {
                    const findCloseCashDesk = await CaixaFechamento.query()
                        .where('id_caixa_movimento', item.id_caixa_movimento)
                        .where('id_forma_de_pagamento_tipo', item.id_forma_de_pagamento_tipo)
                        .first();
                    if (findCloseCashDesk) {
                        findCloseCashDesk.id_usuario = item.id_usuario;
                        findCloseCashDesk.valor_informado = Number(item.value_info);
                        findCloseCashDesk.valor_sistema = Number(item.value_system);
                        findCloseCashDesk.data_fechamento = DateTime.now();
                        findCloseCashDesk.hora_fechamento = DateTime.now();
                        findCloseCashDesk.historico = item.history;
                        findCloseCashDesk.sync_prime = false;
                        await findCloseCashDesk.save();
                    }
                    else {
                        await CaixaFechamento.create({
                            id_caixa_movimento: item.id_caixa_movimento,
                            id_forma_de_pagamento_tipo: item.id_forma_de_pagamento_tipo,
                            id_usuario: item.id_usuario,
                            data_fechamento: DateTime.now(),
                            hora_fechamento: DateTime.now(),
                            historico: item.history,
                            valor_sistema: item.value_system,
                            valor_informado: item.value_info,
                        });
                    }
                }
                return response.status(201);
            }
        }
        catch (error) {
            console.log(error);
        }
    }
}
//# sourceMappingURL=caixa_fechamento_controller.js.map