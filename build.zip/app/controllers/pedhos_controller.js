import PrimeFilaImpressao from '#models/prime_fila_impressao';
import Venda from '#models/venda';
import VendaItem from '#models/venda_item';
import Comanda from '#models/comanda';
import Terminal from '#models/terminal';
import VendaCliente from '#models/venda_cliente';
export default class PedhosController {
    static async preencherVendaPedhos() {
        try {
            const filaImpressao = await PrimeFilaImpressao.query()
                .whereIn('status', ['PEDHOS_DEPARTAMENTO1'])
                .orderBy('created_at', 'asc');
            if (filaImpressao.length === 0) {
                return true;
            }
            const vendasProcessadas = new Set();
            for (const item of filaImpressao) {
                if (item) {
                    const dadosJson = item.conteudo_json;
                    if (vendasProcessadas.has(dadosJson.id_venda)) {
                        await item.delete();
                        continue;
                    }
                    try {
                        const venda = await Venda.query()
                            .where('id', dadosJson.id_venda)
                            .preload('vendaItem', (subQuery) => {
                            subQuery
                                .preload('subItens', (subQuerySubItem) => {
                                subQuerySubItem.preload('produto', (subQueryProduct) => {
                                    subQueryProduct.preload('ProdutoEmpresa');
                                });
                            })
                                .preload('produto', (subQueryProduct) => {
                                subQueryProduct.preload('ProdutoEmpresa');
                            });
                        })
                            .first();
                        if (!venda) {
                            return;
                        }
                        await Promise.all(venda.vendaItem.map(async (itemVenda) => {
                            const vendaItem = await VendaItem.find(itemVenda.id);
                            if (!vendaItem) {
                                return;
                            }
                            vendaItem.syncPrime = false;
                            if (dadosJson.tipo === 'comanda') {
                                const comanda = await Comanda.query()
                                    .where('comanda', dadosJson.id_pedhos)
                                    .select('id')
                                    .first();
                                vendaItem.status = 'PROVISORIO_COMANDA';
                                vendaItem.productDescription = itemVenda.produto.name;
                                vendaItem.totalValue =
                                    Number(vendaItem.saledQuantity) * Number(vendaItem.unitaryValue);
                                vendaItem.codigo = Number(itemVenda.produto.code);
                                vendaItem.ncm = itemVenda.produto.ProdutoEmpresa[0].ncm;
                                vendaItem.cfop = String(itemVenda.produto.ProdutoEmpresa[0].sat_nfce_cfop);
                                vendaItem.csosn = String(itemVenda.produto.ProdutoEmpresa[0].sat_nfce_csosn);
                                vendaItem.aliquotIcms = String(itemVenda.produto.ProdutoEmpresa[0].sat_nfce_aliquot_icms);
                                vendaItem.id_comanda = comanda.id;
                                vendaItem.listar_na_comanda = true;
                            }
                            await vendaItem.save();
                        }));
                        const NovaVendaItens = await VendaItem.query()
                            .where('id_venda', venda.id)
                            .where('status', 'PROVISORIO_COMANDA')
                            .select('totalValue');
                        const valorTotalItens = NovaVendaItens.reduce((acc, itemNovaVenda) => acc + Number(itemNovaVenda.totalValue), 0);
                        const updateVenda = await Venda.find(venda.id);
                        updateVenda.idGrupo = 1;
                        updateVenda.syncPrime = false;
                        updateVenda.totalValue = valorTotalItens;
                        updateVenda.valorProdutos = valorTotalItens;
                        updateVenda.origem = 'COMANDA';
                        await updateVenda.save();
                        const terminal = await Terminal.query()
                            .where('terminalPricipal', true)
                            .select('idterminal')
                            .first();
                        if (!terminal) {
                            return;
                        }
                        const novoJson = await this.preencherFilaImpressao(dadosJson.id_venda);
                        item.conteudo_json = novoJson;
                        item.status = 'PENDENTE';
                        item.id_terminal = terminal.idterminal;
                        await item.save();
                        vendasProcessadas.add(dadosJson.id_venda);
                    }
                    catch (parseError) {
                        console.error('Erro:', parseError);
                        continue;
                    }
                }
            }
            return {
                success: true,
                message: 'Processamento concluído',
            };
        }
        catch (error) {
            console.error('Erro geral:', error);
            return {
                success: false,
                message: 'Erro no processamento',
            };
        }
    }
    static async extratoComandaPedhos() {
        try {
            const filaImpressao = await PrimeFilaImpressao.query()
                .whereIn('status', ['PEDHOS_EXTRATO'])
                .orderBy('created_at', 'asc');
            if (filaImpressao.length === 0) {
                return true;
            }
            for (const item of filaImpressao) {
                const dadosJson = item.conteudo_json;
                const comanda = await Comanda.query()
                    .where('comanda', dadosJson.id_pedhos)
                    .select('id', 'comanda')
                    .first();
                if (!comanda) {
                    return;
                }
                const venda = await Venda.query()
                    .whereHas('vendaItem', (subQuery) => {
                    subQuery.where('id_comanda', comanda.id).where('listar_na_comanda', true);
                })
                    .select('id')
                    .first();
                if (!venda) {
                    return;
                }
                const vendaItens = await VendaItem.query()
                    .where('id_comanda', comanda.id)
                    .where('listar_na_comanda', true)
                    .preload('caracteristicas')
                    .preload('subItens', (subQuerySubItem) => {
                    subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                        subQueryProduct.preload('ProdutoEmpresa');
                    });
                })
                    .preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                })
                    .preload('comanda');
                let novoJson = await this.preencherFilaImpressao(venda.id);
                novoJson.comanda = comanda.comanda;
                novoJson.itens = vendaItens.map((itemVenda) => {
                    return {
                        id: itemVenda.id,
                        id_produto: itemVenda.idProduto,
                        nome: itemVenda.productDescription,
                        quantidade: Number(itemVenda.saledQuantity),
                        valor: Number(itemVenda.unitaryValue),
                        total: Number(itemVenda.totalValue),
                        desconto: Number(itemVenda.totalDescountValue),
                        observacao: itemVenda.observacao,
                        taxa_de_entrega: itemVenda.taxaDeEntrega,
                        taxa_de_couvert: itemVenda.couvert,
                        taxa_de_servico: itemVenda.taxaDeServico,
                        produto: {
                            ...itemVenda.produto,
                        },
                        caracteristicas: itemVenda.caracteristicas.map((car) => ({
                            idProdutoCaracteristica: car.id_produto_caracteristica,
                            categoria: car.categoria,
                            codigo: car.codigo,
                            descricao: car.descricao,
                            fixo: car.fixo,
                        })),
                        sub_itens: itemVenda.subItens.map((subItem) => ({
                            id: subItem.id,
                            id_produto: subItem.idProduto,
                            quantidade: subItem.quantidade,
                            valor: subItem.valorUnitario,
                            total: subItem.valorTotal,
                            descricao: subItem.descricao,
                            codigo: Number(subItem.codigo),
                            observacao: subItem.observacao || '',
                            produto: {
                                ...subItem.produto,
                            },
                            caracteristicas: subItem.caracteristicas.map((car) => ({
                                idProdutoCaracteristica: car.id_produto_caracteristica,
                                categoria: car.categoria,
                                codigo: car.codigo,
                                descricao: car.descricao,
                                fixo: car.fixo,
                            })),
                        })),
                    };
                });
                item.conteudo_json = novoJson;
                item.status = 'PENDENTE';
                await item.save();
            }
        }
        catch (error) {
            console.error('Erro geral:', error);
            return {
                success: false,
                message: 'Erro no processamento',
            };
        }
    }
    static async cancelarItemPedhos() {
        try {
            const filaImpressao = await PrimeFilaImpressao.query()
                .whereIn('status', ['PEDHOS_CANCELAMENTO'])
                .orderBy('created_at', 'asc');
            if (filaImpressao.length === 0) {
                return true;
            }
            for (const item of filaImpressao) {
                const dadosJson = item.conteudo_json;
                const venda = await Venda.query().where('id', dadosJson.id_venda).select('id').first();
                if (!venda) {
                    return;
                }
                let novoJson = await this.preencherFilaImpressao(venda.id);
                novoJson.itens = [];
                item.conteudo_json = novoJson;
                item.status = 'PENDENTE';
                await item.save();
            }
        }
        catch (error) {
            console.error('Erro geral:', error);
            return {
                success: false,
                message: 'Erro no processamento',
            };
        }
    }
    static async preencherFilaImpressao(idVenda) {
        const saleData = {
            id: 0,
            codigo: 0,
            code: 0,
            senha_delivery: 0,
            cpf: '',
            status: '',
            id_vendedor: null,
            id_caixa_movimento: null,
            id_venda_orcamento: null,
            id_usuario_criacao: null,
            itens: [],
            origem: '',
            venda_cliente: {
                id: 0,
                cliente: {
                    id: 0,
                    nome_fantasia: '',
                },
                telefone: '',
                logradouro: '',
                numero: '',
                complemento: '',
                bairro: '',
                cidade: '',
                uf: '',
                cep: '',
                codigo_cidade: '',
                codigo_uf: '',
                referencia: '',
            },
            UsuarioCriacao: {
                id: 0,
                nome: '',
            },
            empresa: {
                id: 0,
                nome_fantasia: '',
                telefone: '',
                cpf_cnpj: '',
                ie_rg: '',
                logradouro: '',
                numero: '',
                complemento: '',
                bairro: '',
                cidade: '',
                uf: '',
                cep: '',
            },
            itens_para_deletar: [],
            venda_forma_de_pagamento_para_deletar: [],
            venda_forma_de_pagamento: [],
            sub_total: 0,
            acrescimo: 0,
            desconto_geral: 0,
            total_a_pagar: 0,
            saldo_a_pagar: 0,
            valor_pago: 0,
            troco: 0,
        };
        const sale = await Venda.query()
            .where('id', idVenda)
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            })
                .preload('comanda');
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .first();
        if (sale) {
            saleData.codigo = sale.codigo;
            saleData.senha_delivery = sale.senhaDelivery;
            saleData.code = sale.code;
            saleData.id_vendedor = sale.idVendedor;
            saleData.id_caixa_movimento = sale.idCaixaMovimento;
            saleData.id_venda_orcamento = sale.idVendaOrcamento;
            saleData.id_usuario_criacao = sale.idUsuarioCriacao;
            saleData.origem = sale.origem;
            saleData.comanda = sale?.vendaItem[0]?.comanda?.comanda;
            saleData.UsuarioCriacao = {
                id: sale.UsuarioCriacao?.idfuncionariousuario || 0,
                nome: sale.UsuarioCriacao?.usuario || '',
            };
            saleData.empresa = {
                id: sale.empresa?.id || 0,
                nome_fantasia: sale.empresa?.nome_fantasia || '',
                telefone: sale.empresa?.telefone || '',
                cpf_cnpj: sale.empresa?.cnpj_cpf || '',
                ie_rg: sale.empresa?.ie_rg || '',
                logradouro: sale.empresa?.enderecos[0]?.logradouro || '',
                numero: sale.empresa?.enderecos[0]?.numero || '',
                complemento: sale.empresa?.enderecos[0]?.complemento || '',
                bairro: sale.empresa?.enderecos[0]?.bairro || '',
                cidade: sale.empresa?.enderecos[0]?.cidade || '',
                uf: sale.empresa?.enderecos[0]?.uf || '',
                cep: sale.empresa?.enderecos[0]?.cep || '',
            };
            const client = await VendaCliente.query().where('id_venda', sale.id).first();
            if (client) {
                saleData.venda_cliente.id = client.id;
                saleData.venda_cliente.codigo = client.codigo;
                saleData.venda_cliente.cliente.id = client.idEmpresa;
                saleData.venda_cliente.nome_fantasia = client.nomeFantasia;
                saleData.venda_cliente.razao_social = client.razaoSocial;
                saleData.venda_cliente.apelido = client.apelido;
                saleData.venda_cliente.cnpj_cpf = client.cnpjCpf;
                saleData.venda_cliente.ie_rg = client.ieRg;
                saleData.venda_cliente.im = client.im;
                saleData.venda_cliente.telefone = client.telefone;
                saleData.venda_cliente.tipo_endereco = client.tipoEndereco;
                saleData.venda_cliente.logradouro = client.logradouro;
                saleData.venda_cliente.numero = client.numero;
                saleData.venda_cliente.complemento = client.complemento;
                saleData.venda_cliente.bairro = client.bairro;
                saleData.venda_cliente.cidade = client.cidade;
                saleData.venda_cliente.uf = client.uf;
                saleData.venda_cliente.cep = client.cep;
                saleData.venda_cliente.codigo_cidade = client.codigoCidade;
                saleData.venda_cliente.codigo_uf = client.codigoUf;
                saleData.venda_cliente.referencia = client.referencia;
            }
            saleData.id = sale.id;
            saleData.cpf = sale.cpf;
            saleData.status = sale.status;
            saleData.itens_para_deletar = [];
            saleData.venda_forma_de_pagamento_para_deletar = [];
            saleData.itens = sale.vendaItem.map((item) => {
                return {
                    id: item.id,
                    id_produto: item.produto.id,
                    nome: item.productDescription,
                    quantidade: Number(item.saledQuantity),
                    valor: Number(item.unitaryValue),
                    total: Number(item.totalValue),
                    desconto: Number(item.totalDescountValue),
                    observacao: item.observacao,
                    taxa_de_entrega: item.taxaDeEntrega,
                    taxa_de_couvert: item.couvert,
                    taxa_de_servico: item.taxaDeServico,
                    produto: {
                        ...item.produto,
                    },
                    caracteristicas: item.caracteristicas.map((car) => ({
                        idProdutoCaracteristica: car.id_produto_caracteristica,
                        categoria: car.categoria,
                        codigo: car.codigo,
                        descricao: car.descricao,
                        fixo: car.fixo,
                    })),
                    sub_itens: item.subItens.map((subItem) => ({
                        id: subItem.id,
                        id_produto: subItem.idProduto,
                        quantidade: subItem.quantidade,
                        valor: subItem.valorUnitario,
                        total: subItem.valorTotal,
                        descricao: subItem.descricao,
                        codigo: Number(subItem.codigo),
                        observacao: subItem.observacao || '',
                        produto: {
                            ...subItem.produto,
                        },
                        caracteristicas: subItem.caracteristicas.map((car) => ({
                            idProdutoCaracteristica: car.id_produto_caracteristica,
                            categoria: car.categoria,
                            codigo: car.codigo,
                            descricao: car.descricao,
                            fixo: car.fixo,
                        })),
                    })),
                };
            });
            saleData.venda_forma_de_pagamento = sale.vendaFormaDePagamento.map((item) => {
                let labelDescription = '';
                const type = item.formaDePagamento.formaDePagamentoTipo;
                const condition = item.formaDePagamento.formaDePagamentoCondicao;
                const paymentMethod = item.formaDePagamento;
                const flag = item.formaDePagamento.bandeira;
                const accountBank = item.formaDePagamento.contaBancaria;
                const installments = item.vendaFormaDePagamentoParcela;
                if ((type.nome === 'CARTÃO DE CRÉDITO' || type.nome === 'CARTÃO DE DÉBITO') &&
                    flag &&
                    flag.nome) {
                    labelDescription = String(`${type.nome} | ${condition.nome} | BANDEIRA ${flag.nome} | QUANTIDADE ${Number(paymentMethod.quantidade)}`);
                }
                else {
                    labelDescription = String(`${type.nome} | ${condition.nome} | QUANTIDADE ${Number(paymentMethod.quantidade)}`);
                }
                return {
                    id: item.id,
                    description: labelDescription,
                    payment_method: {
                        id: paymentMethod.id,
                        amount: paymentMethod.quantidade,
                        term: paymentMethod.prazo,
                        type: type.nome,
                        condition: condition.nome,
                        flag: flag.nome,
                        rate: paymentMethod.tarifa,
                        id_bank_account: accountBank ? accountBank.id : null,
                        cmp: type.cmp,
                        label_description: labelDescription,
                    },
                    value: Number(item.installmentValue),
                    installments: installments.map((installment) => {
                        return {
                            id: installment.id,
                            id_sale_payment_method: installment.idVendaFormaDePagamento,
                            id_payment_method_condition: installment.idFormaDePagamentoCondicao,
                            value: installment.installmentValue,
                            date: installment.installmentDate,
                            count: installment.count,
                            tax_percentage: installment.tax_percentage,
                        };
                    }),
                };
            });
            const totalPaid = sale.vendaFormaDePagamento.reduce((sum, item) => sum + Number(item.installmentValue), 0);
            const addition = Number(sale.valorTaxaDelivery) + Number(sale.valorCouvert) + Number(sale.valorTaxaServico);
            const totalToPay = Number(sale.valorProdutos) - Number(sale.totalDescountValue) + addition;
            const change = totalPaid - totalToPay < 0 ? 0 : totalPaid - totalToPay;
            saleData.sub_total = Number(sale.valorProdutos);
            saleData.acrescimo = addition;
            saleData.desconto_geral = Number(sale.totalDescountValue);
            saleData.total_a_pagar = totalToPay;
            saleData.saldo_a_pagar = totalToPay - totalPaid <= 0 ? 0 : totalToPay - totalPaid;
            saleData.valor_pago = totalPaid;
            saleData.troco = change;
        }
        return saleData;
    }
}
//# sourceMappingURL=pedhos_controller.js.map