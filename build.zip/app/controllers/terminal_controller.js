import Terminal from '#models/terminal';
export default class TerminalController {
    async index({ response }) {
        try {
            const terminals = await Terminal.all();
            return response.status(200).json(terminals);
        }
        catch (error) {
            return response.status(500).json({
                message: 'Erro ao buscar terminais',
                error: error.message,
            });
        }
    }
    async store({ request, response }) {
        try {
            const data = request.only([
                'id_empresa',
                'idVisitor',
                'numero',
                'nome',
                'caixa_destino',
                'liberarEditarValor',
                'solicitarQuantidade',
                'deleted',
                'nfce',
                'tipoImpressaoSatNfce',
                'desativarConsultaProduto',
                'exigirSenhaVendedor',
                'solicitarCodigoVendedor',
                'tiposDeImpressaoEscolhaImpressora',
                'pedirObsFechamentoOrcamento',
                'selecionarImpressoraOrcamento',
                'imprimirItensCupom2Linhas',
                'solicitarConfirmacaoDoValorDoItem',
            ]);
            const terminal = await Terminal.create(data);
            return response.status(201).json(terminal);
        }
        catch (error) {
            return response.status(500).json({
                message: 'Erro ao criar terminal',
                error: error.message,
            });
        }
    }
    async show({ params, response }) {
        try {
            const terminal = await Terminal.findOrFail(params.id);
            return response.status(200).json(terminal);
        }
        catch (error) {
            return response.status(404).json({
                message: 'TERMINAL NÃO ENCONTRADO',
                error: error.message,
            });
        }
    }
    async update({ params, request, response }) {
        try {
            const terminal = await Terminal.findOrFail(params.id);
            const data = request.only([
                'id_empresa',
                'idVisitor',
                'numero',
                'nome',
                'caixa_destino',
                'liberarEditarValor',
                'solicitarQuantidade',
                'deleted',
                'nfce',
                'tipoImpressaoSatNfce',
                'desativarConsultaProduto',
                'exigirSenhaVendedor',
                'solicitarCodigoVendedor',
                'tiposDeImpressaoEscolhaImpressora',
                'pedirObsFechamentoOrcamento',
                'selecionarImpressoraOrcamento',
                'imprimirItensCupom2Linhas',
                'solicitarConfirmacaoDoValorDoItem',
                'acbr_caminho',
                'qztray_certificado',
                'qztray_chave',
            ]);
            await terminal.merge(data).save();
            return response.status(200).json(terminal);
        }
        catch (error) {
            return response.status(404).json({
                message: 'ERRO AO ATUALIZAR TERMINAL',
                error: error.message,
            });
        }
    }
    async destroy({ params, response }) {
        try {
            const terminal = await Terminal.findOrFail(params.id);
            await terminal.delete();
            return response.status(204);
        }
        catch (error) {
            return response.status(404).json({
                message: 'ERRO AO EXCLUIR TERMINAL',
                error: error.message,
            });
        }
    }
}
//# sourceMappingURL=terminal_controller.js.map