import PrimeImagem from '#models/prime_imagem';
export default class PrimeImagemsController {
    async index(ctx) {
        const data = ctx.request.all();
        console.log(data);
        const imagens = await PrimeImagem.all();
        return ctx.response.json(imagens);
    }
}
//# sourceMappingURL=prime_imagems_controller.js.map