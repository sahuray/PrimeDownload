import PrimePermissao from '#models/prime_permissao';
export default class PermissionController {
    async index(ctx) {
        const data = ctx.request.all();
        const permissions = await PrimePermissao.query()
            .whereHas('permissaoUsuario', (query) => {
            query.where('id_usuario', data.id_usuario).whereNull('deleted_at');
        })
            .if(data.slug, (query) => {
            query.whereIn('slug', data.slug);
        })
            .if(data.pagina, (query) => {
            query.whereIn('pagina', data.pagina);
        })
            .whereNull('deleted_at')
            .select('slug');
        const slugs = permissions.map((permission) => permission.slug);
        return ctx.response.status(200).json({ slugs });
    }
}
//# sourceMappingURL=permission_controller.js.map