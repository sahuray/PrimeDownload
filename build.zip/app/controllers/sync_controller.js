import GrupoService from '#services/synchrony/group';
import EmpresaService from '#services/synchrony/empresa';
import EnderecoService from '#services/synchrony/endereco';
import FuncionarioUsuarioService from '#services/synchrony/funcionario_usuario';
import FuncionarioService from '#services/synchrony/funcionario';
import ContatoService from '#services/synchrony/contato';
import FormaDePagamentoService from '#services/synchrony/forma_de_pagamento';
import FormaDePagamentoTipoService from '#services/synchrony/forma_de_pagamento_tipo';
import FormaDePagamentoCondicaoService from '#services/synchrony/forma_de_pagamento_condicao';
import ContaBancariaService from '#services/synchrony/conta_bancaria';
import BandeiraService from '#services/synchrony/bandeira';
import BancoService from '#services/synchrony/banco';
import ProdCategoriaSetorService from '#services/synchrony/produto_categoria_setor';
import ProdCategoriaGrupoService from '#services/synchrony/produto_categoria_grupo';
import ProdCategoriaSubGrupoService from '#services/synchrony/produto_categoria_sub_grupo';
import ProdCategoriaLinhaService from '#services/synchrony/produto_categoria_linha';
import MarcaService from '#services/synchrony/marca';
import UnidadeService from '#services/synchrony/unidade';
import ProdutoInformacaoNutricionalService from '#services/synchrony/produto_informacao_nutricional';
import ProdutoService from '#services/synchrony/produto';
import ProdutoPrecoService from '#services/synchrony/produto_preco';
import ProdutoNumeroSerieService from '#services/synchrony/produto_numero_de_serie';
import ProdutoLoteExpiracaoService from '#services/synchrony/produto_lote_expiracao';
import ProdutoEstoqueService from '#services/synchrony/produto_estoque';
import ProdutoEmpresaService from '#services/synchrony/produto_empresa';
import ProdutoCompostoService from '#services/synchrony/produto_composto';
import ProdutoCompativelService from '#services/synchrony/produto_compativel';
import ProdutoCaracteristicaService from '#services/synchrony/produto_caracteristica';
import Terminalservice from '#services/synchrony/terminal';
import CaixaMovimentoService from '#services/synchrony/caixa_movimento';
import TaxaDeEntregaService from '#services/synchrony/taxa_de_entrega';
import MotoboyService from '#services/synchrony/motoboy';
import SetorService from '#services/synchrony/setor';
import MesaService from '#services/synchrony/mesa';
import UploadService from '#services/synchrony/upload';
import EmpresaComandaConfigsService from '#services/synchrony/empresa_comanda_config';
import EmpresaPdvConfigService from '#services/synchrony/empresa_pdv_config';
import EmpresaDeliveryConfigService from '#services/synchrony/empresa_delivery_config';
import EmpresaPrathosConfigsService from '#services/synchrony/empresa_prathos_config';
import PermissaoService from '#services/synchrony/permissao';
import PermissaoUsuarioService from '#services/synchrony/permissao_usuario';
import ComandaService from '#services/synchrony/comanda';
import MunicipioService from '#services/synchrony/municipio';
export default class SyncController {
    bancoService;
    formaDePagamentoTipoService;
    formaDePagamentoCondicaoService;
    bandeiraService;
    grupoService;
    contaBancariaService;
    empresaService;
    formaDePagamentoService;
    funcionarioUsuarioService;
    prodCategoriaSetorService;
    prodCategoriaGrupoService;
    prodCategoriaSubGrupoService;
    prodCategoriaLinhaService;
    marcaService;
    unidadeService;
    produtoInformacaoNutricionalService;
    produtoPrecoService;
    produtoService;
    produtoNumeroSerieService;
    produtoLoteExpiracaoService;
    produtoEstoqueService;
    produtoEmpresaService;
    produtoCompostoService;
    produtoCompativelService;
    terminalService;
    caixaMovimentoService;
    funcionarioService;
    enderecoService;
    taxaDeEntregaService;
    motoboyService;
    setorService;
    contatoService;
    uploadService;
    empresaComandaConfigsService;
    empresaPdvConfigsService;
    empresaDeliveryConfigService;
    empresaPrathosConfigService;
    produtoCaracteristicaService;
    permissaoService;
    permissaoUsuarioService;
    mesaService;
    comandaService;
    municipioService;
    constructor() {
        this.bancoService = new BancoService();
        this.enderecoService = new EnderecoService();
        this.formaDePagamentoTipoService = new FormaDePagamentoTipoService();
        this.formaDePagamentoCondicaoService = new FormaDePagamentoCondicaoService();
        this.bandeiraService = new BandeiraService();
        this.grupoService = new GrupoService();
        this.contaBancariaService = new ContaBancariaService();
        this.empresaService = new EmpresaService();
        this.formaDePagamentoService = new FormaDePagamentoService();
        this.funcionarioUsuarioService = new FuncionarioUsuarioService();
        this.prodCategoriaSetorService = new ProdCategoriaSetorService();
        this.prodCategoriaGrupoService = new ProdCategoriaGrupoService();
        this.prodCategoriaSubGrupoService = new ProdCategoriaSubGrupoService();
        this.prodCategoriaLinhaService = new ProdCategoriaLinhaService();
        this.marcaService = new MarcaService();
        this.unidadeService = new UnidadeService();
        this.produtoInformacaoNutricionalService = new ProdutoInformacaoNutricionalService();
        this.produtoPrecoService = new ProdutoPrecoService();
        this.produtoService = new ProdutoService();
        this.produtoNumeroSerieService = new ProdutoNumeroSerieService();
        this.produtoLoteExpiracaoService = new ProdutoLoteExpiracaoService();
        this.produtoEstoqueService = new ProdutoEstoqueService();
        this.produtoEmpresaService = new ProdutoEmpresaService();
        this.produtoCompostoService = new ProdutoCompostoService();
        this.produtoCompativelService = new ProdutoCompativelService();
        this.produtoCaracteristicaService = new ProdutoCaracteristicaService();
        this.terminalService = new Terminalservice();
        this.caixaMovimentoService = new CaixaMovimentoService();
        this.funcionarioService = new FuncionarioService();
        this.taxaDeEntregaService = new TaxaDeEntregaService();
        this.motoboyService = new MotoboyService();
        this.setorService = new SetorService();
        this.mesaService = new MesaService();
        this.contatoService = new ContatoService();
        this.uploadService = new UploadService();
        this.empresaComandaConfigsService = new EmpresaComandaConfigsService();
        this.empresaPdvConfigsService = new EmpresaPdvConfigService();
        this.empresaDeliveryConfigService = new EmpresaDeliveryConfigService();
        this.empresaPrathosConfigService = new EmpresaPrathosConfigsService();
        this.permissaoService = new PermissaoService();
        this.permissaoUsuarioService = new PermissaoUsuarioService();
        this.comandaService = new ComandaService();
        this.municipioService = new MunicipioService();
    }
    async syncGroup(ctx) {
        try {
            await this.grupoService.syncGroups();
            return ctx.response.status(200).send({
                message: 'Sincronização de grupo concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
        }
    }
    async syncCompany(ctx) {
        try {
            await this.empresaService.syncCompanies();
            return ctx.response.status(200).send({
                message: 'Sincronização de empresa concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar empresa.',
                error: err.message,
            });
        }
    }
    async syncAddress(ctx) {
        try {
            await this.enderecoService.syncAddresses();
            return ctx.response.status(200).send({
                message: 'Sincronização de empresa concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar empresa.',
                error: err.message,
            });
        }
    }
    async syncUser(ctx) {
        try {
            await this.funcionarioUsuarioService.getUsers();
            return ctx.response.status(200).send({
                message: 'Sincronização de usuarios concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar os usuarios.',
                error: err.message,
            });
        }
    }
    async syncEmployee(ctx) {
        try {
            await this.funcionarioService.syncEmployees();
            return ctx.response.status(200).send({
                message: 'Sincronização de funcionario concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar os funcionario.',
                error: err.message,
            });
        }
    }
    async syncBank(ctx) {
        try {
            await this.bancoService.syncBanks();
            return ctx.response.status(200).send({
                message: 'Sincronização de bancos concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar bancos.',
                error: err.message,
            });
        }
    }
    async syncFlag(ctx) {
        try {
            await this.bandeiraService.syncFlags();
            return ctx.response.status(200).send({
                message: 'Sincronização de bandeiras concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar bandeiras.',
                error: err.message,
            });
        }
    }
    async syncPaymentsMethod(ctx) {
        try {
            await this.formaDePagamentoService.syncPaymentsMethod();
            return ctx.response.status(200).send({
                message: 'Sincronização de forma de pagamentos concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar forma de pagamentos.',
                error: err.message,
            });
        }
    }
    async syncPaymentsMethodType(ctx) {
        try {
            await this.formaDePagamentoTipoService.syncPaymentsMethodType();
            return ctx.response.status(200).send({
                message: 'Sincronização de forma de pagamentos tipo concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar forma de pagamentos tipo.',
                error: err.message,
            });
        }
    }
    async syncPaymentsMethodCondition(ctx) {
        try {
            await this.formaDePagamentoCondicaoService.syncPaymentsMethodCondition();
            return ctx.response.status(200).send({
                message: 'Sincronização de forma de pagamentos condicao concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar forma de pagamentos condicao.',
                error: err.message,
            });
        }
    }
    async syncBankAccount(ctx) {
        try {
            await this.contaBancariaService.syncBankAccount();
            return ctx.response.status(200).send({
                message: 'Sincronização de conta bancária concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar conta bancária.',
                error: err.message,
            });
        }
    }
    async syncProdCategorySector(ctx) {
        try {
            await this.prodCategoriaSetorService.syncProdCategorySector();
            return ctx.response.status(200).send({
                message: 'Sincronização de categoria (setor) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar categoria (setor).',
                error: err.message,
            });
        }
    }
    async syncProdCategoryGroup(ctx) {
        try {
            await this.prodCategoriaGrupoService.syncProdCategoryGroup();
            return ctx.response.status(200).send({
                message: 'Sincronização de categoria (grupo) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar categoria (grupo).',
                error: err.message,
            });
        }
    }
    async syncProdCategorySubGroup(ctx) {
        try {
            await this.prodCategoriaSubGrupoService.syncProdCategorySubGroup();
            return ctx.response.status(200).send({
                message: 'Sincronização de categoria (sub-grupo) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar categoria (sub-grupo).',
                error: err.message,
            });
        }
    }
    async syncProdCategoryLine(ctx) {
        try {
            await this.prodCategoriaLinhaService.syncProdCategoryLine();
            return ctx.response.status(200).send({
                message: 'Sincronização de categoria (linha) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar categoria (linha).',
                error: err.message,
            });
        }
    }
    async syncBrand(ctx) {
        try {
            await this.marcaService.syncBrand();
            return ctx.response.status(200).send({
                message: 'Sincronização de marca(s) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar marca(s).',
                error: err.message,
            });
        }
    }
    async syncUnit(ctx) {
        try {
            await this.unidadeService.syncUnit();
            return ctx.response.status(200).send({
                message: 'Sincronização de unidade(s) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar unidade(s).',
                error: err.message,
            });
        }
    }
    async syncInformationNutritional(ctx) {
        try {
            await this.produtoInformacaoNutricionalService.syncInformationNutritional();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto informacao nutricional(s) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto informacao nutricional(s).',
                error: err.message,
            });
        }
    }
    async syncProduct(ctx) {
        try {
            await this.produtoService.syncProduct();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto(s) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto(s).',
                error: err.message,
            });
        }
    }
    async syncProductCharacteristic(ctx) {
        try {
            await this.produtoCaracteristicaService.syncProductCharacteristic();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto caracteristica concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto caracteristica.',
                error: err.message,
            });
        }
    }
    async syncProductPrice(ctx) {
        try {
            await this.produtoPrecoService.syncProductPrice();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto preco(s) concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto preco(s).',
                error: err.message,
            });
        }
    }
    async syncProductSerialNumber(ctx) {
        try {
            await this.produtoNumeroSerieService.syncProdutoNumeroSerie();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto lote expiracao concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto lote expiracao.',
                error: err.message,
            });
        }
    }
    async syncProductLotExpiration(ctx) {
        try {
            await this.produtoLoteExpiracaoService.syncProdutoLoteExpiracao();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto lote expiracao concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto lote expiracao.',
                error: err.message,
            });
        }
    }
    async syncProductInventory(ctx) {
        try {
            await this.produtoEstoqueService.syncProdutoEstoque();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto estoque concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto estoque.',
                error: err.message,
            });
        }
    }
    async syncProductCompany(ctx) {
        try {
            await this.produtoEmpresaService.syncProdutoEmpresa();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto empresa concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto empresa.',
                error: err.message,
            });
        }
    }
    async syncProductComposite(ctx) {
        try {
            await this.produtoCompostoService.syncProdutoComposto();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto composto concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto composto.',
                error: err.message,
            });
        }
    }
    async syncProductCompatible(ctx) {
        try {
            await this.produtoCompativelService.syncProdutoCompativel();
            return ctx.response.status(200).send({
                message: 'Sincronização de produto compativel concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar produto compativel.',
                error: err.message,
            });
        }
    }
    async syncTerminal(ctx) {
        try {
            await this.terminalService.syncTerminals();
            return ctx.response.status(200).send({
                message: 'Sincronização de terminais concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar terminais.',
                error: err.message,
            });
        }
    }
    async syncMovementCashDesk(ctx) {
        try {
            await this.caixaMovimentoService.syncCaixaMovimento();
            return ctx.response.status(200).send({
                message: 'Sincronização de caixa movimento concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar caixa movimento.',
                error: err.message,
            });
        }
    }
    async syncDeliveryFee(ctx) {
        try {
            await this.taxaDeEntregaService.syncDeliveryFee();
            return ctx.response.status(200).send({
                message: 'Sincronização de taxa de entrega concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar taxa de entrega.',
                error: err.message,
            });
        }
    }
    async syncMotoboy(ctx) {
        try {
            await this.motoboyService.syncMotoboy();
            return ctx.response.status(200).send({
                message: 'Sincronização de motoboy concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar motoboy.',
                error: err.message,
            });
        }
    }
    async syncSetor(ctx) {
        try {
            await this.setorService.syncSetor();
            return ctx.response.status(200).send({
                message: 'Sincronização de setor concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar setor.',
                error: err.message,
            });
        }
    }
    async syncMesa(ctx) {
        try {
            await this.mesaService.syncMesa();
            return ctx.response.status(200).send({
                message: 'Sincronização de mesa concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar mesa.',
                error: err.message,
            });
        }
    }
    async syncContact(ctx) {
        try {
            await this.contatoService.syncContact();
            return ctx.response.status(200).send({
                message: 'Sincronização de contato concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar contato.',
                error: err.message,
            });
        }
    }
    async syncUpload(ctx) {
        try {
            await this.uploadService.syncUpload();
            return ctx.response.status(200).send({
                message: 'Sincronização de upload concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar upload.',
                error: err.message,
            });
        }
    }
    async syncCompanyCommandSetting(ctx) {
        try {
            await this.empresaComandaConfigsService.syncCompanyCommandSetting();
            return ctx.response.status(200).send({
                message: 'Sincronização de configuracao comanda concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar configuracao comanda.',
                error: err.message,
            });
        }
    }
    async syncCompanyPdvSetting(ctx) {
        try {
            await this.empresaPdvConfigsService.syncCompanyPdvSetting();
            return ctx.response.status(200).send({
                message: 'Sincronização de configuracao pdv concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar configuracao pdv.',
                error: err.message,
            });
        }
    }
    async syncCompanyDeliverySetting(ctx) {
        try {
            await this.empresaDeliveryConfigService.syncCompanyDeliverySetting();
            return ctx.response.status(200).send({
                message: 'Sincronização de configuracao delivery concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar configuracao delivery.',
                error: err.message,
            });
        }
    }
    async syncCompanyPrathosSetting(ctx) {
        try {
            await this.empresaPrathosConfigService.syncCompanyPrathosSetting();
            return ctx.response.status(200).send({
                message: 'Sincronização de configuracao prathos concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar configuracao prathos.',
                error: err.message,
            });
        }
    }
    async syncPermission(ctx) {
        try {
            await this.permissaoService.syncPermission();
            return ctx.response.status(200).send({
                message: 'Sincronização de permissao concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar permissao.',
                error: err.message,
            });
        }
    }
    async syncPermissionUser(ctx) {
        try {
            await this.permissaoUsuarioService.syncPermissionUser();
            return ctx.response.status(200).send({
                message: 'Sincronização de permissao usuario concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar permissao usuario.',
                error: err.message,
            });
        }
    }
    async syncComanda(ctx) {
        try {
            await this.comandaService.syncComanda();
            return ctx.response.status(200).send({
                message: 'Sincronização de comanda concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar comanda.',
                error: err.message,
            });
        }
    }
    async syncMunicipality(ctx) {
        try {
            await this.municipioService.syncMunicipality();
            return ctx.response.status(200).send({
                message: 'Sincronização de municipio concluída com sucesso.',
            });
        }
        catch (err) {
            console.log(err);
            return ctx.response.status(500).send({
                message: 'Erro ao sincronizar municipio.',
                error: err.message,
            });
        }
    }
}
//# sourceMappingURL=sync_controller.js.map