import ProdutoPreco from '#models/prime_produto_preco';
export default class ProdutoPrecoController {
    async selectProductPrice(ctx) {
        const data = ctx.request.all();
        const idProduct = ctx.params.id_product;
        const search = data.description;
        if (idProduct) {
            const prices = await ProdutoPreco.query()
                .where('id_produto', idProduct)
                .if(search, (subQuery) => {
                subQuery.whereRaw("(lower(description)) like '%' || (lower(?)) || '%'", [search]);
            })
                .orderByRaw('main_price DESC')
                .orderBy('main_price', 'asc')
                .limit(10);
            return ctx.response.json(prices);
        }
        else {
            return ctx.response.badRequest('PRODUTO NÃO INFORMADO!');
        }
    }
}
//# sourceMappingURL=produto_preco_controller.js.map