import ProdutoCategoriaSetor from '#models/prime_produto_categoria_setor';
import Upload from '#models/upload';
const fieldsToShow = ['id', 'name'];
export default class MercadoLogicoController {
    async indexSector(ctx) {
        const data = ctx.request.all();
        const search = data.search;
        const categorySectors = await ProdutoCategoriaSetor.query()
            .if(search, (subQuerySearch) => {
            subQuerySearch
                .whereRaw(`unaccent(name) ILIKE unaccent('%${String(search).toLowerCase()}%')`)
                .orWhereHas('Produtos', (productQuery) => {
                productQuery.whereRaw(`unaccent(name) ILIKE unaccent('%${String(search).toLowerCase()}%')`);
            });
        })
            .whereNull('deleted_at')
            .select(fieldsToShow);
        const idsCategoriesSector = categorySectors.map((item) => item.id);
        const images = await Upload.query()
            .where('type', 'image_sector')
            .whereIn('id_fk', idsCategoriesSector)
            .select(['id', 'id_fk', 'url']);
        return ctx.response.json({ categorySectors, images });
    }
}
//# sourceMappingURL=mercadologico_controller.js.map