import FuncionarioUsuario from '#models/funcionario_usuario';
import Terminal from '#models/terminal';
import Hash from '@adonisjs/core/services/hash';
export default class LoginController {
    async login({ request, response }) {
        const data = {
            username: request.input('username').toLowerCase(),
            password: request.input('password'),
        };
        const funcionarioUsuario = await FuncionarioUsuario.query()
            .whereRaw('LOWER(usuario) = ?', [data.username])
            .first();
        if (!funcionarioUsuario) {
            return response.status(401).json({ message: 'Usuário ou senha inválidos' });
        }
        const isPasswordValid = await Hash.verify(funcionarioUsuario.senha, data.password);
        if (!isPasswordValid) {
            return response.status(401).json({ message: 'Usuário ou senha inválidos' });
        }
        const terminal = await Terminal.query().exec();
        return response.json({
            message: 'Login realizado com sucesso',
            funcionarioUsuario,
            terminal,
        });
    }
    async loginPedhos(ctx) {
        const { senha, usuario } = ctx.request.qs();
        console.log(senha, usuario);
        try {
            if (!senha || !usuario) {
                return ctx.response.json({
                    sucesso: false,
                    mensagem: 'Senha ou usuário não informados',
                });
            }
            const funcionarioUsuario = await FuncionarioUsuario.query()
                .whereRaw('LOWER(usuario) = ?', [usuario.toLowerCase()])
                .first();
            console.log(funcionarioUsuario);
            if (!funcionarioUsuario) {
                return ctx.response.json({
                    sucesso: false,
                    mensagem: 'USUARIO NÃO ENCONTRADO',
                });
            }
            const hash = funcionarioUsuario.senha;
            const senhaValida = await Hash.verify(hash, senha);
            if (!senhaValida) {
                console.log('🔒 Senha inválida! Verifique suas credenciais e tente novamente.');
                return false;
            }
            console.log('🔑 Login realizado com sucesso!');
            return true;
        }
        catch (error) {
            return ctx.response.json({
                sucesso: false,
                mensagem: 'ERRO AO REALIZAR LOGIN: ' + error.message,
            });
        }
    }
}
//# sourceMappingURL=login_controller.js.map