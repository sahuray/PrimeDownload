import FuncionarioUsuario from '#models/funcionario_usuario';
import Terminal from '#models/terminal';
import Hash from '@adonisjs/core/services/hash';
import os from 'node:os';
export default class LoginController {
    async login({ request, response }) {
        const data = {
            username: request.input('username').toLowerCase(),
            password: request.input('password'),
        };
        const funcionarioUsuario = await FuncionarioUsuario.query()
            .whereRaw('LOWER(usuario) = ?', [data.username])
            .first();
        if (!funcionarioUsuario) {
            return response.status(401).json({ message: 'Usuário ou senha inválidos' });
        }
        const isPasswordValid = await Hash.verify(funcionarioUsuario.senha, data.password);
        if (!isPasswordValid) {
            return response.status(401).json({ message: 'Usuário ou senha inválidos' });
        }
        const terminal = await Terminal.query().exec();
        return response.json({
            message: 'Login realizado com sucesso',
            funcionarioUsuario,
            terminal,
        });
    }
    async vincularTerminal({ request, response }) {
        const data = request.all();
        const terminal = await Terminal.find(data.idterminal);
        const hostname = os.hostname();
        if (!terminal) {
            return response.status(404).json({ message: 'Terminal não encontrado' });
        }
        terminal.hostname = hostname;
        await terminal.save();
        return response.json({ message: 'Terminal vinculado com sucesso' });
    }
    async indexTerminal({ response }) {
        const hostname = os.hostname();
        const terminal = await Terminal.query().where('hostname', hostname).select('*').first();
        return response.json({ terminal });
    }
    async loginPedhos(ctx) {
        const { senha, usuario } = ctx.request.qs();
        try {
            if (!senha || !usuario) {
                console.log('🔒 Senha ou usuário não informados');
                return false;
            }
            const funcionarioUsuario = await FuncionarioUsuario.query()
                .preload('funcionario')
                .whereRaw('LOWER(usuario) = ?', [usuario.toLowerCase()])
                .first();
            if (!funcionarioUsuario) {
                console.log('🔒 Usuário não encontrado! Verifique suas credenciais e tente novamente.');
                return false;
            }
            const hash = funcionarioUsuario.senha;
            const senhaValida = await Hash.verify(hash, senha);
            if (!senhaValida) {
                console.log('🔒 Senha inválida! Verifique suas credenciais e tente novamente.');
                return false;
            }
            console.log('🔑 Login realizado com sucesso!');
            const json = {
                idfuncionario: funcionarioUsuario.idfuncionariousuario,
                nome: funcionarioUsuario.funcionario?.nome || funcionarioUsuario.usuario || '',
                status: funcionarioUsuario.funcionario
                    ? funcionarioUsuario.funcionario.statusfuncionario
                    : true,
            };
            return json;
        }
        catch (error) {
            console.log('🔒 ERRO AO REALIZAR LOGIN: ' + error.message);
            return false;
        }
    }
}
//# sourceMappingURL=login_controller.js.map