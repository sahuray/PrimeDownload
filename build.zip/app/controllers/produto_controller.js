import Produto from '#models/prime_produto';
import Upload from '#models/upload';
export default class ProdutoController {
    async index(ctx) {
        const products = await Produto.all();
        return ctx.response.json(products);
    }
    async selectProduct(ctx) {
        const data = ctx.request.only(['showInactive', 'selectedButton', 'search', 'id']);
        const products = await Produto.query()
            .if(data.id, (query) => {
            query.where('id', data.id);
        })
            .if(data.selectedButton === 'codigo' && data.search, (query) => {
            query.where('code', data.search);
        })
            .if(data.selectedButton === 'codigoBarras' && data.search, (query) => {
            query
                .where('codigo_barra_1', 'ilike', `%${data.search}%`)
                .orWhere('codigo_barra_2', 'ilike', `%${data.search}%`);
        })
            .if(data.selectedButton === 'referencia' && data.search, (query) => {
            query.where('reference', 'ilike', `%${data.search}%`);
        })
            .if(data.selectedButton === 'descricaoExata' && data.search, (query) => {
            query.where('name', 'ilike', `%${data.search}%`);
        })
            .if(data.selectedButton === 'palavraChave' && data.search, (query) => {
            const searchTerms = data.search.toLowerCase().split(' ');
            query.where((builder) => {
                searchTerms.forEach((term) => {
                    builder.whereRaw('LOWER(name) LIKE ?', [`%${term}%`]);
                });
            });
        })
            .if(data.showInactive === false, (query) => {
            query.whereNull('deleted_at');
        })
            .if(data.showInactive === true, (query) => {
            query.whereNotNull('deleted_at');
        })
            .preload('Estoque')
            .preload('Preco')
            .preload('ProdutoEmpresa')
            .select('*')
            .limit(100);
        return ctx.response.json(products);
    }
    async selectProductBySector(ctx) {
        const data = ctx.request.all();
        const idCategorySector = data.id_category_sector;
        const products = await Produto.query()
            .preload('Preco', (subQuery) => {
            subQuery
                .whereNull('deleted_at')
                .select(['id', 'id_produto', 'value', 'discount_max'])
                .where('main_price', true);
        })
            .preload('Upload', (subQuery) => {
            subQuery.select(['id', 'url']);
        })
            .where('id_produto_categoria_setor', idCategorySector)
            .whereNull('deleted_at')
            .select(['id', 'short_name']);
        const idsProducts = products.map((item) => item.id);
        const images = await Upload.query()
            .where('type', 'products')
            .whereIn('id_fk', idsProducts)
            .select(['id', 'id_fk', 'url']);
        return ctx.response.json({ products, images });
    }
    async findProduct(ctx) {
        const data = ctx.request.only(['code']);
        const searchBarcode = data.code;
        const product = await Produto.query()
            .where((query) => {
            query.whereNotNull('code').orWhereNotNull('codigo_barra_1').orWhereNotNull('codigo_barra_2');
        })
            .if(searchBarcode, (subQuery) => {
            subQuery.where((query) => {
                query
                    .where('code', data.code)
                    .orWhere('codigo_barra_1', data.code)
                    .orWhere('codigo_barra_2', data.code);
            });
        })
            .preload('Upload', (subQuery) => {
            subQuery.select(['id', 'url']);
        })
            .preload('Preco', (subQuery) => {
            subQuery.select('value').where('main_price', 1);
        })
            .whereHas('Preco', (subQuery) => {
            subQuery.where('main_price', true);
        })
            .first();
        const images = await Upload.query()
            .where('type', 'products')
            .where('id_fk', product?.id || 0)
            .select(['id', 'id_fk', 'url']);
        if (product) {
            return ctx.response.json({ product, images });
        }
        return ctx.response.noContent();
    }
    async checkPermitFractionate(ctx) {
        const productId = ctx.request.param('id');
        const product = await Produto.query()
            .preload('ProdutoEmpresa', (query) => {
            query.select('permit_fractionate');
        })
            .where('id', productId)
            .first();
        if (!product) {
            return ctx.response.notFound({ message: 'Produto não encontrado' });
        }
        const permitFractionate = product.ProdutoEmpresa?.[0]?.permit_fractionate ?? false;
        return ctx.response.json({ permit_fractionate: permitFractionate });
    }
}
//# sourceMappingURL=produto_controller.js.map