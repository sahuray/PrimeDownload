import Terminal from '#models/terminal';
import Produto from '#models/prime_produto';
import { SerialPort } from 'serialport';
export default class BalancasController {
    static port = null;
    async index({ params, response }) {
        const terminal = await Terminal.query()
            .where('idterminal', params.id)
            .select('modelobalanca', 'portabalanca', 'baundratebalanca', 'databitsbalanca', 'paridadebalanca', 'stopbitsbalanca', 'handshakingbalanca', 'timeoutbalanca')
            .first();
        if (!terminal) {
            return response.status(400).json({ erro: 'TERMINAL NÃO ENCONTRADO' });
        }
        return response.status(200).json({ terminal });
    }
    async updateTerminal({ params, request, response }) {
        const data = request.all();
        const terminal = await Terminal.find(params.id);
        if (!terminal) {
            return response.status(400).json({ erro: 'TERMINAL NÃO ENCONTRADO' });
        }
        terminal.modelobalanca = data.modelobalanca;
        terminal.portabalanca = data.portabalanca;
        terminal.baundratebalanca = data.baundratebalanca;
        terminal.databitsbalanca = data.databitsbalanca;
        terminal.paridadebalanca = data.paridadebalanca;
        terminal.stopbitsbalanca = data.stopbitsbalanca;
        terminal.handshakingbalanca = data.handshakingbalanca;
        terminal.timeoutbalanca = data.timeoutbalanca;
        await terminal.save();
        return response.status(200).json({ mensagem: 'BALANÇA CONFIGURADA COM SUCESSO' });
    }
    async conectar({ request, response }) {
        const data = request.all();
        try {
            if (BalancasController.port) {
                await BalancasController.port.close();
                BalancasController.port = null;
            }
            BalancasController.port = new SerialPort({
                path: String(data.portabalanca),
                baudRate: Number(data.baundratebalanca),
                dataBits: Number(data.databitsbalanca),
                parity: String(data.paridadebalanca),
                stopBits: Number(data.stopbitsbalanca),
            });
            return response.status(200).json({ mensagem: 'Balança conectada com sucesso' });
        }
        catch (error) {
            return response.status(500).json({
                erro: 'Erro ao conectar com a balança',
                detalhes: error.message,
            });
        }
    }
    static getComandoPeso(protocolo) {
        switch (protocolo.toUpperCase()) {
            case 'TOLEDO':
                return Buffer.from([0x05]);
            case 'FILIZOLA':
                return Buffer.from([0x05]);
            case 'URANO':
                return Buffer.from([0x24, 0x50]);
            case 'URANO POP':
                return Buffer.from([0x24, 0x50]);
            case 'MAGNA':
                return Buffer.from([0x4c, 0x50]);
            default:
                throw new Error('MODELO DE BALANÇA NÃO CONFIGURADO');
        }
    }
    static processaPeso(protocolo, data) {
        const resposta = data.toString().trim();
        switch (protocolo.toUpperCase()) {
            case 'TOLEDO':
                return resposta.replace(/[^\d.]/g, '').trim();
            case 'FILIZOLA':
                return resposta.replace(/[^\d.]/g, '').trim();
            case 'URANO':
                return resposta.replace(/[^\d.]/g, '').trim();
            case 'URANO POP':
                return resposta.replace(/[^\d.]/g, '').trim();
            case 'MAGNA':
                return resposta.replace(/[^\d.]/g, '').trim();
            default:
                throw new Error('MODELO DE BALANÇA NÃO CONFIGURADO');
        }
    }
    async lerPeso({ params, response }) {
        if (!BalancasController.port) {
            return response.status(400).json({ erro: 'BALANÇA NÃO ESTÁ CONECTADA' });
        }
        if (!BalancasController.port.isOpen) {
            return response.status(400).json({ erro: 'PORTA NÃO ESTÁ ABERTA' });
        }
        try {
            const terminalData = await Terminal.find(params.id);
            const protocolo = terminalData.modelobalanca;
            if (protocolo === 'NENHUMA') {
                return response.status(400).json({ erro: 'MODELO DE BALANÇA NÃO CONFIGURADO' });
            }
            const peso = await new Promise((resolve, reject) => {
                try {
                    const comando = BalancasController.getComandoPeso(protocolo);
                    BalancasController.port.write(comando, (writeErr) => {
                        if (writeErr) {
                            reject(writeErr);
                        }
                    });
                    BalancasController.port.once('data', (data) => {
                        try {
                            const pesoProcessado = BalancasController.processaPeso(protocolo, data);
                            resolve(pesoProcessado);
                        }
                        catch (error) {
                            reject(error);
                        }
                    });
                    setTimeout(() => {
                        reject(new Error('TIMEOUT AO AGUARDAR RESPOSTA DA BALANÇA'));
                    }, 3000);
                }
                catch (error) {
                    reject(error);
                }
            });
            return response.status(200).json({ peso });
        }
        catch (error) {
            return response.status(500).json({
                erro: 'ERRO AO LER PESO DA BALANÇA',
                detalhes: error.message,
            });
        }
    }
    async desconectar({ response }) {
        if (!BalancasController.port) {
            return response.status(400).json({ erro: 'Balança não está conectada' });
        }
        try {
            await BalancasController.port.close();
            BalancasController.port = null;
            return response.status(200).json({ mensagem: 'Balança desconectada com sucesso' });
        }
        catch (error) {
            return response.status(500).json({ erro: 'Erro ao desconectar balança' });
        }
    }
    async listarPortas({ response }) {
        try {
            const portas = await SerialPort.list();
            return response.status(200).json({ portas });
        }
        catch (error) {
            return response.status(500).json({
                erro: 'Erro ao listar portas',
                detalhes: error.message,
            });
        }
    }
    async verificarStatus({ response }) {
        try {
            const status = {
                conectado: BalancasController.port !== null && BalancasController.port.isOpen,
                porta: BalancasController.port?.path || null,
            };
            return response.status(200).json(status);
        }
        catch (error) {
            return response.status(500).json({
                erro: 'Erro ao verificar status da balança',
                detalhes: error.message,
            });
        }
    }
    async validateProduct({ params, response }) {
        const idProduto = params.id;
        const produto = await Produto.query()
            .preload('UnidadeComercial')
            .preload('UnidadeTributavel')
            .preload('ProdutoEmpresa')
            .where('id', idProduto)
            .first();
        if (!produto) {
            return response.status(400).json({ erro: 'PRODUTO NÃO ENCONTRADO' });
        }
        if (!produto.UnidadeComercial?.sigla || produto.UnidadeComercial.sigla !== 'KG') {
            return false;
        }
        if (!produto.UnidadeTributavel?.sigla || produto.UnidadeTributavel.sigla !== 'KG') {
            return false;
        }
        if (!produto.ProdutoEmpresa?.[0]?.weight_balance) {
            return false;
        }
        return true;
    }
}
//# sourceMappingURL=balancas_controller.js.map