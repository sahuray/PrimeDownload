import Venda from '#models/venda';
export default class SequenceController {
    static async newCodeSale() {
        const lastCodeSale = await Venda.query().select('code').orderBy('id', 'desc').first();
        if (lastCodeSale && lastCodeSale.code) {
            return Number(lastCodeSale.code) + 1;
        }
        return 1;
    }
    static async newPasswordDeliverySale() {
        const lastPasswordDeliverySale = await Venda.query()
            .select('senhaDelivery')
            .orderBy('id', 'desc')
            .first();
        if (lastPasswordDeliverySale && lastPasswordDeliverySale.senhaDelivery) {
            return Number(lastPasswordDeliverySale.senhaDelivery) + 1;
        }
        return 1;
    }
}
//# sourceMappingURL=sequence_controller.js.map