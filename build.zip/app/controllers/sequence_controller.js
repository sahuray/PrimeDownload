import SequenciaNumerica from '#models/sequencia_numerica';
export default class SequenceController {
    static async newCodeSale() {
        const findLastCodeSaleSequence = await SequenciaNumerica.query()
            .where('nome', 'venda')
            .select('*')
            .first();
        if (findLastCodeSaleSequence) {
            findLastCodeSaleSequence.valor = Number(findLastCodeSaleSequence.valor) + 1;
            await findLastCodeSaleSequence.save();
            return findLastCodeSaleSequence.valor;
        }
        else {
            const createLastCodeSaleSequence = await SequenciaNumerica.create({
                nome: 'venda',
                valor: 1,
            });
            return createLastCodeSaleSequence.valor;
        }
    }
    static async newPasswordDeliverySale() {
        const findLastPasswordDeliverySequence = await SequenciaNumerica.query()
            .where('nome', 'senha_delivery')
            .select('*')
            .first();
        if (findLastPasswordDeliverySequence) {
            findLastPasswordDeliverySequence.valor = Number(findLastPasswordDeliverySequence.valor) + 1;
            await findLastPasswordDeliverySequence.save();
            return findLastPasswordDeliverySequence.valor;
        }
        else {
            const createLastCodeSaleSequence = await SequenciaNumerica.create({
                nome: 'senha_delivery',
                valor: 1,
            });
            return createLastCodeSaleSequence.valor;
        }
    }
    async deleteCodeOrder() {
        const findLastCodeOrderSequence = await SequenciaNumerica.query()
            .where('nome', 'venda')
            .select('*')
            .first();
        if (findLastCodeOrderSequence) {
            await findLastCodeOrderSequence.delete();
        }
    }
    async deleteCodePasswordDelivery() {
        const findLastCodePasswordDeliverySequence = await SequenciaNumerica.query()
            .where('nome', 'senha_delivery')
            .select('*')
            .first();
        if (findLastCodePasswordDeliverySequence) {
            await findLastCodePasswordDeliverySequence.delete();
        }
    }
}
//# sourceMappingURL=sequence_controller.js.map