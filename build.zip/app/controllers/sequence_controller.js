import Venda from '#models/venda';
export default class SequenceController {
    static async newCodeSale(idGroup, idMovementCashDesk) {
        const lastCodeSale = await Venda.query()
            .where('id_grupo', idGroup)
            .where('id_caixa_movimento', idMovementCashDesk)
            .select('code')
            .orderBy('id', 'desc')
            .first();
        if (lastCodeSale && lastCodeSale.code) {
            return Number(lastCodeSale.code) + 1;
        }
        return 1;
    }
}
//# sourceMappingURL=sequence_controller.js.map