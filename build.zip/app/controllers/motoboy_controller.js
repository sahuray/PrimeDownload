import Motoboy from '#models/motoboy';
export default class MotoboyController {
    async index(ctx) {
        const data = ctx.request.all();
        const motoboy = await Motoboy.query()
            .if(data.search, (query) => {
            query
                .where('nome', 'ilike', `%${data.search}%`)
                .orWhere('codigo', Number(data.search))
                .orWhere('telefone', 'ilike', `%${data.search}%`)
                .orWhere('rg', 'ilike', `%${data.search}%`);
        })
            .if(data.showInactive === true, (query) => {
            query.whereNotNull('deleted_at');
        })
            .if(data.showInactive === false, (query) => {
            query.whereNull('deleted_at');
        })
            .select('*')
            .orderBy('updated_at', 'desc')
            .limit(10);
        return ctx.response.json(motoboy);
    }
    async createAndUpdate(ctx) {
        const data = ctx.request.all();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        if (sessionData && sessionData.empresaId) {
            if (data.id) {
                const motoboy = await Motoboy.find(data.id);
                if (motoboy) {
                    motoboy.merge(data);
                    motoboy.sync_prime = false;
                    await motoboy.save();
                    return ctx.response.json(motoboy);
                }
            }
            else {
                const motoboy = await Motoboy.create({
                    id_grupo: 1,
                    id_empresa: sessionData.empresaId,
                    nome: data.nome,
                    telefone: data.telefone,
                    rg: data.rg,
                    sync_prime: false,
                });
                return ctx.response.json(motoboy);
            }
        }
    }
}
//# sourceMappingURL=motoboy_controller.js.map