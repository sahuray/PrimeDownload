import Motoboy from '#models/motoboy';
export default class MotoboyController {
    async index(ctx) {
        const data = ctx.request.all();
        const motoboy = await Motoboy.query()
            .if(data.search, (query) => {
            query
                .where('nome', 'ilike', `%${data.search}%`)
                .orWhere('codigo', Number(data.search))
                .orWhere('telefone', 'ilike', `%${data.search}%`)
                .orWhere('rg', 'ilike', `%${data.search}%`);
        })
            .if(data.showInactive === true, (query) => {
            query.whereNotNull('deleted_at');
        })
            .if(data.showInactive === false, (query) => {
            query.whereNull('deleted_at');
        })
            .select('*')
            .limit(10);
        return ctx.response.json(motoboy);
    }
    async createAndUpdate(ctx) {
        const data = ctx.request.all();
        if (data.id) {
            const motoboy = await Motoboy.find(data.id);
            if (motoboy) {
                motoboy.merge(data);
                await motoboy.save();
                return ctx.response.json(motoboy);
            }
        }
        else {
            const ultimoMotoboy = await Motoboy.query().orderBy('codigo', 'desc').first();
            const novoCodigo = ultimoMotoboy ? Number(ultimoMotoboy.codigo) + 1 : 1;
            const motoboy = await Motoboy.create({
                nome: data.nome,
                telefone: data.telefone,
                rg: data.rg,
                codigo: String(novoCodigo),
            });
            return ctx.response.json(motoboy);
        }
    }
}
//# sourceMappingURL=motoboy_controller.js.map