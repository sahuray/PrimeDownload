import { DateTime } from 'luxon';
import CaixaMovimento from '#models/caixa_movimento';
export default class CaixaMovimentoController {
    async create({ request, response }) {
        const data = request.only([
            'dataabertura',
            'horaabertura',
            'suprimentoatual',
            'status',
            'idterminal',
            'idfuncionariousuarioabertura',
        ]);
        data.dataabertura = DateTime.fromFormat(data.dataabertura, 'dd/MM/yyyy').toFormat('yyyy-MM-dd');
        await CaixaMovimento.create(data);
        response.ok({ message: 'Caixa movimento criado com sucesso' });
    }
    async index({ request, response }) {
        const { idterminal } = request.only(['idterminal']);
        const data = await CaixaMovimento.query().where('idterminal', idterminal);
        response.ok(data);
    }
    async show({ request, response }) {
        const { idterminal, idfuncionariousuarioabertura } = request.params();
        const data = await CaixaMovimento.query()
            .preload('funcionarioUsuarioAbertura', (query) => {
            query.select('usuario');
        })
            .where('idterminal', idterminal)
            .where('idfuncionariousuarioabertura', idfuncionariousuarioabertura)
            .where('status', 'ABE')
            .first();
        response.ok(data);
    }
    async update({ request, response }) {
        const { idcaixamovimento } = request.params();
        const data = request.only([
            'status',
            'datafechamento',
            'horafechamento',
            'idfuncionariousuariofechamento',
        ]);
        await CaixaMovimento.query()
            .where('idcaixamovimento', idcaixamovimento)
            .update({
            ...data,
            sync_prime: false,
        });
        const caixaMovimento = await CaixaMovimento.query()
            .preload('funcionarioUsuarioAbertura', (query) => {
            query.select('usuario');
        })
            .preload('funcionarioUsuarioFechamento', (query) => {
            query.select('usuario');
        })
            .where('idcaixamovimento', idcaixamovimento)
            .first();
        response.ok(caixaMovimento);
    }
}
//# sourceMappingURL=caixa_movimento_controller.js.map