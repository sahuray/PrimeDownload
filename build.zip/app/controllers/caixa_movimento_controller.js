import { DateTime } from 'luxon';
import CaixaMovimento from '#models/caixa_movimento';
import SyncManualController from './sync_manual_controller.js';
export default class CaixaMovimentoController {
    async create(ctx) {
        const data = ctx.request.only([
            'dataabertura',
            'horaabertura',
            'suprimentoatual',
            'status',
            'idterminal',
            'idfuncionariousuarioabertura',
        ]);
        data.dataabertura = DateTime.fromFormat(data.dataabertura, 'dd/MM/yyyy').toFormat('yyyy-MM-dd');
        await CaixaMovimento.create({
            ...data,
            valor_abertura: data.suprimentoatual,
            totaldinheirocaixa: data.suprimentoatual,
        });
        const syncManualController = new SyncManualController();
        syncManualController.syncManualSendCaixaMovimento(ctx);
        ctx.response.status(201);
    }
    async index({ request, response }) {
        const { idterminal } = request.only(['idterminal']);
        const data = await CaixaMovimento.query().where('idterminal', idterminal);
        response.ok(data);
    }
    async show({ request, response }) {
        const { idterminal } = request.params();
        const data = await CaixaMovimento.query()
            .preload('funcionarioUsuarioAbertura', (query) => {
            query.select('usuario');
        })
            .where('idterminal', idterminal)
            .where('status', 'ABE')
            .first();
        response.ok(data);
    }
    async update(ctx) {
        const { idcaixamovimento } = ctx.request.params();
        const data = ctx.request.only([
            'status',
            'datafechamento',
            'horafechamento',
            'idfuncionariousuariofechamento',
        ]);
        if (data.datafechamento) {
            data.datafechamento = DateTime.fromFormat(data.datafechamento, 'dd/MM/yyyy').toFormat('yyyy-MM-dd');
        }
        await CaixaMovimento.query()
            .where('idcaixamovimento', idcaixamovimento)
            .update({
            ...data,
            sync_prime: false,
        });
        const caixaMovimento = await CaixaMovimento.query()
            .preload('terminal', (subQuery) => {
            subQuery.select('nome');
        })
            .preload('funcionarioUsuarioAbertura', (query) => {
            query.select('usuario');
        })
            .preload('funcionarioUsuarioFechamento', (query) => {
            query.select('usuario');
        })
            .where('idcaixamovimento', idcaixamovimento)
            .first();
        const syncManualController = new SyncManualController();
        syncManualController.syncManualSendCaixaMovimento(ctx);
        syncManualController.syncManualSendVenda(ctx);
        ctx.response.ok(caixaMovimento);
    }
}
//# sourceMappingURL=caixa_movimento_controller.js.map