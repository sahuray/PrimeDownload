import Setor from '#models/setor';
import Mesa from '#models/prime_mesa';
import Funcionario from '#models/funcionario';
import Usuario from '#models/funcionario_usuario';
import Permissao from '#models/prime_permissao';
import PermissaoUsuario from '#models/prime_permissao_usuario';
import Venda from '#models/venda';
import VendaItem from '#models/venda_item';
import VendaSubItem from '#models/venda_sub_item';
import VendaItemCaracteristica from '#models/venda_item_caracteristica';
import MesaConfig from '#models/prime_mesa_config';
import { DateTime } from 'luxon';
import EmpresaPdvConfig from '#models/prime_empresa_pdv_config';
export default class MesaController {
    async findMesa(ctx) {
        const numeroMesa = ctx.params.numeroMesa;
        const mesa = await Mesa.query().where('numero_mesa', numeroMesa).whereNull('deleted_at').first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        const vendaItem = await VendaItem.query()
            .where('id_mesa', mesa.id)
            .preload('garcon')
            .preload('subItens', (querySub) => {
            querySub.preload('caracteristicas');
        })
            .preload('caracteristicas')
            .whereHas('venda', (query) => {
            query.where('origem', 'MESA');
            query.whereIn('status', ['PROVISORIO_MESA', 'PROVISORIO']);
        })
            .preload('venda', (query) => {
            query.preload('UsuarioCriacao');
        })
            .preload('produto')
            .preload('mesa', (query) => {
            query.whereIn('status', ['OCUPADO', 'FECHAMENTO']);
        })
            .whereNull('deleted_at')
            .select('*');
        if (vendaItem.length === 0) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        return ctx.response.json({ status: 200, message: 'MESA ENCONTRADA', vendaItem });
    }
    async findFuncionario(ctx) {
        const id = ctx.params.id;
        if (!id) {
            return ctx.response.badRequest({ message: 'ID DO GARÇOM É OBRIGATÓRIO' });
        }
        const funcionario = await Funcionario.query()
            .where('idfuncionario', Number(id))
            .where('statusfuncionario', true)
            .whereNull('deleted_at')
            .first();
        return ctx.response.json(funcionario);
    }
    async index(ctx) {
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const userLogged = await Usuario.query()
            .where('idfuncionariousuario', sessionData.idfuncionariousuario)
            .first();
        if (!userLogged) {
            return ctx.response.json({ status: 404, message: 'USUÁRIO NÃO ENCONTRADO' });
        }
        const permissaoMesa = await Permissao.query()
            .where('pagina', 'PRATHOS')
            .where('slug', 'prathos_index')
            .first();
        if (!permissaoMesa) {
            return ctx.response.json({ status: 404, message: 'NENHUMA PERMISSÃO DE MESA ENCONTRADA!' });
        }
        const permissionsUsuario = await PermissaoUsuario.query()
            .where('id_usuario', userLogged.idfuncionariousuario)
            .where('id_permissao', permissaoMesa.id)
            .first();
        if (!permissionsUsuario) {
            return ctx.response.json({
                status: 404,
                message: 'VOCÊ NÃO POSSUI PERMISSÃO PARA ACESSAR ESSA PÁGINA',
            });
        }
        const setor = await Setor.query()
            .where('status', true)
            .whereNull('deleted_at')
            .preload('mesas')
            .select('*')
            .orderBy('favorite', 'desc');
        const mesaData = await Mesa.query()
            .where('active', true)
            .whereNull('deleted_at')
            .select('*')
            .orderBy('numero_mesa', 'asc');
        const mesaSomaCadeiras = await Mesa.query().select('*').orderBy('numero_mesa', 'asc');
        const totalCadeirasPorGrupo = {};
        mesaSomaCadeiras.forEach((mesa) => {
            if (mesa.grupo_mesas) {
                if (!totalCadeirasPorGrupo[mesa.grupo_mesas]) {
                    totalCadeirasPorGrupo[mesa.grupo_mesas] = 0;
                }
                totalCadeirasPorGrupo[mesa.grupo_mesas] += Number(mesa.numero_cadeiras || 0);
            }
        });
        const mesasProcessadas = await Promise.all(mesaData.map(async (mesa) => {
            let permanenciaHoras = 0;
            let dataAbertura = null;
            let horaAbertura = null;
            let horaUltimoAtendimento = null;
            let valorPorPessoa = 0;
            let totalVenda = 0;
            let ultimoGarcom = null;
            if (mesa.hora_abertura) {
                try {
                    const horaAberturaDt = mesa.hora_abertura
                        ? DateTime.fromJSDate(mesa.hora_abertura instanceof Date
                            ? mesa.hora_abertura
                            : mesa.hora_abertura.toJSDate())
                        : DateTime.now();
                    const diff = DateTime.now().diff(horaAberturaDt, ['hours']);
                    permanenciaHoras = Number(diff.hours.toFixed(2));
                    dataAbertura = horaAberturaDt.setLocale('pt-BR').toFormat('dd/MM/yyyy');
                    horaAbertura = horaAberturaDt.setLocale('pt-BR').toFormat('HH:mm');
                    if (mesa.hora_ultimo_atendimento) {
                        horaUltimoAtendimento = DateTime.fromJSDate(mesa.hora_ultimo_atendimento instanceof Date
                            ? mesa.hora_ultimo_atendimento
                            : mesa.hora_ultimo_atendimento.toJSDate())
                            .setLocale('pt-BR')
                            .toFormat('HH:mm');
                    }
                }
                catch (error) {
                    dataAbertura = 'Data inválida';
                    horaAbertura = 'Hora inválida';
                    horaUltimoAtendimento = 'Hora inválida';
                }
            }
            const items = await VendaItem.query()
                .where('id_mesa', mesa.id)
                .whereNull('deleted_at')
                .whereHas('venda', (query) => {
                query.where('origem', 'MESA');
                query.whereIn('status', ['PROVISORIO_MESA', 'PROVISORIO']);
            })
                .preload('garcon')
                .select('totalValue', 'id_garcon', 'created_at')
                .orderBy('created_at', 'desc');
            const historicoGarcons = items.reduce((acc, item) => {
                const garconId = item.id_garcon;
                if (!acc[garconId]) {
                    acc[garconId] = {
                        id_garcon: garconId,
                        nome_garcon: item.garcon?.nome || 'Não identificado',
                        valor_total: 0,
                        ultimo_atendimento: DateTime.fromJSDate(item.createdAt instanceof Date ? item.createdAt : item.createdAt.toJSDate())
                            .setLocale('pt-BR')
                            .toFormat('dd/MM/yyyy HH:mm'),
                    };
                }
                acc[garconId].valor_total += Number(item.totalValue || 0);
                return acc;
            }, {});
            const sortedHistoricoGarcons = Object.values(historicoGarcons).sort((a, b) => b.valor_total - a.valor_total);
            sortedHistoricoGarcons.forEach((garcom) => {
                garcom.valor_total = `R$ ${garcom.valor_total.toLocaleString('pt-BR', {
                    minimumFractionDigits: 2,
                })}`;
            });
            if (items.length > 0) {
                ultimoGarcom = {
                    id: items[0].id_garcon,
                    nome: items[0].garcon?.nome || 'Não identificado',
                };
            }
            totalVenda = items.reduce((acc, item) => acc + Number(item.totalValue || 0), 0);
            valorPorPessoa = mesa.quantidade_pessoas
                ? Number((totalVenda / mesa.quantidade_pessoas).toFixed(2))
                : 0;
            let totalNumeroCadeiras;
            if (mesa.grupo_mesas) {
                totalNumeroCadeiras = totalCadeirasPorGrupo[mesa.grupo_mesas] || 0;
            }
            return {
                ...mesa.toJSON(),
                permanencia_horas: permanenciaHoras,
                data_abertura: dataAbertura,
                hora_abertura: horaAbertura,
                hora_ultimo_atendimento: horaUltimoAtendimento,
                ultimo_garcom: ultimoGarcom,
                quantidade_pessoas: mesa.quantidade_pessoas,
                valor_por_pessoa: `R$ ${valorPorPessoa.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                valor_total: `R$ ${totalVenda.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}`,
                historico_garcons: sortedHistoricoGarcons,
                totalNumeroCadeiras,
            };
        }));
        let mesa = {
            setores: setor,
            mesaData: mesasProcessadas,
        };
        return ctx.response.json(mesa);
    }
    async cancelarAberturaMesa(ctx) {
        const { numeroMesa } = ctx.request.body();
        const mesa = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .whereNull('deleted_at')
            .preload('itens', (query) => {
            query.whereNull('deleted_at');
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
            query.whereHas('venda', (queryVenda) => {
                queryVenda.where('origem', 'MESA');
                queryVenda.whereIn('status', ['PROVISORIO_MESA', 'PROVISORIO']);
            });
        })
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        if (mesa.itens.length === 0) {
            mesa.status = 'LIVRE';
            mesa.hora_ultimo_atendimento = null;
            mesa.hora_abertura = null;
            await mesa.save();
            return ctx.response.json({ status: 200, message: 'ABERTURA DE MESA CANCELADA COM SUCESSO!' });
        }
        else {
            return ctx.response.json({ status: 404, message: 'MESA POSSUI ITENS' });
        }
    }
    async openMesa(ctx) {
        const { numeroMesa, idGarcom, quantidadePessoas, identificacaoMesa, observacao, produtosMesa } = ctx.request.body();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const mesa = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .where('status', 'LIVRE')
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        if (mesa.status === 'OCUPADO') {
            return ctx.response.badRequest({ message: 'MESA JÁ ESTÁ OCUPADA' });
        }
        if (produtosMesa.length === 0) {
            mesa.status = 'OCUPADO';
            if (idGarcom) {
                mesa.id_garcon = idGarcom;
            }
            if (quantidadePessoas) {
                mesa.quantidade_pessoas = quantidadePessoas;
            }
            if (identificacaoMesa) {
                mesa.identificacao_mesa = identificacaoMesa;
            }
            mesa.hora_abertura = DateTime.now();
            mesa.hora_ultimo_atendimento = DateTime.now();
            await mesa.save();
            return ctx.response.json({ status: 200, message: 'MESA ABERTA COM SUCESSO!', mesa });
        }
        else {
            const newSale = await Venda.create({
                idEmpresa: sessionData.empresaId,
                idUsuarioCriacao: sessionData.idfuncionariousuario,
                idGrupo: 1,
                valorProdutos: produtosMesa.reduce((acc, item) => acc + Number(item.valor_total), 0),
                finalizado: false,
                idTerminal: terminal.idterminal || terminal.idTerminal,
                status: 'PROVISORIO_MESA',
                origem: 'MESA',
            });
            for (const item of produtosMesa) {
                const totalValue = Number(item.valor_total);
                const saledQuantity = item.quantidade;
                const vendaItem = await VendaItem.create({
                    idProduto: item.id_produto,
                    saledQuantity: Number(saledQuantity),
                    unitaryValue: Number(totalValue) / Number(saledQuantity),
                    totalValue: Number(totalValue),
                    productDescription: item.descricao,
                    listar_na_comanda: false,
                    id_venda_anterior: newSale.id,
                    idVenda: newSale.id,
                    id_mesa: mesa.id,
                    id_garcon: Number(idGarcom),
                    observacao: observacao,
                });
                if (item.sabores && item.sabores.length > 0) {
                    for (const sab of item.sabores) {
                        const subitem = await VendaSubItem.create({
                            idVendaItem: vendaItem.id,
                            idProduto: sab.id_produto,
                            idVenda: newSale.id,
                            descricao: sab.descricao,
                            quantidade: sab.quantidade,
                            valorUnitario: Number(sab.valor),
                            valorTotal: Number(sab.total),
                        });
                        if (sab.caracteristicas && sab.caracteristicas.length > 0) {
                            for (const caract of sab.caracteristicas) {
                                await VendaItemCaracteristica.create({
                                    id_venda_item: Number(vendaItem.id),
                                    id_produto_caracteristica: caract.caracteristica_id,
                                    descricao: caract.descricao,
                                    fixo: caract.fixo,
                                    id_venda_sub_item: subitem.id,
                                });
                            }
                        }
                    }
                }
                if (item.caracteristicas && item.caracteristicas.caracteristicas.length > 0) {
                    for (const caract of item.caracteristicas.caracteristicas) {
                        await VendaItemCaracteristica.create({
                            id_venda_item: Number(vendaItem.id),
                            id_produto_caracteristica: caract.caracteristica_id,
                            descricao: caract.descricao,
                            fixo: caract.fixo,
                        });
                    }
                }
            }
            mesa.status = 'OCUPADO';
            mesa.id_garcon = idGarcom;
            mesa.quantidade_pessoas = quantidadePessoas;
            mesa.identificacao_mesa = identificacaoMesa;
            mesa.hora_abertura = DateTime.now();
            mesa.hora_ultimo_atendimento = DateTime.now();
            mesa.total_atendimento = (mesa.total_atendimento || 0) + 1;
            await mesa.save();
            return ctx.response.json({ status: 200, message: 'MESA ABERTA COM SUCESSO!', mesa });
        }
    }
    async updateMesaItems(ctx) {
        const { numeroMesa, idGarcom, quantidadePessoas, identificacaoMesa, observacao, produtosMesa } = ctx.request.body();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const mesa = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .whereNot('status', 'LIVRE')
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        const vendaItems = await VendaItem.query()
            .where('id_mesa', mesa.id)
            .whereHas('venda', (query) => {
            query.where('status', 'PROVISORIO_MESA');
        })
            .whereNull('deleted_at')
            .select('*');
        if (vendaItems.length > 0) {
            for (const item of produtosMesa) {
                const totalValue = Number(item.valor_total);
                const saledQuantity = item.quantidade;
                const vendaItem = await VendaItem.create({
                    idProduto: item.id_produto,
                    saledQuantity: Number(saledQuantity),
                    unitaryValue: Number(totalValue) / Number(saledQuantity),
                    productDescription: item.descricao,
                    totalValue: Number(totalValue),
                    listar_na_comanda: false,
                    id_venda_anterior: vendaItems[0].idVenda,
                    idVenda: vendaItems[0].idVenda,
                    id_mesa: mesa.id,
                    id_garcon: idGarcom,
                    observacao: observacao,
                });
                if (item.sabores && item.sabores.length > 0) {
                    for (const sab of item.sabores) {
                        const subitem = await VendaSubItem.create({
                            idVendaItem: vendaItem.id,
                            idProduto: sab.id_produto,
                            idVenda: vendaItems[0].idVenda,
                            descricao: sab.descricao,
                            quantidade: sab.quantidade,
                            valorUnitario: Number(sab.valor),
                            valorTotal: Number(sab.total),
                        });
                        if (sab.caracteristicas && sab.caracteristicas.length > 0) {
                            for (const caract of sab.caracteristicas) {
                                await VendaItemCaracteristica.create({
                                    id_venda_item: Number(vendaItem.id),
                                    id_produto_caracteristica: caract.caracteristica_id,
                                    descricao: caract.descricao,
                                    fixo: caract.fixo,
                                    id_venda_sub_item: subitem.id,
                                });
                            }
                        }
                    }
                }
                if (item.caracteristicas && item.caracteristicas.caracteristicas.length > 0) {
                    for (const caract of item.caracteristicas.caracteristicas) {
                        await VendaItemCaracteristica.create({
                            id_venda_item: Number(vendaItem.id),
                            id_produto_caracteristica: caract.caracteristica_id,
                            descricao: caract.descricao,
                            fixo: caract.fixo,
                        });
                    }
                }
            }
        }
        else {
            const newSale = await Venda.create({
                idEmpresa: sessionData.empresaId,
                idUsuarioCriacao: sessionData.idfuncionariousuario,
                idGrupo: 1,
                valorProdutos: produtosMesa.reduce((acc, item) => acc + Number(item.valor_total), 0),
                finalizado: false,
                idTerminal: terminal.idterminal || terminal.idTerminal,
                status: 'PROVISORIO_MESA',
                origem: 'MESA',
            });
            for (const item of produtosMesa) {
                const totalValue = item.valor_total;
                const saledQuantity = item.quantidade;
                const vendaItem = await VendaItem.create({
                    idProduto: item.id_produto,
                    saledQuantity: Number(saledQuantity),
                    unitaryValue: Number(totalValue) / Number(saledQuantity),
                    productDescription: item.descricao,
                    totalValue: Number(totalValue.toString().replace(/[^\d.-]/g, '')),
                    listar_na_comanda: false,
                    id_venda_anterior: newSale.id,
                    idVenda: newSale.id,
                    id_mesa: mesa.id,
                    id_garcon: Number(idGarcom),
                    observacao: observacao,
                });
                if (item.sabores && item.sabores.length > 0) {
                    for (const sab of item.sabores) {
                        const subitem = await VendaSubItem.create({
                            idVendaItem: vendaItem.id,
                            idProduto: item.id_produto,
                            idVenda: newSale.id,
                            descricao: item.descricao,
                            quantidade: item.quantidade,
                            valorUnitario: Number(item.valor),
                            valorTotal: Number(item.valor_total),
                        });
                        if (sab.caracteristicas && sab.caracteristicas.length > 0) {
                            for (const caract of item.caracteristicas.caracteristicas) {
                                await VendaItemCaracteristica.create({
                                    id_venda_item: Number(vendaItem.id),
                                    id_produto_caracteristica: caract.caracteristica_id,
                                    descricao: caract.descricao,
                                    fixo: caract.fixo,
                                    id_venda_sub_item: subitem.id,
                                });
                            }
                        }
                    }
                }
                if (item.caracteristicas && item.caracteristicas.caracteristicas.length > 0) {
                    for (const caract of item.caracteristicas.caracteristicas) {
                        await VendaItemCaracteristica.create({
                            id_venda_item: Number(vendaItem.id),
                            id_produto_caracteristica: caract.caracteristica_id,
                            descricao: caract.descricao,
                            fixo: caract.fixo,
                        });
                    }
                }
            }
        }
        mesa.status = 'OCUPADO';
        mesa.id_garcon = idGarcom;
        mesa.quantidade_pessoas = quantidadePessoas;
        mesa.identificacao_mesa = identificacaoMesa;
        mesa.observacao = observacao;
        mesa.hora_ultimo_atendimento = DateTime.now();
        mesa.total_atendimento = (mesa.total_atendimento || 0) + 1;
        await mesa.save();
        return ctx.response.json({
            status: 200,
            message: 'ITENS DA MESA ATUALIZADOS COM SUCESSO!',
            mesa,
        });
    }
    async filterMesaBySetor(ctx) {
        const idSetor = ctx.params.idSetor;
        const setor = await Setor.query()
            .where('status', true)
            .whereNull('deleted_at')
            .preload('mesas')
            .select('*')
            .orderBy('nome_setor', 'asc');
        const mesaData = await Mesa.query()
            .where('id_setor', idSetor)
            .whereNull('deleted_at')
            .select('*')
            .orderBy('numero_mesa', 'asc');
        let mesa = {
            setores: setor,
            mesaData,
        };
        return ctx.response.json(mesa);
    }
    async indexStatusMesa(ctx) {
        const status = ['LIVRE', 'OCUPADO', 'FECHANDO', 'OCIOSO'];
        const config = await MesaConfig.query().whereNull('deleted_at').first();
        const tempoLimiteOcioso = 1000 * 60 * (config?.idle_time || 1);
        const mesas = await Mesa.query().whereIn('status', status).whereNull('deleted_at').select('*');
        const mesasFechadas = await Mesa.query()
            .whereNotNull('hora_abertura')
            .whereNotNull('hora_fechamento')
            .whereNull('deleted_at')
            .select('hora_abertura', 'hora_fechamento', 'id')
            .orderBy('hora_fechamento', 'desc');
        let idsToUpdate = [];
        const mesaData = await mesas.reduce((acc, mesa) => {
            if (mesa.hora_ultimo_atendimento) {
                const horaAtendimentoStr = String(mesa.hora_ultimo_atendimento);
                const dateObject = new Date(horaAtendimentoStr);
                const ultimoAtendimento = DateTime.fromJSDate(dateObject, { zone: 'utc' });
                if (ultimoAtendimento.isValid) {
                    const tempoDesdeUltimoAtendimento = DateTime.now().diff(ultimoAtendimento).toMillis();
                    acc.totalTime = (acc.totalTime || 0) + tempoDesdeUltimoAtendimento;
                    acc.count = (acc.count || 0) + 1;
                    if (mesa.status !== 'FECHANDO' && tempoDesdeUltimoAtendimento > tempoLimiteOcioso) {
                        idsToUpdate.push(mesa.id);
                        acc['OCIOSO'] = (acc['OCIOSO'] || 0) + 1;
                    }
                    else {
                        acc[mesa.status] = (acc[mesa.status] || 0) + 1;
                    }
                }
            }
            else {
                acc[mesa.status] = (acc[mesa.status] || 0) + 1;
            }
            return acc;
        }, { LIVRE: 0, FECHANDO: 0, OCUPADO: 0, OCIOSO: 0, totalTime: 0, count: 0 });
        mesaData['T.M.A'] =
            mesaData.count > 0 ? Math.round(mesaData.totalTime / mesaData.count / (1000 * 60)) : 0;
        const tempoTotalOcupacao = [...mesasFechadas, ...mesas].reduce((total, mesa) => {
            try {
                if (!mesa.hora_abertura) {
                    return total;
                }
                const abertura = DateTime.fromJSDate(mesa.hora_abertura instanceof Date ? mesa.hora_abertura : mesa.hora_abertura.toJSDate());
                const fechamento = mesa.hora_fechamento
                    ? DateTime.fromJSDate(mesa.hora_fechamento instanceof Date
                        ? mesa.hora_fechamento
                        : mesa.hora_fechamento.toJSDate())
                    : DateTime.now();
                const ultimoAtendimento = mesa.hora_ultimo_atendimento
                    ? DateTime.fromJSDate(mesa.hora_ultimo_atendimento instanceof Date
                        ? mesa.hora_ultimo_atendimento
                        : mesa.hora_ultimo_atendimento.toJSDate())
                    : null;
                const finalTime = fechamento || ultimoAtendimento || DateTime.now();
                const diffEmMinutos = finalTime.diff(abertura, ['minutes']).minutes;
                return total + (diffEmMinutos > 0 ? diffEmMinutos : 0);
            }
            catch (error) {
                console.error('Erro ao calcular tempo de ocupação:', error);
                return total;
            }
        }, 0);
        const tmoCalculado = mesasFechadas.length + mesas.length > 0
            ? Math.max(0, Math.round(tempoTotalOcupacao / (mesasFechadas.length + mesas.length)))
            : 0;
        mesaData['T.M.O'] = tmoCalculado;
        delete mesaData.totalTime;
        delete mesaData.count;
        if (idsToUpdate.length > 0) {
            await Mesa.query().whereIn('id', idsToUpdate).update({ status: 'OCIOSO' });
        }
        return ctx.response.json(mesaData);
    }
    async setIdleTime(ctx) {
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const { idleTime } = ctx.request.body();
        await MesaConfig.query().update({ deletedAt: DateTime.now() });
        const config = await MesaConfig.create({
            id_usuario: sessionData.idfuncionariousuario,
            idle_time: idleTime,
        });
        return ctx.response.json({
            status: 200,
            message: 'TEMPO DE OCIOSIDADE SETADO COM SUCESSO!',
            config,
        });
    }
    async desagruparMesas(ctx) {
        const { numeroMesa } = ctx.request.body();
        const mesas = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .whereNull('deleted_at')
            .whereNotNull('grupo_mesas')
            .first();
        if (!mesas || !mesas.grupo_mesas) {
            return ctx.response.json({
                status: 404,
                message: 'MESA NÃO ENCONTRADA OU NÃO PERTENCE A UM GRUPO',
            });
        }
        const mesasDoGrupo = await Mesa.query().where('grupo_mesas', mesas.grupo_mesas).select('*');
        const todasLivres = mesasDoGrupo.every((mesa) => mesa.status === 'LIVRE');
        if (!todasLivres) {
            return ctx.response.json({
                status: 400,
                message: 'TODAS AS MESAS DO GRUPO PRECISAM ESTAR LIVRES PARA DESAGRUPAR',
            });
        }
        for (const mesaGrupo of mesasDoGrupo) {
            await Mesa.query().where('id', mesaGrupo.id).update({
                grupo_mesas: null,
                hora_abertura: null,
                hora_ultimo_atendimento: null,
                deleted_at: null,
                active: true,
            });
        }
        return ctx.response.json({
            status: 200,
            message: 'MESAS DESAGRUPADAS COM SUCESSO!',
        });
    }
    async agruparMesas(ctx) {
        const { numeroMesas } = ctx.request.body();
        const mesas = await Mesa.query()
            .whereIn('numero_mesa', numeroMesas)
            .whereNull('deleted_at')
            .whereNull('grupo_mesas')
            .select('*');
        if (mesas.length === 0) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        const menorNumeroMesa = Math.min(...mesas.map((mesa) => Number(mesa.numero_mesa)));
        const grupoMesa = `G${menorNumeroMesa}`;
        const mesaPrincipal = mesas.find((mesa) => Number(mesa.numero_mesa) === menorNumeroMesa);
        if (!mesaPrincipal) {
            return ctx.response.json({
                status: 400,
                message: 'MESA PRINCIPAL NÃO ENCONTRADA',
            });
        }
        for (const mesa of mesas) {
            mesa.grupo_mesas = grupoMesa;
            if (Number(mesa.numero_mesa) !== menorNumeroMesa) {
                mesa.active = false;
                mesa.deletedAt = DateTime.now();
                const vendaPrincipal = await VendaItem.query()
                    .where('id_mesa', mesaPrincipal.id)
                    .whereNull('deleted_at')
                    .select('idVenda')
                    .first();
                if (vendaPrincipal) {
                    const vendasParaAtualizar = await VendaItem.query()
                        .where('id_mesa', mesa.id)
                        .whereNull('deleted_at')
                        .select('idVenda')
                        .distinct();
                    for (const venda of vendasParaAtualizar) {
                        await Venda.query().where('id', venda.idVenda).update({ status: 'SUSPENSO' });
                    }
                    await VendaItem.query().where('id_mesa', mesa.id).whereNull('deleted_at').update({
                        id_mesa: mesaPrincipal.id,
                        idVenda: vendaPrincipal.idVenda,
                    });
                }
            }
            await mesa.save();
        }
        return ctx.response.json({ status: 200, message: 'MESA AGRUPADA COM SUCESSO!', grupoMesa });
    }
    async transferirItens(ctx) {
        const { numeroMesaOrigem, numeroMesaDestino, itens } = ctx.request.body();
        const sessionData = JSON.parse(ctx.request.header('SESSION') || '{}');
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const mesaOrigem = await Mesa.query()
            .where('numero_mesa', numeroMesaOrigem)
            .whereNull('deleted_at')
            .first();
        if (!mesaOrigem) {
            return ctx.response.json({ status: 404, message: 'MESA ORIGEM NÃO ENCONTRADA' });
        }
        const mesaDestino = await Mesa.query()
            .where('numero_mesa', numeroMesaDestino)
            .whereNull('deleted_at')
            .first();
        if (!mesaDestino) {
            return ctx.response.json({ status: 404, message: 'MESA DESTINO NÃO ENCONTRADA' });
        }
        if (mesaOrigem.grupo_mesas && mesaOrigem.grupo_mesas === mesaDestino.grupo_mesas) {
            return ctx.response.json({
                status: 400,
                message: 'NÃO PODE TRANSFERIR ITENS ENTRE MESAS DO MESMO GRUPO',
            });
        }
        if (mesaOrigem.grupo_mesas && mesaDestino.deletedAt !== null) {
            return ctx.response.json({ status: 400, message: 'MESA DESTINO NÃO ESTÁ ATIVA' });
        }
        const vendaItemOrigem = await VendaItem.query()
            .where('id_mesa', mesaOrigem.id)
            .whereNull('deleted_at')
            .whereHas('venda', (query) => {
            query.where('status', 'PROVISORIO_MESA');
        })
            .first();
        if (!vendaItemOrigem) {
            return ctx.response.json({ status: 404, message: 'ITENS DE ORIGEM NÃO ENCONTRADOS' });
        }
        const idVendaOrigem = vendaItemOrigem.idVenda;
        let idVendaDestino = null;
        const valorProdutos = itens.reduce((acc, item) => {
            const valorTotal = item.valor_total;
            if (typeof valorTotal === 'string') {
                return acc + Number(valorTotal.replace('R$', '').replace('.', '').replace(',', '.'));
            }
            return acc;
        }, 0);
        if (mesaDestino.status === 'OCUPADO' || mesaDestino.status === 'OCIOSO') {
            const vendaItemDestino = await VendaItem.query()
                .where('id_mesa', mesaDestino.id)
                .whereNull('deleted_at')
                .whereHas('venda', (query) => {
                query.where('status', 'PROVISORIO_MESA');
            })
                .first();
            if (vendaItemDestino) {
                idVendaDestino = vendaItemDestino.idVenda;
            }
            else {
                const newVenda = await Venda.create({
                    idEmpresa: sessionData.empresaId,
                    idUsuarioCriacao: sessionData.idfuncionariousuario,
                    idGrupo: 1,
                    valorProdutos,
                    finalizado: false,
                    idTerminal: terminal.idterminal || terminal.idTerminal,
                    status: 'PROVISORIO_MESA',
                    origem: 'MESA',
                });
                idVendaDestino = newVenda.id;
            }
        }
        if (mesaDestino.status === 'LIVRE') {
            mesaDestino.status = 'OCUPADO';
            mesaDestino.hora_abertura = DateTime.now();
            mesaDestino.hora_ultimo_atendimento = DateTime.now();
            await mesaDestino.save();
            const newVenda = await Venda.create({
                idEmpresa: sessionData.empresaId,
                idUsuarioCriacao: sessionData.idfuncionariousuario,
                idGrupo: 1,
                valorProdutos,
                finalizado: false,
                idTerminal: terminal.idterminal || terminal.idTerminal,
                status: 'PROVISORIO_MESA',
                origem: 'MESA',
            });
            idVendaDestino = newVenda.id;
        }
        for (const item of itens) {
            const vendaItem = await VendaItem.query()
                .where('id_mesa', mesaOrigem.id)
                .where('id_produto', item.id_produto)
                .whereNull('deleted_at')
                .whereHas('venda', (query) => {
                query.where('status', 'PROVISORIO_MESA');
            })
                .first();
            if (!vendaItem) {
                continue;
            }
            await VendaItem.create({
                idProduto: vendaItem.idProduto,
                saledQuantity: vendaItem.saledQuantity,
                productDescription: vendaItem.productDescription,
                totalValue: vendaItem.totalValue,
                listar_na_comanda: vendaItem.listar_na_comanda,
                id_venda_anterior: Number(idVendaDestino),
                idVenda: Number(idVendaDestino),
                id_mesa: mesaDestino.id,
                id_garcon: vendaItem.id_garcon,
                observacao: vendaItem.observacao,
                unitaryValue: vendaItem.unitaryValue,
            });
            const vendaParaAtualizar = await Venda.query().where('id', Number(idVendaDestino)).first();
            if (vendaParaAtualizar) {
                vendaParaAtualizar.valorProdutos = valorProdutos;
            }
            await vendaItem
                .merge({
                deletedAt: DateTime.now(),
            })
                .save();
        }
        const remainingItems = await VendaItem.query()
            .where('id_mesa', mesaOrigem.id)
            .whereNull('deleted_at')
            .whereHas('venda', (query) => {
            query.where('status', 'PROVISORIO_MESA');
        })
            .count('* as total');
        const totalRemainingItems = Number(remainingItems[0].$extras.total);
        if (totalRemainingItems === 0) {
            await Venda.query().where('id', idVendaOrigem).update({ status: 'SUSPENSO' });
            await Mesa.query().where('id', mesaOrigem.id).update({
                status: 'LIVRE',
                hora_abertura: null,
                hora_ultimo_atendimento: null,
                hora_fechamento: null,
                identificacao_mesa: null,
                id_garcon: null,
                quantidade_pessoas: 0,
                grupo_mesas: null,
                deleted_at: null,
                active: true,
            });
            if (mesaOrigem.grupo_mesas) {
                await Mesa.query().where('grupo_mesas', mesaOrigem.grupo_mesas).update({
                    grupo_mesas: null,
                    status: 'LIVRE',
                    hora_abertura: null,
                    hora_ultimo_atendimento: null,
                    hora_fechamento: null,
                    identificacao_mesa: null,
                    id_garcon: null,
                    quantidade_pessoas: 0,
                    deleted_at: null,
                    active: true,
                });
            }
        }
        await Mesa.query().where('id', mesaDestino.id).update({
            hora_ultimo_atendimento: DateTime.now(),
        });
        return ctx.response.json({ status: 200, message: 'ITENS TRANSFERIDOS COM SUCESSO!' });
    }
    async getMesaDetails(ctx) {
        const numeroMesa = ctx.params.numeroMesa;
        const mesa = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .whereNull('deleted_at')
            .preload('itens', (query) => {
            query.whereNull('deleted_at');
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
            query.whereHas('venda', (queryVenda) => {
                queryVenda.where('origem', 'MESA');
                queryVenda.whereIn('status', ['PROVISORIO_MESA', 'PROVISORIO']);
            });
        })
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        const filteredItens = mesa.itens.filter((item) => item.venda && item.venda.status !== 'SUSPENSO');
        return ctx.response.json({
            status: 200,
            message: 'MESA ENCONTRADA',
            mesa: { ...mesa.toJSON(), itens: filteredItens },
        });
    }
    async cancelarItens(ctx) {
        const { numeroMesaOrigem, itens } = ctx.request.body();
        const mesas = await Mesa.query()
            .where('numero_mesa', numeroMesaOrigem)
            .whereNull('deleted_at')
            .first();
        if (!mesas) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        let vendaId = null;
        for (const item of itens) {
            const mesaItens = await VendaItem.query()
                .where('id_mesa', mesas.id)
                .where('id', item.item_id)
                .whereNull('deleted_at')
                .whereHas('venda', (query) => {
                query.where('status', 'PROVISORIO_MESA');
            })
                .first();
            if (!mesaItens) {
                return ctx.response.json({ status: 404, message: 'NENHUM ITEM ENCONTRADO NA MESA' });
            }
            await VendaItem.query().where('id', item.item_id).update({ deletedAt: DateTime.now() });
            vendaId = mesaItens.idVenda;
        }
        const remainingItems = await VendaItem.query()
            .where('id_mesa', mesas.id)
            .whereNull('deleted_at')
            .whereHas('venda', (query) => {
            query.where('status', 'PROVISORIO_MESA');
        })
            .select('*');
        if (remainingItems.length === 0) {
            await Mesa.query().where('id', mesas.id).update({
                status: 'LIVRE',
                hora_abertura: null,
                hora_ultimo_atendimento: null,
                hora_fechamento: null,
                identificacao_mesa: null,
                id_garcon: null,
                quantidade_pessoas: 0,
                grupo_mesas: null,
            });
            await Venda.query().where('id', Number(vendaId)).update({ status: 'SUSPENSO' });
        }
        return ctx.response.json({ status: 200, message: 'ITENS CANCELADOS COM SUCESSO!' });
    }
    async fecharMesa(ctx) {
        const { numeroMesa } = ctx.request.body();
        const mesas = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .preload('itens', (query) => {
            query.whereNull('deleted_at');
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
            query.whereHas('venda', (queryVenda) => {
                queryVenda.where('status', 'PROVISORIO_MESA');
            });
        })
            .whereNull('deleted_at')
            .first();
        if (!mesas) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        if (mesas.itens.length === 0) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO POSSUI ITENS' });
        }
        await Mesa.query().where('id', mesas.id).update({
            status: 'FECHANDO',
            hora_fechamento: DateTime.now(),
        });
        return ctx.response.json({ status: 200, message: 'MESA FECHADA COM SUCESSO!' });
    }
    async fecharVenda(ctx) {
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const { numeroMesa, totalDescount, addTax, addCouvert } = ctx.request.body();
        const config = await EmpresaPdvConfig.query().where('id_empresa', terminal.idEmpresa).first();
        const mesas = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .whereNull('deleted_at')
            .preload('itens', (query) => {
            query.whereNull('deleted_at');
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
            query.whereHas('venda', (queryVenda) => {
                queryVenda.where('status', 'PROVISORIO_MESA');
            });
        })
            .first();
        if (!mesas) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        if (mesas.itens.length === 0) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO POSSUI ITENS' });
        }
        if (mesas.status !== 'FECHANDO') {
            mesas.status = 'FECHANDO';
            await mesas.save();
        }
        let valorTaxaServico = 0;
        let valorCouvert = 0;
        let valorTotal = 0;
        for (const item of mesas.itens) {
            valorTotal += Number(item.totalValue);
        }
        if (addTax && config?.utiliza_taxa) {
            valorTaxaServico = valorTotal * (Number(config.valor_taxa) / 100);
            if (!config.id_servico_taxa) {
                return ctx.response.json({ status: 404, message: 'PRODUTO TAXA MÃO CADASTRADO' });
            }
            await VendaItem.create({
                idProduto: Number(config.id_servico_taxa),
                saledQuantity: 1,
                unitaryValue: Number(valorTaxaServico),
                totalValue: Number(valorTaxaServico),
                productDescription: config.nome_produto_taxa,
                listar_na_comanda: false,
                id_venda_anterior: mesas.itens[0].idVenda,
                idVenda: mesas.itens[0].idVenda,
                id_mesa: mesas.id,
                taxaDeServico: true,
            });
        }
        if (addCouvert && config?.utiliza_couvert) {
            valorCouvert = Number(config.valor_couvert);
            if (!config.id_servico_couvert) {
                return ctx.response.json({ status: 404, message: 'PRODUTO COBERT MÃO CADASTRADO' });
            }
            await VendaItem.create({
                idProduto: Number(config.id_servico_couvert),
                saledQuantity: 1,
                unitaryValue: Number(valorCouvert),
                totalValue: Number(valorCouvert),
                productDescription: config.nome_produto_taxa,
                listar_na_comanda: false,
                id_venda_anterior: mesas.itens[0].idVenda,
                idVenda: mesas.itens[0].idVenda,
                id_mesa: mesas.id,
                couvert: true,
            });
        }
        await Venda.query()
            .where('id', mesas.itens[0].idVenda)
            .update({
            status: 'PROVISORIO',
            total_value: valorTotal,
            total_descount_value: totalDescount ? totalDescount / 100 : 0,
            valor_produtos: valorTotal,
            valorTaxaServico: valorTaxaServico,
            valorCouvert: valorCouvert,
        });
        return ctx.response.json({ status: 200, message: 'VENDA FECHADA COM SUCESSO!' });
    }
    async reabrirMesa(ctx) {
        const { numeroMesa } = ctx.request.body();
        const mesas = await Mesa.query()
            .where('numero_mesa', numeroMesa)
            .whereNull('deleted_at')
            .preload('itens', (query) => {
            query.whereNull('deleted_at');
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
            query.whereHas('venda', (queryVenda) => {
                queryVenda.where('origem', 'MESA');
                queryVenda.whereIn('status', ['PROVISORIO', 'PROVISORIO_MESA']);
            });
        })
            .first();
        if (!mesas) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA' });
        }
        const venda = await Venda.query().where('id', mesas.itens[0].idVenda).first();
        if (!venda)
            return ctx.response.json({ status: 404, message: 'VENDA NÃO ENCONTRADA!' });
        if (venda.status !== 'PROVISORIO_MESA') {
            venda.status = 'PROVISORIO_MESA';
            await venda.save();
        }
        await Mesa.query().where('id', mesas.id).update({
            status: 'OCUPADO',
            hora_fechamento: null,
        });
        return ctx.response.json({ status: 200, message: 'MESA REABERTA COM SUCESSO!' });
    }
    async getAllStatusMesa(ctx) {
        const mesas = await Mesa.query()
            .whereNull('deleted_at')
            .whereIn('status', ['OCUPADO', 'OCIOSO', 'FECHANDO', 'LIVRE'])
            .preload('garcon')
            .preload('itens', (query) => {
            query.whereNull('deleted_at');
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
            query.whereHas('venda', (queryVenda) => {
                queryVenda.where('origem', 'MESA');
                queryVenda.whereIn('status', ['PROVISORIO', 'PROVISORIO_MESA']);
            });
        })
            .preload('setor')
            .orderBy('numero_mesa', 'asc')
            .select('*');
        if (mesas.length === 0) {
            return ctx.response.json({ status: 404, message: 'VOCÊ NÃO POSSUI MESAS CADASTRADAS!' });
        }
        let totalMesasLivre = [];
        let totalMesasOcupada = [];
        let totalMesasOciosas = [];
        let totalMesasFechamento = [];
        let totalPessoas = 0;
        let totalAtendimento = 0;
        let totalEmFechamento = 0;
        let totalEmOcupados = 0;
        let totalEmOciosos = 0;
        let totalGeral = 0;
        let mediaPorPessoa = 0;
        for (const mesa of mesas) {
            if (mesa.status === 'LIVRE') {
                totalMesasLivre.push(mesa);
            }
            if (mesa.status === 'OCUPADO') {
                totalMesasOcupada.push(mesa);
                const valorTotal = mesa.itens.reduce((acc, item) => acc + Number(item.totalValue), 0);
                totalEmOcupados += valorTotal;
            }
            if (mesa.status === 'OCIOSO') {
                totalMesasOciosas.push(mesa);
                const valorTotal = mesa.itens.reduce((acc, item) => acc + Number(item.totalValue), 0);
                totalEmOciosos += valorTotal;
            }
            if (mesa.status === 'FECHANDO') {
                totalMesasFechamento.push(mesa);
                const valorTotal = mesa.itens.reduce((acc, item) => acc + Number(item.totalValue), 0);
                totalEmFechamento += valorTotal;
            }
            totalPessoas += mesa.quantidade_pessoas;
            totalAtendimento += mesa.total_atendimento;
        }
        totalGeral = totalEmFechamento + totalEmOcupados + totalEmOciosos;
        mediaPorPessoa = totalGeral / totalAtendimento;
        const tableReport = {
            mesas: mesas,
            mesasLivres: totalMesasLivre.length,
            mesasOcupadas: totalMesasOcupada.length,
            mesasOciosas: totalMesasOciosas.length,
            mesasFechamento: totalMesasFechamento.length,
            totalPessoas,
            totalAtendimento,
            totalEmFechamento,
            totalEmOcupados,
            totalEmOciosos,
            totalGeral,
            mediaPorPessoa,
        };
        return ctx.response.json({ status: 200, tableReport });
    }
    async getVendaByMesa(ctx) {
        const { numeroMesa, addTax, addCouvert } = ctx.request.body();
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const config = await EmpresaPdvConfig.query().where('id_empresa', terminal.idEmpresa).first();
        if (numeroMesa === '000') {
            return ctx.response.json({ status: 404, message: 'NUMERO DA MESA NÃO É VALIDO!' });
        }
        if (!numeroMesa) {
            return ctx.response.json({ status: 404, message: 'NUMERO DA MESA É OBRIGATÓRIO!' });
        }
        const mesa = await Mesa.query()
            .whereNull('deleted_at')
            .where('numero_mesa', numeroMesa)
            .preload('garcon')
            .preload('itens', (query) => {
            query.whereNull('deleted_at');
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
            query.whereHas('venda', (queryVenda) => {
                queryVenda.where('origem', 'MESA');
                queryVenda.whereIn('status', ['PROVISORIO', 'PROVISORIO_MESA']);
            });
        })
            .preload('setor')
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA!' });
        }
        if (mesa.itens.length === 0) {
            return ctx.response.json({ status: 200, venda: null, taxes: null });
        }
        let valorTaxaServico = 0;
        let valorCouvert = 0;
        let valorTotal = 0;
        for (const item of mesa.itens) {
            valorTotal += Number(item.totalValue);
        }
        if (addTax && config?.utiliza_taxa) {
            valorTaxaServico = valorTotal * (config.valor_taxa / 100);
        }
        if (addCouvert && config?.utiliza_couvert) {
            valorCouvert = config.valor_couvert;
        }
        let taxes = {
            valor_taxa: Number(valorTaxaServico),
            valor_couvert: Number(valorCouvert),
            total_value_taxes: Number(valorTaxaServico) + Number(valorCouvert) + Number(valorTotal),
        };
        const venda = await Venda.query()
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .where('id', mesa.itens[0].idVenda)
            .first();
        if (!venda) {
            return ctx.response.json({
                status: 404,
                message: 'VENDA NÃO ENCONTRADA PARA ESTA MESA',
            });
        }
        return ctx.response.json({ status: 200, venda, taxes });
    }
    async getVendaByMesaCancelamento(ctx) {
        const { numeroMesa, addTax, addCouvert } = ctx.request.body();
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const config = await EmpresaPdvConfig.query().where('id_empresa', terminal.idEmpresa).first();
        if (numeroMesa === '000') {
            return ctx.response.json({ status: 404, message: 'NUMERO DA MESA NÃO É VALIDO!' });
        }
        if (!numeroMesa) {
            return ctx.response.json({ status: 404, message: 'NUMERO DA MESA É OBRIGATÓRIO!' });
        }
        const mesa = await Mesa.query()
            .whereNull('deleted_at')
            .where('numero_mesa', numeroMesa)
            .preload('garcon')
            .preload('itens', (query) => {
            query.preload('produto');
            query.preload('garcon');
            query.preload('venda');
        })
            .preload('setor')
            .first();
        if (!mesa) {
            return ctx.response.json({ status: 404, message: 'MESA NÃO ENCONTRADA!' });
        }
        if (mesa.itens.length === 0) {
            return ctx.response.json({ status: 200, venda: null, taxes: null });
        }
        let valorTaxaServico = 0;
        let valorCouvert = 0;
        let valorTotal = 0;
        for (const item of mesa.itens) {
            valorTotal += Number(item.totalValue);
        }
        if (addTax && config?.utiliza_taxa) {
            valorTaxaServico = valorTotal * (config.valor_taxa / 100);
        }
        if (addCouvert && config?.utiliza_couvert) {
            valorCouvert = config.valor_couvert;
        }
        let taxes = {
            valor_taxa: Number(valorTaxaServico),
            valor_couvert: Number(valorCouvert),
            total_value_taxes: Number(valorTaxaServico) + Number(valorCouvert) + Number(valorTotal),
        };
        const venda = await Venda.query()
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .where('id', mesa.itens[0].idVenda)
            .first();
        if (!venda) {
            return ctx.response.json({
                status: 404,
                message: 'VENDA NÃO ENCONTRADA PARA ESTA MESA',
            });
        }
        return ctx.response.json({ status: 200, venda, taxes });
    }
    async verifyExistSaleStatusProvisional(ctx) {
        const terminal = JSON.parse(ctx.request.header('CONTINGENCIA_TERMINAL') || '{}');
        const idTerminal = terminal.idterminal;
        const sale = await Venda.query()
            .where('id_terminal', idTerminal)
            .where('status', 'PROVISORIO')
            .where('e_orcamento', false)
            .select(['id'])
            .first();
        if (sale) {
            return ctx.response.json(sale.id);
        }
        else {
            return ctx.response.json(0);
        }
    }
}
//# sourceMappingURL=mesa_controller.js.map