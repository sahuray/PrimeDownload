import PrimeFilaImpressao from '#models/prime_fila_impressao';
import { DateTime } from 'luxon';
import PedhosController from '#controllers/pedhos_controller';
export default class PrimeFilaImpressaosController {
    async index() {
        await PedhosController.preencherVendaPedhos();
        const filaImpressao = await PrimeFilaImpressao.query()
            .whereIn('status', ['PENDENTE'])
            .orderBy('created_at', 'asc');
        return filaImpressao;
    }
    async store({ request }) {
        const data = request.only(['conteudo_json', 'funcao_impressao', 'id_terminal']);
        const filaImpressao = await PrimeFilaImpressao.create({
            ...data,
            status: 'PENDENTE',
            tentativas: 0,
        });
        return filaImpressao;
    }
    async update({ request, params }) {
        const filaImpressao = await PrimeFilaImpressao.findOrFail(params.id);
        const data = request.only(['status', 'mensagem_erro']);
        if (data.status === 'PROCESSANDO' || data.status === 'CONCLUIDO') {
            filaImpressao.data_processamento = DateTime.now();
        }
        if (data.status === 'ERRO') {
            filaImpressao.tentativas = filaImpressao.tentativas + 1;
        }
        filaImpressao.merge(data);
        await filaImpressao.save();
        return filaImpressao;
    }
    async getErros() {
        const filaImpressao = await PrimeFilaImpressao.query()
            .where('status', 'ERRO')
            .where('tentativas', '<', 3)
            .orderBy('created_at', 'asc');
        return filaImpressao;
    }
    async limparAntigos() {
        const umaSemanaAtras = new Date();
        umaSemanaAtras.setDate(umaSemanaAtras.getDate() - 7);
        await PrimeFilaImpressao.query()
            .where('status', 'CONCLUIDO')
            .where('created_at', '<', umaSemanaAtras)
            .delete();
        return { message: 'Registros antigos removidos com sucesso' };
    }
}
//# sourceMappingURL=prime_fila_impressao_controller.js.map