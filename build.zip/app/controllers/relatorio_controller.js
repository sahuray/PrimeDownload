import Sale from '#models/venda';
import Motoboy from '#models/motoboy';
import Venda from '#models/venda';
export default class RelatorioController {
    async printDeliverySimpleReport(ctx) {
        const data = ctx.request.all();
        const sales = await Sale.query()
            .preload('motoboy')
            .preload('taxaDeEntrega')
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .preload('caixaMovimento')
            .where('id_caixa_movimento', data.params.id_caixa_movimento)
            .where('id_terminal', data.params.terminal)
            .where('origem', 'DELIVERY')
            .whereIn('status', ['ENVIADO', 'FINALIZADO'])
            .whereNotNull('id_motoboy')
            .where('e_orcamento', false)
            .select('*');
        return sales;
    }
    async getMotoboys(ctx) {
        const data = ctx.request.all();
        const sales = await Venda.query()
            .where('id_caixa_movimento', data.params.id_caixa_movimento)
            .where('id_terminal', data.params.terminal)
            .where('origem', 'DELIVERY')
            .whereIn('status', ['ENVIADO', 'FINALIZADO'])
            .whereNotNull('id_motoboy')
            .where('e_orcamento', false)
            .select('id_motoboy')
            .distinct();
        const idsMotoboys = sales.map((venda) => venda.idMotoboy);
        const motoboys = await Motoboy.query().whereIn('id', idsMotoboys).select('id', 'nome', 'codigo');
        return ctx.response.json(motoboys);
    }
    async reportByMotoboy(ctx) {
        const data = ctx.request.all();
        const sales = await Sale.query()
            .preload('motoboy')
            .preload('taxaDeEntrega')
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .preload('caixaMovimento')
            .where('id_caixa_movimento', data.params.id_caixa_movimento)
            .where('id_terminal', data.params.terminal)
            .where('origem', 'DELIVERY')
            .whereIn('status', ['ENVIADO', 'FINALIZADO'])
            .whereNotNull('id_motoboy')
            .where('e_orcamento', false)
            .where('id_motoboy', data.params.id_motoboy)
            .select('*');
        return sales;
    }
}
//# sourceMappingURL=relatorio_controller.js.map