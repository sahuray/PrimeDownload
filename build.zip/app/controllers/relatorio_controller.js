import Sale from '#models/venda';
import Motoboy from '#models/motoboy';
import Venda from '#models/venda';
import CaixaMovimento from '#models/caixa_movimento';
export default class RelatorioController {
    async getCaixaMovimento(ctx) {
        const data = ctx.request.all();
        const caixaMovimento = await CaixaMovimento.query()
            .where('idterminal', data.params.terminal)
            .if(data.params.search, (query) => {
            query
                .whereRaw('CAST(id_prime AS TEXT) ILIKE ?', [`%${data.params.search}%`])
                .orWhereRaw("TO_CHAR(dataabertura, 'DD/MM/YYYY') ILIKE ?", [`%${data.params.search}%`])
                .orWhereRaw("TO_CHAR(horaabertura, 'HH24:MI:SS') ILIKE ?", [`%${data.params.search}%`]);
        })
            .select('*')
            .orderBy('id_prime', 'desc')
            .limit(100);
        return ctx.response.json(caixaMovimento);
    }
    async printDeliverySimpleReport(ctx) {
        const data = ctx.request.all();
        const sales = await Sale.query()
            .preload('motoboy')
            .preload('taxaDeEntrega')
            .preload('vendaCliente')
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .preload('caixaMovimento')
            .where('id_caixa_movimento', data.params.id_caixa_movimento)
            .where('id_terminal', data.params.terminal)
            .where('origem', 'DELIVERY')
            .whereIn('status', ['ENVIADO', 'FINALIZADO'])
            .whereNotNull('id_motoboy')
            .where('e_orcamento', false)
            .select('*');
        return sales;
    }
    async getMotoboys(ctx) {
        const data = ctx.request.all();
        const sales = await Venda.query()
            .where('id_caixa_movimento', data.params.id_caixa_movimento)
            .where('id_terminal', data.params.terminal)
            .where('origem', 'DELIVERY')
            .whereIn('status', ['ENVIADO', 'FINALIZADO'])
            .whereNotNull('id_motoboy')
            .where('e_orcamento', false)
            .select('id_motoboy')
            .distinct();
        const idsMotoboys = sales.map((venda) => venda.idMotoboy);
        const motoboys = await Motoboy.query().whereIn('id', idsMotoboys).select('id', 'nome', 'codigo');
        return ctx.response.json(motoboys);
    }
    async reportByMotoboy(ctx) {
        const data = ctx.request.all();
        const sales = await Sale.query()
            .preload('motoboy')
            .preload('taxaDeEntrega')
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .preload('caixaMovimento')
            .where('id_caixa_movimento', data.params.id_caixa_movimento)
            .where('id_terminal', data.params.terminal)
            .where('origem', 'DELIVERY')
            .whereIn('status', ['ENVIADO', 'FINALIZADO'])
            .whereNotNull('id_motoboy')
            .where('e_orcamento', false)
            .where('id_motoboy', data.params.id_motoboy)
            .select('*');
        return sales;
    }
}
//# sourceMappingURL=relatorio_controller.js.map