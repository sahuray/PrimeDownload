import Sale from '#models/venda';
export default class RelatorioController {
    async printDeliverySimpleReport(ctx) {
        const data = ctx.request.all();
        const sales = await Sale.query()
            .preload('motoboy')
            .preload('taxaDeEntrega')
            .preload('vendaItem', (subQuery) => {
            subQuery
                .preload('caracteristicas')
                .preload('subItens', (subQuerySubItem) => {
                subQuerySubItem.preload('caracteristicas').preload('produto', (subQueryProduct) => {
                    subQueryProduct.preload('ProdutoEmpresa');
                });
            })
                .preload('produto', (subQueryProduct) => {
                subQueryProduct.preload('ProdutoEmpresa');
            });
        })
            .preload('vendaFormaDePagamento', (subQuery) => {
            subQuery
                .preload('vendaFormaDePagamentoParcela')
                .preload('formaDePagamento', (subPayMethod) => {
                subPayMethod
                    .preload('formaDePagamentoCondicao', (subQueryPayMethodCondition) => {
                    subQueryPayMethodCondition.select(['id', 'nome']);
                })
                    .preload('formaDePagamentoTipo', (subQueryPayMethodType) => {
                    subQueryPayMethodType.select(['id', 'nome', 'cmp']);
                })
                    .preload('bandeira', (subQueryFlag) => {
                    subQueryFlag.select(['id', 'nome']);
                })
                    .preload('contaBancaria', (subQueryAccountBank) => {
                    subQueryAccountBank.select(['id']);
                });
            });
        })
            .preload('vendedor')
            .preload('UsuarioCriacao')
            .preload('empresa', (subQueryCompany) => {
            subQueryCompany.preload('enderecos', (subQueryAddress) => {
                subQueryAddress.select('*').first();
            });
        })
            .where('id_caixa_movimento', data.params.id_caixa_movimento)
            .where('id_terminal', data.params.terminal)
            .where('origem', 'DELIVERY')
            .where('e_orcamento', false)
            .select('*');
        return sales;
    }
    async printDeliveryDetailedReport() {
    }
}
//# sourceMappingURL=relatorio_controller.js.map