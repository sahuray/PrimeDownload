import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table
                .integer('id_usuario')
                .unsigned()
                .nullable()
                .references('idfuncionario')
                .inTable('funcionario_usuario')
                .onDelete('CASCADE');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_usuario');
        });
    }
}
//# sourceMappingURL=1741721743496_create_alter_table_prime_venda_item_add_id_garcons_table.js.map