import { BaseJob } from '#types/job';
import FuncionarioService from '#services/synchrony/funcionario';
import HealthCheckJob from './health_check_job.js';
export default class FuncionarioJob extends BaseJob {
    async run() {
        const healthCheckJob = new HealthCheckJob();
        const isOnline = await healthCheckJob.run();
        if (!isOnline) {
            return;
        }
        const funcionarioService = new FuncionarioService();
        await funcionarioService.syncEmployees();
    }
}
//# sourceMappingURL=funcionario_job.js.map