import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('codigo_barra_1', 13).defaultTo(null);
            table.string('codigo_barra_2', 13).defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('codigo_barra_1');
            table.dropColumn('codigo_barra_2');
        });
    }
}
//# sourceMappingURL=1738176760420_create_add_column_codigo_barra_in_table_prime_produtos_table.js.map