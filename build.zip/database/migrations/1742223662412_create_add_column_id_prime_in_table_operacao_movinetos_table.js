import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName01 = 'prime_operacao_movimento_tipo';
    tableName02 = 'prime_operacao_movimento';
    tableName03 = 'prime_operacao_movimento_item';
    async up() {
        this.schema.alterTable(this.tableName01, (table) => {
            table.integer('id_prime');
        });
        this.schema.alterTable(this.tableName02, (table) => {
            table.integer('id_prime');
        });
        this.schema.alterTable(this.tableName03, (table) => {
            table.integer('id_prime');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName01, (table) => {
            table.dropColumn('id_prime');
        });
        this.schema.alterTable(this.tableName02, (table) => {
            table.dropColumn('id_prime');
        });
        this.schema.alterTable(this.tableName03, (table) => {
            table.dropColumn('id_prime');
        });
    }
}
//# sourceMappingURL=1742223662412_create_add_column_id_prime_in_table_operacao_movinetos_table.js.map