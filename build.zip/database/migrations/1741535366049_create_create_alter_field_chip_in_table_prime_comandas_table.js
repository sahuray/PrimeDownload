import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_comanda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('chip', 50).nullable().alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('chip', 50).notNullable().alter();
        });
    }
}
//# sourceMappingURL=1741535366049_create_create_alter_field_chip_in_table_prime_comandas_table.js.map