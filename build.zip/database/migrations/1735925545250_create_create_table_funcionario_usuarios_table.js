import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('idfuncionariousuario');
            table.text('usuario');
            table.text('senha');
            table.decimal('tema', 16, 0);
            table.text('biometria');
            table.timestamp('ultimaalteracao', { useTz: false });
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1735925545250_create_create_table_funcionario_usuarios_table.js.map