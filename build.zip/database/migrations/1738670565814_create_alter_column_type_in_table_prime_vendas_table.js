import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.raw(`ALTER TABLE ${this.tableName} ALTER COLUMN type SET DATA TYPE INTEGER USING type::INTEGER`);
    }
    async down() {
        this.schema.raw(`ALTER TABLE ${this.tableName} ALTER COLUMN type SET DATA TYPE DECIMAL(8,2) USING type::DECIMAL(8,2)`);
    }
}
//# sourceMappingURL=1738670565814_create_alter_column_type_in_table_prime_vendas_table.js.map