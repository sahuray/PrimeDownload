import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('cpf').alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('cpf', 11).alter();
        });
    }
}
//# sourceMappingURL=1737472483213_create_alter_columns_varchar_to_text_in_table_funcionarios_table.js.map