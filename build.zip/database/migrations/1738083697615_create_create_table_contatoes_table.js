import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_contato';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_fk');
            table.integer('id_prime');
            table.text('tipo_relacionamento');
            table.text('email');
            table.text('nome');
            table.text('telefone');
            table.text('observacao');
            table.text('tipo_contato');
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1738083697615_create_create_table_contatoes_table.js.map