import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('observacao');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('observacao');
        });
    }
}
//# sourceMappingURL=1737375321160_create_field_observacao_in_prime_venda_item_table.js.map