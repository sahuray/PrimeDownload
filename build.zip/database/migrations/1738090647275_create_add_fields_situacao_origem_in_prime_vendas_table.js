import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('status').nullable();
            table.text('origem').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('status');
            table.dropColumn('origem');
        });
    }
}
//# sourceMappingURL=1738090647275_create_add_fields_situacao_origem_in_prime_vendas_table.js.map