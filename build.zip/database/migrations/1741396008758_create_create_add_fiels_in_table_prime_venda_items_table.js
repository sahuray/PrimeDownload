import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('listar_na_comanda').notNullable().defaultTo(false);
            table.integer('id_venda_anterior').unsigned().nullable();
            table
                .integer('id_comanda')
                .unsigned()
                .nullable()
                .references('id')
                .inTable('prime_comanda')
                .onDelete('CASCADE');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('listar_na_comanda');
            table.dropColumn('id_venda_anterior');
            table.dropColumn('id_comanda');
        });
    }
}
//# sourceMappingURL=1741396008758_create_create_add_fiels_in_table_prime_venda_items_table.js.map