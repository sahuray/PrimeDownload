import { BaseSchema } from '@adonisjs/lucid/schema';
export default class AddColumnQuickLoginPrathos extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('quick_login_prathos').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('quick_login_prathos');
        });
    }
}
//# sourceMappingURL=1747140266277_create_alter_table_funcionario_usuario_add_column_quick_login_prathos_table.js.map