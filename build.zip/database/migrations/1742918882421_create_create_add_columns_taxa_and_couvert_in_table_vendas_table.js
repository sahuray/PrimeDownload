import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('valor_taxa_servico', 16, 2).defaultTo(0);
            table.decimal('valor_couvert', 16, 2).defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('valor_couvert');
            table.dropColumn('valor_taxa_servico');
        });
    }
}
//# sourceMappingURL=1742918882421_create_create_add_columns_taxa_and_couvert_in_table_vendas_table.js.map