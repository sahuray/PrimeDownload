import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('empresa_id').nullable().unsigned().references('id').inTable('prime_empresa');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('empresa_id');
        });
    }
}
//# sourceMappingURL=1737209319864_create_create_new_field_empresa_id_in_funcionario_usuarios_table.js.map