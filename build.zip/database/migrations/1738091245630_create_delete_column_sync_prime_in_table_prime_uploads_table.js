import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_upload';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('sync_prime');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('sync_prime').defaultTo(false);
        });
    }
}
//# sourceMappingURL=1738091245630_create_delete_column_sync_prime_in_table_prime_uploads_table.js.map