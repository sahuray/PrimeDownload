import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableNamePrimeConfig = 'prime_config';
    async up() {
        this.schema.alterTable(this.tableNamePrimeConfig, (table) => {
            table.integer('id_empresa_prime').references('id').inTable('prime_empresa');
        });
    }
    async down() {
        this.schema.alterTable(this.tableNamePrimeConfig, (table) => {
            table.dropColumn('id_empresa_prime');
        });
    }
}
//# sourceMappingURL=1744288097322_create_alter_table_prime_configs_table.js.map