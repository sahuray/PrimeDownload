import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('listar_na_mesa').notNullable().defaultTo(false);
            table
                .integer('id_mesa')
                .unsigned()
                .nullable()
                .references('id')
                .inTable('prime_mesa')
                .onDelete('CASCADE');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('listar_na_mesa');
            table.dropColumn('id_mesa');
        });
    }
}
//# sourceMappingURL=1741711600098_create_alter_table_prime_venda_item_add_id_mesas_table.js.map