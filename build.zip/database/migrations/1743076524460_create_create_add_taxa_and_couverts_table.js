import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('taxa_de_servico').defaultTo(false);
            table.boolean('couvert').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('taxa_de_servico');
            table.dropColumn('couvert');
        });
    }
}
//# sourceMappingURL=1743076524460_create_create_add_taxa_and_couverts_table.js.map