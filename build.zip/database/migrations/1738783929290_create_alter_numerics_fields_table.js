import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    VendaSubItem = 'prime_venda_sub_item';
    async up() {
        this.schema.alterTable(this.VendaSubItem, (table) => {
            table.decimal('quantidade', 16, 2).alter();
            table.decimal('valor_unitario', 16, 2).alter();
            table.decimal('valor_total', 16, 2).alter();
            table.decimal('valor_desconto', 16, 2).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.VendaSubItem, (table) => {
            table.integer('quantidade').alter();
            table.integer('valor_unitario').alter();
            table.integer('valor_total').alter();
            table.integer('valor_desconto').alter();
        });
    }
}
//# sourceMappingURL=1738783929290_create_alter_numerics_fields_table.js.map