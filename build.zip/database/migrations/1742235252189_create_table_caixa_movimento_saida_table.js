import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_saida';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table
                .integer('id_caixa_movimento')
                .unsigned()
                .references('idcaixamovimento')
                .inTable('caixa_movimento');
            table
                .integer('id_forma_pagamento_tipo')
                .unsigned()
                .references('id')
                .inTable('prime_forma_de_pagamento_tipo');
            table
                .integer('id_funcionario_usuario')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.decimal('valor', 16, 2);
            table.text('descricao').nullable();
            table.boolean('sangria').defaultTo(false);
            table.date('dataemissao');
            table.time('horaemissao');
            table.boolean('tipo').defaultTo(false);
            table.boolean('sync_prime').defaultTo(false);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1742235252189_create_table_caixa_movimento_saida_table.js.map