import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_departamento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
        });
    }
}
//# sourceMappingURL=1741008249895_create_add_id_prime_in_table_prime_departamentos_table.js.map