import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_sub_item';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_venda_item').unsigned().references('id').inTable('prime_venda_item');
            table.integer('id_produto').unsigned().references('id').inTable('prime_produto');
            table.integer('id_venda').unsigned().references('id').inTable('prime_venda');
            table.text('status');
            table.text('descricao');
            table.integer('comissao_porcentagem');
            table.integer('quantidade');
            table.integer('valor_unitario');
            table.integer('valor_total');
            table.integer('valor_desconto');
            table.integer('codigo');
            table.text('ncm');
            table.text('cfop');
            table.text('csosn');
            table.text('aliquota_icms');
            table.text('observacao');
            table.integer('sync_prime');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1737373777501_create_create_prime_venda_sub_item_table.js.map