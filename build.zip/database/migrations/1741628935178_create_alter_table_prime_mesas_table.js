import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_mesa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('identificacao_mesa').defaultTo(null);
            table.integer('quantidade_pessoas').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('identificacao_mesa');
            table.dropColumn('quantidade_pessoas');
        });
    }
}
//# sourceMappingURL=1741628935178_create_alter_table_prime_mesas_table.js.map