import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_informacao_nutricional';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('description').alter();
            table.text('ingredients').alter();
            table.text('complementary_attributes').alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('description', 255).alter();
            table.string('ingredients', 255).alter();
            table.string('complementary_attributes', 255).alter();
        });
    }
}
//# sourceMappingURL=1737545178143_create_alter_fields_value_varchar_to_texts_table.js.map