import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_pdv_config';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.string('tipo_de_prazo').defaultTo(null);
            table.decimal('limite_qtd_itens_venda', 16).notNullable().defaultTo(0);
            table.decimal('qtd_vias_cupom_prazo', 16, 2).notNullable().defaultTo(1);
            table.decimal('qtd_vias_cupom_vista', 16, 2).notNullable().defaultTo(1);
            table.decimal('limite_vendas_a_prazo', 16, 2).notNullable().defaultTo(0);
            table.decimal('desconto_maximo_na_venda', 16, 2).notNullable().defaultTo(0);
            table.decimal('dia_do_prazo', 16, 0).notNullable().defaultTo(0);
            table.boolean('nao_pedir_valor_caixa').notNullable().defaultTo(false);
            table.boolean('gerar_comissao').notNullable().defaultTo(false);
            table.boolean('imprimir_codigo_produto').notNullable().defaultTo(false);
            table.boolean('utiliza_numero_serie').notNullable().defaultTo(false);
            table.boolean('solicitar_confirmacao_exclusao_estoque').notNullable().defaultTo(false);
            table.boolean('imprimir_observacao_produto').notNullable().defaultTo(false);
            table.boolean('desconto_maximo_venda').notNullable().defaultTo(false);
            table.boolean('exigir_senha_sangria').notNullable().defaultTo(false);
            table.boolean('imprimir_comprovante_operacao').notNullable().defaultTo(false);
            table.boolean('fechar_venda_com_enter').notNullable().defaultTo(false);
            table.boolean('imprimir_obs_peso').notNullable().defaultTo(false);
            table.boolean('imprimir_endereco_cliente_detalhado').notNullable().defaultTo(false);
            table.boolean('nao_permitir_orcamento_estoque_zerado').notNullable().defaultTo(false);
            table.boolean('permitir_escolher_preco_venda').notNullable().defaultTo(false);
            table.boolean('imprimir_comprovante_venda_prazo').notNullable().defaultTo(false);
            table.boolean('confirmar_impressao_comprovante_venda_prazo').notNullable().defaultTo(false);
            table.boolean('msg_rodape_impresso_gerado_sistema').notNullable().defaultTo(false);
            table.boolean('bloquear_vendas_a_prazo_por_limite').notNullable().defaultTo(false);
            table.boolean('bloquear_vendas_a_prazo_por_atraso_do_cliente').notNullable().defaultTo(false);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1738241704402_create_create_prime_empresa_pdv_configs_table.js.map