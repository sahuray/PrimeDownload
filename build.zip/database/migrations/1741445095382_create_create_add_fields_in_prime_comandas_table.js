import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_comanda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('observacao').nullable();
            table.boolean('bloqueado').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('observacao');
            table.dropColumn('bloqueado');
        });
    }
}
//# sourceMappingURL=1741445095382_create_create_add_fields_in_prime_comandas_table.js.map