import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_forma_de_pagamento';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_empresa').references('id').inTable('prime_empresa');
            table
                .integer('id_forma_de_pagamento_tipo')
                .references('id')
                .inTable('prime_forma_de_pagamento_tipo');
            table
                .integer('id_forma_de_pagamento_condicao')
                .references('id')
                .inTable('prime_forma_de_pagamento_condicao');
            table.integer('id_bandeira').references('id').inTable('prime_bandeira');
            table.integer('id_conta_bancaria').references('id').inTable('prime_conta_bancaria');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
            table.boolean('sync_prime').defaultTo(false);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736271567361_create_create_table_prime_forma_de_pagamentos_table.js.map