import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_comanda_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('utiliza_codigo_comanda').notNullable().defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('utiliza_codigo_comanda');
        });
    }
}
//# sourceMappingURL=1741515218220_create_create_add_field_utiliza_codigo_comanda_in_table_prime_empresa_comanda_configs_table.js.map