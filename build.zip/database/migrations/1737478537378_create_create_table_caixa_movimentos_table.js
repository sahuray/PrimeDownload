import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_movimento';
    async up() {
        const hasTable = await this.schema.hasTable(this.tableName);
        if (hasTable)
            return;
        this.schema.createTable(this.tableName, (table) => {
            table.increments('idcaixamovimento').primary();
            table
                .integer('idfuncionariousuarioabertura')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table
                .integer('idfuncionariousuariofechamento')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.integer('idterminal').unsigned().references('idterminal').inTable('terminal');
            table.date('dataabertura');
            table.time('horaabertura');
            table.date('datafechamento');
            table.time('horafechamento');
            table.decimal('totalvenda', 16, 3);
            table.decimal('totalsaida', 16, 3);
            table.decimal('totalestorno', 16, 3);
            table.decimal('totaldinheirocaixa', 16, 3);
            table.decimal('suprimentoatual', 16, 3);
            table.decimal('saldoanterior', 16, 3);
            table.decimal('saldofinal', 16, 3);
            table.string('status', 3);
            table.string('justificativa', 500);
        });
    }
    async down() {
    }
}
//# sourceMappingURL=1737478537378_create_create_table_caixa_movimentos_table.js.map