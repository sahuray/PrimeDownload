import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_pagamento_a_prazo';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('tax_percentage', 16, 2).defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('tax_percentage');
        });
    }
}
//# sourceMappingURL=1741780161653_create_add_column_tax_more_id_account_in_table_prime_venda_pagamento_a_prazos_table.js.map