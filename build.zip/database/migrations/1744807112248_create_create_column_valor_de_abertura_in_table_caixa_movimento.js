import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_movimento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('valor_abertura', 16, 4).defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('valor_abertura');
        });
    }
}
//# sourceMappingURL=1744807112248_create_create_column_valor_de_abertura_in_table_caixa_movimento.js.map