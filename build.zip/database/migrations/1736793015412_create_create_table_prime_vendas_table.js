import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_grupo').unsigned().references('id').inTable('prime_grupo');
            table.integer('id_cliente').unsigned().references('id').inTable('prime_empresa');
            table
                .integer('id_caixa_movimento')
                .unsigned()
                .references('idcaixamovimento')
                .inTable('caixa_movimento');
            table
                .integer('id_usuario_inativar')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table
                .integer('id_usuario_criacao')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.integer('id_terminal').unsigned().references('idterminal').inTable('terminal');
            table.integer('id_vendedor').unsigned().references('idfuncionario').inTable('funcionario');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.boolean('sync_prime').defaultTo(false);
            table.decimal('comissao_porcentagem', 16, 2);
            table.decimal('total_value', 16, 2);
            table.decimal('total_descount_value', 16, 2);
            table.decimal('type');
            table.text('cpf');
            table.text('motivo_cancelamento');
            table.decimal('codigo');
            table.text('observacao');
            table.boolean('finalizado').defaultTo(false);
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
            table.decimal('code');
            table.text('sat_xml');
            table.text('sat_xml_path');
            table.text('sat_numero_serie');
            table.text('tipo');
            table.text('coo');
            table.text('sat_xml_cancelamento');
            table.text('sat_xml_path_cancelamento');
            table.text('coo_cancelamento');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736793015412_create_create_table_prime_vendas_table.js.map