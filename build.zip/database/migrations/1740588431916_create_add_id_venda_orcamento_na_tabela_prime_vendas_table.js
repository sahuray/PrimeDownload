import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_venda_orcamento');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_venda_orcamento');
        });
    }
}
//# sourceMappingURL=1740588431916_create_add_id_venda_orcamento_na_tabela_prime_vendas_table.js.map