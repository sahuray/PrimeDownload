import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_delivery_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('status_loja_ifood').nullable().defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('status_loja_ifood');
        });
    }
}
//# sourceMappingURL=1746011877672_create_add_fild_intable_prime_empresa_delivery_configs_table.js.map