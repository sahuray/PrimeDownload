import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_grupo';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
        });
    }
}
//# sourceMappingURL=1736355560401_create_add_column_id_prime_in_table_primes_table.js.map