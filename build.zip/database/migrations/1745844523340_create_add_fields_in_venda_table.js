import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('pedido_aplicativo');
            table.timestamp('hora_preparo');
            table.timestamp('hora_entrega');
            table.timestamp('agendado');
            table.text('status_aplicativo');
            table.text('id_venda_aplicativo');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('pedido_aplicativo');
            table.dropColumn('hora_preparo');
            table.dropColumn('hora_entrega');
            table.dropColumn('agendado');
            table.dropColumn('status_aplicativo');
            table.dropColumn('id_venda_aplicativo');
        });
    }
}
//# sourceMappingURL=1745844523340_create_add_fields_in_venda_table.js.map