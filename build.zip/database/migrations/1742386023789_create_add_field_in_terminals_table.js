import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableNameTerminal = 'terminal';
    tableNameEmpresaPdvConfig = 'prime_empresa_pdv_config';
    async up() {
        this.schema.alterTable(this.tableNameTerminal, (table) => {
            table.text('hostname').unique().nullable();
            table.boolean('pedhos').defaultTo(false);
        });
        this.schema.alterTable(this.tableNameEmpresaPdvConfig, (table) => {
            table.boolean('utiliza_mesa_com_comanda').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableNameTerminal, (table) => {
            table.dropColumn('hostname');
            table.dropColumn('pedhos');
        });
        this.schema.alterTable(this.tableNameEmpresaPdvConfig, (table) => {
            table.dropColumn('utiliza_mesa_com_comanda');
        });
    }
}
//# sourceMappingURL=1742386023789_create_add_field_in_terminals_table.js.map