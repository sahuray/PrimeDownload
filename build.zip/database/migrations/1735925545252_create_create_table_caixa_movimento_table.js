import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_movimento';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('idcaixamovimento');
            table
                .integer('idfuncionariousuarioabertura')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table
                .integer('idfuncionariousuariofechamento')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.integer('idterminal').unsigned().references('idterminal').inTable('terminal');
            table.date('dataabertura');
            table.time('horaabertura');
            table.date('datafechamento');
            table.time('horafechamento');
            table.decimal('totalvenda', 16, 3).defaultTo(0);
            table.decimal('totalsaida', 16, 3).defaultTo(0);
            table.decimal('totalestorno', 16, 3).defaultTo(0);
            table.decimal('totaldinheirocaixa', 16, 3).defaultTo(0);
            table.decimal('suprimentoatual', 16, 3).defaultTo(0);
            table.decimal('saldoanterior', 16, 3).defaultTo(0);
            table.decimal('saldofinal', 16, 3).defaultTo(0);
            table.text('status');
            table.text('justificativa');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1735925545252_create_create_table_caixa_movimento_table.js.map