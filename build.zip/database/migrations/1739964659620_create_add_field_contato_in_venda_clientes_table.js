import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_cliente';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('contato').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('contato');
        });
    }
}
//# sourceMappingURL=1739964659620_create_add_field_contato_in_venda_clientes_table.js.map