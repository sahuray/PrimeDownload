import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('sat_arquivo');
            table.text('sat_codigo_de_retorno');
            table.text('sat_numero_sessao');
            table.text('sat_resultado');
            table.text('sat_retorno_str');
            table.text('sat_nCFe');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('sat_arquivo');
            table.dropColumn('sat_codigo_de_retorno');
            table.dropColumn('sat_numero_sessao');
            table.dropColumn('sat_resultado');
            table.dropColumn('sat_retorno_str');
            table.dropColumn('sat_nCFe');
        });
    }
}
//# sourceMappingURL=1742930544752_create_add_columns_sales_table.js.map