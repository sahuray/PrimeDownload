import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_nfce';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_venda').unsigned().references('id').inTable('prime_venda');
            table.boolean('sync_prime').defaultTo(false);
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.text('status');
            table.text('message');
            table.text('data');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736795315753_create_create_table_prime_venda_nfces_table.js.map