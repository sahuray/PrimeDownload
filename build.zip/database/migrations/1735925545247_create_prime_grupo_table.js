import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_grupo';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('server_id').unsigned();
            table.text('nome').notNullable().unique();
            table.text('slug').notNullable().unique();
            table.text('foto').nullable();
            table.boolean('ativo').defaultTo(true).notNullable();
            table.boolean('utiliza_contabilizathos').defaultTo(false);
            table.boolean('vizualizar_empresas').defaultTo(false);
            table.timestamp('created_at', { useTz: true });
            table.timestamp('updated_at', { useTz: true });
            table.timestamp('deleted_at', { useTz: true });
            table.text('db_hash_initialization');
            table.timestamp('db_initialized_at', { useTz: true });
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1735925545247_create_prime_grupo_table.js.map