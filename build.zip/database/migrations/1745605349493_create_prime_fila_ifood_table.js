import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_fila_ifood';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.json('conteudo_json').notNullable();
            table.text('status').defaultTo('PENDENTE');
            table.integer('tentativas').defaultTo(0);
            table.text('mensagem_erro').nullable();
            table.timestamp('data_processamento').nullable();
            table.timestamp('created_at');
            table.timestamp('updated_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1745605349493_create_prime_fila_ifood_table.js.map