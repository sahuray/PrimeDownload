import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'terminal';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('acbr_caminho').nullable();
            table.text('qztray_certificado').nullable();
            table.text('qztray_chave').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('acbr_caminho');
            table.dropColumn('qztray_certificado');
            table.dropColumn('qztray_chave');
        });
    }
}
//# sourceMappingURL=1741712034234_create_add_columns_terminals_table.js.map