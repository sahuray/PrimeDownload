import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_delivery_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_produto_vinculado').nullable().references('id').inTable('prime_produto');
            table.text('label_produto_vinculado').nullable();
            table.boolean('trazer_endereco_delivery_cupom_venda').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_produto_vinculado');
            table.dropColumn('label_produto_vinculado');
            table.dropColumn('trazer_endereco_delivery_cupom_venda');
        });
    }
}
//# sourceMappingURL=1740575347574_create_add_fields_in_table_prime_empresa_delivery_configs_table.js.map