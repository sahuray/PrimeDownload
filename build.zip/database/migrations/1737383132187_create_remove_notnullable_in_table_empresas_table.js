import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('emissao_nfse_nothos_prime_completo').defaultTo(false).alter();
            table.boolean('emissao_nfce_nothos_prime_completo').defaultTo(false).alter();
            table.boolean('emissao_nfe_nothos_prime_completo').defaultTo(false).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('emissao_nfse_nothos_prime_completo').notNullable().defaultTo(false).alter();
            table.boolean('emissao_nfce_nothos_prime_completo').notNullable().defaultTo(false).alter();
            table.boolean('emissao_nfe_nothos_prime_completo').notNullable().defaultTo(false).alter();
        });
    }
}
//# sourceMappingURL=1737383132187_create_remove_notnullable_in_table_empresas_table.js.map