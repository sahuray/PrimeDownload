import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_delivery_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.renameColumn('empresa_id', 'id_empresa');
            table.integer('id_prime').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.renameColumn('id_empresa', 'empresa_id');
            table.dropColumn('id_prime');
        });
    }
}
//# sourceMappingURL=1738330673367_create_alter_empresa_id_for_id_empresa_in_table_config_deliveries_table.js.map