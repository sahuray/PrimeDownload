import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_operacao_movimento';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table
                .integer('id_usuario')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.integer('id_terminal').unsigned().references('idterminal').inTable('terminal');
            table
                .integer('id_operacao_tipo')
                .unsigned()
                .references('id')
                .inTable('prime_operacao_movimento_tipo');
            table.text('observacao');
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1742215569231_create_create_table_prime_operacao_movimentos_table.js.map