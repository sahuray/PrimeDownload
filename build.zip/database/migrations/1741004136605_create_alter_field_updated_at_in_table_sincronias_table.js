import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'sincronia';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('updated_at', { useTz: false }).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('updated_at', { useTz: true }).alter();
        });
    }
}
//# sourceMappingURL=1741004136605_create_alter_field_updated_at_in_table_sincronias_table.js.map