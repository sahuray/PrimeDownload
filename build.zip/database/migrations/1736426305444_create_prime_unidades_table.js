import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_unidade';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.string('sigla');
            table.string('nome');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at').defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736426305444_create_prime_unidades_table.js.map