import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_funcionario').unsigned().references('idfuncionario').inTable('funcionario');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_funcionario');
        });
    }
}
//# sourceMappingURL=1740419034437_create_add_id_funcionario_in_table_funcionario_usuarios_table.js.map