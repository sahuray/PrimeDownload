import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table.integer('id_grupo').unsigned().references('id').inTable('prime_grupo');
            table
                .integer('id_unidade_comercial')
                .unsigned()
                .references('id')
                .inTable('prime_produto_unidade');
            table
                .integer('id_unidade_tributavel')
                .unsigned()
                .references('id')
                .inTable('prime_produto_unidade');
            table.integer('id_marca').unsigned().references('id').inTable('prime_marca');
            table
                .integer('id_produto_informacao_nutricional')
                .unsigned()
                .references('id')
                .inTable('prime_produto_informacao_nutricional');
            table.integer('id_fornecedor').unsigned().references('id').inTable('prime_empresa');
            table
                .integer('id_produto_categoria_setor')
                .unsigned()
                .references('id')
                .inTable('prime_produto_categoria_setor');
            table
                .integer('id_produto_categoria_grupo')
                .unsigned()
                .references('id')
                .inTable('prime_produto_categoria_grupo');
            table
                .integer('id_produto_categoria_subgrupo')
                .unsigned()
                .references('id')
                .inTable('prime_produto_categoria_subgrupo');
            table
                .integer('id_produto_categoria_linha')
                .unsigned()
                .references('id')
                .inTable('prime_produto_categoria_linha');
            table.string('code');
            table.decimal('packing_width', 8, 2);
            table.decimal('packing_heigth', 8, 2);
            table.decimal('packing_depth', 8, 2);
            table.decimal('packing_weight', 8, 2);
            table.string('reference');
            table.string('name');
            table.string('short_name');
            table.boolean('use_gride');
            table.text('characteristics');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736427275174_create_prime_produtos_table.js.map