import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    oldTableName = 'caixa_saida';
    newTableName = 'caixa_entrada_e_saida';
    async up() {
        this.schema.renameTable(this.oldTableName, this.newTableName);
    }
    async down() {
        this.schema.renameTable(this.newTableName, this.oldTableName);
    }
}
//# sourceMappingURL=1744726277521_rename_table_caixa_saida_to_caixa_entrada_e_saida.js.map