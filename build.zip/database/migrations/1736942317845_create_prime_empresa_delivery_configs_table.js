import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_delivery_config';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('empresa_id').unsigned().references('id').inTable('prime_empresa');
            table.boolean('utiliza_delivery').defaultTo(false);
            table.boolean('trazer_ultima_observacao_pedido').defaultTo(false);
            table.boolean('confirmar_impressao_caminho_entrega').defaultTo(false);
            table.boolean('alterar_valor_produto').defaultTo(false);
            table.boolean('confirmacao_geral_delivery_pedidos_aplicativo').defaultTo(false);
            table.boolean('utiliza_ifood').defaultTo(false);
            table.boolean('utiliza_pedido_whatsapp').defaultTo(false);
            table.boolean('utiliza_pedido_anota_ai').defaultTo(false);
            table.boolean('impressao_por_departamento').defaultTo(false);
            table.decimal('tempo_medio', 16, 4).nullable().defaultTo(0);
            table.boolean('epadoca').defaultTo(false);
            table.boolean('ifood').defaultTo(false);
            table.boolean('app_delivery').defaultTo(false);
            table.boolean('multi_pedidos').defaultTo(false);
            table.boolean('anota_ai').defaultTo(false);
            table.boolean('divisao_de_pizza_maior_valor').defaultTo(false);
            table.string('taxa_ao_produto').nullable();
            table.string('valor_utilizado_na_venda').nullable();
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736942317845_create_prime_empresa_delivery_configs_table.js.map