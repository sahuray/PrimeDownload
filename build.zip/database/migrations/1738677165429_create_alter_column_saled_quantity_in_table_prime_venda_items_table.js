import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.raw(`ALTER TABLE ${this.tableName} ALTER COLUMN saled_quantity SET DATA TYPE INTEGER USING saled_quantity::INTEGER`);
    }
    async down() {
        this.schema.raw(`ALTER TABLE ${this.tableName} ALTER COLUMN saled_quantity SET DATA TYPE DECIMAL(16,2) USING saled_quantity::DECIMAL(16,2)`);
    }
}
//# sourceMappingURL=1738677165429_create_alter_column_saled_quantity_in_table_prime_venda_items_table.js.map