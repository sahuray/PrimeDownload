import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_fila_impressao';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('conteudo_json');
            table.dropColumn('funcao_impressao');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('conteudo_json');
            table.text('funcao_impressao');
        });
    }
}
//# sourceMappingURL=1747320004569_create_delete_field_table_fila_impressao_table.js.map