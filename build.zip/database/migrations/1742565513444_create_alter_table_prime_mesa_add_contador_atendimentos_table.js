import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_mesa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('total_atendimento').nullable().defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('total_atendimento');
        });
    }
}
//# sourceMappingURL=1742565513444_create_alter_table_prime_mesa_add_contador_atendimentos_table.js.map