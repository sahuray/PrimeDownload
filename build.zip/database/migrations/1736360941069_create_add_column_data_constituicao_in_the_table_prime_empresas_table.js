import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('data_constituicao').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('data_constituicao');
        });
    }
}
//# sourceMappingURL=1736360941069_create_add_column_data_constituicao_in_the_table_prime_empresas_table.js.map