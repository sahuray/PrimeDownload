import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_banco';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.text('codigo');
            table.text('nome');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
            table.boolean('homologado').defaultTo(false);
            table.boolean('sync_prime').defaultTo(false);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736262933357_create_create_table_prime_bancos_table.js.map