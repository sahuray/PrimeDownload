import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('usuario', 100).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('usuario', 20).alter();
        });
    }
}
//# sourceMappingURL=1737038562832_create_alter_ususario_string_20_s_table.js.map