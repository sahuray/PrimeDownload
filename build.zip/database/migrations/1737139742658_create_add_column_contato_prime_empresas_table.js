import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('contato').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('contato');
        });
    }
}
//# sourceMappingURL=1737139742658_create_add_column_contato_prime_empresas_table.js.map