import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_cliente';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('aniversario', { useTz: false }).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('aniversario');
        });
    }
}
//# sourceMappingURL=1739973762584_create_alter_field_aniversario_in_table_prime_venda_clientes_table.js.map