import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_composto';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table.integer('id_detalhe').unsigned().references('id').inTable('prime_produto');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.integer('id_produto').unsigned().references('id').inTable('prime_produto');
            table.string('quantity');
            table.string('composicao');
            table.decimal('custo_unitario', 16, 4);
            table.decimal('custo_total', 16, 4);
            table.decimal('estoque', 16, 4);
            table.decimal('restante', 16, 4);
            table.decimal('perda_real', 16, 4);
            table.decimal('perda_porcentagem', 16, 4);
            table.decimal('custo_perda', 16, 4);
            table.decimal('custo_real_com_perdas', 16, 4);
            table.string('codigo');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at').defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736430098743_create_prime_produto_compostos_table.js.map