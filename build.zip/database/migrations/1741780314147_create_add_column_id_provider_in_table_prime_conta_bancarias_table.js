import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_conta_bancaria';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_provider').nullable().references('id').inTable('prime_empresa');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_provider');
        });
    }
}
//# sourceMappingURL=1741780314147_create_add_column_id_provider_in_table_prime_conta_bancarias_table.js.map