import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_endereco';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('sync_prime').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('sync_prime');
        });
    }
}
//# sourceMappingURL=1737564545826_create_add_sync_prime_in_table_enderecos_table.js.map