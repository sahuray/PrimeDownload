import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'terminal';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('numero');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('numero');
        });
    }
}
//# sourceMappingURL=1737477441979_create_add_column_numero_in_table_terminals_table.js.map