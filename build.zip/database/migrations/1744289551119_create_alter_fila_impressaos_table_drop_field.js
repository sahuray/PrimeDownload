import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_fila_impressao';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_terminal');
        });
    }
    async down() {
        await this.db.rawQuery('DELETE FROM prime_fila_impressao');
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_terminal').notNullable().references('idterminal').inTable('terminal');
        });
    }
}
//# sourceMappingURL=1744289551119_create_alter_fila_impressaos_table_drop_field.js.map