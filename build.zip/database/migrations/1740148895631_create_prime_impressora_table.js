import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_impressora';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table
                .integer('id_impressora_configuracao')
                .references('id')
                .inTable('prime_impressora_configuracao');
            table.text('nome_impressora');
            table.integer('id_departamento').references('id').inTable('prime_departamento');
            table.decimal('colunas', 10, 2).defaultTo(48);
            table.decimal('avanco_papel', 10, 0).defaultTo(0);
            table.text('modelo_impressora');
            table.boolean('debug_impressao').defaultTo(false);
            table.boolean('status').defaultTo(true);
            table.text('comando_guilhotina');
            table.decimal('fixa', 10, 0).defaultTo(0);
            table.decimal('tipo_fonte', 10, 0).defaultTo(0);
            table.text('modelo_acbr');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1740148895631_create_prime_impressora_table.js.map