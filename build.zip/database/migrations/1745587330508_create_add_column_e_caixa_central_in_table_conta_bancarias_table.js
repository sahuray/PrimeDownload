import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_conta_bancaria';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('e_caixa_central').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('e_caixa_central');
        });
    }
}
//# sourceMappingURL=1745587330508_create_add_column_e_caixa_central_in_table_conta_bancarias_table.js.map