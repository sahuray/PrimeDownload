import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_fila_impressao';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('conteudo_json').nullable();
            table.text('funcao_impressao').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('conteudo_json');
            table.dropColumn('funcao_impressao');
        });
    }
}
//# sourceMappingURL=1747320016592_create_add_table_fila_impressaos_table.js.map