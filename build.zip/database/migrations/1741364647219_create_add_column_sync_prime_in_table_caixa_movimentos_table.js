import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_movimento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('sync_prime').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('sync_prime');
        });
    }
}
//# sourceMappingURL=1741364647219_create_add_column_sync_prime_in_table_caixa_movimentos_table.js.map