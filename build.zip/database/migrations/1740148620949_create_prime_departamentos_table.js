import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_departamento';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.text('nome');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1740148620949_create_prime_departamentos_table.js.map