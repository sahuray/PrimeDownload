import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_fechamento';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_usuario').unsigned().references('idfuncionario').inTable('funcionario');
            table
                .integer('id_caixa_movimento')
                .unsigned()
                .references('idcaixamovimento')
                .inTable('caixa_movimento');
            table
                .integer('id_forma_de_pagamento_tipo')
                .unsigned()
                .references('id')
                .inTable('prime_forma_de_pagamento_tipo');
            table.text('historico');
            table.decimal('valor_sistema', 16, 2);
            table.decimal('valor_informado', 16, 2);
            table.boolean('tipo_movimento').defaultTo(false);
            table.timestamp('data_fechamento', { useTz: false });
            table.timestamp('hora_fechamento', { useTz: false });
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1741611288531_create_create_table_caixa_fechamentos_table.js.map