import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_mesa';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime').defaultTo(null);
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.integer('id_setor').unsigned().references('id').inTable('prime_setor');
            table.integer('id_garcon').defaultTo(null);
            table.integer('id_agrupamento').defaultTo(null);
            table.text('numero_mesa');
            table.text('numero_cadeiras');
            table.text('observacao');
            table.text('status').defaultTo('LIVRE');
            table.boolean('active').defaultTo(true);
            table.boolean('favorite').defaultTo(false);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1741337266355_create_create_table_prime_mesas_table.js.map