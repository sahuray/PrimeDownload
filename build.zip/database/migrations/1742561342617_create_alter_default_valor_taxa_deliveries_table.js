import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('valor_taxa_delivery', 16, 2).defaultTo(0).alter();
            table.decimal('valor_produtos', 16, 2).defaultTo(0).alter();
            table.decimal('valor_troco', 16, 2).defaultTo(0).alter();
            table.decimal('comissao_porcentagem', 16, 2).defaultTo(0).alter();
            table.decimal('total_value', 16, 2).defaultTo(0).alter();
            table.decimal('total_descount_value', 16, 2).defaultTo(0).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('valor_taxa_delivery', 16, 2).nullable().alter();
            table.decimal('valor_produtos', 16, 2).nullable().alter();
            table.decimal('valor_troco', 16, 2).nullable().alter();
            table.decimal('comissao_porcentagem', 16, 2).alter();
            table.decimal('total_value', 16, 2).alter();
            table.decimal('total_descount_value', 16, 2).alter();
        });
    }
}
//# sourceMappingURL=1742561342617_create_alter_default_valor_taxa_deliveries_table.js.map