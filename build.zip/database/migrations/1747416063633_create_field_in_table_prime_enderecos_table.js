import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_endereco';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table
                .integer('id_taxa_de_entrega')
                .unsigned()
                .nullable()
                .references('id')
                .inTable('prime_taxa_de_entrega');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_taxa_de_entrega');
        });
    }
}
//# sourceMappingURL=1747416063633_create_field_in_table_prime_enderecos_table.js.map