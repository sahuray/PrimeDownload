import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime').alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('id_prime', 254).alter();
        });
    }
}
//# sourceMappingURL=1736516614905_create_alter_id_prime_in_table_funcionario_usuarios_table.js.map