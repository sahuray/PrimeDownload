import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_cliente_bloqueado';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.integer('id_prime');
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1745844827873_create_create_table_prime_cliente_bloqueados_table.js.map