import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_mesa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('grupo_mesas').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('grupo_mesas');
        });
    }
}
//# sourceMappingURL=1741887696754_create_alter_table_prime_mesa_add_grupo_mesas_table.js.map