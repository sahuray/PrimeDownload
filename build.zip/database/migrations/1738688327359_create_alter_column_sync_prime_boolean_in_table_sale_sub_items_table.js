import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_sub_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('sync_prime').defaultTo(false).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('sync_prime').alter();
        });
    }
}
//# sourceMappingURL=1738688327359_create_alter_column_sync_prime_boolean_in_table_sale_sub_items_table.js.map