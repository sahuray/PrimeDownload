import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_prathos_config';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_empresa').unsigned().notNullable().references('id').inTable('prime_empresa');
            table.boolean('utiliza_prathos').notNullable().defaultTo(false);
            table.boolean('utiliza_replique').notNullable().defaultTo(false);
            table.boolean('utiliza_taxa_de_servico').notNullable().defaultTo(false);
            table.boolean('utiliza_couvert').notNullable().defaultTo(false);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1738244631624_create_create_prime_empresa_prathos_configs_table.js.map