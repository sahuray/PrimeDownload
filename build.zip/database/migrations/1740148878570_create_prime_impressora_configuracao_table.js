import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_impressora_configuracao';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.text('nome_configuracao');
            table.text('nome_computador');
            table.text('impressora_padrao');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1740148878570_create_prime_impressora_configuracao_table.js.map