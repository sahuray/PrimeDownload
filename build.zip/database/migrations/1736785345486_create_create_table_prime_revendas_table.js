import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_revenda';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_conta_bancaria').unsigned().references('id').inTable('prime_conta_bancaria');
            table.boolean('sync_prime');
            table.text('nome');
            table.text('razao_social');
            table.text('ie');
            table.boolean('ie_isento').defaultTo(false);
            table.boolean('ie_aguardando').defaultTo(false);
            table.text('im');
            table.boolean('im_isento').defaultTo(false);
            table.boolean('im_aguardando').defaultTo(false);
            table.text('cnpj');
            table.boolean('cnpj_aguardando').defaultTo(false);
            table.text('telefone');
            table.text('site');
            table.text('contato_nome');
            table.text('contato_telefone');
            table.text('contato_email');
            table.text('contato_rg');
            table.text('contato_profissao');
            table.integer('estado_civil');
            table.text('cnae');
            table.text('atividade_principal');
            table.timestamp('constituicao_firma').defaultTo(null);
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at').defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736785345486_create_create_table_prime_revendas_table.js.map