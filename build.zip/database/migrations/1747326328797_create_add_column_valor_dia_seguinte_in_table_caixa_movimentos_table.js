import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_movimento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('valor_proximo_turno', 16, 2).defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('valor_proximo_turno');
        });
    }
}
//# sourceMappingURL=1747326328797_create_add_column_valor_dia_seguinte_in_table_caixa_movimentos_table.js.map