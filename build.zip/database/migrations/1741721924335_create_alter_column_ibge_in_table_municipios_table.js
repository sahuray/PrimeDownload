import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_municipio';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('ibge').nullable().alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('ibge').notNullable().alter();
        });
    }
}
//# sourceMappingURL=1741721924335_create_alter_column_ibge_in_table_municipios_table.js.map