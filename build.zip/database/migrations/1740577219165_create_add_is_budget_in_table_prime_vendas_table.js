import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('type');
            table.dropColumn('tipo');
            table.boolean('e_orcamento').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('type');
            table.text('tipo');
            table.dropColumn('e_orcamento');
        });
    }
}
//# sourceMappingURL=1740577219165_create_add_is_budget_in_table_prime_vendas_table.js.map