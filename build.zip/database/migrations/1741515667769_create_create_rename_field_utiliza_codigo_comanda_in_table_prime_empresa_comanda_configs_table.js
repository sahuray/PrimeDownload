import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_comanda_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.renameColumn('utiliza_codigo_comanda', 'utiliza_chip_comanda');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.renameColumn('utiliza_chip_comanda', 'utiliza_codigo_comanda');
        });
    }
}
//# sourceMappingURL=1741515667769_create_create_rename_field_utiliza_codigo_comanda_in_table_prime_empresa_comanda_configs_table.js.map