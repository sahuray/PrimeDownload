import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.raw('DROP VIEW IF EXISTS vw_funcionario_usuario');
        this.schema.alterTable(this.tableName, (table) => {
            table.string('senha', 254).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('senha', 50).alter();
        });
    }
}
//# sourceMappingURL=1736253465134_create_alter_password_users_table.js.map