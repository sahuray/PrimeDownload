import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_close_comandas';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_comanda').unsigned().notNullable();
            table.integer('id_empresa').unsigned().notNullable();
            table.integer('id_usuario').unsigned().nullable();
            table.integer('id_venda').unsigned().nullable();
            table.string('numero_comanda', 50).nullable();
            table.decimal('valor_total', 10, 2).defaultTo(0);
            table.decimal('valor_taxa_servico', 10, 2).defaultTo(0);
            table.decimal('valor_couvert', 10, 2).defaultTo(0);
            table.timestamp('created_at', { useTz: true }).notNullable();
            table.timestamp('updated_at', { useTz: true }).notNullable();
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1742664527276_create_create_create_table_close_comandas_table.js.map