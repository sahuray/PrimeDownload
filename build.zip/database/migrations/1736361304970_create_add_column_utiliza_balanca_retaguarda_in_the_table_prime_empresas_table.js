import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('utiliza_balanca_retaguarda').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('utiliza_balanca_retaguarda');
        });
    }
}
//# sourceMappingURL=1736361304970_create_add_column_utiliza_balanca_retaguarda_in_the_table_prime_empresas_table.js.map