import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('senha_delivery').nullable();
            table.time('hora_pedido').nullable();
            table.decimal('valor_produtos', 16, 2).nullable();
            table.decimal('valor_taxa_delivery', 16, 2).nullable();
            table.decimal('valor_troco', 16, 2).nullable();
            table.decimal('prestar_conta', 16, 2).nullable();
            table.boolean('retirada').defaultTo(false);
            table.integer('id_motoboy').unsigned().references('id').inTable('prime_motoboy');
            table
                .integer('id_taxa_de_entrega')
                .unsigned()
                .references('id')
                .inTable('prime_taxa_de_entrega');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('senha_delivery');
            table.dropColumn('hora_pedido');
            table.dropColumn('valor_produtos');
            table.dropColumn('valor_taxa_delivery');
            table.dropColumn('valor_troco');
            table.dropColumn('prestar_conta');
            table.dropColumn('retirada');
            table.dropColumn('id_motoboy');
            table.dropColumn('id_taxa_de_entrega');
        });
    }
}
//# sourceMappingURL=1739189388340_create_fields_in_prime_vendas_table.js.map