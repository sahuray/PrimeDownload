import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_comanda_config';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_empresa').unsigned().notNullable().references('id').inTable('prime_empresa');
            table.boolean('utiliza_comanda').notNullable().defaultTo(false);
            table.boolean('pedir_mesa_lancamento_comanda').notNullable().defaultTo(false);
            table.boolean('imprimir_item_composicao').notNullable().defaultTo(false);
            table.boolean('utiliza_observacao_comanda').notNullable().defaultTo(false);
            table.boolean('utiliza_couvert').notNullable().defaultTo(false);
            table.boolean('utiliza_taxa_de_servico').notNullable().defaultTo(false);
            table
                .boolean('ativar_busca_comandas_campo_lancamento_produtos_pdv')
                .notNullable()
                .defaultTo(false);
            table.text('codigo_taxa_servico').nullable();
            table.text('digito_controle_comanda').nullable();
            table.decimal('percentual_taxa_servico', 16, 2).nullable();
            table.decimal('quantidade_caracteres_comanda', 16, 2).nullable();
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).nullable();
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1738243993484_create_create_prime_empresa_comanda_configs_table.js.map