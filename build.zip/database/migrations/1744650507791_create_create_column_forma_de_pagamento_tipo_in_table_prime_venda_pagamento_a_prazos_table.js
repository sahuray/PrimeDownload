import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_pagamento_a_prazo';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table
                .integer('id_forma_de_pagamento_tipo')
                .unsigned()
                .references('id')
                .inTable('prime_forma_de_pagamento_tipo');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_forma_de_pagamento_tipo');
        });
    }
}
//# sourceMappingURL=1744650507791_create_create_column_forma_de_pagamento_tipo_in_table_prime_venda_pagamento_a_prazos_table.js.map