import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_saida';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('tipo').defaultTo(null).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('tipo').defaultTo(false).alter();
        });
    }
}
//# sourceMappingURL=1744726277520_create_create_column_type_in_table_caixa_saidas_table.js.map