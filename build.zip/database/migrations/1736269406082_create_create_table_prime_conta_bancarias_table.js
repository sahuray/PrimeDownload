import { BaseSchema } from '@adonisjs/lucid/schema';
export default class ContasBancarias extends BaseSchema {
    tableName = 'prime_conta_bancaria';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('updated_by').references('idfuncionariousuario').inTable('funcionario_usuario');
            table.integer('id_grupo').references('id').inTable('prime_grupo');
            table.integer('id_banco').references('id').inTable('prime_banco');
            table.integer('id_empresa').references('id').inTable('prime_empresa');
            table.string('agencia', 20);
            table.string('conta_corrente', 50);
            table.integer('tipo_pessoa');
            table.string('titular_conta', 255);
            table.string('socio_titular_conta', 255);
            table.string('gerente_conta', 255);
            table.string('telefone_gerente', 50);
            table.string('email_gerente', 255);
            table.string('operadora', 50);
            table.boolean('status').defaultTo(true);
            table.boolean('boleto_registrado_status').defaultTo(false);
            table.boolean('utiliza_desconto_pontualidade').defaultTo(false);
            table.boolean('padrao_para_todas_as_vendas').defaultTo(false);
            table.string('boleto_carteira_registrado', 50);
            table.string('especie_padrao', 50);
            table.string('boleto_carteira_registrado_codigo', 50);
            table.string('boleto_nosso_numero_automatico', 50);
            table.string('boleto_nosso_numero', 50);
            table.string('boleto_dias_devolucao', 50);
            table.string('boleto_carteira_variacao', 50);
            table.text('boleto_instrucao');
            table.text('boleto_instrucao_remessa1');
            table.text('boleto_instrucao_remessa2');
            table.text('boleto_instrucao_remessa3');
            table.string('boleto_dias_carencia', 50);
            table.string('boleto_dias_negativacao', 50);
            table.string('boleto_tipo_cobranca', 50);
            table.string('boleto_layout', 50);
            table.string('boleto_especie_padrao', 50);
            table.boolean('boleto_aceite_padrao').defaultTo(false);
            table.string('boleto_codigo_cedente', 50);
            table.string('boleto_porcentagem_mora', 50);
            table.string('boleto_porcentagem_multa', 50);
            table.string('dias_carencia', 50);
            table.string('boleto_convenio', 50);
            table.string('boleto_tipo_numero_documento', 50);
            table.string('boleto_layoutremessa', 50);
            table.string('boleto_codigo_transmissao', 50);
            table.string('boleto_tipo_nome_pagador', 50);
            table.string('boleto_tipo_cliente_arquivo_remessa', 50);
            table.integer('agencia_digito');
            table.integer('conta_digito');
            table.boolean('permite_boleto').defaultTo(false);
            table.text('instruction_six');
            table.text('instruction_seven');
            table.text('instruction_eight');
            table.text('local_pagamento');
            table.boolean('sync_prime').defaultTo(false);
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736269406082_create_create_table_prime_conta_bancarias_table.js.map