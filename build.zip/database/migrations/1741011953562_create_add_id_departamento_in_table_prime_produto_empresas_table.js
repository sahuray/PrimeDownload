import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_empresa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_departamento').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_departamento');
        });
    }
}
//# sourceMappingURL=1741011953562_create_add_id_departamento_in_table_prime_produto_empresas_table.js.map