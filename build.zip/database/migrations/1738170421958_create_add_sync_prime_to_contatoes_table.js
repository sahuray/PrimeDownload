import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_contato';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('sync_prime').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('sync_prime');
        });
    }
}
//# sourceMappingURL=1738170421958_create_add_sync_prime_to_contatoes_table.js.map