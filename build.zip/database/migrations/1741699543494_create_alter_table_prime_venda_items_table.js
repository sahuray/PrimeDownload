import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('saled_quantity', 10, 4).nullable().alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('saled_quantity').nullable().alter();
        });
    }
}
//# sourceMappingURL=1741699543494_create_alter_table_prime_venda_items_table.js.map