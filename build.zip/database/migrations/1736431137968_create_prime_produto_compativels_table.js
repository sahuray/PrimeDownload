import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_compativel';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table.integer('id_produto').unsigned().references('id').inTable('prime_produto');
            table.integer('id_produto_compativel').unsigned().references('id').inTable('prime_produto');
            table.timestamp('deleted_at').defaultTo(null);
            table.timestamp('created_at');
            table.timestamp('updated_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736431137968_create_prime_produto_compativels_table.js.map