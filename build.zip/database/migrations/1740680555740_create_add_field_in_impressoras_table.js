import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_impressora';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('impressora_padrao').defaultTo(false);
            table.text('apelido').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('impressora_padrao');
            table.dropColumn('apelido');
        });
    }
}
//# sourceMappingURL=1740680555740_create_add_field_in_impressoras_table.js.map