import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_numero_de_serie';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id').primary();
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.integer('id_produto').unsigned().references('id').inTable('prime_produto');
            table.string('serial_number');
            table.string('doc_origin');
            table.string('doc_destination');
            table.decimal('stock_quantity', 16, 4);
            table.timestamp('expired_at').defaultTo(null);
            table.timestamp('deleted_at').defaultTo(null);
            table.timestamp('created_at');
            table.timestamp('updated_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736431355964_create_prime_produto_numero_de_series_table.js.map