import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_fechamento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_funcionario');
            table
                .integer('id_usuario')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_funcionario');
            table.dropColumn('id_usuario');
        });
    }
}
//# sourceMappingURL=1741702433795_create_alter_column_id_funcionarios_table.js.map