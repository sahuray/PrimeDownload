import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableNameTerminal = 'terminal';
    tableNameImpressoraConfiguracao = 'prime_impressora_configuracao';
    tableNameEmpresa = 'prime_empresa_pdv_config';
    async up() {
        this.schema.alterTable(this.tableNameTerminal, (table) => {
            table.boolean('terminal_principal').defaultTo(false);
        });
        this.schema.alterTable(this.tableNameImpressoraConfiguracao, (table) => {
            table.integer('id_terminal').references('idterminal').inTable(this.tableNameTerminal);
            table.text('nome_terminal');
        });
        this.schema.alterTable(this.tableNameEmpresa, (table) => {
            table.text('ip_server_core');
        });
    }
    async down() {
        this.schema.alterTable(this.tableNameTerminal, (table) => {
            table.dropColumn('terminal_principal');
        });
        this.schema.alterTable(this.tableNameImpressoraConfiguracao, (table) => {
            table.dropColumn('id_terminal');
            table.dropColumn('nome_terminal');
        });
        this.schema.alterTable(this.tableNameEmpresa, (table) => {
            table.dropColumn('ip_server_core');
        });
    }
}
//# sourceMappingURL=1742921204125_create_add_field_in_terminals_table.js.map