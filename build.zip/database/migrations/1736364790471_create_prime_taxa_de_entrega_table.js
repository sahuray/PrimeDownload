import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_taxa_de_entrega';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.decimal('valor', 16, 2);
            table.text('descricao');
            table.text('tempo_previsao');
            table.integer('grupo_id').references('id').inTable('prime_grupo');
            table.integer('user_created_id');
            table.integer('user_updated_id');
            table.text('user_created_name');
            table.text('user_updated_name');
            table.integer('codigo');
            table.integer('empresa_id').references('id').inTable('prime_empresa');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736364790471_create_prime_taxa_de_entrega_table.js.map