import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_pagamento_a_prazo';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('count').defaultTo('01/01');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('count');
        });
    }
}
//# sourceMappingURL=1744139650379_create_create_column_count_in_table_prime_venda_pagamento_a_prazos_table.js.map