import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('desconto_rateio_venda', 16, 4).defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('desconto_rateio_venda');
        });
    }
}
//# sourceMappingURL=1746465423948_create_add_column_desconto_rateio_venda_in_table_prime_venda_items_table.js.map