import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_imagem';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.text('nome_do_arquivo');
            table.text('caminho_do_arquivo');
            table.text('tipo');
            table.text('ordem_de_execucao');
            table.text('tamanho_do_arquivo');
            table.text('extensao_do_arquivo');
            table.text('descricao');
            table.text('base64');
            table.text('duracao_exibicao_minutos');
            table.integer('id_usuario').references('idfuncionariousuario').inTable('funcionario_usuario');
            table.integer('id_terminal').nullable().references('idterminal').inTable('terminal');
            table.boolean('status').defaultTo(true);
            table.timestamp('created_at');
            table.timestamp('updated_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1744027909171_create_prime_imagem_table.js.map