import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_motoboy';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('sync_prime').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('sync_prime');
        });
    }
}
//# sourceMappingURL=1744288078826_create_add_column_sync_prime_in_table_prime_motoboys_table.js.map