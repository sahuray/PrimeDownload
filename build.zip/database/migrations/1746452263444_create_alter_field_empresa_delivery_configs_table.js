import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_delivery_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('status_loja_ifood').nullable().alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('status_loja_ifood').defaultTo(false).alter();
        });
    }
}
//# sourceMappingURL=1746452263444_create_alter_field_empresa_delivery_configs_table.js.map