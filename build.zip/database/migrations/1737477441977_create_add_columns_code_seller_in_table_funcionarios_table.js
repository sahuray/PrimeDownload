import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('code_seller');
            table.boolean('funcionario_venda_permission').defaultTo(false);
            table.boolean('seller').defaultTo(false);
            table.timestamp('deleted_at').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('code_seller');
            table.dropColumn('funcionario_venda_permission');
            table.dropColumn('seller');
            table.dropColumn('deleted_at');
        });
    }
}
//# sourceMappingURL=1737477441977_create_add_columns_code_seller_in_table_funcionarios_table.js.map