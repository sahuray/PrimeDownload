import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.raw(`ALTER TABLE ${this.tableName} ALTER COLUMN code SET DATA TYPE INTEGER USING code::INTEGER`);
    }
    async down() {
        this.schema.raw(`ALTER TABLE ${this.tableName} ALTER COLUMN code SET DATA TYPE DECIMAL(8,2) USING code::DECIMAL(8,2)`);
    }
}
//# sourceMappingURL=1738670216211_create_alter_column_code_in_table_prime_vendas_table.js.map