import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_controle_estoque';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.string('tipo', 10);
            table.integer('id_estoque').unsigned().references('id').inTable('prime_produto_estoque');
            table.integer('id_estoque_prime').notNullable();
            table.decimal('quantidade', 16, 4).notNullable();
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1740242066095_create_create_table_venda_controle_estoques_table.js.map