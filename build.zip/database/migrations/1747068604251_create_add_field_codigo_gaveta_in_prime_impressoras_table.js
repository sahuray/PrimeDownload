import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_impressora';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('codigo_gaveta').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('codigo_gaveta');
        });
    }
}
//# sourceMappingURL=1747068604251_create_add_field_codigo_gaveta_in_prime_impressoras_table.js.map