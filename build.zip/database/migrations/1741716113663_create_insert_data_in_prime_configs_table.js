import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_config';
    async up() {
        try {
            const configAtual = await this.db.from('prime_config').first();
            const versaoAtual = configAtual ? Number(configAtual.versao_banco) : 0;
            const novaVersao = versaoAtual + 1;
            if (configAtual) {
                await this.db.from('prime_config').update({
                    versao_banco: String(novaVersao),
                    updated_at: new Date(),
                });
            }
            else {
                await this.db.table('prime_config').insert({
                    prime: true,
                    versao_banco: '1',
                    created_at: new Date(),
                    updated_at: new Date(),
                });
            }
            console.log(`Versão do banco atualizada para: ${novaVersao}`);
        }
        catch (error) {
            console.error('Erro ao atualizar versão do banco:', error);
        }
    }
    async down() {
        try {
            await this.db.from('prime_config').delete();
            console.log('Todos os registros da tabela prime_config foram removidos');
        }
        catch (error) {
            console.error('Erro ao remover registros da tabela prime_config:', error);
        }
    }
}
//# sourceMappingURL=1741716113663_create_insert_data_in_prime_configs_table.js.map