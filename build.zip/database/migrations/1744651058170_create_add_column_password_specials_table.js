import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('password_special');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('password_special');
        });
    }
}
//# sourceMappingURL=1744651058170_create_add_column_password_specials_table.js.map