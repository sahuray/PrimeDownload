import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_upload';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table
                .integer('id_funcionario_usuario')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.string('url');
            table.string('type');
            table.string('id_fk');
            table.string('description');
            table.string('name');
            table.timestamp('expiration_date');
            table.timestamp('created_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736425613014_create_prime_uploads_table.js.map