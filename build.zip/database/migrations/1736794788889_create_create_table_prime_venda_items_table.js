import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_produto').unsigned().references('id').inTable('prime_produto');
            table.integer('id_venda').unsigned().references('id').inTable('prime_venda');
            table.boolean('sync_prime').defaultTo(false);
            table.text('status');
            table.text('product_description');
            table.decimal('comissao_porcentagem', 16, 2);
            table.decimal('saled_quantity', 16, 2);
            table.decimal('unitary_value', 16, 2);
            table.decimal('total_value', 16, 2);
            table.decimal('total_descount_value', 16, 2);
            table.integer('codigo');
            table.text('ncm');
            table.text('cfop');
            table.text('csosn');
            table.text('aliquot_icms');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736794788889_create_create_table_prime_venda_items_table.js.map