import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_imagem';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('dimensoes');
            table.text('duracao_exibicao_segundos').defaultTo(0);
            table.text('id_prime');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.boolean('fixo').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('dimensoes');
            table.dropColumn('duracao_exibicao_segundos');
            table.dropColumn('id_prime');
            table.dropColumn('id_empresa');
            table.dropColumn('fixo');
        });
    }
}
//# sourceMappingURL=1746625673772_create_prime_imagems_table.js.map