import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('created_at');
            table.timestamp('updated_at');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('created_at');
            table.dropColumn('updated_at');
        });
    }
}
//# sourceMappingURL=1737470610522_create_add_columns_data_alteracao_criacao_in_table_funcionarios_table.js.map