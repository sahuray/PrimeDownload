import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'terminal';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('idterminal');
            table.integer('terminaldestino');
            table.integer('colunasimpressorabalcao');
            table.integer('colunasimpressoraecf');
            table.boolean('caixa');
            table.boolean('utilizacontroledeentrega');
            table.boolean('imprimircontroledeentrega');
            table.boolean('travarsistemacomgavetaaberta');
            table.boolean('desativarconsultadeprodutopdv');
            table.boolean('emitirnotapromissoriavendaprazo');
            table.boolean('emitircarnedecobrancavendaparce');
            table.boolean('balcaogeraorcamento');
            table.boolean('balcaogeravenda');
            table.boolean('balcaofazrecebimento');
            table.boolean('exigirsenhavendedorbalcao');
            table.boolean('tipopapel');
            table.boolean('tamanhopapel');
            table.boolean('concomitante');
            table.boolean('controlagaveta');
            table.boolean('fecharorcamentorapido');
            table.text('nome');
            table.text('descricaoterminal');
            table.text('nomeimgpdv');
            table.text('impressorapdvbalcao');
            table.text('modeloimpressoraecf');
            table.text('velocidadeporta');
            table.text('portaimpressao');
            table.text('mensagemrodapeecf');
            table.text('portaimpcodbarra');
            table.text('linguagemimpcodbarra');
            table.text('veleocidadeportacodbarra');
            table.text('modeloimpnaofiscal');
            table.text('modelobalanca');
            table.text('portabalanca');
            table.text('baundratebalanca');
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1735925545251_create_create_table_terminal_table.js.map