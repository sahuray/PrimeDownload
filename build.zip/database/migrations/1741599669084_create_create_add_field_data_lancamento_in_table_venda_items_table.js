import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_comanda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('data_lancamento', { useTz: false }).nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('data_lancamento');
        });
    }
}
//# sourceMappingURL=1741599669084_create_create_add_field_data_lancamento_in_table_venda_items_table.js.map