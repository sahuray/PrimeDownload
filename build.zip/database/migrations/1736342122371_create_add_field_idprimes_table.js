import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario_usuario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('id_prime', 254);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
        });
    }
}
//# sourceMappingURL=1736342122371_create_add_field_idprimes_table.js.map