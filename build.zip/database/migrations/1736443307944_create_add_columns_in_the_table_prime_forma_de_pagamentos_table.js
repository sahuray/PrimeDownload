import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_forma_de_pagamento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('quantidade', 16, 2);
            table.decimal('prazo', 16, 2);
            table.string('tarifa');
            table.string('description');
            table.string('code');
            table.boolean('inativo').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('quantidade');
            table.dropColumn('prazo');
            table.dropColumn('tarifa');
            table.dropColumn('description');
            table.dropColumn('code');
            table.dropColumn('inativo');
        });
    }
}
//# sourceMappingURL=1736443307944_create_add_columns_in_the_table_prime_forma_de_pagamentos_table.js.map