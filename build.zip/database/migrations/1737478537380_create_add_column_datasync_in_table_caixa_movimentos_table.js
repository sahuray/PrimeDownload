import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_movimento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('datasync');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('datasync');
        });
    }
}
//# sourceMappingURL=1737478537380_create_add_column_datasync_in_table_caixa_movimentos_table.js.map