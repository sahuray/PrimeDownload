import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_permissao_usuario';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.integer('id_permissao').unsigned().references('id').inTable('prime_permissao');
            table
                .integer('id_usuario')
                .unsigned()
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.integer('id_grupo').unsigned().references('id').inTable('prime_grupo');
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1739208702999_create_create_table_prime_permissao_usuarios_table.js.map