import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_cliente';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
        });
    }
}
//# sourceMappingURL=1738691654162_create_add_column_id_prime_in_table_venda_clientes_table.js.map