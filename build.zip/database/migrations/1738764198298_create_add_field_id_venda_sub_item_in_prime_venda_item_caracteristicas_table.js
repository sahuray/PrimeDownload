import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item_caracteristica';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table
                .integer('id_venda_sub_item')
                .nullable()
                .unsigned()
                .references('id')
                .inTable('prime_venda_sub_item');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_venda_sub_item');
        });
    }
}
//# sourceMappingURL=1738764198298_create_add_field_id_venda_sub_item_in_prime_venda_item_caracteristicas_table.js.map