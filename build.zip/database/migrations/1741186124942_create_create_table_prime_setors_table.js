import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_setor';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime').defaultTo(null);
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.text('nome_setor');
            table.text('observacao_setor');
            table.boolean('status').defaultTo(true);
            table.boolean('favorite').defaultTo(false);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1741186124942_create_create_table_prime_setors_table.js.map