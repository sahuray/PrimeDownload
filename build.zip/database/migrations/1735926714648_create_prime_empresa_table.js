import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa';
    async up() {
        await this.db.rawQuery(`DROP TYPE IF EXISTS "TipoEmpresa", "OrigemEmpresa", "Sexo", "prazoTipo";`);
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime_empresa');
            table.boolean('sync_prime').notNullable().defaultTo(false);
            table.integer('id_focus');
            table.text('focus_token_producao');
            table.text('focus_token_homologacao');
            table.text('url_logo');
            table.integer('regime_tributario');
            table.text('regime_especial_tributacao');
            table.integer('grupo_id').references('id').inTable('prime_grupo');
            table
                .integer('funcionario_usuario_id_responsavel_cadastro')
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table
                .integer('funcionario_usuario_id_responsavel_ultima_alteracao')
                .references('idfuncionariousuario')
                .inTable('funcionario_usuario');
            table.text('situacao_cadastral');
            table.enu('tipo', ['J', 'F'], {
                useNative: true,
                enumName: 'TipoEmpresa',
                existingType: false,
            });
            table.enu('origem', ['C', 'F'], {
                useNative: true,
                enumName: 'OrigemEmpresa',
                existingType: false,
            });
            table.enu('sexo', ['M', 'F'], {
                useNative: true,
                enumName: 'Sexo',
                existingType: false,
            });
            table.enu('prazo_tipo', ['padrao', 'data_base', 'dias_prazo'], {
                useNative: true,
                enumName: 'prazoTipo',
                existingType: false,
            });
            table.text('descricao_servico');
            table.boolean('ativo').notNullable().defaultTo(true);
            table.text('nome_fantasia').notNullable();
            table.text('razao_social').nullable();
            table.text('apelido').nullable();
            table.boolean('emissao_nfse_nothos_prime_completo').notNullable().defaultTo(false);
            table.boolean('emissao_nfce_nothos_prime_completo').notNullable().defaultTo(false);
            table.boolean('emissao_nfe_nothos_prime_completo').notNullable().defaultTo(false);
            table.boolean('cnpj_aguardando').notNullable().defaultTo(false);
            table.boolean('ie_isento').notNullable().defaultTo(false);
            table.boolean('ie_aguardando').notNullable().defaultTo(false);
            table.boolean('im_isento').notNullable().defaultTo(false);
            table.boolean('im_aguardando').notNullable().defaultTo(false);
            table.boolean('prazo_bloqueado').notNullable().defaultTo(false);
            table.text('cnpj_cpf').nullable();
            table.text('ie_rg').nullable();
            table.text('im').nullable();
            table.text('suframa').nullable();
            table.text('email').nullable();
            table.text('telefone').nullable();
            table.text('representante_nome').nullable();
            table.text('representante_tipo').nullable();
            table.text('representante_cpf').nullable();
            table.text('representante_rg').nullable();
            table.text('representante_celular').nullable();
            table.text('representante_email').nullable();
            table.text('representante_data_nascimento').nullable();
            table.boolean('cartao_preferencial_utiliza').notNullable().defaultTo(false);
            table.text('cartao_preferencial_numero').nullable();
            table.text('cartao_preferencial_saldo').nullable();
            table.integer('prazo_dias').nullable();
            table.integer('prazo_limite').nullable();
            table.text('codigo').nullable();
            table.boolean('cliente_athos').notNullable().defaultTo(false);
            table.integer('quantity_decimal_places').nullable();
            table.integer('price_decimal_places').nullable();
            table.text('rounding_type').nullable();
            table.text('user_repos_id').nullable();
            table.boolean('permitir_item_duplicado').notNullable().defaultTo(false);
            table.boolean('permitir_ajustar_quantidade').notNullable().defaultTo(false);
            table.boolean('associar_cliente_orcamento').notNullable().defaultTo(false);
            table.boolean('pedir_observacao_venda').notNullable().defaultTo(false);
            table.boolean('pedir_observacao_orcamento').notNullable().defaultTo(false);
            table.boolean('estoque_zerado_orcamento').notNullable().defaultTo(false);
            table.boolean('associar_transportadora').notNullable().defaultTo(false);
            table.boolean('exibir_observacao_cliente').notNullable().defaultTo(false);
            table.boolean('utilizar_data_entrega').notNullable().defaultTo(false);
            table.integer('periodo_orcamento').nullable();
            table.boolean('controle_estoque_reservado').notNullable().defaultTo(false);
            table.integer('vencimento_orcamento').nullable().defaultTo(0);
            table.integer('quantidade_dia_orcamento').nullable().defaultTo(0);
            table.timestamp('data_vencimento_orcamento', { useTz: true });
            table.integer('desconto_maximo').nullable().defaultTo(0);
            table.boolean('associar_cliente_venda_inicio').notNullable().defaultTo(false);
            table.boolean('associar_cliente_venda_final').notNullable().defaultTo(false);
            table.boolean('aceitar_cpf_invalido').notNullable().defaultTo(false);
            table.boolean('pedir_codigo_vendedor').notNullable().defaultTo(false);
            table.integer('limite_items_venda').nullable().defaultTo(0);
            table.integer('ponto_sangria').nullable().defaultTo(0);
            table.boolean('focar_preco_unitario').notNullable().defaultTo(false);
            table.boolean('permitir_escolha_preco_venda').notNullable().defaultTo(false);
            table.boolean('informar_diferenca_entre_valores').notNullable().defaultTo(false);
            table.boolean('utilizar_balanca_retaguarda').notNullable().defaultTo(false);
            table.integer('quantidade_digitos').nullable().defaultTo(0);
            table.integer('tipo_codigo_barras').nullable().defaultTo(0);
            table.text('observacao_venda').nullable();
            table.text('observacao_orcamento').nullable();
            table.text('site');
            table.boolean('carga_portal').notNullable().defaultTo(false);
            table.boolean('permission_show_vehicular_plate').notNullable().defaultTo(false);
            table.timestamp('created_at', { useTz: true });
            table.timestamp('updated_at', { useTz: true });
            table.timestamp('deleted_at', { useTz: true });
            table.timestamp('aniversario', { useTz: true });
        });
    }
    async down() {
        await this.db.rawQuery(`DROP table prime_empresa;`);
        await this.db.rawQuery(`DROP TYPE IF EXISTS "TipoEmpresa", "OrigemEmpresa", "Sexo", "prazoTipo";`);
    }
}
//# sourceMappingURL=1735926714648_create_prime_empresa_table.js.map