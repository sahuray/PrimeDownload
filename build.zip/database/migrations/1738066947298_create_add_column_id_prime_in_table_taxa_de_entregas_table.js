import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_taxa_de_entrega';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime').defaultTo(null);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
        });
    }
}
//# sourceMappingURL=1738066947298_create_add_column_id_prime_in_table_taxa_de_entregas_table.js.map