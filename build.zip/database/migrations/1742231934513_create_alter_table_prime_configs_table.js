import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('prime').nullable().alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('prime').notNullable().alter();
        });
    }
}
//# sourceMappingURL=1742231934513_create_alter_table_prime_configs_table.js.map