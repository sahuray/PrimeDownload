import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('cobrar_taxa_de_entrega').defaultTo(true);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('cobrar_taxa_de_entrega');
        });
    }
}
//# sourceMappingURL=1747752328424_create_field_in_table_prime_vendas_table.js.map