import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.string('cobrar_taxa_servico').defaultTo(false);
            table.string('cobrar_taxa_covert').defaultTo(false);
            table.string('quantidade_pessoas_covert').defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('cobrar_taxa_servico');
            table.dropColumn('cobrar_taxa_covert');
            table.dropColumn('quantidade_pessoas_covert');
        });
    }
}
//# sourceMappingURL=1744225664854_create_alter_table_prime_vendas_table.js.map