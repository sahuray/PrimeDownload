import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_conta_bancaria';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('tipo_pessoa').alter();
            table.renameColumn('boleto_instrucao_remessa1', 'boleto_instrucao_remessa_1');
            table.renameColumn('boleto_instrucao_remessa2', 'boleto_instrucao_remessa_2');
            table.renameColumn('boleto_instrucao_remessa3', 'boleto_instrucao_remessa_3');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, () => {
        });
    }
}
//# sourceMappingURL=1736514635518_create_alter_tipo_pessoa_in_table_prime_conta_bancarias_table.js.map