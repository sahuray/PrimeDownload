import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'funcionario';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime').defaultTo(null);
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.integer('id_revenda').unsigned().references('id').inTable('prime_revenda');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
            table.dropColumn('id_revenda');
            table.dropColumn('id_empresa');
        });
    }
}
//# sourceMappingURL=1737477441976_create_add_columns_in_table_funcionarios_table.js.map