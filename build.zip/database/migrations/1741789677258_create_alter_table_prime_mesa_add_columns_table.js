import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_mesa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.timestamp('hora_abertura', { useTz: false }).nullable();
            table.timestamp('hora_ultimo_atendimento', { useTz: false }).nullable();
            table.timestamp('hora_fechamento', { useTz: false }).nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('hora_abertura');
            table.dropColumn('hora_ultimo_atendimento');
            table.dropColumn('hora_fechamento');
        });
    }
}
//# sourceMappingURL=1741789677258_create_alter_table_prime_mesa_add_columns_table.js.map