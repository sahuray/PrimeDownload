import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_pdv_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('lancar_mesa_fechamento').defaultTo(false);
            table.boolean('divisao_maior_valor').defaultTo(false);
            table.decimal('arredondamento_padrao_valor', 10, 4).defaultTo(0);
            table.boolean('utiliza_taxa').defaultTo(false);
            table.boolean('utiliza_couvert').defaultTo(false);
            table.integer('id_servico_taxa').nullable().references('id').inTable('prime_produto');
            table.text('nome_produto_taxa').nullable();
            table.text('codigo_produto_taxa').nullable();
            table.integer('id_servico_couvert').nullable().references('id').inTable('prime_produto');
            table.text('nome_produto_couvert').nullable();
            table.text('codigo_produto_couvert').nullable();
            table.decimal('valor_taxa', 10, 4).defaultTo(0);
            table.decimal('valor_couvert', 10, 4).defaultTo(0);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('lancar_mesa_fechamento');
            table.dropColumn('divisao_maior_valor');
            table.dropColumn('arredondamento_padrao_valor');
            table.dropColumn('utiliza_taxa');
            table.dropColumn('utiliza_couvert');
            table.dropColumn('id_servico_taxa');
            table.dropColumn('nome_produto_taxa');
            table.dropColumn('codigo_produto_taxa');
            table.dropColumn('id_servico_couvert');
            table.dropColumn('nome_produto_couvert');
            table.dropColumn('codigo_produto_couvert');
            table.dropColumn('valor_taxa');
            table.dropColumn('valor_couvert');
        });
    }
}
//# sourceMappingURL=1741006616925_create_add_fields_in_prime_empresa_pdv_configs_table.js.map