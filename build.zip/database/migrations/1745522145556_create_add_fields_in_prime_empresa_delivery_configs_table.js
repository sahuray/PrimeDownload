import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa_delivery_config';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('id_client_ifood').nullable();
            table.text('client_secret_ifood').nullable();
            table.text('url_aprovacao_ifood').nullable();
            table.text('codigo_autorizacao_ifood').nullable();
            table.text('id_athos_prime_ifood').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_client_ifood');
            table.dropColumn('client_secret_ifood');
            table.dropColumn('url_aprovacao_ifood');
            table.dropColumn('codigo_autorizacao_ifood');
            table.dropColumn('id_athos_prime_ifood');
        });
    }
}
//# sourceMappingURL=1745522145556_create_add_fields_in_prime_empresa_delivery_configs_table.js.map