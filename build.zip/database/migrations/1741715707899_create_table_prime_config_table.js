import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_config';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.boolean('prime').defaultTo(false);
            table.string('versao_banco', 20).defaultTo('1');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1741715707899_create_table_prime_config_table.js.map