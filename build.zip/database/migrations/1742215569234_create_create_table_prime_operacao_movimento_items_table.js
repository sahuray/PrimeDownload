import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_operacao_movimento_item';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table
                .integer('id_operacao_movimento')
                .unsigned()
                .references('id')
                .inTable('prime_operacao_movimento');
            table.integer('id_produto').unsigned().references('id').inTable('prime_produto');
            table.decimal('quantidade', 16, 2);
            table.decimal('desconto_produto', 16, 2);
            table.decimal('valor_produto', 16, 2);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1742215569234_create_create_table_prime_operacao_movimento_items_table.js.map