import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_endereco';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.text('tipo_relacionamento');
            table.integer('id_fk');
            table.text('tipo').nullable();
            table.text('cep').nullable();
            table.text('uf').nullable();
            table.text('cidade').nullable();
            table.text('bairro').nullable();
            table.text('logradouro').nullable();
            table.text('numero').nullable();
            table.text('complemento').nullable();
            table.string('codigo_cidade');
            table.string('codigo_uf');
            table.text('referencia').nullable();
            table.timestamp('created_at', { useTz: true });
            table.timestamp('updated_at', { useTz: true });
            table.timestamp('deleted_at', { useTz: true });
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736177654607_create_prime_enderecos_table.js.map