import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_municipio';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id').primary();
            table.integer('id_prime');
            table.string('cidade').notNullable();
            table.string('uf', 2).notNullable();
            table.string('ibge').notNullable().unique();
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at').defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1739300205654_create_create_table_prime_municipios_table.js.map