import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_informacao_nutricional';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id').primary();
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table.integer('id_grupo').unsigned().references('id').inTable('prime_grupo');
            table.string('description');
            table.decimal('portion', 12, 2);
            table.decimal('liquid_weight', 12, 2);
            table.string('origin');
            table.decimal('calories_grams', 12, 2);
            table.decimal('calories_vd', 12, 2);
            table.decimal('carbohydrates_grams', 12, 2);
            table.decimal('carbohydrates_vd', 12, 2);
            table.decimal('proteins_grams', 12, 2);
            table.decimal('proteins_vd', 12, 2);
            table.decimal('fats_grams', 12, 2);
            table.decimal('fats_vd', 12, 2);
            table.decimal('fats_totals', 12, 2);
            table.decimal('fats_totals_vd', 12, 2);
            table.decimal('fats_saturated_grams', 12, 2);
            table.decimal('fats_saturated_vd', 12, 2);
            table.decimal('fats_trans_grams', 12, 2);
            table.decimal('fats_trans_vd', 12, 2);
            table.decimal('dietary_fiber_grams', 12, 2);
            table.decimal('dietary_fiber_vd', 12, 2);
            table.decimal('sodium_miligrams', 12, 2);
            table.decimal('sodium_vd', 12, 2);
            table.string('complementary_attributes');
            table.string('ingredients');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at').defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736427275173_create_prime_produto_informacao_nutricionals_table.js.map