import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.boolean('taxa_de_entrega').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('taxa_de_entrega');
        });
    }
}
//# sourceMappingURL=1740063477502_create_add_field_taxa_in_venda_items_table.js.map