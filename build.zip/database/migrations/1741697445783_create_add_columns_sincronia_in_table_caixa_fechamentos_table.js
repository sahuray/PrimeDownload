import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'caixa_fechamento';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
            table.dropColumn('sync_prime');
        });
    }
}
//# sourceMappingURL=1741697445783_create_add_columns_sincronia_in_table_caixa_fechamentos_table.js.map