import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_comanda';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.text('comanda').notNullable();
            table.string('chip', 50).nullable();
            table.text('status');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1741283543605_create_create_comandas_table.js.map