import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_permissao';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.string('slug').unique();
            table.string('pagina');
            table.string('icon');
            table.boolean('index').defaultTo(false);
            table.string('name');
            table.string('description');
            table.boolean('por_grupo').defaultTo(false);
            table.boolean('internal_access').defaultTo(false);
            table.string('agrupamento_cor');
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1739208689157_create_create_table_prime_permissaos_table.js.map