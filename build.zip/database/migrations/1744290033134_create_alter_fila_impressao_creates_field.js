import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_fila_impressao';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_terminal').nullable().references('idterminal').inTable('terminal');
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_terminal');
        });
    }
}
//# sourceMappingURL=1744290033134_create_alter_fila_impressao_creates_field.js.map