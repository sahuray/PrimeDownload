import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_cliente';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_venda').unsigned().references('id').inTable('prime_venda');
            table.integer('id_empresa').unsigned().references('id').inTable('prime_empresa');
            table.boolean('sync_prime').defaultTo(false);
            table.text('nome_fantasia');
            table.text('razao_social');
            table.text('apelido');
            table.text('cnpj_cpf');
            table.text('ie_rg');
            table.text('im');
            table.text('email');
            table.text('telefone');
            table.text('codigo');
            table.enu('tipo', ['J', 'F']);
            table.enu('origem', ['C', 'F']);
            table.timestamp('aniversario');
            table.text('tipo_endereco');
            table.text('cep');
            table.text('uf');
            table.text('cidade');
            table.text('bairro');
            table.text('logradouro');
            table.text('numero');
            table.text('complemento');
            table.text('codigo_cidade');
            table.text('codigo_uf');
            table.text('referencia');
            table.text('contato_nome');
            table.text('contato_email');
            table.text('contato_telefone');
            table.text('contato_observacao');
            table.text('tipo_contato');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at');
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1738264258068_create_create_table_prime_venda_clientes_table.js.map