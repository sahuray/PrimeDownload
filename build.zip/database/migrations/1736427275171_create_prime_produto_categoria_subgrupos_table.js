import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_produto_categoria_subgrupo';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table.string('name');
            table
                .integer('id_produto_categoria_grupo')
                .unsigned()
                .references('id')
                .inTable('prime_produto_categoria_grupo');
            table.timestamp('created_at');
            table.timestamp('updated_at');
            table.timestamp('deleted_at').defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1736427275171_create_prime_produto_categoria_subgrupos_table.js.map