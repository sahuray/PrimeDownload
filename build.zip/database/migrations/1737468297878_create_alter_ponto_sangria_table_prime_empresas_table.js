import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_empresa';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.decimal('ponto_sangria', 16, 2).defaultTo(0).alter();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('ponto_sangria');
        });
    }
}
//# sourceMappingURL=1737468297878_create_alter_ponto_sangria_table_prime_empresas_table.js.map