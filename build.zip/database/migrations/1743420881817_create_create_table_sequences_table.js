import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'sequencia_numerica';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.text('nome');
            table.decimal('valor', 10, 0).defaultTo(0);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1743420881817_create_create_table_sequences_table.js.map