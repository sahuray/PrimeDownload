import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'terminal';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.integer('id_prime');
            table.text('id_visitor');
            table.boolean('liberar_editar_valor').defaultTo(false);
            table.boolean('solicitar_quantidade').defaultTo(false);
            table.boolean('deleted').defaultTo(false);
            table.boolean('nfce').defaultTo(false);
            table.boolean('tipo_impressao_sat_nfce').defaultTo(false);
            table.boolean('desativar_consulta_produto').defaultTo(false);
            table.boolean('exigir_senha_vendedor').defaultTo(false);
            table.boolean('solicitar_codigo_vendedor').defaultTo(false);
            table.boolean('tipos_de_impressao_escolha_impressora').defaultTo(false);
            table.boolean('pedir_obs_fechamento_orcamento').defaultTo(false);
            table.boolean('selecionar_impressora_orcamento').defaultTo(false);
            table.boolean('imprimir_itens_cupom_2_linhas').defaultTo(false);
            table.boolean('solicitar_confirmacao_do_valor_do_item').defaultTo(false);
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('id_prime');
            table.dropColumn('id_visitor');
            table.dropColumn('liberar_editar_valor');
            table.dropColumn('solicitar_quantidade');
            table.dropColumn('deleted');
            table.dropColumn('nfce');
            table.dropColumn('tipo_impressao_sat_nfce');
            table.dropColumn('desativar_consulta_produto');
            table.dropColumn('exigir_senha_vendedor');
            table.dropColumn('solicitar_codigo_vendedor');
            table.dropColumn('tipos_de_impressao_escolha_impressora');
            table.dropColumn('pedir_obs_fechamento_orcamento');
            table.dropColumn('selecionar_impressora_orcamento');
            table.dropColumn('imprimir_itens_cupom_2_linhas');
            table.dropColumn('solicitar_confirmacao_do_valor_do_item');
        });
    }
}
//# sourceMappingURL=1737477441972_create_add_columns_in_table_terminals_table.js.map