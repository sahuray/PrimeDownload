import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_venda_item_caracteristica';
    async up() {
        this.schema.createTable(this.tableName, (table) => {
            table.increments('id');
            table.integer('id_prime');
            table.boolean('sync_prime').defaultTo(false);
            table.integer('id_venda_item').unsigned().references('id').inTable('prime_venda_item');
            table
                .integer('id_produto_caracteristica')
                .unsigned()
                .references('id')
                .inTable('prime_produto_caracteristica');
            table.text('codigo');
            table.text('descricao');
            table.text('categoria');
            table.boolean('fixo').defaultTo(false);
            table.timestamp('created_at', { useTz: false });
            table.timestamp('updated_at', { useTz: false });
            table.timestamp('deleted_at', { useTz: false }).defaultTo(null);
        });
    }
    async down() {
        this.schema.dropTable(this.tableName);
    }
}
//# sourceMappingURL=1738696012741_create_prime_venda_item_caracteristica_table.js.map