import { BaseSchema } from '@adonisjs/lucid/schema';
export default class extends BaseSchema {
    tableName = 'prime_fila_ifood';
    async up() {
        this.schema.alterTable(this.tableName, (table) => {
            table.text('funcao').nullable();
        });
    }
    async down() {
        this.schema.alterTable(this.tableName, (table) => {
            table.dropColumn('funcao');
        });
    }
}
//# sourceMappingURL=1745946131821_create_add_fields_in_table_fila_ifoofs_table.js.map