import { BaseSchema } from '@adonisjs/lucid/schema';
import CaixaEntradaESaida from '#models/caixa_entrada_e_saida';
export default class extends BaseSchema {
    tableName = 'fill_field_type_in_table_caixa_entrada_e_saidas';
    async up() {
        await CaixaEntradaESaida.query().update({ tipo: 'SAIDA' });
    }
    async down() {
        await CaixaEntradaESaida.query().update({ tipo: null });
    }
}
//# sourceMappingURL=1744727381707_create_fill_field_type_in_table_caixa_entrada_e_saidas_table.js.map