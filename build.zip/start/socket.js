import { Server } from 'socket.io';
let io = null;
export function initializeSocket(httpServer) {
    io = new Server(httpServer, {
        cors: {
            origin: '*',
            methods: ['GET', 'POST'],
        },
        transports: ['websocket', 'polling'],
        pingTimeout: 60000,
        pingInterval: 25000,
    });
    const pdvConnections = new Map();
    io.on('connection', (socket) => {
        console.log('Nova conexão Socket.IO estabelecida');
        socket.on('pdv-register', (data) => {
            console.log(`PDV ${socket.id} registrado como ${data.isPrimary ? 'principal' : 'secundário'}`);
            pdvConnections.set(socket.id, {
                isPrimary: data.isPrimary,
                terminalId: data.terminalId,
            });
        });
        socket.on('print-request', (data) => {
            console.log(`Solicitação de impressão recebida do PDV ${socket.id}`);
            const primaryPdv = Array.from(pdvConnections.entries()).find(([_, info]) => info.isPrimary);
            if (primaryPdv) {
                console.log(`Encaminhando impressão para o PDV principal ${primaryPdv[0]}`);
                io?.to(primaryPdv[0]).emit('execute-print', data);
            }
            else {
                console.log('Nenhum PDV principal encontrado para processar a impressão');
            }
        });
        socket.on('disconnect', () => {
            console.log('PDV desconectado:', socket.id);
            pdvConnections.delete(socket.id);
        });
    });
    console.log('Servidor Socket.IO inicializado');
}
export default io;
//# sourceMappingURL=socket.js.map