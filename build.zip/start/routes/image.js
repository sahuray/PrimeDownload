import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.post('/', '#controllers/image_controller.create');
    router.get('/', '#controllers/image_controller.index');
    router.put('/:id', '#controllers/image_controller.update');
    router.delete('/:id', '#controllers/image_controller.delete');
})
    .prefix('/image');
//# sourceMappingURL=image.js.map