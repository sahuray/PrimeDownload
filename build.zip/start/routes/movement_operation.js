import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.get('/select', '#controllers/operacao_movimento_controller.select');
    router.post('/', '#controllers/operacao_movimento_controller.create');
})
    .prefix('/movement_operation');
//# sourceMappingURL=movement_operation.js.map