import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.get('/select/:id_product', '#controllers/produto_preco_controller.selectProductPrice');
})
    .prefix('/product_price');
//# sourceMappingURL=product_price.js.map