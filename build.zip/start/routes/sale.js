import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.get('/exist/:id_terminal', '#controllers/venda_pdv_controller.verifyExistSaleStatusProvisional');
    router.get('/status_provisional/:id_terminal', '#controllers/venda_pdv_controller.getSaleStatusProvisional');
    router.get('/movement_cash_desk/close/:id_movement_cash_desk', '#controllers/venda_pdv_controller.getAllSalesByIdMovementCashDesk');
    router.get('/status_provisional/only_client/:id_terminal', '#controllers/venda_pdv_controller.getSaleStatusProvisionalOnlyTheClient');
    router.get('/status_provisional/only_items/:id_terminal', '#controllers/venda_pdv_controller.getSaleStatusProvisionalOnlyTheItems');
    router.post('/seller', '#controllers/venda_pdv_controller.requestSeller');
    router.post('/register_seller', '#controllers/venda_pdv_controller.registerSellerInTheSale');
    router.post('/creation_in_progress', '#controllers/venda_pdv_controller.salesCreationInProgress');
    router.post('/finish/:id_sale/:id_cash_movement_desk', '#controllers/venda_pdv_controller.finishSale');
    router.post('/transform_budget/:id_sale', '#controllers/venda_pdv_controller.transformSaleIntoBudget');
    router.post('/transform_budget_for_sale/:id_sale', '#controllers/venda_pdv_controller.transformBudgetIntoSale');
    router.delete('/suspended/:id_sale', '#controllers/venda_pdv_controller.suspendedOrCancelSale');
    router.post('/create_sale_fiscal/:id_sale/:id_terminal', '#controllers/venda_pdv_controller.createSaleFiscal');
    router.put('/cancel_operation/:id_sale', '#controllers/venda_pdv_controller.cancelOperation');
    router.put('/update_sale_fiscal/:id_sale', '#controllers/venda_pdv_controller.updateSaleFiscal');
})
    .prefix('sale_pdv');
//# sourceMappingURL=sale.js.map