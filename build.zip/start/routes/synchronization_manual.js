import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.get('/get_table', '#controllers/sync_manual_controller.getTableSynchrony');
    router.get('/receive_rearguard', '#controllers/sync_manual_controller.syncManualGetDataAll');
    router.get('/receive_rearguard/company', '#controllers/sync_manual_controller.syncManualGetEmpresa');
    router.get('/receive_rearguard/user', '#controllers/sync_manual_controller.syncManualGetUsuarioAndFuncionarioAndPermissao');
    router.get('/receive_rearguard/bank_account', '#controllers/sync_manual_controller.syncManualGetContaBancaria');
    router.get('/receive_rearguard/terminal', '#controllers/sync_manual_controller.syncManualGetTerminal');
    router.get('/receive_rearguard/motoboy', '#controllers/sync_manual_controller.syncManualGetMotoboy');
    router.get('/receive_rearguard/payment_method', '#controllers/sync_manual_controller.syncManualGetFormaDePagamento');
    router.get('/receive_rearguard/marketing', '#controllers/sync_manual_controller.syncManualMercadologico');
    router.get('/receive_rearguard/product', '#controllers/sync_manual_controller.syncManualGetProduto');
    router.get('/receive_rearguard/command_and_prathos', '#controllers/sync_manual_controller.syncManualGetPrathosAndComanda');
    router.get('/receive_rearguard/blocked_customers', '#controllers/sync_manual_controller.syncManualGetClienteBloqueado');
    router.get('/send_rearguard', '#controllers/sync_manual_controller.syncManualSendDataAll');
    router.get('/send_rearguard/movement_cash_desk', '#controllers/sync_manual_controller.syncManualSendCaixaMovimento');
    router.get('/send_rearguard/company', '#controllers/sync_manual_controller.syncManualSendEmpresa');
    router.get('/send_rearguard/sale', '#controllers/sync_manual_controller.syncManualSendVenda');
    router.get('/send_rearguard/motoboy', '#controllers/sync_manual_controller.syncManualSendMotoboy');
})
    .prefix('sync_manual');
//# sourceMappingURL=synchronization_manual.js.map