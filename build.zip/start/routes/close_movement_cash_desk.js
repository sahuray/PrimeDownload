import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.post('/', '#controllers/caixa_fechamento_controller.create');
})
    .prefix('/movent-cash-desk');
//# sourceMappingURL=close_movement_cash_desk.js.map