import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.post('/delivery-simple', '#controllers/relatorio_controller.printDeliverySimpleReport');
    router.post('/delivery-detailed', '#controllers/relatorio_controller.printDeliveryDetailedReport');
})
    .prefix('/report');
//# sourceMappingURL=report.js.map