import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.post('/delivery-simple', '#controllers/relatorio_controller.printDeliverySimpleReport');
    router.post('/motoboy-report', '#controllers/relatorio_controller.getMotoboys');
    router.post('/motoboy-report-by-id', '#controllers/relatorio_controller.reportByMotoboy');
})
    .prefix('/report');
//# sourceMappingURL=report.js.map