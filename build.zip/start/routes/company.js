import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.get('/', '#controllers/empresa_controller.index');
    router.get('/pdv/filter', '#controllers/empresa_controller.filterClients');
    router.post('/create', '#controllers/empresa_controller.create');
    router.post('/create/pdv', '#controllers/empresa_controller.createByPdv');
    router.post('/select', '#controllers/empresa_controller.selectCliente');
    router.post('/update', '#controllers/empresa_controller.update');
    router.get('/delivery-config', '#controllers/empresa_controller.getDeliveryConfig');
    router.get('/ip-server-core', '#controllers/empresa_controller.getIpServerCore');
    router.get('/observacao-venda/:id', '#controllers/empresa_controller.getObservacaoVenda');
})
    .prefix('/company');
//# sourceMappingURL=company.js.map