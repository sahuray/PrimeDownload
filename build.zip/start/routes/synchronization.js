import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.get('/group', '#controllers/sync_controller.syncGroup');
    router.get('/company', '#controllers/sync_controller.syncCompany');
    router.get('/permission', '#controllers/sync_controller.syncPermission');
    router.get('/permission_user', '#controllers/sync_controller.syncPermissionUser');
    router.get('/address', '#controllers/sync_controller.syncAddress');
    router.get('/user', '#controllers/sync_controller.syncUser');
    router.get('/employee', '#controllers/sync_controller.syncEmployee');
    router.get('/bank', '#controllers/sync_controller.syncBank');
    router.get('/flag', '#controllers/sync_controller.syncFlag');
    router.get('/account_bank', '#controllers/sync_controller.syncBankAccount');
    router.get('/payment_method', '#controllers/sync_controller.syncPaymentsMethod');
    router.get('/payment_method_type', '#controllers/sync_controller.syncPaymentsMethodType');
    router.get('/payment_method_condition', '#controllers/sync_controller.syncPaymentsMethodCondition');
    router.get('/municipality', '#controllers/sync_controller.syncMunicipality');
    router.get('/product_category_sector', '#controllers/sync_controller.syncProdCategorySector');
    router.get('/product_category_group', '#controllers/sync_controller.syncProdCategoryGroup');
    router.get('/product_category_sub_group', '#controllers/sync_controller.syncProdCategorySubGroup');
    router.get('/product_category_line', '#controllers/sync_controller.syncProdCategoryLine');
    router.get('/brand', '#controllers/sync_controller.syncBrand');
    router.get('/product_unit', '#controllers/sync_controller.syncUnit');
    router.get('/product_nutricional_information', '#controllers/sync_controller.syncInformationNutritional');
    router.get('/product', '#controllers/sync_controller.syncProduct');
    router.get('/product_price', '#controllers/sync_controller.syncProductPrice');
    router.get('/product_serial_number', '#controllers/sync_controller.syncProductSerialNumber');
    router.get('/product_lot_expiration', '#controllers/sync_controller.syncProductLotExpiration');
    router.get('/product_inventory', '#controllers/sync_controller.syncProductInventory');
    router.get('/product_company', '#controllers/sync_controller.syncProductCompany');
    router.get('/product_composite', '#controllers/sync_controller.syncProductComposite');
    router.get('/product_compatible', '#controllers/sync_controller.syncProductCompatible');
    router.get('/barcode', '#controllers/sync_controller.syncProductBarcode');
    router.get('/product_characteristic', '#controllers/sync_controller.syncProductCharacteristic');
    router.get('/terminal', '#controllers/sync_controller.syncTerminal');
    router.get('/movement_cash_desk', '#controllers/sync_controller.syncMovementCashDesk');
    router.get('/delivery_fee', '#controllers/sync_controller.syncDeliveryFee');
    router.get('/motoboy', '#controllers/sync_controller.syncMotoboy');
    router.get('/setor', '#controllers/sync_controller.syncSetor');
    router.get('/mesa', '#controllers/sync_controller.syncMesa');
    router.get('/contact', '#controllers/sync_controller.syncContact');
    router.get('/upload', '#controllers/sync_controller.syncUpload');
    router.get('/company_command_setting', '#controllers/sync_controller.syncCompanyCommandSetting');
    router.get('/company_pdv_setting', '#controllers/sync_controller.syncCompanyPdvSetting');
    router.get('/company_delivery_setting', '#controllers/sync_controller.syncCompanyDeliverySetting');
    router.get('/company_prathos_setting', '#controllers/sync_controller.syncCompanyPrathosSetting');
    router.get('/comanda', '#controllers/sync_controller.syncComanda');
})
    .prefix('sync');
router
    .group(() => {
    router.get('/company', '#controllers/sync_core_controller.syncCoreCompany');
    router.get('/address', '#controllers/sync_core_controller.syncCoreAddress');
    router.get('/contact', '#controllers/sync_core_controller.syncCoreContact');
    router.get('/sale', '#controllers/sync_core_controller.syncCoreSale');
    router.get('/sale_item', '#controllers/sync_core_controller.syncCoreSaleItem');
    router.get('/sale_sub_item', '#controllers/sync_core_controller.syncCoreSaleSubItem');
    router.get('/sale_client', '#controllers/sync_core_controller.syncCoreSaleClient');
    router.get('/sale_nfce', '#controllers/sync_core_controller.syncCoreSaleNfce');
    router.get('/sale_payment_method', '#controllers/sync_core_controller.syncCoreSalePaymentMethod');
    router.get('/sale_term_payment', '#controllers/sync_core_controller.syncCoreSaleTermPayment');
    router.get('/sale_item_characteristic', '#controllers/sync_core_controller.syncCoreSaleItemCharacteristic');
    router.get('/sale_control_inventory', '#controllers/sync_core_controller.syncCoreSaleControlInventory');
    router.get('/motoboy', '#controllers/sync_core_controller.syncCoreMotoboy');
})
    .prefix('sync_core');
//# sourceMappingURL=synchronization.js.map