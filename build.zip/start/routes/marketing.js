import router from '@adonisjs/core/services/router';
router
    .group(() => {
    router.get('/sector', '#controllers/mercadologico_controller.indexSector');
})
    .prefix('/marketing');
//# sourceMappingURL=marketing.js.map