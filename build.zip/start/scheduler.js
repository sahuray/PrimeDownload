import SchedulerService from '#services/scheduler_service';
import CompanyJob from '#jobs/empresa_job';
import GrupoJob from '#jobs/grupo_job';
import FuncionarioUsuarioJob from '#jobs/funcionario_usuario_job';
import TerminalJob from '#jobs/terminal_job';
import MercadoLogicoJob from '#jobs/mercadologico_job';
import ContaBancariaJob from '#jobs/conta_bancaria_job';
import FormaDePagamentoJob from '#jobs/forma_de_pagamento_job';
import ProdutoJob from '#jobs/produto_job';
import FuncionarioJob from '#jobs/funcionario_job';
import AddressJob from '#jobs/endereco_job';
import DeliveryFeeJob from '#jobs/taxa_de_entrega_job';
import MotoboyJob from '#jobs/motoboy_job';
import SetorJob from '#jobs/setor_job';
import MesaJob from '#jobs/mesa_job';
import ContactJob from '#jobs/contato_job';
import UploadJob from '#jobs/upload_job';
import CompanySettingJob from '#jobs/empresa_configs_job';
import PermissionJob from '#jobs/permissao_job';
import DepartamentJob from '#jobs/departamento_job';
import ComandaJob from '#jobs/comanda_job';
import CompanyCoreJob from '#jobs/core_prime/empresa_core_job';
import AddressCoreJob from '#jobs/core_prime/endereco_core_job';
import ContactCoreJob from '#jobs/core_prime/contato_core_job';
import SaleCoreJob from '#jobs/core_prime/venda_core_job';
import MovementCashDeskCoreJob from '#jobs/core_prime/caixa_movimento_job';
import MovementOperationCoreJob from '#jobs/core_prime/movimento_operacao_job';
import MotoboyCoreJob from '#jobs/core_prime/motoboy_core_job';
import IpServerCoreJob from '#jobs/ip_server_core_job';
const scheduler = new SchedulerService();
const jobsInit = [
    { key: 'grupo-job', job: new GrupoJob(), dependsOn: [] },
    { key: 'company-job', job: new CompanyJob(), dependsOn: ['grupo-job'] },
    {
        key: 'funcionario-usuario-job',
        job: new FuncionarioUsuarioJob(),
        dependsOn: ['company-job', 'funcionario-job'],
    },
    { key: 'funcionario-job', job: new FuncionarioJob(), dependsOn: ['company-job'] },
    { key: 'address-job', job: new AddressJob(), dependsOn: ['company-job'] },
    { key: 'contact-job', job: new ContactJob(), dependsOn: ['company-job'] },
    { key: 'conta-bancaria-job', job: new ContaBancariaJob(), dependsOn: ['company-job'] },
    { key: 'delivery-fee-job', job: new DeliveryFeeJob(), dependsOn: ['grupo-job'] },
    { key: 'company-setting-job', job: new CompanySettingJob(), dependsOn: ['company-job'] },
    {
        key: 'forma-de-pagamento-job',
        job: new FormaDePagamentoJob(),
        dependsOn: ['company-job', 'conta-bancaria-job'],
    },
    { key: 'produto-job', job: new ProdutoJob(), dependsOn: ['grupo-job', 'company-job'] },
    {
        key: 'permission-job',
        job: new PermissionJob(),
        dependsOn: ['grupo-job', 'company-job', 'funcionario-usuario-job'],
    },
    { key: 'upload-job', job: new UploadJob(), dependsOn: [] },
    { key: 'mercadologico-job', job: new MercadoLogicoJob(), dependsOn: ['grupo-job'] },
    { key: 'company-core-job', job: new CompanyCoreJob(), dependsOn: [] },
    { key: 'movement-cash-desk-core-job', job: new MovementCashDeskCoreJob(), dependsOn: [] },
    { key: 'address-core-job', job: new AddressCoreJob(), dependsOn: ['company-job'] },
    { key: 'contact-core-job', job: new ContactCoreJob(), dependsOn: ['company-job'] },
    { key: 'motoboy-core-job', job: new MotoboyCoreJob(), dependsOn: ['company-job'] },
    {
        key: 'sale-core-job',
        job: new SaleCoreJob(),
        dependsOn: ['grupo-job', 'company-job', 'produto-job'],
    },
    { key: 'movement-operation-core-job', job: new MovementOperationCoreJob(), dependsOn: [] },
    { key: 'terminal-job', job: new TerminalJob(), dependsOn: ['company-job'] },
    { key: 'departament-job', job: new DepartamentJob(), dependsOn: [] },
    { key: 'motoboy-job', job: new MotoboyJob(), dependsOn: [] },
    { key: 'setor-job', job: new SetorJob(), dependsOn: [] },
    { key: 'mesa-job', job: new MesaJob(), dependsOn: ['setor-job'] },
    { key: 'comanda-job', job: new ComandaJob(), dependsOn: ['company-job'] },
    { key: 'ip-server-core-job', job: new IpServerCoreJob(), dependsOn: [] },
];
async function executeJobs(jobs) {
    const completedJobs = new Set();
    while (jobs.length > 0) {
        const readyJobs = jobs.filter((job) => job.dependsOn.every((dep) => completedJobs.has(dep)));
        if (readyJobs.length === 0) {
            console.error('ERRO: Dependências circulares ou job não encontrado. Jobs pendentes:', jobs.map((j) => j.key));
            jobs = [];
        }
        await Promise.allSettled(readyJobs.map(async (job) => {
            await job.job.run();
            completedJobs.add(job.key);
        }));
        jobs = jobs.filter((job) => !completedJobs.has(job.key));
    }
}
async function initializeJobs() {
    await executeJobs(jobsInit);
    const jobs = [
        { key: 'funcionario-usuario-job', job: new FuncionarioUsuarioJob(), cron: '*/5 * * * *' },
        { key: 'company-job', job: new CompanyJob(), cron: '0 0 * * *' },
        { key: 'funcionario-job', job: new FuncionarioJob(), cron: '*/5 * * * *' },
        { key: 'contact-job', job: new ContactJob(), cron: '*/5 * * * *' },
        { key: 'terminal-job', job: new TerminalJob(), cron: '*/5 * * * *' },
        { key: 'mercadologico-job', job: new MercadoLogicoJob(), cron: '*/5 * * * *' },
        { key: 'conta-bancaria-job', job: new ContaBancariaJob(), cron: '*/5 * * * *' },
        { key: 'forma-de-pagamento-job', job: new FormaDePagamentoJob(), cron: '*/5 * * * *' },
        { key: 'produto-job', job: new ProdutoJob(), cron: '*/5 * * * *' },
        { key: 'address-job', job: new AddressJob(), cron: '*/5 * * * *' },
        { key: 'delivery-fee-job', job: new DeliveryFeeJob(), cron: '*/5 * * * *' },
        { key: 'motoboy-job', job: new MotoboyJob(), cron: '*/5 * * * *' },
        { key: 'setor-job', job: new SetorJob(), cron: '*/5 * * * *' },
        { key: 'mesa-job', job: new MesaJob(), cron: '*/5 * * * *' },
        { key: 'upload-job', job: new UploadJob(), cron: '*/5 * * * *' },
        { key: 'company-setting-job', job: new CompanySettingJob(), cron: '*/5 * * * *' },
        { key: 'permission-job', job: new PermissionJob(), cron: '*/5 * * * *' },
        { key: 'departament-job', job: new DepartamentJob(), cron: '*/5 * * * *' },
        { key: 'comanda-job', job: new ComandaJob(), cron: '*/5 * * * *' },
        { key: 'company-core-job', job: new CompanyCoreJob(), cron: '*/5 * * * *' },
        { key: 'address-core-job', job: new AddressCoreJob(), cron: '*/5 * * * *' },
        { key: 'contact-core-job', job: new ContactCoreJob(), cron: '*/5 * * * *' },
        { key: 'sale-core-job', job: new SaleCoreJob(), cron: '*/5 * * * *' },
        { key: 'movement-cash-desk-core-job', job: new MovementCashDeskCoreJob(), cron: '*/5 * * * *' },
        { key: 'motoboy-core-job', job: new MotoboyCoreJob(), cron: '*/5 * * * *' },
    ];
    jobs.forEach(({ key, job, cron }) => {
        scheduler.addJob({
            key,
            cronExpression: cron,
            job,
        });
    });
    scheduler.scheduleAllJobs();
}
initializeJobs().catch(console.error);
//# sourceMappingURL=scheduler.js.map