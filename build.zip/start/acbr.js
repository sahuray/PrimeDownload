import { WebSocketServer } from 'ws';
import net from 'node:net';
function startAcbrServer() {
    const TCP_HOST = process.env.ACBR_HOST;
    const TCP_PORT = 3434;
    const WS_PORT = 3435;
    const ACTIVE = process.env.ACBR_ACTIVE === 'true';
    if (!ACTIVE) {
        console.log('Servidor ACBR desativado');
        return;
    }
    const wss = new WebSocketServer({ port: WS_PORT });
    wss.on('connection', (ws) => {
        const tcpSocket = new net.Socket();
        tcpSocket.connect(TCP_PORT, TCP_HOST || 'localhost', () => {
            console.log('Conectado ao servidor ACBR');
        });
        tcpSocket.on('error', (error) => {
            console.log(error.message);
            if (error.message === 'read ECONNRESET') {
                console.error('Erro ECONNRESET:', error.message);
            }
            else {
                ws.close();
                console.error('Erro no socket TCP:', error.message);
            }
        });
        tcpSocket.on('data', (data) => {
            try {
                ws.send(data.toString());
            }
            catch (error) {
                console.error('Erro ao enviar dados para WebSocket:', error.message);
            }
        });
        ws.on('message', (message) => {
            try {
                console.log('Mensagem recebida:', message.toString());
                tcpSocket.write(message.toString());
            }
            catch (error) {
                console.error('Erro ao processar mensagem:', error.message);
            }
        });
        ws.on('error', (error) => {
            console.error('Erro no WebSocket:', error.message);
            tcpSocket.end();
        });
        ws.on('close', () => {
            console.log('Conexão com o WebSocket encerrada');
            tcpSocket.end();
        });
        tcpSocket.on('close', () => {
            ws.close();
        });
    });
    wss.on('error', (error) => {
        console.error('Erro no servidor WebSocket:', error.message);
    });
    console.log(`Servidor WebSocket rodando em ws://localhost:${WS_PORT}`);
}
process.on('uncaughtException', (error) => {
    console.error('Erro não tratado:', error.message);
});
startAcbrServer();
//# sourceMappingURL=acbr.js.map