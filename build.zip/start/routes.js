import router from '@adonisjs/core/services/router';
import os from 'node:os';
import './routes/synchronization.js';
import './routes/sale.js';
import './routes/company.js';
import './routes/product_price.js';
import './routes/marketing.js';
import './routes/close_movement_cash_desk.js';
router.get('/health', async () => {
    return {
        status: 'ok',
    };
});
router.get('/verificar-senha', '#controllers/login_controller.loginPedhos');
router.get('/hostname', async () => {
    return {
        hostname: os.hostname(),
    };
});
router.post('/login', '#controllers/login_controller.login');
router.post('/caixa-entrada', '#controllers/caixa_entrada_controller.create');
router.post('/caixa-movimento', '#controllers/caixa_movimento_controller.create');
router.get('/caixa-movimento/:idterminal/:idfuncionariousuarioabertura', '#controllers/caixa_movimento_controller.show');
router.put('/caixa-movimento/:idcaixamovimento', '#controllers/caixa_movimento_controller.update');
router
    .group(() => {
    router.get('/select', '#controllers/forma_de_pagamento_controller.selectPaymentMethodByType');
    router.get('/select/type', '#controllers/forma_de_pagamento_controller.selectTypePaymentIfPaymentMethodExists');
    router.get('/condition', '#controllers/forma_de_pagamento_controller.indexCondition');
})
    .prefix('/payment_method');
router
    .group(() => {
    router.get('/:cep', '#controllers/cep_controller.searchCep');
})
    .prefix('cep');
router
    .group(() => {
    router.post('/select-address-company', '#controllers/endereco_controller.selectAddressCompany');
    router.post('/create-address-company', '#controllers/endereco_controller.createAddressCompany');
    router.post('/destroy-address-company', '#controllers/endereco_controller.destroyAddressCompany');
    router.post('/update-address-company', '#controllers/endereco_controller.updateAddressCompany');
})
    .prefix('address');
router
    .group(() => {
    router.get('/filter', '#controllers/municipio_controller.searchMunicipality');
})
    .prefix('municipality');
router
    .group(() => {
    router.post('/select-contact-company', '#controllers/contato_controller.selectContactCompany');
    router.post('/create-contact-company', '#controllers/contato_controller.createContactCompany');
    router.post('/destroy-contact-company', '#controllers/contato_controller.destroyContactCompany');
    router.post('/update-contact-company', '#controllers/contato_controller.updateContactCompany');
})
    .prefix('contact');
router
    .group(() => {
    router.post('/index', '#controllers/taxa_de_entregas_controller.index');
})
    .prefix('delivery-fee');
router
    .group(() => {
    router.post('/index', '#controllers/motoboy_controller.index');
    router.post('/create-and-update', '#controllers/motoboy_controller.createAndUpdate');
})
    .prefix('motoboy');
router
    .group(() => {
    router.get('/index', '#controllers/mesa_controller.index');
    router.get('/find-funcionario/:id', '#controllers/mesa_controller.findFuncionario');
    router.post('/open-mesa', '#controllers/mesa_controller.openMesa');
    router.put('/update-mesa-items', '#controllers/mesa_controller.updateMesaItems');
    router.post('/set-idle-time', '#controllers/mesa_controller.setIdleTime');
    router.get('/find-mesa/:numeroMesa', '#controllers/mesa_controller.findMesa');
    router.get('/filter-mesa-by-setor/:idSetor', '#controllers/mesa_controller.filterMesaBySetor');
    router.get('/index-status-mesa', '#controllers/mesa_controller.indexStatusMesa');
})
    .prefix('mesa');
router
    .group(() => {
    router.get('/select_by_sector', '#controllers/produto_controller.selectProductBySector');
    router.post('/index', '#controllers/produto_controller.index');
    router.post('/select', '#controllers/produto_controller.selectProduct');
    router.post('/find', '#controllers/produto_controller.findProduct');
})
    .prefix('product');
router
    .group(() => {
    router.post('/select', '#controllers/produto_caracteristica_controller.selectProductCharacteristic');
})
    .prefix('product-characteristic');
router
    .group(() => {
    router.get('/get-sale', '#controllers/venda_delivery_controller.getSale');
    router.get('/get-sale-observation/:id', '#controllers/venda_delivery_controller.getSaleObservation');
    router.post('/get-order', '#controllers/venda_delivery_controller.getOrder');
    router.post('/select', '#controllers/venda_delivery_controller.selectSale');
    router.post('/sales-creation-in-progress', '#controllers/venda_delivery_controller.salesCreationInProgress');
    router.get('/get-sale-item/:id', '#controllers/venda_delivery_controller.getSaleItem');
    router.post('/create-sale-item', '#controllers/venda_delivery_controller.createSaleItem');
    router.delete('/delete-sale-item/:id', '#controllers/venda_delivery_controller.deleteSaleItem');
    router.delete('/delete-sale/:id', '#controllers/venda_delivery_controller.deleteSale');
    router.put('/sale-item/:id/characteristics', '#controllers/venda_delivery_controller.updateCharacteristics');
    router.put('/caracteristicas/:id', '#controllers/venda_delivery_controller.updateCharacteristics');
    router.put('/finalize-order/:id', '#controllers/venda_delivery_controller.finalizeOrder');
    router.put('/update-sale/:id', '#controllers/venda_delivery_controller.updateSale');
    router.put('/update-order/:id', '#controllers/venda_delivery_controller.updateOrder');
    router.post('/get-sale-core', '#controllers/venda_delivery_controller.getSaleCore');
})
    .prefix('sale');
router
    .group(() => {
    router.get('/', '#controllers/terminal_controller.index');
    router.post('/', '#controllers/terminal_controller.store');
    router.get('/:id', '#controllers/terminal_controller.show');
    router.put('/:id', '#controllers/terminal_controller.update');
    router.delete('/:id', '#controllers/terminal_controller.destroy');
})
    .prefix('terminal');
router.post('/caixa-movimento-saida', '#controllers/caixa_movimento_saida_controller.store');
router.get('/caixa-movimento-saida/:idcaixamovimento', '#controllers/caixa_movimento_saida_controller.index');
router.get('/caixa-movimento-saida-especie-saida', '#controllers/caixa_movimento_saida_controller.especieSaida');
router
    .group(() => {
    router.post('/', '#controllers/impressora_configuracao_controller.createOrUpdatePrinter');
    router.delete('/:id', '#controllers/impressora_configuracao_controller.deletePrinter');
})
    .prefix('impressora');
router
    .group(() => {
    router.get('/', '#controllers/impressora_configuracao_controller.getPrinterConfig');
    router.post('/', '#controllers/impressora_configuracao_controller.createOrUpdatePrinterConfig');
})
    .prefix('impressora-configuracao');
router
    .group(() => {
    router.post('/assign-items', '#controllers/comanda_controller.assignItemsComanda');
    router.post('/bring-items', '#controllers/comanda_controller.bringItemsFromComandaToSale');
    router.put('/update-status/:id', '#controllers/comanda_controller.updateComandaStatus');
    router.get('/comandas-abertas', '#controllers/comanda_controller.getComandasAbertas');
    router.get('/items', '#controllers/comanda_controller.getItems');
    router.get('/items/comanda/:id', '#controllers/comanda_controller.getItemsComanda');
    router.get('/total-parcial/:comanda', '#controllers/comanda_controller.getTotalValueComanda');
    router.get('/:comanda', '#controllers/comanda_controller.getComanda');
})
    .prefix('comandas');
//# sourceMappingURL=routes.js.map